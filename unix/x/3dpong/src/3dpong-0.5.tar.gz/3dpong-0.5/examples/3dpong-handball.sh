#!/bin/sh

# Example script to launch a 1-player (handball) game of 3dpong on the
# current X-Window display

# By Bill Kendrick; 1997-2004

3dpong $DISPLAY -g 1 $*

