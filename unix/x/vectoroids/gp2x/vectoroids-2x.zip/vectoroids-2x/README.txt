README.txt for "Vectoroids"

(Based on "Agendaroids")

by Bill Kendrick
bill@newbreedsoftware.com
http://www.newbreedsoftware.com/vectoroids/

Ported by IceOnly 05.01.06
______________________________________________

Installation:
-----------
- vectoroids.gpe zusammen mit dem data verzeichnis auf die sd kopieren (egal wohin).

Steuerung:
----------

Im Menu:
[select] Programm beenden
[a] neues Spiel
[x] Spiel fortsetzen

Im Spiel:
[select] Menu aufrufen
[A],[B],[X],[Y] Schiessen
[R],[L],[HOCH] Schub
[LINKS] links drehen
[RECHTS] rechts drehen
[STICK_TASTE] neues Schiff benutzen (nachdem man ein leben verloren hat)


Bekannte Fehler:
----------------
Sound geht noch nicht