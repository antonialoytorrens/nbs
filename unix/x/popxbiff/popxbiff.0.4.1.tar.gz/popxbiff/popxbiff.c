/*
  popxbiff.c
  
  version 0.4.1
  
  by Bill Kendrick
  nbs@sonic.net
  http://www.newbreedsoftware.com/
  
  0.4 - 0.4.1: SHIFT-Key patch by Steven Lass <steve@syl.dl.nec.com>
  
  September 10, 1998 - January 22, 1999
*/


/* #define DEBUG */

#define COMPLAIN 0
#define QUIET 1

#define SUBMIT "- OK -"


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <fcntl.h>
#include <errno.h>
#include <pwd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include "hints.h"
#include "visual.h"
#include "text.h"


/* Prototypes: */

void usage(char * progname, int ret);
Window OpenWindow(Display *display, Window parent, int x, int y, int width,
                  int height, unsigned long bordercolor, 
                  unsigned long backcolor, unsigned long event_mask,
                  Visual *visual);
GC CreateGC(Display *display, Drawable drawable, unsigned long forecolor,
            unsigned long backcolor);
unsigned long AllocNamedColor(Display *display, Colormap colormap,
                              char* colorname, unsigned long default_color);
int SetUpColormap(Display *display, int screen, Window window, Visual *visual,
                  Colormap *colormap);
int socketreadline(int s, char * buf, int quiet);
void socketprint(int s, char * str);


/* --- popxbiff: Main: --- */

int main(int argc, char * argv[])
{
  char server[1024], bgcolor[1024], fgcolor[1024], display[1024], temp[1024],
    temp2[1024], username[1024], password[1024], str[1024], flagupfile[1024],
    flagdownfile[1024], passwordfile[1024], try_server[1024], try_name[1024],
    aufile[1024];
  int i, port, width, height, x, y, volume, rv, done, done_it_once,
    how_much_mail, how_much_mail_before, s, n, c, len, cntl, redraw, flagup,
    whichgc, pwwidth, pwheight, submitbuttonwidth, inputfieldwidth, key,
    pwx, pwy, neterror, quit, hwidth, hheight, hx, hy, topmesg, in_window,
    showing_info, nodisplay;
  char froms[10][1024], subjects[10][1024];
  long update, last_update;
  GC gc[2];
  GC blackgc, whitegc;
  XFontStruct * font;
  Display * disp;
  int screen, black, white, temp_depth, xhot, yhot, fh;
  Window rootwindow, window, pwwindow, hwindow;
  Pixmap flags[2];
  int widths[2], heights[2];
  Colormap colormap;
  Visual * temp_visual;
  XEvent event;
  struct timeval now, then, enter_time;
  struct hostent * hp;
  struct sockaddr_in name;
  KeySym keysym;
  XComposeStatus composestatus;
  static Atom wm_delete_window, wm_delete_hwindow, wm_resize_hwindow;
  FILE * fi, * fo;
  
  
  /* Set default values: */
  
  /* (Default display:) */
  if (getenv("DISPLAY") == NULL)
    strcpy(display, ":0.0");
  else
    strcpy(display, getenv("DISPLAY"));
  nodisplay = 0;
  
  /* (Default geometry:) */
  width = 45;
  height = 45;
  x = 5;
  y = 5;
  
  /* (Default volume/sound:) */
  volume = 50;
  strcpy(aufile, "");
  
  /* (Default colors:) */
  strcpy(bgcolor, "white");
  strcpy(fgcolor, "black");
  rv = 0;
  
  /* (Default bitmaps:) */
  sprintf(flagupfile, "%s/flagup.xbm", BITMAPDIR);
  sprintf(flagdownfile, "%s/flagdown.xbm", BITMAPDIR);
  
  /* (Default host and port:) */
  strcpy(server, "localhost");
  port = 110;
  
  /* (Default username/password/passwordfile:) */
  if (getenv("LOGNAME") != NULL)
    strcpy(username, getenv("LOGNAME"));
  else
    strcpy(username, "");
  strcpy(password, "");
  strcpy(passwordfile, "");
  
  /* (Default update time:) */
  update = 300;
  
  
  /* Get command line arguments: */
  
  for (i = 1; i < argc; i++)
    {
      if (strcmp(argv[i], "-help") == 0 || strcmp(argv[i], "-h") == 0 ||
	  strcmp(argv[i], "--help") == 0)
	{
	  /* Display help/usage: */
	  
	  usage(argv[0], 0);
	}
      else if (strcmp(argv[i], "-version") == 0 ||
	       strcmp(argv[i], "-v") == 0 ||
	       strcmp(argv[i], "--version") == 0)
	{
	  /* Display version: */
	  
	  printf("\n%s: popxbiff version 0.4 - October 7, 1998\n\n", argv[0]);
	  exit(0);
	}
      else if (strcmp(argv[i], "-display") == 0 && i < argc - 1)
	{
	  /* Get display: */
	  
	  strcpy(display, argv[i + 1]);
	  i++;
	}
      else if (strcmp(argv[i], "-nodisplay") == 0)
	{
	  /* Don't use X?: */
	  
	  nodisplay = 1;
	}
      else if (strcmp(argv[i], "-au") == 0 && i < argc - 1)
	{
	  /* Get AU file: */
	  
	  strcpy(aufile, argv[i + 1]);
	  i++;
	}
      else if (strcmp(argv[i], "-passwordfile") == 0 && i < argc - 1)
	{
	  /* Get passwordfile: */
	  
	  strcpy(passwordfile, argv[i + 1]);
	  i++;
	}
      else if (strcmp(argv[i], "-geometry") == 0 && i < argc - 1)
	{
	  /* Get geometry (WxH+X+Y): */
	  
	  strcpy(temp, argv[i + 1]);
	  
	  width = atoi(temp);
	  
	  if (strchr(temp, 'x') != NULL)
	    height = atoi(strchr(temp, 'x') + 1);
	  
	  if (strchr(temp, '+') != NULL)
	    {
	      x = atoi(strchr(temp, '+') + 1);
	      
	      if (strchr(strchr(temp, '+') + 1, '+') != NULL)
		y = atoi(strchr(strchr(temp, '+') + 1, '+') + 1);
	    }
	  
	  i++;
	}
      else if (strcmp(argv[i], "-server") == 0 && i < argc - 1)
	{
	  /* Get POP server: */
	  
	  strcpy(server, argv[i + 1]);
	  i++;
	}
      else if (strcmp(argv[i], "-user") == 0 && i < argc - 1)
	{
	  /* Get username: */
	  
	  strcpy(username, argv[i + 1]);
	  i++;
	}
      else if (strcmp(argv[i], "-port") == 0 && i < argc - 1)
	{
	  /* Get POP port: */
	  
	  port = atoi(argv[i + 1]);
	  i++;
	}
      else if (strcmp(argv[i], "-update") == 0 && i < argc - 1)
	{
	  /* Get update time: */
	  
	  update = atoi(argv[i + 1]);
	  i++;
	}
      else if (strcmp(argv[i], "-volume") == 0 && i < argc - 1)
	{
	  /* Get volume: */
	  
	  volume = atoi(argv[i + 1]);
	  i++;
	}
      else if (strcmp(argv[i], "-bg") == 0 && i < argc - 1)
	{
	  /* Get background color name: */
	  
	  strcpy(bgcolor, argv[i + 1]);
	  i++;
	}
      else if (strcmp(argv[i], "-fg") == 0 && i < argc - 1)
	{
	  /* Get foreground color name: */
	  
	  strcpy(fgcolor, argv[i + 1]);
	  i++;
	}
      else if (strcmp(argv[i], "-flagup") == 0 && i < argc - 1)
	{
	  /* Get flagup bitmap name: */
	  
	  strcpy(flagupfile, argv[i + 1]);
	  i++;
	}
      else if (strcmp(argv[i], "-flagdown") == 0 && i < argc - 1)
	{
	  /* Get flagdown bitmap name: */
	  
	  strcpy(flagdownfile, argv[i + 1]);
	  i++;
	}
      else if (strcmp(argv[i], "-rv") == 0)
	{
	  /* Set reverse-video: */
	  
	  rv = 1;
	}
      else
	{
	  /* Oops!  I don't get it!  Usage! */
	  
	  fprintf(stderr, "%s: Unknown or bad option: %s\n", argv[0], argv[i]);
	  
	  usage(argv[0], 1);
	}
    }
  
  
  /* Make sure we have a username! */
  
  if (strlen(username) == 0)
    {
      fprintf(stderr,
	      "%s: Can't determine username, please supply it with '-user'\n",
	      argv[0]);
      exit(1);
    }
  
  
  /* Try to connect to display: */
  
  if (nodisplay == 0)
    {
      disp = XOpenDisplay(display);
      if (disp == NULL)
	{
	  fprintf(stderr, "%s: Cannot connect to display: %s\n", argv[0],
		  display);
	  fprintf(stderr, "Use -nodisplay to run in text mode.\n");
	  exit(1);
	}
      
      screen = DefaultScreen(disp);
      rootwindow = RootWindow(disp, screen);
      
      
      /* Get primitve colors: */
      
      black = BlackPixel(disp, screen);
      white = WhitePixel(disp, screen);
      
      
      /* Load font: */
      
      font = LoadFont(disp, "variable", "fixed");
      fh = FontHeight(font);
      
      
      /* Open the window: */
      
      window = OpenWindow(disp, rootwindow, x, y, width, height,
			  CopyFromParent, white,
			  (ExposureMask | ButtonPressMask |
			   StructureNotifyMask | PropertyChangeMask |
			   KeyPressMask | EnterWindowMask | LeaveWindowMask),
			  (Visual *)CopyFromParent);
      
      sprintf(temp, "popxbiff - %s on %s", username, server);
      SetStandardHints(disp, window, "popxbiff", temp, x, y,
		       width, height);
      
      wm_delete_window = XInternAtom(disp, "WM_DELETE_WINDOW", False);
      XSetWMProtocols(disp, window, &wm_delete_window, 1);
      
      
      /* Set up visual: */
      
      if (SetUpVisual(disp, screen, &temp_visual, &temp_depth))
	{
	  if (!SetUpColormap(disp, screen, window,
			     temp_visual, &colormap))
	    {
	      fprintf(stderr, "%s: Could not create a colormap!\n", argv[0]);
	      exit(1);
	    }
	}
      else
	{
	  fprintf(stderr, "%s: Could not find a PseudoColor visual!\n",
		  argv[0]);
	  exit(1);
	}
      
      
      /* Get colors: */
      
      whitegc = CreateGC(disp, rootwindow, white, white);
      blackgc = CreateGC(disp, rootwindow, black, black);
      
      gc[0] = CreateGC(disp, rootwindow,
		       AllocNamedColor(disp, colormap, fgcolor,
				       (unsigned long) black),
		       AllocNamedColor(disp, colormap, bgcolor,
				       (unsigned long) white));
      
      
      gc[1] = CreateGC(disp, rootwindow,
		       AllocNamedColor(disp, colormap, bgcolor,
				       (unsigned long) white),
		       AllocNamedColor(disp, colormap, fgcolor,
				       (unsigned long) black));
      
      
      /* Load bitmaps: */
      
      if (XReadBitmapFile(disp, window, flagdownfile,
			  &widths[0], &heights[0],
			  &flags[0], &xhot, &yhot) != BitmapSuccess)
	{
	  fprintf(stderr, "%s: Error opening bitmap: %s\n",
		  argv[0], flagdownfile);
	  exit(1);
	}
      
      if (XReadBitmapFile(disp, window, flagupfile,
			  &widths[1], &heights[1],
			  &flags[1], &xhot, &yhot) != BitmapSuccess)
	{
	  fprintf(stderr, "%s: Error opening bitmap: %s\n",
		  argv[0], flagupfile);
	  exit(1);
	}
      
      
      /* Bring window up: */
      
      XMapWindow(disp, window);
      XMapRaised(disp, window);
      XFlush(disp);
      sleep(1);
    }
  
  
  /* Get remote host information: */
  
  fprintf(stderr, "%s: Looking up host: %s...\n", argv[0], server);
  
  hp = gethostbyname(server);
  
  if (hp == NULL)
    {
      fprintf(stderr, "%s: Unknown host: %s\n", argv[0], server);
      exit(1);
    }
  
  
  /* Show that we're looking up host: */
  
  if (nodisplay == 0)
    {
      /* (Blank:) */
      XFillRectangle(disp, window, gc[1 - rv],
		     0, 0, width, height);
      
      /* (Note:) */	
      drawtext(disp, window, gc[rv], 3, fh,
	       server);
      drawtext(disp, window, gc[rv], 3, fh * 2,
	       "Lookup");
      
      XFlush(disp);
    }
  
  
  /* MAIN LOOP: */
  
  quit = 0;
  
  done_it_once = 0;
  redraw = 1;
  flagup = 0;
  in_window = 0;
  showing_info = 0;
  how_much_mail_before = 0;
  
  gettimeofday(&then, NULL);
  last_update = then.tv_sec;
  
  do
    {
      /* Check for events: */
      
      if (nodisplay == 0)
	{
	  if (XPending(disp))
	    {
	      XNextEvent(disp, &event);
	      
	      if (event.type == ButtonPress)
		{
		  /* Button - clear flag and redraw: */
		  
		  flagup = 0;
		  redraw = 1;
		  
		  
		  /* If it's Button-3, then show message info: */
		  
		  if (event.xbutton.button == Button3)
		    {
		      if (how_much_mail == 0)
			{
			  /* Complain if there's no mail to see headers for: */
			  
			  XBell(disp, 25);
			}
		      else
			{
			  /* Determine geometry for headers window: */
			  
			  hwidth = XTextWidth(font, "*", 1) * 80;
			  
			  if (how_much_mail <= 10)
			    hheight = fh * how_much_mail + 3;
			  else
			    hheight = fh * 11 + 3;
			  
			  /* (Position window in center of display:) */
			  hx = (DisplayWidth(disp, screen) - hwidth) / 2;
			  hy = (DisplayHeight(disp, screen) - hheight) / 2;
			  
			  
			  /* Open the password window: */
			  
			  hwindow = OpenWindow(disp, rootwindow, hx, hy,
					       hwidth, hheight,
					       CopyFromParent, white,
					       (ExposureMask |
						ButtonPressMask |
						StructureNotifyMask |
						PropertyChangeMask),
					       (Visual *)CopyFromParent);
			  
			  SetStandardHints(disp, hwindow, "popxbiff-headers",
					   "popxbiff - headers",
					   hx, hy, hwidth, hheight);
			  
			  wm_delete_hwindow = XInternAtom(disp,
							  "WM_DELETE_WINDOW",
							  False);
			  XSetWMProtocols(disp, hwindow,
					  &wm_delete_hwindow, 1);
			  
			  wm_resize_hwindow = XInternAtom(disp,
							  "WM_RESIZE_WINDOW",
							  False);
			  XSetWMProtocols(disp, hwindow,
					  &wm_resize_hwindow, 1);
			  
			  
			  /* Bring window up: */
			  
			  XMapWindow(disp, hwindow);
			  XMapRaised(disp, hwindow);
			  XFlush(disp);
			  
			  
			  /* Headers loop: */
			  
			  topmesg = 0;
			  done = 0;
			  
			  do
			    {
			      usleep(10000);
			      
			      
			      if (XPending(disp))
				{
				  XNextEvent(disp, &event);
				  
				  if (event.type == ButtonPress)
				    {
				      /* Buttons in either window close me: */
				      
				      done = 1;
				    }
				  else if (event.type == ClientMessage)
				    {
				      /* Delete in either window closes me: */
				      
				      done = 1;
				      
				      
				      /* Delete in main window quits: */
				      
				      if (event.xclient.window == window)
					quit = 1;
				    }
				  else
				    {
				      /* All others, we'll redraw: */
				      
				      redraw = 1;
				    }
				}
			      
			      if (redraw == 1)
				{
				  redraw = 0;
				  
				  
				  /* Clear window: */
				  
				  XFillRectangle(disp, hwindow, gc[1], 0, 0,
						 hwidth, hheight);
				  
				  
				  /* Draw each line: */
				  
				  for (i = topmesg;
				       i < topmesg + 10 && i < how_much_mail;
				       i++)
				    {
				      sprintf(temp, "%-18s: %-60s",
					      froms[i], subjects[i]);
				      
				      drawtext(disp, hwindow, gc[0],
					       1, fh * (1 + i - topmesg),
					       temp);
				    }
				  
				  if (how_much_mail > 10)
				    {
				      drawtext(disp, hwindow, gc[0],
					       hwidth / 2 - 5, fh * 11, "...");
				    }
				  
				  XFlush(disp);
				}
			    }
			  while (done == 0);
			  
			  
			  /* Close the headers window: */
			  
			  XUnmapWindow(disp, hwindow);
			  XDestroyWindow(disp, hwindow);
			  XFlush(disp);
			}
		    }
		}
	      else if (event.type == KeyPress)
		{
		  /* Keypress - do key command: */
		  
		  XLookupString(&event.xkey, temp, 1, &keysym,
				&composestatus);
		  
		  key = toupper(temp[0]);
		  
		  if (key == 'Q')
		    {
		      /* Q quits */
		      
		      quit = 1;
		    }
		  else if (key == 'C')
		    {
		      /* C checks */
		      
		      done_it_once = 0;
		    }
		}
	      else if (event.type == EnterNotify)
		{
		  /* Enter - start counting (a few seconds til info.): */
		  
		  in_window = 1;
		  gettimeofday(&enter_time, NULL);
		}
	      else if (event.type == LeaveNotify)
		{
		  /* Leave - no more info. display: */
		  
		  in_window = 0;
		  showing_info = 0;
		  redraw = 1;
		}
	      else if (event.type == Expose)
		{
		  /* Expose - redraw: */
		  
		  redraw = 1;
		}
	      else if (event.type == ConfigureNotify)
		{
		  /* Configure - get new size and redraw: */
		  
		  width = event.xconfigure.width;
		  height = event.xconfigure.height;
		  redraw = 1;
		}
	      else if (event.type == ClientMessage)
		{
		  /* Delete - quit nicely:  (I think this is alright!?) */
		  
		  quit = 1;
		}
	    }
	}
      
      
      /* Check time: */
      
      usleep(10000);
      gettimeofday(&now, NULL);
      
      
      /* Is it time for an update? */
      
      if (now.tv_sec > last_update)
	{
	  redraw = 1;
	  last_update = now.tv_sec;
	}
      
      
      /* Is it time to check for mail again? */
      
      if (now.tv_sec - then.tv_sec >= update || done_it_once == 0)
	{
	  gettimeofday(&then, NULL);
	  
	  
	  /* Yes!  Make connection to server: */
	  
	  done_it_once = 1;
	  
	  
	  /* Make sure we have a password first: */
	  
	  if (strlen(password) == 0)
	    {	
	      if (strlen(passwordfile) != 0)
		{
		  /* Got a file to check for it? */
		  
		  fi = fopen(passwordfile, "r");
		  
		  if (fi == NULL)
		    {
		      /* Oops: */
		      
		      fprintf(stderr, "%s: ", argv[0]);
		      perror(passwordfile);
		      
		      strcpy(passwordfile, "");
		      done_it_once = 0;
		    }
		  else
		    {
		      /* Look for the password: */
		      
		      do
			{
			  fgets(temp, 1024, fi);
			  
			  if (!feof(fi))
			    {
			      temp[strlen(temp) - 1] = '\0';
			      
			      
			      /* Make sure it has a second field: */
			      
			      if (strchr(temp, ':') == NULL)
				{
				  fprintf(stderr, "%s: Bad line in %s.\n",
					  argv[0], passwordfile);
				}
			      else
				{
				  /* Grab the server field: */
				  
				  strcpy(try_server, temp);
				  strcpy(strchr(try_server, ':'), "\0");
				  
				  strcpy(temp2, strchr(temp, ':') + 1);
				  strcpy(temp, temp2);
				  
				  
				  /* Make sure it has a third field: */
				  
				  if (strchr(temp, ':') == NULL)
				    {
				      fprintf(stderr, "%s: Bad line in %s.\n",
					      argv[0], passwordfile);
				    }
				  else
				    {
				      /* Grab the username field: */
				      
				      strcpy(try_name, temp);
				      strcpy(strchr(try_name, ':'), "\0");
				      
				      strcpy(temp2, strchr(temp, ':') + 1);
				      strcpy(temp, temp2);
				      
				      
				      /* See if this is a match: */
				      
				      if (strcasecmp(server, try_server) == 0
					  && strcmp(username, try_name) == 0)
					{
					  strcpy(password, temp);
					}
				    }
				}
			    }
			}
		      while (!feof(fi));
		      
		      fclose(fi);
		    }
		}
	      else
		{
		  if (nodisplay == 0)
		    {
		      /* We need a password window! */
		      /* Determine geometry for password window: */
		      
		      /* (Input field and submit button:) */
		      inputfieldwidth = XTextWidth(font, "****************",
						   16);
		      submitbuttonwidth = XTextWidth(font, SUBMIT,
						     strlen(SUBMIT));
		      
		      /* (Is that wide enough?) */
		      pwwidth = inputfieldwidth + submitbuttonwidth + 30;
		      
		      sprintf(temp, "for %s on %s", username, server);
		      if (pwwidth < XTextWidth(font, temp, strlen(temp)))
			pwwidth = XTextWidth(font, temp, strlen(temp));
		      
		      pwheight = fh * 4;
		      
		      /* (Position window in center of display:) */
		      pwx = (DisplayWidth(disp, screen) - pwwidth) / 2;
		      pwy = (DisplayHeight(disp, screen) - pwheight) / 2;
		      
		      
		      /* Open the password window: */
		      
		      pwwindow = OpenWindow(disp, rootwindow, pwx, pwy,
					    pwwidth, pwheight,
					    CopyFromParent, white,
					    (ExposureMask | ButtonPressMask |
					     KeyPressMask |
					     VisibilityChangeMask),
					    (Visual *)CopyFromParent);
		      
		      SetStandardHints(disp, pwwindow, "popxbiff-password",
				       "popxbiff - password",
				       pwx, pwy, pwwidth, pwheight);
		      
		      
		      /* Bring window up: */
		      
		      XMapWindow(disp, pwwindow);
		      XMapRaised(disp, pwwindow);
		      XFlush(disp);
		      
		      
		      /* Password-prompt loop: */
		      
		      len = 0;
		      strcpy(password, "");
		      
		      done = 0;
		      
		      do
			{
			  usleep(10000);
			  
			  if (XPending(disp))
			    {
			      XNextEvent(disp, &event);
			      
			      if (event.type == ButtonPress)
				{
				  /* Button - check for "submit" button */
				  
				  if (strlen(password) > 0 &&
				      (event.xbutton.x >=
				       (pwwidth -
					submitbuttonwidth - 10)) &&
				      event.xbutton.y >= (pwheight -
							  fh - 10))
				    {
				      done = 1;
				    }
				}
			      else if (event.type == KeyPress)
				{
				  /* Keypress - add to or remove-from
				     password: */
				  
				  XLookupString(&event.xkey, temp, 1, &keysym,
						&composestatus);
				  
				  key = temp[0];
				  
				  if (key == 42)
				    {
				      /* Shift key - ignore */
				    }
				  else if (isprint(key))
				    {
				      if (len < 16)
					{
					  password[len] = key;
					  len++;
					  password[len] = '\0';
					}
				      else
					XBell(disp, 25);
				    }
				  else if (key == 8 || key == 127)
				    {
				      if (len > 0)
					{
					  len--;
					  password[len] = '\0';
					}
				      else
					XBell(disp, 25);
				    }
				  else if (key == 13 || key == 10)
				    {
				      if (len > 0)
					done = 1;
				      else
					XBell(disp, 25);
				    }
				}
			      
			      
			      /* Redraw password window: */
			      
			      /* (Blank:) */
			      XFillRectangle(disp, pwwindow, gc[1 - rv],
					     0, 0, pwwidth, pwheight);
			      
			      /* (Query:) */
			      drawtext(disp, pwwindow, gc[rv], 3, fh,
				       "Enter POP Server Password");
			      
			      /* (Server/User Info:) */
			      sprintf(temp, "for %s on %s", username, server);
			      drawtext(disp, pwwindow, gc[rv], 3, fh * 2,
				       temp);
			      
			      /* (Current password:) */
			      strcpy(temp, password);
			      strcat(temp, "|");
			      for (i = 0; i < strlen(password); i++)
				temp[i] = '*';
			      drawtext(disp, pwwindow, gc[rv],
				       3, pwheight - fh,
				       temp);
			      
			      /* (Submittion button:) */
			      if (strlen(password) == 0)
				{
				  /* Unclickable (outline): */
				  
				  XDrawRectangle(disp, pwwindow, gc[rv],
						 (pwwidth -
						  submitbuttonwidth - 10),
						 pwheight - fh - 5,
						 submitbuttonwidth,
						 fh);
				  
				  XDrawRectangle(disp, pwwindow, gc[rv],
						 (pwwidth - submitbuttonwidth -
						  10 - 2),
						 pwheight - fh - 5 - 2,
						 submitbuttonwidth + 4,
						 fh + 4);
				  
				  drawtext(disp, pwwindow, gc[rv],
					   pwwidth - submitbuttonwidth - 5,
					   pwheight - 5 - 2,
					   SUBMIT);
				}
			      else
				{
				  /* Clickable (filled): */
				  
				  XFillRectangle(disp, pwwindow, gc[rv],
						 (pwwidth -
						  submitbuttonwidth - 10),
						 pwheight - fh - 5,
						 submitbuttonwidth,
						 fh);
				  
				  XDrawRectangle(disp, pwwindow, gc[1 - rv],
						 (pwwidth - submitbuttonwidth -
						  10 - 2),
						 pwheight - fh - 5 - 2,
						 submitbuttonwidth + 5,
						 fh + 5);
				  
				  drawtext(disp, pwwindow, gc[1 - rv],
					   pwwidth - submitbuttonwidth - 5,
					   pwheight - 5 - 2,
					   SUBMIT);
				}
			    }
			  
			  
			  /* Redraw mail flag window: */
			  
			  /* (Blank:) */
			  XFillRectangle(disp, window, gc[1 - rv],
					 0, 0, width, height);
			  
			  /* (Note:) */	
			  drawtext(disp, window, gc[rv], 3, fh,
				   server);
			  drawtext(disp, window, gc[rv], 3, fh * 2,
				   username);
			  drawtext(disp, window, gc[rv], 3, fh * 3,
				   "Pass?");
			  
			  XFlush(disp);
			}
		      while (done == 0);
		      
		      
		      /* Close the password-input window: */
		      
		      XUnmapWindow(disp, pwwindow);
		      XDestroyWindow(disp, pwwindow);
		      XFlush(disp);
		    }
		  else
		    {
		      /* Get password (text mode): */
		      
		      sprintf(temp, "popxbiff: Enter password for %s on %s: ",
			      username, server);
		      strcpy(password, getpass(temp));
		      printf("Thank you.\n");
		    }
		}
	    }
	  
	  
	  /* Show that we're connecting: */
	  
	  if (nodisplay == 0)
	    {
	      /* (Blank:) */
	      XFillRectangle(disp, window, gc[1 - rv],
			     0, 0, width, height);
	      
	      /* (Note:) */	
	      drawtext(disp, window, gc[rv], 3, fh,
		       server);
	      drawtext(disp, window, gc[rv], 3, fh * 2,
		       "Connect");
	      
	      XFlush(disp);
	    }
	  
	  
	  /* Create a socket in the INET domain: */
	  
	  s = socket(AF_INET, SOCK_STREAM, 0);
	  
	  if (s < 0)
	    {
	      perror("socket()");
	      exit(1);
	    }
	  
	  
	  /* Create the address of the server: */
	  
	  memset(&name, 0, sizeof(struct sockaddr_in));
	  
	  name.sin_family = AF_INET;
	  name.sin_port = htons(port);
	  memcpy(&name.sin_addr, hp->h_addr_list[0], hp->h_length);
	  len = sizeof(struct sockaddr_in);
	  
	  
	  if (connect(s, (struct sockaddr *) &name, len) < 0)
	    {
	      sprintf(temp, "%s: connect()", argv[0]);
	      perror(temp);
	      
	      if (errno == ENETDOWN ||
		  errno == ENETUNREACH ||
		  errno == ECONNREFUSED ||
		  errno == EHOSTDOWN ||
		  errno == EHOSTUNREACH)
		{
		  /* I consider these non-fatal (maybe PPP is down, or
		     server is temporarily dead, or..?) */
		  
		  neterror = 1;
		  redraw = 1;
		  
		  if (nodisplay == 1)
		    printf("\n%s: No network.\n\n", argv[0]);
		}
	      else
		{
		  /* Everything else is probably pretty bad. */
		  
		  exit(1);
		}
	    }
	  else
	    {
	      /* Was the last thing we saw a network error?  If so clear it: */
	      
	      if (neterror == 1)
		{
		  neterror = 0;
		}
	      
	      
	      /* Don't block on read from socket: */
	      
	      cntl = fcntl(s, F_GETFL, 0);
	      cntl = cntl | O_NONBLOCK;
	      fcntl(s, F_SETFL, cntl);
	  
	      
	      /* Send user: */
	      
	      sprintf(temp, "USER %s", username);
	      socketprint(s, temp);
	      
	      
	      /* Read welcome line: */
	      
	      if (socketreadline(s, str, COMPLAIN) == 1 || 1 == 1)
		{
		  /* Read (hopefully) user-ok line: */
		  
		  if (socketreadline(s, str, COMPLAIN) == 1)
		    {
		      /* Send password: */
		      
		      sprintf(temp, "PASS %s", password);
		      socketprint(s, temp);
		      
		      
		      /* Read (hopefully) password-ok line: */
		      
		      if (socketreadline(s, str, COMPLAIN) == 1)
			{
			  /* Ask for mailbox status: */
			  
			  socketprint(s, "STAT");
			  
			  
			  /* Read (hopefully) 'OK' and status line: */
			  
			  if (socketreadline(s, str, COMPLAIN) == 1)
			    {
			      /* Get number of messages: */
			      
			      sscanf(str, "%s %d", temp, &how_much_mail);
			      
			      
			      /* Get message headers (if mailbox seems to
				 have changed): */
			      
			      if (nodisplay == 0)
				{
				  if (how_much_mail != how_much_mail_before)
				    {
				      for (i = 0; i < how_much_mail && i < 10;
					   i++)
					{
					  /* Draw effects while happening: */
					  
					  XFillRectangle(disp, window,
							 gc[i % 2],
							 i, i,
							 width - i * 2,
							 height - i * 2);
					  
					  sprintf(temp, "(%d/%d)", i + 1,
						  how_much_mail);
					  
					  drawtext(disp, window, gc[0],
						   ((width -
						     XTextWidth(font,
								temp,
								strlen(temp)))
						    / 2),
						   (height + fh) / 2,
						   temp);
					  
					  XFlush(disp);
					  
					  
					  /* Default vals (if problems): */
					  
					  strcpy(froms[i], "[Unknown]");
					  strcpy(subjects[i], "[Unknown]");
					  
					  
					  /* Send "TOP" Command: */
					  
					  sprintf(temp, "TOP %d 0", i + 1);
					  socketprint(s, temp);
					  
					  if (socketreadline(s, str,
							     COMPLAIN) == 1)
					    {
					      /* Read all header lines: */
					      
					      do
						{
						  socketreadline(s, str,
								 QUIET);
						  
						  
						  /* Take "From:"/"Subject:" */
						  
						  if (strstr(str, "From: ") ==
						      str)
						    {
						      strcpy(froms[i],
							     str + 6);
						      froms[i][18] = '\0';
						    }
						  else if (strstr(str,
								  "Subject: ")
							   == str)
						    {
						      strcpy(subjects[i],
							     str + 9);
						      subjects[i][60] = '\0';
						    }
						}
					      while (strcmp(str, ".") != 0);
					    }
					}
				    }
				}
			    }
			  
			  
			  /* Send 'QUIT' command: */
			  
			  socketprint(s, "QUIT");
			  
			  
			  /* If the amount of mail changes... */
			  
			  if (how_much_mail != how_much_mail_before)
			    {
			      /* Beep if there's more: */
			      
			      if (how_much_mail > how_much_mail_before)
				{
				  if (strlen(aufile) == 0)
				    {
				      if (nodisplay == 0)
					XBell(disp, volume);
				      else
					{
					  /* Need something here!!! */
					}
				    }
				  else
				    {
				      fi = fopen(aufile, "r");
				      if (fi == NULL)
					{
					  fprintf(stderr, "%s: ", argv[0]);
					  perror(aufile);
					  strcpy(aufile, "");
					}
				      else
					{
					  fo = fopen("/dev/audio", "w");
					  if (fo == NULL)
					    {
					      fclose(fi);
					      strcpy(aufile, "");
					      fprintf(stderr, "%s: ", argv[0]);
					      perror("/dev/audio");
					    }
					  else
					    {
					      do
						{
						  c = fgetc(fi);
						  if (c != EOF)
						    fputc(c, fo);
						}
					      while (c != EOF);
					      
					      fclose(fi);
					      fclose(fo);
					    }
					}
				    }
				  
				  
				  /* Text alert if there's mail: */
				  
				  if (nodisplay == 1 &&
				      how_much_mail > how_much_mail_before)
				    {
				      printf("\n\n[-- ");
				      printf("%d new messages (%d total) for %s on %s",
					     (how_much_mail -
					      how_much_mail_before),
					     how_much_mail,
					     username, server);
				      printf(" --]\n\n");
				    }
				  
				  
				  /* Set the flag up if there's any: */
				  
				  if (how_much_mail > 0)
				    flagup = 1;
				  else
				    flagup = 0;
				}
			      
			      how_much_mail_before = how_much_mail;
			      
			      
			      /* Definitely redraw: */
			      
			      redraw = 1;
			    }
			}
		      else
			{
			  /* Bad password? */
			  
			  strcpy(password, "");
			  strcpy(passwordfile, "");
			  done_it_once = 0;
			}
		    }
		}
	    }
	  
	  close(s);
	}
      
      
      /* In the window?  Time for info. display? */
      
      if (nodisplay == 0)
	{
	  if (in_window == 1 && showing_info == 0)
	    {
	      if (now.tv_sec - enter_time.tv_sec >= 1)
		{
		  showing_info = 1;
		  redraw = 1;
		}
	    }
	}
      
      
      /* Redraw window contents? */
      
      if (redraw == 1 && nodisplay == 0)
	{
	  redraw = 0;
	  
	  
	  /* Figure out the colors: */
	  
	  if (rv == 0)
	    whichgc = flagup;
	  else
	    whichgc = 1 - flagup;
	  
	  
	  /* Clear window: */
	  
	  XFillRectangle(disp, window, gc[1 - whichgc], 0, 0,
			 width, height);
	  
	  
	  if (neterror == 0)
	    {
	      /* Draw bitmap: */
	      
	      XCopyPlane(disp, flags[flagup], window, gc[whichgc],
			 0, 0, widths[flagup], heights[flagup],
			 (width - widths[flagup]) / 2,
			 (height - heights[flagup]) / 2, 1);
	      
	      
	      /* Draw how many messages: */
	      
	      sprintf(temp, "(%d)", how_much_mail);
	      drawtext(disp, window, gc[1 - rv],
		       width - XTextWidth(font, temp, strlen(temp)),
		       height,
		       temp);
	    }
	  else
	    {
	      /* Oops! An error! */
	      
	      drawtext(disp, window, gc[1 - rv], 0, fh, "No");
	      drawtext(disp, window, gc[1 - rv], 0, fh * 2, "Network");
	    }
	  
	  
	  /* Showing info.? */
	  
	  if (showing_info == 1)
	    {
	      sprintf(temp, "%-20s", server);
	      drawtext(disp, window, gc[rv], 0, fh, temp);
	      
	      sprintf(temp, "%-20s", username);
	      drawtext(disp, window, gc[rv], 0, fh * 2 - 1, temp);
	      
	      sprintf(temp, "T-%-18d", update - (now.tv_sec - then.tv_sec));
	      drawtext(disp, window, gc[rv], 0, fh * 3 - 2, temp);
	    }
	  
	  XFlush(disp);
	}
    }
  while (quit == 0);
  
  
  /* Exit cleanly: */
  
  if (nodisplay == 0)
    {
      XUnmapWindow(disp, window);
      XDestroyWindow(disp, window);
    }
  
  exit(0);
  return(0);
}


/* Usage error: */

void usage(char * progname, int ret)
{
  fprintf(stderr, "\n");
  fprintf(stderr, "Usage: %s [options ...]  where options include:\n",
	  progname);
  fprintf(stderr, "  General Info:\n");
  fprintf(stderr, "    -help                List this usage help\n");
  fprintf(stderr, "    -version             displays version number\n");
  fprintf(stderr, "  X Window attributes:\n");
  fprintf(stderr, "    -display host:dpy    X server to contact ($DISPLAY)\n");
  fprintf(stderr, "    -nodisplay           run in text mode instead of X\n");
  fprintf(stderr, "    -geometry WxH+X+Y    size of mailbox (45x45+5+5)\n");
  fprintf(stderr, "  POP Server and User attributes:\n");
  fprintf(stderr, "    -server srv          server to check (localhost)\n");
  fprintf(stderr, "    -port prt            POP port on the server (110)\n");
  fprintf(stderr, "    -update seconds      how often to check for mail (300)\n");
  fprintf(stderr, "    -user username       username on POP server ($LOGNAME)\n");
  fprintf(stderr, "    -passwordfile file   file to look in for password\n");
  fprintf(stderr, "  Sound and Graphics Settings:\n");
  fprintf(stderr, "    -volume percentage   how loud to ring the bell (50)\n");
  fprintf(stderr, "    -au aufile           play an AU file instead of ringing the bell (none)\n");
  fprintf(stderr, "    -bg color            background color (white)\n");
  fprintf(stderr, "    -fg color            foreground color (black)\n");
  fprintf(stderr, "    -flagup bitmap       bitmap for mail (flagup)\n");
  fprintf(stderr, "    -flagdown bitmap     bitmap for no mail (flagdown)\n");
  fprintf(stderr, "    -rv                  reverse video\n");
  fprintf(stderr, "\n");
  
  exit(ret);
}


/* Open a window: */

Window OpenWindow(Display *display, Window parent, int x, int y, int width,
                  int height, unsigned long bordercolor, 
                  unsigned long backcolor, unsigned long event_mask,
                  Visual *visual)
{
  Window window;
  XSetWindowAttributes attributes;
  unsigned long attr_mask;
  
  /* Set up window attributes first */
  
  attributes.event_mask = event_mask;
  attributes.border_pixel = bordercolor;
  attributes.background_pixel = backcolor;
  attr_mask = CWEventMask | CWBackPixel | CWBorderPixel;
  
  /* Create window! */
  
  window = XCreateWindow(display, parent, x, y, width, height, 3,
                         CopyFromParent, InputOutput, visual, attr_mask,
                         &attributes);
  
  return(window);
}


/* Create a GC: */

GC CreateGC(Display *display, Drawable drawable, unsigned long forecolor,
            unsigned long backcolor)
{
  XGCValues xgcvalues;
  GC gc;
  
  xgcvalues.foreground = forecolor;
  xgcvalues.background = backcolor;
  gc = XCreateGC(display,drawable,(GCForeground | GCBackground),
                 &xgcvalues);
  
  return(gc);
}


/* Allocate a color by name: */

unsigned long AllocNamedColor(Display *display, Colormap colormap,
                              char* colorname, unsigned long default_color)
{
  XColor hardwarecolor,exactcolor;
  unsigned long color;
  int status;
  
  status = XAllocNamedColor(display, colormap, colorname, &hardwarecolor,
                          &exactcolor);
  if (status != 0)
    color = hardwarecolor.pixel;
  else
    color = default_color;
  
  return(color);
}


/* Set up the colormap: */

int SetUpColormap(Display *display, int screen, Window window, Visual *visual,
                  Colormap *colormap)
{
  int status = False;
  
  if (visual == DefaultVisual(display,screen))
    {
      *colormap = DefaultColormap(display,screen);
      status = True;
    }
  else
    {
      *colormap = XCreateColormap(display,window,visual,AllocNone);
      if (*colormap != None)
        {
          XSetWindowColormap(display,window,*colormap);
          status = True;
        }
      else
        *colormap = DefaultColormap(display,screen);
    }
  
  return(status);
}


/* Read a line (up to EOL or no more data) from a socket stream: */

int socketreadline(int s, char * buf, int quiet)
{
  int n, len, done, retry;
  char c;
  
  do
    {
      len = 0;
      done = 0;
      retry = 0;
      
      do
	{
	  /* Read a byte: */
	  
	  n = read(s, &c, 1);
	  
	  
	  /* Error? */
	  
	  if (n < 0)
	    {
	      if (errno != EAGAIN)
		{
		  /* If it's not a retry, then we abort: */
		  
		  perror("read()");
		  done = 1;
		}
	      else
		{
		  /* If it's a retry, then retry: */
		  
		  retry++;
		  usleep(100);
		  
		  
		  /* Too many retries?  Give up! */
		  
		  if (retry >= 1000)
		    {
		      done = 1;
		    }
		}
	    }
	  
	  
	  /* Add only if it's a value character: */
	  
	  if (n == 1)
	    {
	      if (c != 13 && c != 10)
		{
		  buf[len] = c;
		  len++;
		}
	    }
	  
	  
	  /* Done on EOL or EOF: */
	  
	  if (c == 10 || c == 13 || n == 0)
	    done = 1;
	}
      while (done == 0);
      
      buf[len] = '\0';
      
      
      usleep(100);
      
#ifdef DEBUG
      fprintf(stderr, "IN==%s (%d)\n", buf, strlen(buf));
#endif
    }
  while (strlen(buf) == 0);
  
  
  /* Abort if the result isn't "+OK...": */
  
  if (strstr(buf, "+OK") != buf)
    {
      if (quiet == 0)
	fprintf(stderr, "POP error: %s\n", buf);
      
      return(0);
    }
  
  
  return(1);
}


/* Print a string (followed by EOL) to a socket stream: */

void socketprint(int s, char * str)
{
  int n;
  
  usleep(100);
  
#ifdef DEBUG
  fprintf(stderr, "OUT=%s\n", str);
#endif

  n = write(s, str, strlen(str));
  n = write(s, "\n", 1);
}
