README.txt for popxbiff

version 0.4.1

Mailbox flag for X (or not) using the POP mail protocol

by Bill Kendrick
nbs@sonic.net
http://www.newbreedsoftware.com/

September 10, 1998 - January 22, 1999


CHANGES
-------
  Version 0.4.1 - 22.Jan.1999
    * Patch to ignore SHIFT key by Steven Lass <steve@syl.dl.nec.com>

  Version 0.4 - 7.Oct.1998
    * Oops!  Left some debugging code in the 0.3.1 release.  Took it out in
      0.4 (obviously working too quickly).
    * Made text-mode e-mail alert tell you how many messages are new, AND
      how many you have total, instead of just how many are new.
    * Made a cooler usage display (and added some options that were missing).
    * Usage display ("-help") can be seen with "-h" or "--help" now, too.
    * Added -version option. (Also "-v" and "--version.)

  Version 0.3.1 - 7.Oct.1998
    * Fixed a bug introduced in 0.3 which would make popxbiff sometimes NOT
      notify you of new mail when running from X.

  Version 0.3 - 6.Oct.1998
    * Added "-au" option to play AU files instead of ringing the bell.
    * Added "-nodisplay" option to run in text mode (instead of X).
    * Fixed a bug where popxbiff would say "s: connect()..." instead of
      "popxbiff: connect()..." when there was a network error.

  Version 0.2 - 27.Sept.1998
    * Added "-passwordfile" option.
    * Added popup info. display.

  Version 0.1 - 12.Sept.1998
    * Added 'Q'uit and 'C'heck keyboard commands.
    * Add more useful displays while "popxbiff" is working.
    * Gave non-mail-flag-windows different names (so you can make them sticky,
      remove Window Manager decorations, etc. to the mail flag window
      separately from the password and headers windows).

  Version 0.0 - 11.Sept.1998
    * First Release.


WHAT IS IT?
-----------
  This program tells you whether you have mail.  Specifically, it displays
  an image in a window (the "mail flag window") showing a different icon
  depending on whether you have mail or not, as well as a count of how many
  messages you have.

  It checks your mailbox at regular intervals, and beeps when you get new
  mail.  You can also view the "From" and "Subject" headers of the
  first 10 messages in your box in a "headers window".


WHY DID I WRITE IT?
-------------------
  I wrote this program because the Local Area Network that my new Linux PC
  is on (in my apartment) uses one IP for all of the machines.  This means
  that I couldn't run "xbiff" remotely and have its window appear on my
  local display.

  So, I wrote a program that runs locally, and finds out whether I have
  mail on the remote machine by using a POP connection.

  I wrote it in about a day, and didn't base any of the code (except about
  two lines dealing with the window manager "delete" command) on any
  existing version of "biff" or "xbiff".  I tried to make it act as closely
  as possible to "xbiff" for the average user, however.  Power users will
  notice a few things missing.  Oh well, it suits my needs, which is really
  the only reason I wrote it! :)  Also, you may have problems due to my
  ignorance about the POP protocol (see below).


INSTALLING IT
-------------
  To install, simply type "make".  You can specify a few variables to it
  if you need or want to:

    PREFIX=/path-to-X

      The path to your X files ("lib" and "include").  Defaults to "/usr/X11".

    BITMAPDIR=/path-to-xbms

      Path to the directory containing the default bitmaps ("flagup.xbm" and
      "flagdown.xbm").  Defaults to the directory you're running "make" in.

  For example:

    make PREFIX=/usr/openwin BITMAPDIR=/usr/X11/bin/popxbiff-bitmaps

  (make sure to put the default images in the directory you speicifed with
  "BITMAPDIR", otherwise when you run "popxbiff" without the
  "-flagup" and "-flagdown" options, it will die!)


RUNNING IT
----------
  The following options can be specified on the command line.
  (Defaults are listed in brackets ("["/"]").

  General popxbiff Info. Request Options:
  ---------------------------------------
    -help                List the usage help (and quit)
                         (Also, "-h" and "--help" work.)
    -version             Display what version you're running (and quit)
                         (Also, "-v" and "--version" work.)

  X-Window Attributes:
  --------------------
    -display host:dpy    X server to contact [$DISPLAY]
    -geometry WxH+X+Y    size of mailbox [45x45+5+5]
    -nodisplay           run in text mode instead of X

  POP Server Attributes: 
  ----------------------
    -server srv          server to check [localhost]
    -port prt            POP port on the server [110]
    -update seconds      how often to check for mail [300]

  User Info.:
  -----------
    -user username       username for that server [$LOGNAME]
    -passwordfile file   file containing servers/usernames/passwords [none]

  Sound Settings:
  ---------------
    -volume percentage   how loud to ring the bell [50]
    -au aufile           play an AU file instead of ringing the bell [none]

  Graphics Settings:
  ------------------
    -bg color            background color [white]
    -fg color            foreground color [black]
    -flagup bitmap       bitmap for mail [flagup]
    -flagdown bitmap     bitmap for no mail [flagdown]
    -rv                  reverse video

  For example, to check your mail every 30 seconds on a "computer.net"
  account called  "johndoe", you could run:

    ./popxbiff -server computer.net -user johndoe -update 30

  To check your mail on the machine you're on (just use "xbiff"!) using the
  supplied "inboxempty.xbm" and "inboxfull.xbm" bitmaps in a nice green/black
  scheme, you could run:

    ./popxbiff -flagup ./inboxfull.xbm -flagdown ./inboxempty.xbm \
               -bg black -fg green

  Note: I coded the geometry option by hand.  It probably isn't nearly
  as robust as whatever the standard is.  Just make sure to always specify
  all dimensions (width, height, x position and y position) and you should
  be alright.  Also, it currently doesn't understand negative x/y positions.
  (Can someone point me to this toolkit options library thingy!?)


USING IT
--------
  Start-up:
  ---------
    When you start "popxbiff" up in X, it will open the mail flag window and
    begin connecting to the POP server.

    If you specified a password file (using the "-passwordfile" option),
    the file will be searched, and if a line containing the server and
    username for this popxbiff process is found, that line's password will
    be used (see "Password Files" below).

    If you didn't specify a password file, the file couldn't be opened,
    the server/username combination couldn't be found, or the password
    in that file is wrong, in X, a new window will appear for you to input
    your password (it will appear as asterisks ("*") when you type).
    In text mode, you will be prompted for your password.  As you type it,
    nothing will be echoed.

    Type your password and press [Enter], [Return] or, in X, click the "OK"
    button in the window.

    If the password (NOTE: OR USERNAME!) are incorrect, you will be asked
    to enter your password again.  Take note of what server and username
    "popxbiff" is asking you for in this window if you have problems.
    Perhaps you forgot what account "popxbiff" is trying to check for you!

  Password Files:
  ---------------
    Password files (you'll personally probably need only one) are text files
    containing line(s) in the form:

      server:username:password

    When "popxbiff" is ran and a password file is specified, "popxbiff" will
    search through it looking for a line containing the same server and
    username as "popxbiff" is using.  If it finds one, it will grab the
    password and try to use it.  (This lets you stick a "popxbiff" call
    in your X-Window startup file (like ".fvwmrc") and have it know the
    password without any user intervention.)

    NOTE: For your OWN safety, make sure that NOBODY else has access to
    any of your password files.  Realize that superuser(s) on your local
    system could read your "popxbiff" password file(s) and break into
    your account(s) on outside systems!  Only use "-passwordfile" and
    password files if you're certain of (or don't care) about security.

    To use the password file option, you'll want to call "popxbiff" like
    this:

      ./popxbiff -server computer.net -user johndoe -passwordfile ./pw.txt

    The password file "pw.txt" would need to contain a line like:

      computer.net:johndoe:ITisAsecret

    for this to be of any use, of course.

  Checking:
  ---------
    In X mode, while popxbiff is checking for mail, the window will be
    filled with flashing rectangles.  This lets you know that the program
    is busy.  (Sometimes, if the network is extremely busy (like on our
    14.4k bps connection here in the apartment), the window will just
    lock-up.  Give it a few moments to connect before you decide to kill
    the process!)

    If you have new mail (since the last time popxbiff checked), the program
    will beep or play the specified AU audio file.  In X mode, the
    mail flag window will display the "flagup" image.  In text mode, the
    number of new messages will be displayed (along with the username and
    server, for your reference).

    If you have no new mail, nothing happens.

    NOTE: If the program gets a network-related error (say, PPP is down here
    in the apartment) it will simply say "No Network".  It will keep trying
    to connect and check for mail at regular intervals, so when the network
    does come back up, you'll eventually find out whether you have mail or not.

  Controls in X:
  --------------
    Mouse-click
    -----------
      If you click in the mail flag window, the window will switch to the
      "flagdown" image if it was currently in "flagup" mode.  It won't go
      back to "flagup" until you get new e-mail.

    Right-click
    -----------
      If you right-click in the mail flag window, the headers of the
      first 10 messages will appear in a new window.  (NOTE: The program
      doesn't check for mail while this window is up!)  If you have more
      than 10 messages, you'll see "..." at the end of the list.

      Click in either the mail flag window or the headers window to close the
      headers window.

    Q Key
    -----
      You can press the [Q] key while focus is in the mail flag window to quit,
      or use your Window Manager's "Destroy" command.  "popxbiff" should exit
      nicely. (NOTE: It may not quit immediately if it is busy!)

    C Key
    -----
      Press the [C] key while focus is in the mail flag window to force
      "popxbiff" to check for mail immediately (and reset the timer).

    Point
    -----
      Place the mouse in the window (no need to click or otherwise gain
      focus) for one second to cause an information display to appear in
      the mail flag window.  The information displayed includes the
      server being checked, the username of the account being checked,
      and the time remaining before "popxbiff" plans to check for mail
      again.  (ie, "T-60" for 60 seconds)

      Move the mouse out of the window to return the window to normal.

  Controls in Text Mode
  ---------------------
    There are really no built-in controls in text mode, but you can use
    your shell's process-backgrounding features to throw "popxbiff" in
    the background:

      * If you're not specifying a password file:
        + Run "popxbiff" in the foreground.
        + Enter your password.
        + Wait for the "Thank You" message.
        + Press [Control]-[Z] to suspend the process.
        + Run the command "bg" to place "popxbiff" in the background.
      * If you're specifying a password file:
        + Place "popxbiff" in the background right when you run in, by
          appending the "&" character at the end of the command.

    To quit "popxbiff":
      * Bring it to the foreground (using "jobs" to figure out which job it is,
        and "fg" to bring it to the foreground).
      * Press [Control]-[C] to kill the process.

  Expert X Usage
  --------------
    Here's a few lines you can add to your ".fvwmrc" (or similar ".*rc"
    resource file) if you use the FVWM or compatible Window Manager:

    Make popxbiff Look Nicer:
    -------------------------
        Style "popxbiff" NoTitle, NoHandles, Sticky, WindowListSkip

      This will cause the mail flag window to appear without a titlebar or
      handles, and it will stick to your desktop when you move between screens.
      It also won't appear in FVWM's Window List.  (I stole this idea from
      FVWM's "GoodStuff" module's 'Style' line.)

      NOTE: Since there will be no Window Manager controls, you'll need to quit
      by clicking in the mail flag window and pressing [Q] or (not recommended)
      by killing the "popxbiff" process.

    Make popxbiff Run When You Start X:
    -----------------------------------
      Find the "InitFunction" in your ".fvwmrc" file.
      Add a line like this to start "popxbiff" when you first enter X Window:

        Exec  "I"  /path/to/popxbiff -the -arguments you -want it -to -have

  Expert Text Mode Usage
  ----------------------
    You can also make "popxbiff" run when you log in (in a telnet session)
    by adding a "popxbiff" command to your ".login", ".profile", ".bashrc",
    ".cshrc" or other login script.  Talk to your system administrator for
    help.


ABOUT POP
---------
  I had zero references on the POP protocol.  I figured out how POP worked
  by telnetting to port 110 (the POP port) of my RedHat Linux 5.1 machine
  and my ISP's Linux 3.1 machine.  Hopefully, this program will work for you.
  If not, please let me know everything you can about the problems
  "popxbiff" had (try running it from an "xterm" so that you can see its
  "stderr" output) and what type of POP your server is running.  Thanks!


CREDITS
-------
  popxbiff's concept was based on:
    Original biff: Unknown.
    Original xbiff: Jim Fulton, Ralph Swick.
    Original frm: Derived from Elm by Dave Taylor

  popxbiff was written by:
    Bill Kendrick, 1998-1999

  popxbiff patches have been sent in by:
    Steven Lass <steve@syl.dl.nec.com>

CONTACT
-------
  New Breed Software
  c/o Bill Kendrick
  919 Drake Drive #147
  Davis, CA 95616 USA
  nbs@sonic.net
  http://www.newbreedsoftware.com/

  Donations accepted, of course! :)  Please distribute freely (with all
  files intact!)
