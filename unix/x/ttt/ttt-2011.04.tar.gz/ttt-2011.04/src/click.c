/*
 * A very simple tic-tac-toe game.
 *
 * Copyright (c) 2011 Cyber Switching, Inc.
 * Chris Verges <chrisv@cyberswitching.com>
 *
 * Copyright (c) 2003 Bill Kendrick
 * Bill Kendrick <bill@newbreedsoftware.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 */

#include "ttt.h"

void click_human_vs_computer(SDL_Event *event)
{
	debug("Clicked 'HUMAN vs COMPUTER' button\n");
	game_type = HUMAN_VS_COMPUTER;
	reset_game();
}

void click_human_vs_human(SDL_Event *event)
{
	debug("Clicked 'HUMAN vs HUMAN' button\n");
	game_type = HUMAN_VS_HUMAN;
	reset_game();
}

void click_grid_handler(SDL_Event *event)
{
	int x, y;

	/* Technically, should divide by [(grid's width|height) / 3] */
	x = event->button.x / 80;
	y = event->button.y / 80;

	debug("Clicked grid square %dx%d\n", x, y);

	register_move(x, y);
}
