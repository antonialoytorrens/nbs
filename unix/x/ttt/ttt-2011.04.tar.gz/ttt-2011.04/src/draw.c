/*
 * A very simple tic-tac-toe game.
 *
 * Copyright (c) 2011 Cyber Switching, Inc.
 * Chris Verges <chrisv@cyberswitching.com>
 *
 * Copyright (c) 2003 Bill Kendrick
 * Bill Kendrick <bill@newbreedsoftware.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 */

#include "ttt.h"

ttt_element_id_t game_type = 0;

void strikeout_element(ttt_element_id_t id)
{
	ttt_element_t *e, *screen;
	SDL_Rect dest;
	int y, y_final;

	screen = &board_elements[SCREEN];
	e = &board_elements[id];

	debug("Striking out from %dx%d to %dx%d\n",
			e->pos.x,
			e->pos.y,
			e->pos.x + e->pos.w,
			e->pos.y + e->pos.h);

	dest.x = e->pos.x;
	dest.w = e->pos.w;
	dest.h = 1;

	y = e->pos.y;
	y_final = y + e->pos.h;

	for ( ; y < y_final; y += 2 ) {
		dest.y = y;
		SDL_FillRect(screen->img, &dest,
				SDL_MapRGB(screen->img->format, 0, 0, 0));
	}

	SDL_Flip(screen->img);
}

void draw_element(ttt_element_id_t id)
{
	ttt_element_t *e, *screen;

	screen = &board_elements[SCREEN];
	e = &board_elements[id];

	if (e->pos.x >= 0 && e->pos.y >= 0) {
		SDL_BlitSurface(e->img, NULL, screen->img, &e->pos);
		SDL_Flip(screen->img);
	}
}

void draw_board(void)
{
	draw_element(GAME_BOARD);
	draw_element(PROGRAM_LOGO);
	draw_element(HUMAN_VS_COMPUTER);
	draw_element(HUMAN_VS_HUMAN);

	if (game_type != HUMAN_VS_COMPUTER)
		strikeout_element(HUMAN_VS_COMPUTER);

	if (game_type != HUMAN_VS_HUMAN)
		strikeout_element(HUMAN_VS_HUMAN);
}
