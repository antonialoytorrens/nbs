/*
 * A very simple tic-tac-toe game.
 *
 * Copyright (c) 2011 Cyber Switching, Inc.
 * Chris Verges <chrisv@cyberswitching.com>
 *
 * Copyright (c) 2003 Bill Kendrick
 * Bill Kendrick <bill@newbreedsoftware.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 */

#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>

#include "ttt.h"

#define CHECK_ELEMENT_CLICK(id, event_ptr) \
	do { \
		ttt_element_t *e; \
		int x1, y1, x2, y2; \
		e = &board_elements[(id)]; \
		x1 = e->pos.x; \
		y1 = e->pos.y; \
		x2 = x1 + e->pos.w; \
		y2 = y1 + e->pos.h; \
		if ((event_ptr)->button.x >= x1 && \
				(event_ptr)->button.x < x2 && \
				(event_ptr)->button.y >= y1 && \
				(event_ptr)->button.y < y2) { \
			if (e->on_click != NULL) \
				e->on_click((event_ptr)); \
			else \
				debug("No click handler defined for " \
						"element %d\n", (id)); \
		} \
	} while (0)

static void print_usage(char * const program)
{
	printf(	"Usage: %s [options...]\n"
		"\n"
		"-h,--help             Print this help message\n"
		"-l,--landscape        Landscape orientation (default)\n"
		"-p,--portrait         Portrait orientation\n",
		program
	);
}

int main(int argc, char * const argv[])
{
	SDL_Event event;
	static screen_orientation_t orientation = LANDSCAPE;
	int c;

	while (1) {
		static struct option long_options[] = {
			{"help",	no_argument,	NULL,		'h'},
			{"landscape",	no_argument,	NULL,		'l'},
			{"portrait",	no_argument,	NULL,		'p'},
			{0, 0, 0, 0}
		};
		int option_index = 0;

		c = getopt_long(argc, argv, "hlp",
				long_options, &option_index);
		if (c == -1)
			break;

		switch (c) {
		case 'h':
			print_usage(argv[0]);
			exit(0);
		case 'l':
			orientation = LANDSCAPE;
			break;
		case 'p':
			orientation = PORTRAIT;
			break;
		case '?':
			/* getopt_long() already printed an error message */
			break;
		default:
			abort();
		}
	}

	init_orientation(orientation);

	/*
	 * Create a pattern on the board at start-up:
	 *
	 *    X | O | X
	 *    --+---+---
	 *    O | X | O
	 *    --+---+---
	 *    X | O | X
	 *
	 * where all of the "O" characters are struck through.
	 */
	draw_board();
	draw_element(MARK_X_A1);
	draw_element(MARK_O_A2);
	draw_element(MARK_X_A3);
	draw_element(MARK_O_B1);
	draw_element(MARK_X_B2);
	draw_element(MARK_O_B3);
	draw_element(MARK_X_C1);
	draw_element(MARK_O_C2);
	draw_element(MARK_X_C3);
	strikeout_element(MARK_O_A2);
	strikeout_element(MARK_O_B1);
	strikeout_element(MARK_O_B3);
	strikeout_element(MARK_O_C2);

	/* Do the meat of the event loop */
	do {
		SDL_WaitEvent(&event);
		if (event.type == SDL_QUIT) {
			break;
		} else if (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_ESCAPE) {
			break;
		} else if (event.type == SDL_MOUSEBUTTONDOWN) {
			debug("Mouse down event detected at %dx%d\n",
					event.button.x, event.button.y);
			CHECK_ELEMENT_CLICK(GAME_BOARD, &event);
			CHECK_ELEMENT_CLICK(HUMAN_VS_COMPUTER, &event);
			CHECK_ELEMENT_CLICK(HUMAN_VS_HUMAN, &event);
		}
	} while (1);

	SDL_Quit();
	return 0;
}
