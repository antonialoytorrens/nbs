/*
 * A very simple tic-tac-toe game.
 *
 * Copyright (c) 2011 Cyber Switching, Inc.
 * Chris Verges <chrisv@cyberswitching.com>
 *
 * Copyright (c) 2003 Bill Kendrick
 * Bill Kendrick <bill@newbreedsoftware.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 */

#include <errno.h>
#include <sys/stat.h>

#include "ttt.h"

#ifndef TTT_IMAGE_PATH
	#define TTT_IMAGE_PATH		"./images/"
#endif

#define SET_ELEMENT_POS(id, x_pos, y_pos) \
	do { \
		ttt_element_t *_e = &board_elements[(id)]; \
		_e->pos.x = (x_pos); \
		_e->pos.y = (y_pos); \
	} while (0)

ttt_element_t board_elements[NUM_TTT_ELEMENTS];

static void init_landscape_orientation(void)
{
	SET_ELEMENT_POS(PROGRAM_LOGO,		240,	0);
	SET_ELEMENT_POS(GAME_BOARD,		0,	0);
	SET_ELEMENT_POS(HUMAN_VS_COMPUTER,	240,	120);
	SET_ELEMENT_POS(HUMAN_VS_HUMAN,		240,	160);
	SET_ELEMENT_POS(TURN_X,			240,	200);
	SET_ELEMENT_POS(TURN_O,			240,	200);
	SET_ELEMENT_POS(STATUS_WIN_X,		240,	200);
	SET_ELEMENT_POS(STATUS_WIN_O,		240,	200);
	SET_ELEMENT_POS(STATUS_DRAW,		240,	200);

	SET_ELEMENT_POS(MARK_X_A1,		4,	4);
	SET_ELEMENT_POS(MARK_O_A1,		4,	4);
	SET_ELEMENT_POS(MARK_X_A2,		84,	4);
	SET_ELEMENT_POS(MARK_O_A2,		84,	4);
	SET_ELEMENT_POS(MARK_X_A3,		164,	4);
	SET_ELEMENT_POS(MARK_O_A3,		164,	4);

	SET_ELEMENT_POS(MARK_X_B1,		4,	84);
	SET_ELEMENT_POS(MARK_O_B1,		4,	84);
	SET_ELEMENT_POS(MARK_X_B2,		84,	84);
	SET_ELEMENT_POS(MARK_O_B2,		84,	84);
	SET_ELEMENT_POS(MARK_X_B3,		164,	84);
	SET_ELEMENT_POS(MARK_O_B3,		164,	84);

	SET_ELEMENT_POS(MARK_X_C1,		4,	164);
	SET_ELEMENT_POS(MARK_O_C1,		4,	164);
	SET_ELEMENT_POS(MARK_X_C2,		84,	164);
	SET_ELEMENT_POS(MARK_O_C2,		84,	164);
	SET_ELEMENT_POS(MARK_X_C3,		164,	164);
	SET_ELEMENT_POS(MARK_O_C3,		164,	164);
}

static void init_portrait_orientation(void)
{
	SET_ELEMENT_POS(PROGRAM_LOGO,		-1,	-1);
	SET_ELEMENT_POS(GAME_BOARD,		0,	0);
	SET_ELEMENT_POS(HUMAN_VS_COMPUTER,	20,	275);
	SET_ELEMENT_POS(HUMAN_VS_HUMAN,		130,	275);
	SET_ELEMENT_POS(TURN_X,			80,	235);
	SET_ELEMENT_POS(TURN_O,			80,	235);
	SET_ELEMENT_POS(STATUS_WIN_X,		80,	235);
	SET_ELEMENT_POS(STATUS_WIN_O,		80,	235);
	SET_ELEMENT_POS(STATUS_DRAW,		80,	235);

	SET_ELEMENT_POS(MARK_X_A1,		4,	4);
	SET_ELEMENT_POS(MARK_O_A1,		4,	4);
	SET_ELEMENT_POS(MARK_X_A2,		84,	4);
	SET_ELEMENT_POS(MARK_O_A2,		84,	4);
	SET_ELEMENT_POS(MARK_X_A3,		164,	4);
	SET_ELEMENT_POS(MARK_O_A3,		164,	4);

	SET_ELEMENT_POS(MARK_X_B1,		4,	84);
	SET_ELEMENT_POS(MARK_O_B1,		4,	84);
	SET_ELEMENT_POS(MARK_X_B2,		84,	84);
	SET_ELEMENT_POS(MARK_O_B2,		84,	84);
	SET_ELEMENT_POS(MARK_X_B3,		164,	84);
	SET_ELEMENT_POS(MARK_O_B3,		164,	84);

	SET_ELEMENT_POS(MARK_X_C1,		4,	164);
	SET_ELEMENT_POS(MARK_O_C1,		4,	164);
	SET_ELEMENT_POS(MARK_X_C2,		84,	164);
	SET_ELEMENT_POS(MARK_O_C2,		84,	164);
	SET_ELEMENT_POS(MARK_X_C3,		164,	164);
	SET_ELEMENT_POS(MARK_O_C3,		164,	164);
}

static void init_element_image(ttt_element_t *e, char *file)
{
	SDL_Surface *tmp;
	char filename[256];
	struct stat sts;
	int err;

	/* Form the full filename path */
	err = snprintf(filename, ARRAY_SIZE(filename),
			"%s%s", TTT_IMAGE_PATH, file);
	if (err >= ARRAY_SIZE(filename)) {
		fprintf(stderr, "Filename for %s exceeds buffer length\n", file);
		exit(-1);
	}

	/* Check to see if the file exists at the derived path */
	if (stat(filename, &sts) == -1 && errno == ENOENT) {
		fprintf(stderr, "Unable to find image file %s\n", filename);
		exit(-1);
	}

	tmp = SDL_LoadBMP(filename);
	if (!tmp) {
		fprintf(stderr, "Unable to load image file %s\n", filename);
		exit(-1);
	}

	e->img = SDL_DisplayFormatAlpha(tmp);
	SDL_FreeSurface(tmp);

	if (!e->img) {
		fprintf(stderr, "Unable to create screen for image %s\n", filename);
		exit(-1);
	}

	e->pos.w = e->img->w;
	e->pos.h = e->img->h;

	debug("Loaded %-30s: %dx%d\n",
			file,
			e->pos.w,
			e->pos.h);
}

void init_orientation(screen_orientation_t o)
{
	void (*init_func)(void);
	ttt_element_t *e;
	int width;
	int height;

	switch (o) {
	case PORTRAIT:
		width = 240;
		height = 320;
		init_func = &init_portrait_orientation;
		break;
	case LANDSCAPE:
		width = 320;
		height = 240;
		init_func = &init_landscape_orientation;
		break;
	}

	if (SDL_Init(SDL_INIT_VIDEO) < 0) {
		fprintf(stderr, "Unable to initialize video mode\n");
		exit(-1);
	}

	debug("Setting screen dimensions for %dx%d\n",
			width, height);

	e = &board_elements[SCREEN];
	e->img = SDL_SetVideoMode(width, height, 16, SDL_SWSURFACE);
	if (!e->img) {
		fprintf(stderr, "Unable to set the screen's video mode\n");
		exit(-1);
	}

	e = &board_elements[PROGRAM_LOGO];
	init_element_image(e, "program_logo.bmp");

	e = &board_elements[GAME_BOARD];
	init_element_image(e, "game_board.bmp");
	e->on_click = &click_grid_handler;

	e = &board_elements[HUMAN_VS_COMPUTER];
	init_element_image(e, "human_vs_computer.bmp");
	e->on_click = &click_human_vs_computer;

	e = &board_elements[HUMAN_VS_HUMAN];
	init_element_image(e, "human_vs_human.bmp");
	e->on_click = &click_human_vs_human;

	e = &board_elements[TURN_X];
	init_element_image(e, "turn_x.bmp");

	e = &board_elements[TURN_O];
	init_element_image(e, "turn_o.bmp");

	e = &board_elements[STATUS_WIN_X];
	init_element_image(e, "status_win_x.bmp");

	e = &board_elements[STATUS_WIN_O];
	init_element_image(e, "status_win_o.bmp");

	e = &board_elements[STATUS_DRAW];
	init_element_image(e, "status_draw.bmp");

	e = &board_elements[MARK_X_A1];
	init_element_image(e, "mark_x.bmp");

	e = &board_elements[MARK_O_A1];
	init_element_image(e, "mark_o.bmp");

	e = &board_elements[MARK_X_A2];
	init_element_image(e, "mark_x.bmp");

	e = &board_elements[MARK_O_A2];
	init_element_image(e, "mark_o.bmp");

	e = &board_elements[MARK_X_A3];
	init_element_image(e, "mark_x.bmp");

	e = &board_elements[MARK_O_A3];
	init_element_image(e, "mark_o.bmp");

	e = &board_elements[MARK_X_B1];
	init_element_image(e, "mark_x.bmp");

	e = &board_elements[MARK_O_B1];
	init_element_image(e, "mark_o.bmp");

	e = &board_elements[MARK_X_B2];
	init_element_image(e, "mark_x.bmp");

	e = &board_elements[MARK_O_B2];
	init_element_image(e, "mark_o.bmp");

	e = &board_elements[MARK_X_B3];
	init_element_image(e, "mark_x.bmp");

	e = &board_elements[MARK_O_B3];
	init_element_image(e, "mark_o.bmp");

	e = &board_elements[MARK_X_C1];
	init_element_image(e, "mark_x.bmp");

	e = &board_elements[MARK_O_C1];
	init_element_image(e, "mark_o.bmp");

	e = &board_elements[MARK_X_C2];
	init_element_image(e, "mark_x.bmp");

	e = &board_elements[MARK_O_C2];
	init_element_image(e, "mark_o.bmp");

	e = &board_elements[MARK_X_C3];
	init_element_image(e, "mark_x.bmp");

	e = &board_elements[MARK_O_C3];
	init_element_image(e, "mark_o.bmp");

	init_func();
}
