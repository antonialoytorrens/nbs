/*
 * A very simple tic-tac-toe game.
 *
 * Copyright (c) 2011 Cyber Switching, Inc.
 * Chris Verges <chrisv@cyberswitching.com>
 *
 * Copyright (c) 2003 Bill Kendrick
 * Bill Kendrick <bill@newbreedsoftware.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 */

#ifndef _ttt_h_
#define _ttt_h_

#include <SDL/SDL.h>

#ifndef ARRAY_SIZE
	#define ARRAY_SIZE(arr)		(sizeof(arr) / sizeof((arr)[0]))
#endif

#ifdef DEBUG
	#define debug(...)	printf(__VA_ARGS__)
#else
	#define debug(...)	do { } while (0)
#endif

typedef enum {
	PORTRAIT,
	LANDSCAPE
} screen_orientation_t;

typedef enum {
	SCREEN,
	PROGRAM_LOGO,
	GAME_BOARD,
	HUMAN_VS_COMPUTER,
	HUMAN_VS_HUMAN,
	TURN_X,
	TURN_O,
	STATUS_WIN_X,
	STATUS_WIN_O,
	STATUS_DRAW,
	MARK_X_A1,
	MARK_X_A2,
	MARK_X_A3,
	MARK_X_B1,
	MARK_X_B2,
	MARK_X_B3,
	MARK_X_C1,
	MARK_X_C2,
	MARK_X_C3,
	MARK_O_A1,
	MARK_O_A2,
	MARK_O_A3,
	MARK_O_B1,
	MARK_O_B2,
	MARK_O_B3,
	MARK_O_C1,
	MARK_O_C2,
	MARK_O_C3,
	NUM_TTT_ELEMENTS	/* Must be last in the list */
} ttt_element_id_t;

typedef struct {
	SDL_Surface	*img;
	SDL_Rect	pos;
	void (*on_click)(SDL_Event *event);
} ttt_element_t;

extern ttt_element_t board_elements[NUM_TTT_ELEMENTS];
extern ttt_element_id_t game_type;

void init_orientation(screen_orientation_t o);

void strikeout_element(ttt_element_id_t id);
void draw_element(ttt_element_id_t id);
void draw_board(void);

void reset_game(void);
void game_over(void);
void register_move(int x, int y);

void click_human_vs_computer(SDL_Event *event);
void click_human_vs_human(SDL_Event *event);
void click_grid_handler(SDL_Event *event);

#endif
