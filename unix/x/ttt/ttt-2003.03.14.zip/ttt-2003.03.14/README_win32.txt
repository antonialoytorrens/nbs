ttt.exe is for Windows

Built by Jon Atkins
jcatki@jonatkins.org
March 14, 2003

