/* March 17, 2003 - March 19, 2003 */


#include "SDL.h"
#include "SDL_mixer.h"
#include "optionsloop.h"
#include "globals.h"
#include "drawtext.h"


int optionsloop(void)
{
  SDL_Event event;
  SDLKey key;
  SDL_Rect dest;
  int done, menu;

  done = 0;
  menu = 0;

  SDL_FillRect(screen, NULL, color_black);

  dest.x = (screen->w - img_menu_bkgd->w) / 2;
  dest.y = (screen->h - img_menu_bkgd->h) / 2;

  SDL_BlitSurface(img_menu_bkgd, NULL, screen, &dest);
  draw_centered_text(img_font[1][0], 0, "O P T I O N S");
  SDL_Flip(screen);

  do
  {
    while (SDL_PollEvent(&event) > 0)
    {
      if (event.type == SDL_QUIT)
      {
	done = 1;
      }
      else if (event.type == SDL_KEYDOWN)
      {
	key = event.key.keysym.sym;

	if (key == SDLK_ESCAPE)
	{
	  done = 1;
	}
	else if (key == SDLK_SPACE || key == SDLK_RETURN)
	{
	  if (menu == OPTIONS_MAINMENU)
	    done = 1;
	}
	else if (key == SDLK_UP)
	{
	  menu--;
	  if (menu < 0)
	    menu = 0;

	  playsound(snd_menuitem);
	}
	else if (key == SDLK_DOWN)
	{
	  menu++;
	  if (menu >= NUM_OPTIONS_ITEMS)
	    menu = NUM_OPTIONS_ITEMS - 1;

	  playsound(snd_menuitem);
	}
      }
    }
  }
  while (!done);

  return(menu);
}
