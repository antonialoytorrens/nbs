/*
  setup.c
  setup functions for cts demo

  Cardboard Tube Samurai game starring Gabe from Penny Arcade comics
  http://www.penny-arcade.com/
  
  Artwork by Andrew
  
  Coding by Bill Kendrick, New Breed Software
  http://www.newbreedsoftware.com/

  March 16, 2003 - March 19, 2003
*/


#include "SDL.h"
#include "SDL_image.h"
#include "SDL_mixer.h"
#include "setup.h"
#include "globals.h"

#ifdef WIN32
#define snprintf _snprintf
#endif

#define WIDTH 640
#define HEIGHT 480


/* Local function prototypes: */

SDL_Surface * my_load_img(char * basename, int num);


/* Main setup function.  Set defaults.  Load any defaults from config. files.
   Accept any options on the command line.  Initialize SDL.  Open our window.
   Load the images and sounds.  WHEW! */

void setup(int argc, char * argv[])
{
  int i;


  /* Set default options: */
	
  use_audio = 1;


  /* Load options from an options file: */

  /* FIXME: Do it! */


  /* Get command-line options: */

  /* FIXME: Do it! */


  /* Init SDL video: */
  
  if (SDL_Init(SDL_INIT_VIDEO) < 0)
  {
    fprintf(stderr, "Error: Cannot init video:\n%s\n", SDL_GetError());
    exit(1);
  }


  /* Init SDL audio: */

  if (use_audio)
  {
    if (SDL_Init(SDL_INIT_AUDIO) < 0)
    {
      fprintf(stderr, "Warning: Cannot init audio:\n%s\n", SDL_GetError());
      use_audio = 0;
    }
  }


  /* Open a window: */

  screen = SDL_SetVideoMode(WIDTH, HEIGHT, 16, SDL_SWSURFACE);
  if (screen == NULL)
  {
    fprintf(stderr, "Error: Couldn't open window:\n%s\n", SDL_GetError());
    shutdown();
    exit(1);
  }


  /* Determine some useful colors' pixel values: */
  
  color_grey = SDL_MapRGB(screen->format, 128, 128, 128);
  color_black = SDL_MapRGB(screen->format, 0, 0, 0);


  /* Load images: */

  for (i = 0; i < 5; i++)
  {
    img_crouch[RIGHT][i] = my_load_img("right/crouch", i);
    img_crouch[LEFT][i] = my_load_img("left/crouch", i);
  }

  for (i = 0; i < 3; i++)
  {
    img_idle[RIGHT][i] = my_load_img("right/idle", i);
    img_idle[LEFT][i] = my_load_img("left/idle", i);
  }

  for (i = 0; i < 6; i++)
  {
    img_run[RIGHT][i] = my_load_img("right/run", i);
    img_run[LEFT][i] = my_load_img("left/run", i);
  }

  for (i = 0; i < 10; i++)
  {
    img_strike[RIGHT][i] = my_load_img("right/strike", i);
    img_strike[LEFT][i] = my_load_img("left/strike", i);
  }

  img_strike_charge[RIGHT] = my_load_img("right/strike-charge", -1);
  img_strike_charge[LEFT] = my_load_img("left/strike-charge", -1);

  img_sparkles = my_load_img("sparkles", -1);
  
  for (i = 0; i < 7; i++)
  {
    img_jump[RIGHT][i] = my_load_img("right/jump", i);
    img_jump[LEFT][i] = my_load_img("left/jump", i);
  }

  for (i = 0; i < 2; i++)
  {
    img_projectile[RIGHT][i] = my_load_img("right/projectile", i);
    img_projectile[LEFT][i] = my_load_img("left/projectile", i);
  }

  img_title_bkgd = my_load_img("title-bkgd", -1);

  img_menu_bkgd = my_load_img("menu-bkgd", -1);

  for (i = 0; i < 2; i++)
  {
    img_font[RIGHT][i] = my_load_img("font-gold", i);
    img_font[LEFT][i] = my_load_img("font-purple", i);
  }

  img_blocks[0] = my_load_img("blocks/box", -1);


  /* Load sounds: */

  if (use_audio)
  {
    if (Mix_OpenAudio(44100, AUDIO_S16, 2, 1024) < 0)
    {
      fprintf(stderr, "Error: Couldn't open audio!\n%s\n", SDL_GetError());
      shutdown();
      exit(1);
    }

    snd_jump = Mix_LoadWAV("sounds/jump.wav");
    snd_superjump = Mix_LoadWAV("sounds/superjump.wav");
    snd_thwack = Mix_LoadWAV("sounds/thwack.wav");
    snd_thud = Mix_LoadWAV("sounds/thud.wav");
    snd_duck = Mix_LoadWAV("sounds/duck.wav");
    snd_charge = Mix_LoadWAV("sounds/charge.wav");
    snd_gong = Mix_LoadWAV("sounds/gong.wav");
    snd_menuitem = Mix_LoadWAV("sounds/menuitem.wav");

    mus_title = Mix_LoadMUS("music/diplomatic-intro.mod");
    mus_game[0] = Mix_LoadMUS("music/obsessio.mod");
  }
}


/* Shut down!  All done!  Goodnight! */

void shutdown(void)
{
  /* FIXME: Do something! */
}


/* Local function to easily load an image.  Glues basename (e.g., "run", "idle")
   to image number, and sticks "images/" at the beginning and ".png" at the end,
   to come up with a full filename (e.g., "images/run2.png") */

SDL_Surface * my_load_img(char * basename, int num)
{
  char fname[128];
  SDL_Surface * tmpsurf, * tmpconv;


  /* Figure out filename: */
 
  if (num != -1)
    snprintf(fname, sizeof(fname), "images/%s%d.png", basename, num);
  else
    snprintf(fname, sizeof(fname), "images/%s.png", basename);


  /* Load image: */
  
  tmpsurf = IMG_Load(fname);
  if (tmpsurf == NULL)
  {
    fprintf(stderr, "Error: Can't load %s:\n%s\n", fname, SDL_GetError());
    shutdown();
    exit(1);
  }


  /* Convert image for quicker blitting: */
  
  tmpconv = SDL_DisplayFormatAlpha(tmpsurf);
  if (tmpconv == NULL)
  {
    fprintf(stderr, "Error: Can't convert %s:\n%s\n", fname, SDL_GetError());
    shutdown();
    exit(1);
  }


  /* Free memory of temp surface: */
  
  SDL_FreeSurface(tmpsurf);


  /* Return converted surface: */

  return (tmpconv);
}

