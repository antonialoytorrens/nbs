#include "SDL.h"
#include "globals.h"
#include "drawtext.h"

void draw_text(SDL_Surface * fontsurf, int x, int y, char * str)
{
  int i, ch;
  SDL_Rect src, dest;

  for (i = 0; i < strlen(str); i++)
  {
    if (str[i] >= '0' && str[i] <= '9')
      ch = str[i] - '0';
    else if (str[i] >= 'A' && str[i] <= 'Z')
      ch = str[i] - 'A' + 10;
    else
      ch = -1;

    if (ch != -1)
    {
      dest.x = x + i * 16;
      dest.y = y;
    
      src.x = ch * 16;
      src.y = 0;
      src.w = 16;
      src.h = 16;

      SDL_BlitSurface(fontsurf, &src, screen, &dest);
    }
  }
}


void draw_centered_text(SDL_Surface * fontsurf, int y, char * str)
{
  int x;

  x = (screen->w - strlen(str) * 16) / 2;
  draw_text(fontsurf, x, y, str);
}
