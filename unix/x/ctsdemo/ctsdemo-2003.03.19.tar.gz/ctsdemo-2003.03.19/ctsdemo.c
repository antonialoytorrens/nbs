/*
  ctsdemo.c
  cts demo

  Cardboard Tube Samurai game starring Gabe from Penny Arcade comics
  http://www.penny-arcade.com/

  Artwork by Andrew

  Coding by Bill Kendrick, New Breed Software
  http://www.newbreedsoftware.com/

  March 16, 2003 - March 17, 2003
*/


#include <stdio.h>
#include <stdlib.h>
#include "setup.h"
#include "menuloop.h"
#include "demoloop.h"
#include "optionsloop.h"


int main(int argc, char * argv[])
{
  int menu;

  setup(argc, argv);

  do
  {
    menu = menuloop();

    if (menu == MENU_PLAY)
      demoloop();
    else if (menu == MENU_OPTIONS)
      optionsloop();
  }
  while (menu != MENU_QUIT);

  shutdown();

  return 0;
}
