#ifndef DEMOLOOP_H
#define DEMOLOOP_H

void setup(int argc, char * argv[]);
void shutdown(void);

#endif /* DEMOLOOP_H */

