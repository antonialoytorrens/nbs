#ifndef OPTIONSLOOP_H
#define OPTIONSLOOP_H

enum {
  OPTIONS_MAINMENU,
  NUM_OPTIONS_ITEMS
};

static const char * options_labels[NUM_OPTIONS_ITEMS] = {
  "MAIN MENU"
};

int optionsloop(void);

#endif /* OPTIONSLOOP_H */

