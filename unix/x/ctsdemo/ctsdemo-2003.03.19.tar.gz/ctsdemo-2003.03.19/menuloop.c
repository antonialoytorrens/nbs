#include "SDL.h"
#include "SDL_mixer.h"
#include "menuloop.h"
#include "globals.h"
#include "drawtext.h"


/* Local function prototype: */

void show_menu_screen(int menu);



int menuloop(void)
{
  SDL_Event event;
  SDLKey key;
  int done, menu;

  done = 0;
  menu = 0;
  
  show_menu_screen(menu);

  do
  {
    while (SDL_PollEvent(&event) > 0)
    {
      if (event.type == SDL_QUIT)
      {
	menu = MENU_QUIT;
	done = 1;
      }
      else if (event.type == SDL_KEYDOWN)
      {
	key = event.key.keysym.sym;

	if (key == SDLK_ESCAPE)
	{
	  menu = MENU_QUIT;
	  done = 1;
	}
	else if (key == SDLK_SPACE || key == SDLK_RETURN)
	{
	  done = 1;
	}
	else if (key == SDLK_UP)
	{
	  menu--;
	  if (menu < 0)
	    menu = 0;

	  show_menu_screen(menu);
	  playsound(snd_menuitem);
	}
	else if (key == SDLK_DOWN)
	{
	  menu++;
	  if (menu >= NUM_MENU_ITEMS)
	    menu = NUM_MENU_ITEMS - 1;

	  show_menu_screen(menu);
	  playsound(snd_menuitem);
	}
      }
    }

    SDL_Delay(100);

    if (use_audio)
    {
      if (!Mix_PlayingMusic())
      {
	Mix_PlayMusic(mus_title, 0);
      }
    }
  }
  while (!done);

  if (use_audio)
  {
    Mix_HaltMusic();
  }

  return(menu);
}


void show_menu_screen(int menu)
{
  SDL_Rect dest;
  
  SDL_FillRect(screen, NULL, color_black);


  dest.x = (screen->w - img_title_bkgd->w) / 2;
  dest.y = (screen->h - img_title_bkgd->h) / 2;
  
  SDL_BlitSurface(img_title_bkgd, NULL, screen, &dest);

  if (menu > 0)
    draw_centered_text(img_font[0][1], screen->h - 48, menu_labels[menu - 1]);
  
  draw_centered_text(img_font[0][0], screen->h - 32, menu_labels[menu]);
  
  if (menu < NUM_MENU_ITEMS - 1)
     draw_centered_text(img_font[0][1], screen->h - 16, menu_labels[menu + 1]);

  SDL_Flip(screen);
}

