#ifndef MENULOOP_H
#define MENULOOP_H

enum {
  MENU_PLAY,
  MENU_OPTIONS,
  MENU_CREDITS,
  MENU_QUIT,
  NUM_MENU_ITEMS
};

static char * menu_labels[NUM_MENU_ITEMS] = {
  "PLAY",
  "OPTIONS",
  "CREDITS",
  "QUIT"
};

int menuloop(void);

#endif /* MENULOOP_H */

