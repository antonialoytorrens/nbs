/*
  demoloop.c

  main demo loop for cts demo

  by Bill Kendrick
  bill@newbreedsoftware.com
  http://www.newbreedsoftware.com/cts/

  March 16, 2003 - March 19, 2003
*/


#include <stdlib.h>
#include "SDL.h"
#include "SDL_mixer.h"
#include "demoloop.h"
#include "globals.h"


/* #define BUMP_DEBUG */


/* Local function prototypes: */

void playsound(Mix_Chunk * snd);
void add_sparkle(int x, int y);
int bump(int x, int y);


#define NUM_SPARKLES 12

typedef struct sparkle_type {
  int time, x, y;
} sparkle_type;

sparkle_type sparkle[NUM_SPARKLES];

#define MAP_WIDTH 20
#define MAP_HEIGHT 15

char map[15][21] = {
  {"...................."},
  {"...................."},
  {"...................."},
  {"...................."},
  {"...................."},
  {"...................."},
  {"...................."},
  {"...................."},
  {"...................."},
  {"...................."},
  {"...#................"},
  {"...#...........#...."},
  {"...#####......###..."},
  {"...#...#.....#####.."},
  {"####################"}
};


#define KEY_JUMP SDLK_x
#define KEY_FIRE SDLK_z


/* --- DEMO LOOP! --- */

void demoloop(void)
{
  SDL_Event event;
  SDLKey key;
  SDL_Rect dest, src;
  SDL_Surface * which_img;
  Uint8 key_down, key_left, key_right, key_fire;
  int x, y, ym, jumping, falling, adj_x[2], proj_x, proj_y, proj_xm, proj_on,
    level;
  int done, i, bx, by;
  int was_running_counter, exhale_frame, crouch_frame, strike_frame,
    jump_frame, strike_charge_counter, jump_charge_counter, face, super_jumping;
  Uint32 last_time, cur_time;
  Uint32 frame;


  x = 0;
  y = screen->h - 64;
  face = RIGHT;


  key_down = key_left = key_right = key_fire = SDL_KEYUP;


  /* MAIN LOOP! */
  
  level = 0;
  frame = 0;
  done = 0;
  was_running_counter = 0;
  exhale_frame = -1;
  crouch_frame = 0;
  strike_frame = 0;
  strike_charge_counter = 0;
  jump_charge_counter = 0;
  super_jumping = 0;
  jump_frame = 0;
  jumping = 0;
  falling = 0;
  ym = 0;
  proj_on = 0;
  proj_x = 0;
  proj_y = 0;
  proj_xm = 0;

  for (i = 0; i < NUM_SPARKLES; i++)
    sparkle[i].time = 0;
  
 
  playsound(snd_gong);

  do
  {
    last_time = SDL_GetTicks();
    frame++;
    
    /* Deal with any pending events: */
	  
    while (SDL_PollEvent(&event) > 0)
    {
      if (event.type == SDL_QUIT)
      {
	/* Clicked close button on titlebar (or something similar)!  Quit! */

	done = 1;
      }
      else if (event.type == SDL_KEYDOWN || event.type == SDL_KEYUP)
      {
	/* Key press!  Keep track of what's been pressed! */
	
	key = event.key.keysym.sym;


	/* Deal with the keys: */

	if (key == SDLK_ESCAPE && event.type == SDL_KEYDOWN)
	  done = 1;
	else if (key == SDLK_LEFT)
	{
	  key_left = event.type;

	  if (event.type == SDL_KEYDOWN)
	    face = LEFT;
	}
	else if (key == SDLK_RIGHT)
	{
	  key_right = event.type;
	  
	  if (event.type == SDL_KEYDOWN)
	    face = RIGHT;
	}
	else if (key == KEY_JUMP)
	{
	  if (event.type == SDL_KEYDOWN)
	  {
            if (bump(x, y + 64) || bump(x + 32, y + 64))
            {
	      jumping = 1;

	      if (jump_charge_counter >= 20)
	      {
		ym = -16;
		super_jumping = 1;
	        playsound(snd_superjump);
	      }
	      else
	      {
	        ym = -12;
	        playsound(snd_jump);
	      }
	    }
	  }
	  else
	  {
	    if (jumping)
	    {
	      jumping = 0;
	      super_jumping = 0;
	      falling = 1;
	      ym = 0;
	    }
	  }
	}
	else if (key == SDLK_DOWN)
	{
	  key_down = event.type;

	  if (event.type == SDL_KEYDOWN &&
	      !falling && !jumping && (key_fire == SDL_KEYUP))
	    playsound(snd_duck);

	  if (event.type == SDL_KEYUP)
	    jump_charge_counter = 0;
	}
	else if (key == KEY_FIRE)
	{
	  key_fire = event.type;
	  if (event.type == SDL_KEYUP)
	  {
	    if (strike_charge_counter > 30)
	    {
	      /* Launch projectile! */

	      proj_on = 1;

	      if (face == RIGHT)
	      {
	        proj_x = x + 21;
	        proj_y = y + 20;
		proj_xm = 16;
	      }
	      else
	      {
		proj_x = x - 21 - 16;
		proj_y = y + 20;
		proj_xm = -16;
	      }
	    }
	    
	    strike_charge_counter = 0;
	  }
	}
      }
    }


    /* Handle projectile: */

    if (proj_on)
    {
      proj_x = proj_x + proj_xm;

      if (proj_x > screen->w)
	proj_on = 0;
      if (proj_x < -(img_projectile[0][0]->w))
	proj_on = 0;
    }
    

    /* Draw the screen: */

    /* (Start by erasing!) */

    SDL_FillRect(screen, NULL, color_grey);


    /* Draw the blocks: */

    for (by = MAP_HEIGHT - 1; by >= 0; by--)
    {
      for (bx = 0; bx < MAP_WIDTH; bx++)
      {
	if (map[by][bx] == '#')
	{
	  dest.x = (bx * 32);
	  dest.y = (by * 32) - 8;
	  
	  SDL_BlitSurface(img_blocks[0], NULL, screen, &dest);
	}
      }
    }


    /* (Now draw Gabe) */

    adj_x[RIGHT] = 0;
    adj_x[LEFT] = 0;


    if ((key_right == SDL_KEYDOWN || key_left == SDL_KEYDOWN) &&
	(key_down == SDL_KEYUP || jumping || falling) &&
	(key_fire == SDL_KEYUP || jumping || falling))
    {
      if (jumping == 0 && falling == 0)
      {
        which_img = img_run[face][(frame >> 2) % 6];
	adj_x[RIGHT] = -16;
	adj_x[LEFT] = -16;
	
	if ((frame % 12) == 3)
	  playsound(snd_thud);
      }

      if (key_right == SDL_KEYDOWN && 
          !bump(x + 32 + 4, y) && !bump(x + 32 + 4, y + 32))
      {
        x = x + 4;
      }
      else if (key_left == SDL_KEYDOWN &&
          !bump(x - 4, y) && !bump(x - 4, y + 32))
      {
	x = x - 4;
      }

      if (x > screen->w - 32)
	x = screen->w - 32;
      else if (x < 0)
	x = 0;

      if (was_running_counter < 500)
	was_running_counter++;
    }
    else 
    {
      was_running_counter--;

      if (was_running_counter > 100)
      {
	/* Ran recently;  Breath fast. */
	      
	which_img = img_idle[face][(frame >> 4) % 2];
	adj_x[RIGHT] = 0;
	adj_x[LEFT] = 0;
      }
      else
      {
	if (((frame >> 6) % 2) == 0)
	{
	  /* Exhalation frame;  Randomly look shifty-eyed: */
	
	  if (exhale_frame == -1)
	  {
	    /* Need to choose which exhalation frame to use for right now! */
		  
	    if ((rand() % 10) < 2)
	      exhale_frame = 2;
	    else
	      exhale_frame = 0;
	  }

	  which_img = img_idle[face][exhale_frame];
	  adj_x[RIGHT] = 0;
	  adj_x[LEFT] = 0;
	}
	else
	{
	  /* Inhalation frame: */

	  exhale_frame = -1;
	  which_img = img_idle[face][1];
	  adj_x[RIGHT] = 0;
	  adj_x[LEFT] = 0;
	}
      }
    }
      
    
    if (key_down == SDL_KEYDOWN)
    {
      which_img = img_crouch[face][crouch_frame];
      adj_x[RIGHT] = -16;
      adj_x[LEFT] = -16;

      if (frame % 3 == 0)
      {
        if (crouch_frame < 3)
	  crouch_frame++;
      }

      if (jump_charge_counter > 20)
	add_sparkle(x + adj_x[face] + (which_img->w) / 2 + ((rand() % 17) - 8),
		    y + (which_img->h));
    }
    else
    {
      if (crouch_frame > 0)
      {
	which_img = img_crouch[face][4];
	adj_x[RIGHT] = -16;
	adj_x[LEFT] = -16;
      }

      crouch_frame = 0;
    }


    if (jumping)
    {
      which_img = img_jump[face][jump_frame];
      adj_x[RIGHT] = -16;
      adj_x[LEFT] = -16;
      
      if ((frame % 2) == 0)
      {
        if (jump_frame < 3)
	  jump_frame++;
      }

      if (super_jumping)
      {
	add_sparkle(x + adj_x[face] + (which_img->w / 2),
	            y + (which_img->h / 2));
      }
    }

    if (falling)
    {
      which_img = img_jump[face][4];
      adj_x[RIGHT] = -16;
      adj_x[LEFT] = -16;
    }


    if (key_down == SDL_KEYDOWN && !falling && !jumping && key_fire == SDL_KEYUP)
    {
      jump_charge_counter++;
    }
    else
    {
      jump_charge_counter = 0;
    }
    

    if (key_fire == SDL_KEYDOWN)
    {
      which_img = img_strike[face][strike_frame];
      adj_x[RIGHT] = 0;
      adj_x[LEFT] = -48;

      if (strike_frame < 6)
        strike_frame++;
      else if (strike_frame > 6)
	key_fire = SDL_KEYUP;
      else
      {
	strike_charge_counter++;

	if (strike_charge_counter > 30 && (frame % 4) == 0)
	{
	  adj_x[LEFT] = -12;
	  playsound(snd_charge);
          which_img = img_strike_charge[face];

	  add_sparkle(x + adj_x[face] + (rand() % which_img->w),
		      y + (rand() % which_img->h));
	}
      }
    }

    if (key_fire == SDL_KEYUP && strike_frame > 0)
    {
      if (strike_frame <= 6)
      {
        strike_frame = 7;
	playsound(snd_thwack);
      }

      which_img = img_strike[face][strike_frame];
      adj_x[RIGHT] = 0;
      adj_x[LEFT] = -48;

      if ((frame % 3) == 0)
      {
        if (strike_frame < 9)
	  strike_frame++;
        else
	  strike_frame = 0;
      }
    }


    if (jumping || falling)
    {
      y = y + ym;
      ym = ym + 1;

      if (ym > 0)
      {
	jumping = 0;
	super_jumping = 0;
	falling = 1;
      }

      if (falling && ((bump(x, y + 64) || bump(x + 32, y + 64))))
      {
	y = (y / 32) * 32;
	ym = 0;

	falling = 0;
	
	playsound(snd_thud);

	jump_frame = 5;
      }
    }
    else
    {
      if ((!bump(x, y + 64) && !bump(x + 32, y + 64)) || y < 0)
      {
	falling = 1;
	jump_frame = 3;
      }
    }

    
    /* (Draw Gabe!) */

    dest.x = x + adj_x[face];
    dest.y = y;

    SDL_BlitSurface(which_img, NULL, screen, &dest);


    /* (Draw projectile tube energy!) */

    if (proj_on)
    {
      dest.x = proj_x;
      dest.y = proj_y;

      SDL_BlitSurface(img_projectile[face][(frame >> 2) % 2],
		      NULL, screen, &dest);
    }


    /* Draw charge sparkles: */

    for (i = 0; i < NUM_SPARKLES; i++)
    {
      if (sparkle[i].time > 0)
      {
	sparkle[i].time--;

	dest.x = sparkle[i].x - 4;
	dest.y = sparkle[i].y - 4;

	src.x = 0;
	src.y = (rand() % 4) * 8;
	src.w = 8;
	src.h = 8;

	SDL_BlitSurface(img_sparkles, &src, screen, &dest);


	sparkle[i].y = sparkle[i].y - 4;
	sparkle[i].x = sparkle[i].x + ((rand() % 5) - 2);
      }
    }

    
    /* (Finally, refresh the screen) */
    
    SDL_Flip(screen);

    
    /* Pause until the next frame should be dealt with: */
   
    cur_time = SDL_GetTicks();
    if (cur_time < last_time + (1000 / FPS))
    {
      SDL_Delay(last_time + (1000 / FPS) - cur_time);
    }

      
    /* Play music: */

    if (use_audio)
    {
      if (!Mix_PlayingMusic())
        Mix_PlayMusic(mus_game[level], 0);
    }
  }
  while (!done);


  if (use_audio)
  {
    Mix_HaltChannel(-1);
    Mix_HaltMusic();
  }
}


void playsound(Mix_Chunk * snd)
{
  if (use_audio)
  {
    Mix_PlayChannel(-1, snd, 0);
    Mix_Volume(-1, MIX_MAX_VOLUME);
  }
}


void add_sparkle(int x, int y)
{
  int i, found;

  found = -1;

  for (i = 0; i < NUM_SPARKLES && found == -1; i++)
  {
    if (sparkle[i].time <= 0)
      found = i;
  }

  if (found != -1)
  {
    sparkle[found].time = 10;
    sparkle[found].x = x;
    sparkle[found].y = y;
  }
}


int bump(int x, int y)
{
  int bx, by;
#ifdef BUMP_DEBUG
  SDL_Rect dest;
#endif
  
  bx = x / 32;
  by = y / 32;

#ifdef BUMP_DEBUG
  dest.x = (bx * 32);
  dest.y = (by * 32);
  dest.w = 32;
  dest.h = 32;
  
  SDL_FillRect(screen, &dest, SDL_MapRGB(screen->format, 0, 0, 0));
  SDL_UpdateRect(screen, dest.x, dest.y, dest.w, dest.h);
#endif

  if (bx >= 0 && bx < MAP_WIDTH && by >= 0 && by < MAP_HEIGHT)
  {
    if (map[by][bx] == '#')
      return 1;
    else
      return 0;
  }
  else
  {
    return 1;
  }
}

