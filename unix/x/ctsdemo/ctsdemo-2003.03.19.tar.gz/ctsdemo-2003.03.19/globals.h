/*
  globals.h

  globals for cts demo

  by Bill Kendrick
  bill@newbreedsoftware.com
  http://www.newbreedsoftware.com/cts/
  
  March 16, 2003 - March 19, 2003
*/


#ifndef GLOBALS_H
#define GLOBALS_H

#include "SDL.h"
#include "SDL_image.h"
#include "SDL_mixer.h"

SDL_Surface * screen;
SDL_Surface * img_crouch[2][5],
	    * img_idle[2][3],
	    * img_run[2][6],
	    * img_strike[2][10],
	    * img_strike_charge[2],
	    * img_sparkles,
	    * img_projectile[2][2],
	    * img_jump[2][7],
	    * img_title_bkgd,
	    * img_menu_bkgd,
	    * img_font[2][2],
	    * img_blocks[1];
Mix_Chunk * snd_thwack,
          * snd_jump,
          * snd_superjump,
	  * snd_thud,
	  * snd_duck,
	  * snd_charge,
	  * snd_gong,
	  * snd_menuitem;
Mix_Music * mus_title,
	  * mus_game[1];
Uint32 color_grey,
       color_black;

int use_audio;

#define RIGHT 0
#define LEFT 1

#define FPS 45

#endif /* GLOBALS_H */

