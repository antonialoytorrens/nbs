#ifndef DRAWTEXT_H
#define DRAWTEXT_H

void draw_text(SDL_Surface * fontsurf, int x, int y, char * str);
void draw_centered_text(SDL_Surface * fontsurf, int y, char * str);

#endif /* DRAWTEXT_H */
