
 			Teeter Torture Wii port, by MiniK (minik.h4x@gmail.com) 


USAGE 
===== 
Copy teetertorture to the apps folder on your SD card. (Hard coded path, do not rename!) 
Launch with the Homebrew Channel. 



CONTROLS 
======== 
Hold the Wiimote sideways 

Home	Exit to loader 
+	Return to menu 
2	Shoot



Thanks 
====== 
New Breed Software 
Team Twiizers 
DevkitPro Authors 
The Wii homebrew community as a whole. 

Last but not least, thank YOU for downloading! =D 



CHANGELOG 
========= 
Version 2005-10-18
	Initial Port