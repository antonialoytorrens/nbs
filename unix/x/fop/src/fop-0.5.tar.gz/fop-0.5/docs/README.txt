README.txt for FOP: Fight or Perish
by Bill Kendrick <bill@newbreedsoftware.com>
http://www.newbreedsoftware.com/fop/

March 15, 2009

About:
------
"FOP: Fight or Perish" is a multi-player dungeon crawling game,
based on the game concept in Jack Pavelich's Atari 8-bit
computer game "Dandy" (aka his "Thesis of Terror" at MIT),
from 1983.

The game concept is well-known thanks to Atari Games'
"Gauntlet", which was obviously inflused by "Dandy".
Some concepts from Gauntlet were also borrowed in FOP.

The name "FOP" was chosen as a play on the term "Dandy"
(itself being a play on "D&D", or "Dungeons and Dragons").


Gameplay Overview:
------------------
Up to four players move their characters around a dungeon,
collecting treasure and other items, while avoiding being
killed by monsters.

Each player is armed with a weapon, which they can shoot
in any of 8 directions.  Players can also fight 'hand-to-hand'
against enemies, although this incurs damage to the player's
character.

Each dungeon level begins with various enemies, treasure
and other collectible items placed on it.
This includes 'generators': places in the dungeon that
give rise to new enemies.  Because of this, the more time
you spend in the dungeon, the more enemies there might be.

Some enemies require multiple hits to be destroyed.
Generators that create those enemies also require multiple hits.
(Each hit to a generator causes it to create enemies that
require one less hit.)


Starting a Game:
----------------
From the main menu, press [Enter/Return] or [Space] to
start a new game.

On the new game screen, press [1], [2], [3] or [4] to
change the number of players that will play.

Press [Page Up] or [Page Down] to change the level.
FIXME: It goes from 1-99, regardless of how many
level maps actually exist.

Each player presses their own Left/Right controls to
change which character they will play as. (See "Controls".)
Each active player's character stats will be displayed
below their character:  Health, Weapon and Speed.
(See "Characters".)


Characters:
-----------
There are four characters that each player can choose from,
each with different statistics:

(FIXME: There's no picking yet.)

* Character 1:
  Speed:  Fast   (3)
  Health: Normal (2)
  Weapon: Weak   (1) (Cannot shoot diagonal)

* Character 2:
  Speed:  Slow   (1)
  Health: High   (3)
  Weapon: Normal (2)

* Character 3:
  Speed:  Normal (2)
  Health: Normal (2)
  Weapon: Normal (2)

* Character 4:
  Speed:  Normal (2)
  Health: Low    (1)
  Weapon: Strong (3) (Not absorbed when destroying an enemy)


Collectible Items:
------------------
* Treasure
  This adds to your score.
  When you pass certain score thresholds, your health is raised
  to its current maximum level and, if possible, the maximum
  level itself is increased.

* Key
  Having one or more keys allows you to open a door.
  For each door you open, one of your keys is used.

* Bomb
  This allows the player to instantly damage all enemies
  and generators currently visible on the screen
  (reducing their power, or destroying them if they're already
  at the lowest level).

  You can either collect the bomb, and use it later (see 'Controls'),
  or shoot it with your weapon to activate it immediately.

* Pile (looks like treasure and keys)
  When a player dies, any collectible objects (keys and bombs)
  that they were carrying are placed in a pile on the map
  (at the spot where they died).  It's important to gather
  this, because that player may have had the keys required
  to exit the current dungeon level.

* Food
  Collecting food increases your health.  (It cannot go beyond
  its current maximum level, though.)

  Note: When food is hit by a weapon, it gets destroyed...
  so watch where you're shooting!

* Temporaty Upgrade (a crate with a "?" on the side)
  Collecting a temporary upgrade will improve one of your
  abilities for a limited amount of time.  The ability is
  picked randomly, and if you're already at the limit,
  the upgrade does nothing.
  FIXME: Should it never give out useless bonuses?

  A countdown meter appears next to your other status
  information.  An icon from the player select screen
  appears, denoting which ability is being improved.

  * Health - You are temporarily impervious to attack.
  * Speed - You move more quickly.
  * Weapon - Your weapon is more powerful.


General Controls:
-----------------
Press [Enter/Return] or [Space] to select menu items
or start the game from the game start screen.

Press [Esc] from the game start screen, or within the
game to quit back to the main menu.


Default player controls:
------------------------
Player 1:
  Up:        [Up arrow]
  Down:      [Down arrow]
  Left:      [Left arrow]
  Right:     [Right arrow]
  Fire:      [Ctrl (on right)]
  Bomb:      [1]

Player 2:
  Up:        [W]
  Down:      [S]
  Left:      [A]
  Right:     [D]
  Fire:      [Q]
  Bomb:      [2]

Player 3:
  Up:        [Keypad 8]
  Down:      [Keypad 2]
  Left:      [Keypad 4]
  Right:     [Keypad 6]
  Fire:      [Keypad 0]
  Bomb:      [3]

Player 4:
  Up:        [T]
  Down:      [G]
  Left:      [F]
  Right:     [H]
  Fire:      [R]
  Bomb:      [4]


Overriding player controls:
---------------------------
FIXME: There should be an options menu for this.

In FOP's configuration file ("~/.foprc" on Linux),
controls for each player may be stored.

The control setting lines begin with:

  P#_FIRE = 
  P#_BOMB =
  P#_UP =
  P#_DOWN =
  P#_LEFT =
  P#_RIGHT =

... where "#" is a number between 1 and 4,
corresponding to the player.

For joystick controls, use the value:

  JOYn_BTN#
  JOYn_AXIS#_POS
  JOYn_AXIS#_NEG

Where 'n' is the joystick number, and '#'
is the number of the button or axis on that
controller.

For example, to use a PlayStation controller
attached to a USB connector for player 1,
with the D-pad for movement, (X) for fire and
(O) for bomb, use:

  P1_FIRE = JOY0_BTN2
  P1_BOMB = JOY0_BTN1
  P1_UP = JOY0_AXIS5_NEG
  P1_DOWN = JOY0_AXIS5_POS
  P1_LEFT = JOY0_AXIS4_NEG
  P1_RIGHT = JOY0_AXIS4_POS

For keyboard controls, use the libSDL "SDLK" keysym
value.  (See "/usr/include/SDL/SDL_keysym.h")

For example, to use the keyboard [Up]/[Down]/[Left]/[Right]
arrow keys for movement, the left [Ctrl] key for fire,
and [B] for bomb, for player to, use:

  P2_FIRE = 306
  P2_BOMB = 98
  P2_UP = 273
  P2_DOWN = 274
  P2_LEFT = 276
  P2_RIGHT = 275


Creating maps:
--------------
FIXME: There is no way to select a map.
FIXME: There is no way to exit a map/dungeon.

Map file begins with two lines with numbers.
The first describes the map width, the second the map height.

They should be followed by the map -- "map height" lines,
each "map width" long.

Map characters:

    - Empty space
  # - Wall
  = - Door segment
  % - Exit to next level

  $ - Treasure
  F - Food
  b - Bomb
  k - Key
  ? - Temporary upgrade

  A - Level 1 enemy
  B - Level 2 enemy
  C - Level 3 enemy

  1 - Level 1 generator
  2 - Level 2 generator
  3 - Level 3 generator

  5 - Starting position for player 1
  6 - Starting position for player 2
  7 - Starting position for player 3
  8 - Starting position for player 4

