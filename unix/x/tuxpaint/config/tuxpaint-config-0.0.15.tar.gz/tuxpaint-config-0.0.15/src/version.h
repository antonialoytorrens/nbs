#ifndef VERSION_H
#define VERSION_H

/* Now set in makefile */

#endif /* VERSION_H */

