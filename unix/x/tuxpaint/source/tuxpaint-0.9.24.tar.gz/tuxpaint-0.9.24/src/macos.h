#ifndef __MACOS_H__
#define __MACOS_H__

const char *macos_fontsPath(void);
const char *macos_preferencesPath(void);
const char *macos_globalPreferencesPath(void);


#endif /* __MACOS_H__ */
