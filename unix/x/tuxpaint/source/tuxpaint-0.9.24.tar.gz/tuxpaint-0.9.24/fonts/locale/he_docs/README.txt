README.txt for "tuxpaint-ttf-hebrew"
Hebrew TrueType Font (TTF) for Tux Paint

Bill Kendrick
bill@newbreedsoftware.com
http://www.newbreedsoftware.com/tuxpaint/

August 5, 2003 - August 5, 2003


This font is required to run Tux Paint in Hebrew.
(e.g., with the "--lang hebrew" option)

To install, run "make install" as the superuser ('root').
The font file will be placed in the /usr/share/tuxpaint/fonts/locale/ directory.

