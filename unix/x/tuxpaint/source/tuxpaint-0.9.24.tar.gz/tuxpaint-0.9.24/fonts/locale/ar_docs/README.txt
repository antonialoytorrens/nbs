README.txt for "tuxpaint-ttf-arabic"
Hebrew TrueType Font (TTF) for Tux Paint

Bill Kendrick
bill@newbreedsoftware.com
http://www.newbreedsoftware.com/tuxpaint/

March 28, 2006 - March 28, 2006


This font is required to run Tux Paint in Arabic.
(e.g., with the "--lang arabic" option)

To install, run "make install" as the superuser ('root').
The font file will be placed in the /usr/share/tuxpaint/fonts/locale/
directory.

