README.txt for "tuxpaint-ttf-tibetan"
Tibetan TrueType Font (TTF) for Tux Paint

Bill Kendrick
bill@newbreedsoftware.com
http://www.newbreedsoftware.com/tuxpaint/

March 29, 2006 - March 29, 2006


This font is required to run Tux Paint in Tibetan.
(e.g., with the "--lang tibetan" option)

To install, run "make install" as the superuser ('root').
The font file will be placed in the /usr/share/tuxpaint/fonts/ directory.

