README.txt for "tuxpaint-ttf-georgian"
Georgian TrueType Font (TTF) for Tux Paint

Bill Kendrick
bill@newbreedsoftware.com
http://www.newbreedsoftware.com/tuxpaint/

March 24, 2005 - March 24, 2005


This font is required to run Tux Paint in Georgian.
(e.g., with the "--lang georgian" option)

To install, run "make install" as the superuser ('root').
The font file will be placed in the /usr/share/tuxpaint/fonts/locale/ directory.

