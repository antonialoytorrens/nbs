README.txt for "tuxpaint-ttf-greek"
Greek TrueType Font (TTF) for Tux Paint

Bill Kendrick
bill@newbreedsoftware.com
http://www.newbreedsoftware.com/tuxpaint/

January 13, 2003 - January 13, 2003


This font is required to run Tux Paint in Greek.
(e.g., with the "--lang greek" option)

To install, run "make install" as the superuser ('root').
The font file will be placed in the /usr/share/tuxpaint/fonts/locale/ directory.

