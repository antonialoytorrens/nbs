See [locale]/html/README.html or [locale]/README.txt.

