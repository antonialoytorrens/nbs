#windres -i resources.rc -o resource.o
gcc -O3 -Wl,-subsystem,console -Wall -static win32_dirent.c kpx2png.c -o kpx2png.exe -L/user/local/lib/ -ljpeg -lpng -lz
#gcc -O3 -Wl,-subsystem,windows -Wall -static win32_dirent.c kpx2png.c -o kpx2png.exe -L/user/local/lib/ -ljpeg -lpng -lz
strip -s kpx2png.exe

