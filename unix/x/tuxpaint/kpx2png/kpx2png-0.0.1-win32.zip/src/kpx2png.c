/*
  kpx2png.c

  For Tux Paint
  Windows Utility to convert '.kpx' files to PNG images

  Copyright (C) 2009 by John Popplewell and others
  john@johnnypops.demon.co.uk
  http://www.johnnypops.co.uk/

  Copyright (C) 2002-2006 by Bill Kendrick and others
  bill@newbreedsoftware.com
  http://www.newbreedsoftware.com/tuxpaint/

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
  (See COPYING.txt)

  October 9th 2009
  $Id$
*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "png.h"
#include "jpeglib.h"
#include "win32_dirent.h"

typedef struct _Surface
{
    int             width;
    int             height;
    int             pitch;
    int             bpp;
    unsigned char  *pixels;
} Surface;


static Surface *alloc_surface(int width, int height, int bpp)
{
    Surface *surf = (Surface*)malloc(sizeof(Surface));

    if (surf)
    {
        int     bytespp = bpp/8;

        surf->width  = width;
        surf->height = height;
        surf->bpp    = bpp;
        surf->pitch  = (width*bytespp + bytespp) & -4;
        surf->pixels = (unsigned char*)malloc(surf->pitch*surf->height);
        if (!surf->pixels)
        {
            free(surf);
            return NULL;
        }
    }
    return surf;
}

static void free_surface(Surface **surf)
{
    free((*surf)->pixels);
    free(*surf);
    *surf = NULL;
}


/* png saving based on code from Tux Paint */

static int save_png_file(const char *fname, Surface *surf)
{
    FILE            *fp = NULL;
    png_structp     png_ptr;
    png_infop       info_ptr;
    png_text        text_ptr[4];
    int             y, count;
    unsigned char   **png_rows = NULL;

    if ((fp = fopen(fname, "wb")) == NULL)
    {
        return -1;
    }

    png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    if (png_ptr == NULL)
    {
        fclose(fp);
        png_destroy_write_struct(&png_ptr, NULL);
        return -2;
    }

    info_ptr = png_create_info_struct(png_ptr);
    if (info_ptr == NULL)
    {
        fclose(fp);
        png_destroy_write_struct(&png_ptr, NULL);
        return -3;
    }

    // must be allocated before the setjump
    png_rows = (unsigned char **)malloc(sizeof(unsigned char*) * surf->height);

    if (setjmp(png_jmpbuf(png_ptr)))
    {
        fclose(fp);
        png_destroy_write_struct(&png_ptr, &info_ptr);
        free(png_rows);
        return -4;
    }
    
    png_init_io(png_ptr, fp);

    info_ptr->width = surf->width;
    info_ptr->height = surf->height;
    info_ptr->bit_depth = 8;
    info_ptr->color_type = PNG_COLOR_TYPE_RGB;
    info_ptr->interlace_type = 1;
    info_ptr->valid = 0;

    png_set_sRGB_gAMA_and_cHRM(png_ptr, info_ptr, PNG_sRGB_INTENT_PERCEPTUAL);

    count = 0;

    text_ptr[count].key = (png_charp) "Software";
    text_ptr[count].text = (png_charp) "kpx2png 0.0.1 (09-10-2009)";
    text_ptr[count].compression = PNG_TEXT_COMPRESSION_NONE;
    count++;

    png_set_text(png_ptr, info_ptr, text_ptr, count);

    png_write_info(png_ptr, info_ptr);

    for (y = 0; y < surf->height; y++)
    {
        png_rows[y] = ((unsigned char*)surf->pixels) + y * surf->pitch;
    }
    png_write_image(png_ptr, png_rows);
    free(png_rows);
    png_write_end(png_ptr, NULL);
    png_destroy_write_struct(&png_ptr, &info_ptr);
    fclose(fp);

    return 0;
}


typedef struct
{
    struct jpeg_error_mgr errmgr;
    jmp_buf escape;
} my_error_mgr;

static void my_error_exit(j_common_ptr cinfo)
{
    my_error_mgr *err = (my_error_mgr*)cinfo->err;
    longjmp(err->escape, 1);
}

static Surface *load_jpg_from_kpx(const char *fname)
{
    FILE                            *fp = NULL;
    Surface                         *image = NULL;
    struct jpeg_decompress_struct   cinfo;
    my_error_mgr                    jerr;
    JSAMPROW                        rowptr[1];

    if ((fp = fopen(fname, "rb")) == NULL)
        return NULL;

    fseek(fp, 60, 0);

    cinfo.err = jpeg_std_error(&jerr.errmgr);
    jerr.errmgr.error_exit = my_error_exit;
    if(setjmp(jerr.escape))
    {
        jpeg_destroy_decompress(&cinfo);
        if (image != NULL)
        {
            free_surface(&image);
        }
        if (fp != NULL)
        {
            fclose(fp);
        }
        return NULL;
    }

    jpeg_create_decompress(&cinfo);
    jpeg_stdio_src(&cinfo, fp);
    jpeg_read_header(&cinfo, TRUE);
    if (cinfo.num_components == 4)
    {
        fclose(fp);
        jpeg_destroy_decompress(&cinfo);
        fprintf(stderr, "Unsupported JPG format. Contact John :-)\n");
        return NULL;
    }

    cinfo.out_color_space = JCS_RGB;
    cinfo.quantize_colors = FALSE;
    jpeg_calc_output_dimensions(&cinfo);

    image = alloc_surface(cinfo.output_width, cinfo.output_height, 24);

    jpeg_start_decompress(&cinfo);
    while (cinfo.output_scanline < cinfo.output_height)
    {
        rowptr[0] = (JSAMPROW)(unsigned char*)image->pixels + cinfo.output_scanline * image->pitch;
        jpeg_read_scanlines(&cinfo, rowptr, (JDIMENSION)1);
    }
    jpeg_finish_decompress(&cinfo);
    jpeg_destroy_decompress(&cinfo);
    fclose(fp);
    return image;
}


static int filter_kpx(const struct dirent *entry)
{
    char    ext[256];

    _splitpath(entry->d_name, NULL, NULL, NULL, ext);
    return stricmp(ext, ".kpx") == 0;
}


int main(int argc, char *argv[])
{
    struct dirent **namelist = NULL;
    int             i, n;
    char            *dir = ".";

    if (argc == 2)
    {
        dir = argv[1];
    }
    if (argc > 2 || !stricmp(dir, "-h"))
    {
        fprintf(stdout, "Usage: kpx2png [directory]\n");
        fprintf(stdout, "\n");
        fprintf(stdout, "If directory is omitted, processes files in the current directory.\n");
        fprintf(stdout, "Example: kpx2png \"C:/Documents and Settings/jfp/My Documents/templates\"\n\n");
        exit(0);
    }

    n = scandir(dir, &namelist, filter_kpx, alphasort);
    if (n < 0)
    {
        fprintf(stderr, "No '.kpx' files found in '%s'.\n", dir);
        return -1;
    }
    for(i = 0; i < n; i++)
    {
        char    ipath[256];
        char    *filename = namelist[i]->d_name;
        Surface *image;

        strcpy(ipath, dir);
        strcat(ipath, "/");
        strcat(ipath, filename);
        fprintf(stdout, "Processing '%s' ...\n", ipath);
        image = load_jpg_from_kpx(ipath);
        if (image != NULL)
        {
            char    opath[256];
            char    name[256];

            _splitpath(ipath, NULL, opath, name, NULL);
            strcat(opath, name);
            strcat(opath, ".png");
            fprintf(stdout, "Output: '%s'\n", opath);
            if (save_png_file(opath, image))
            {
                fprintf(stderr, "Error writing '%s'.\n", opath);
            }
        }
        else
        {
            fprintf(stderr, "Unable to load '%s'.\n", ipath);
        }
        free(namelist[i]);
    }
    free(namelist);

    return 0;
}

