README.txt for Virtual Bill Kendrick

by Bill Kendrick
bill@newbreedsoftware.com
http://www.newbreedsoftware.com/

June 3, 2002 - June 3, 2002


Virtual Bill Kendrick simulator in SDL.
Made mainly for the Sharp Zaurus SL-5500 Linux-based PDA, thanks
to an Anonymous comment at LinuxGames.com
( http://www.linuxgames.com/news/index.php3/5677 )


Requires libSDL.  Press SPACE or ENTER, or click to begin.
Press ESCAPE to quit.

Other than that, it doesn't do anything.


Enjoy!  Goodnight!

-bill!

