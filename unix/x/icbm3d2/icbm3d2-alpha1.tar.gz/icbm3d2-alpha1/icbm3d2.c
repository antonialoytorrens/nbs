/*
  icbm3d2.c
  
  ICBM3D/2 - Inter-Continental Ballistic Missiles 3D II
  
  by Bill Kendrick
  nbs@sonic.net
  http://www.newbreedsoftware.com/
  
  January 28, 1999 - March 7, 1999
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <unistd.h>
#include <sys/time.h>
#include <X11/Xlib.h>
#include <GL/glx.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#ifdef SDL_USE_YES
#include <SDL/SDL.h>
#include <SDL/mixer.h>
#endif


/* Keydefs: */

#define HKEY_UP 0
#define HKEY_DOWN 1
#define HKEY_LEFT 2
#define HKEY_RIGHT 3
#define HKEY_AWAY 4
#define HKEY_TOWARDS 5
#define HKEY_ROTATE_UP 6
#define HKEY_ROTATE_DOWN 7
#define HKEY_ROTATE_LEFT 8
#define HKEY_ROTATE_RIGHT 9
#define HKEY_ZOOM_IN 10
#define HKEY_ZOOM_OUT 11
#define NUM_KEYS 12

#define KEY_UP "a"
#define KEY_DOWN "z"
#define KEY_LEFT "Left"
#define KEY_RIGHT "Right"
#define KEY_AWAY "Up"
#define KEY_TOWARDS "Down"
#define KEY_FIRE "space"
#define KEY_ROTATE_UP "Home"
#define KEY_ROTATE_DOWN "End"
#define KEY_ROTATE_LEFT "Delete"
#define KEY_ROTATE_RIGHT "Next"
#define KEY_ZOOM_IN "i"
#define KEY_ZOOM_OUT "o"
#define KEY_PAUSE "p"


/* Title screen controls: */

#define BUTTON_BEGIN 0
#define BUTTON_SETUP 1
#define BUTTON_ABOUT 2
#define BUTTON_QUIT  3
#define NUM_BUTTONS  4

char * button_names[NUM_BUTTONS] = {
  "begin", "setup", "about", "quit"
};


/* Display Lists and Textures */

#define NUM_CITY_TEXS 3
#define NUM_EXPLOSION_TEXS 14
#define NUM_CLOUD_TEXS 2

#define DL_GROUND     1
#define DL_CITY       DL_GROUND + 1
#define DL_EXPLOSION  DL_CITY + NUM_CITY_TEXS
#define DL_CLOUD      DL_EXPLOSION + NUM_EXPLOSION_TEXS
#define DL_MOON       DL_CLOUD + NUM_CLOUD_TEXS
#define DL_STARS      DL_MOON + 1
#define DL_MISSILE    DL_STARS + 1
#define DL_TARGET     DL_MISSILE + 1
#define DL_GUN        DL_TARGET + 1
#define DL_CRATER     DL_GUN + 1
#define DL_BUTTONS    DL_CRATER + 1
#define DL_PAUSE      DL_BUTTONS + NUM_BUTTONS

#define NIGHT_CITY (NUM_CITY_TEXS - 1)


/* Game constraints: */

#define NUM_MISSILES 20
#define NUM_CLOUDS 3
#define NUM_STARS 100
#define NUM_SMOKES 500
#define NUM_EXPLOSIONS 50
#define NUM_BULLETS 100
#define NUM_GUNS 4

#define WIDTH 300
#define HEIGHT 300

#define MAX_EXPLOSION_RADIUS 0.25


/* Useful values: */

#define CANNOT_SPLIT 0
#define CAN_SPLIT 1
#define PICK -1000.0
#define NONE 0


#ifdef SDL_USE_YES
/* SDL audio stuff: */

/* (Sound effects) */

#define SND_FIRE 0
#define SND_EXPLOSION 1
#define SND_SELECT 2
#define NUM_SOUNDS 3

char * soundfiles[NUM_SOUNDS] = {"fire", "explosion", "select"};

Mix_Chunk * sounds[NUM_SOUNDS];

/* (Music) */

#define SONG_1 0
#define SONG_2 1
#define SONG_3 2
#define SONG_4 3
#define SONG_5 4
#define SONG_6 5
#define SONG_7 6
#define SONG_8 7
#define SONG_9 8
#define NUM_SONGS 9  /* <-- */
#define SONG_TITLE 9
#define NUM_MODS 10

Mix_Music * songs[NUM_MODS];

char * songfiles[NUM_MODS] = {"music1.mod", "music2.mod", "music3.mod",
			      "music4.mod", "music5.mod", "music6.mod",
			      "music7.mod", "music8.mod", "music9.mod",
			      "title.xm"};
#endif


/* Level waves: */

#define MAX_LEVELS 7

int level_waves[MAX_LEVELS][4] = {
  {3, 0, 0},
  {3, 3, 0},
  {5, 0, 0},
  {5, 3, 0},
  {5, 5, 3},
  {9, 3, 4},
  {7, 3, 1}
};


/* Typedefs: */

typedef struct {
    int sizeX, sizeY;
    GLubyte *data;
} PPMImage;

typedef struct {
  int alive, wait;
  int spiraller, splitter;
  float x, y, z;
  float destx, desty, destz;
  float xm, ym, zm;
} missile_type;

typedef struct {
  int alive, owner;
  float intensity;
  float x, y, z;
} smoke_type;

typedef struct {
  int alive, explosion_frame;
  float x, y, z;
  int color;
} city_type;

typedef struct {
  int tex;
  float a, y;
} cloud_type;

typedef struct {
  int alive;
  float x, y, z, radius;
  float rm;
} explosion_type;

typedef struct {
  int alive;
  float x, y, z;
  float destx, desty, destz;
  float xm, ym, zm;
  int channel;
} bullet_type;

typedef struct {
  int alive;
  float x, y, z;
  int bullets;
} gun_type;


/* Game Globals: */

missile_type missiles[NUM_MISSILES];
city_type cities[4][4];
cloud_type clouds[NUM_CLOUDS];
smoke_type smokes[NUM_SMOKES];
explosion_type explosions[NUM_EXPLOSIONS];
bullet_type bullets[NUM_BULLETS];
gun_type guns[NUM_GUNS];
int timer, anglex, angley, level, wave;
float target_x, target_y, target_z, zoom;


/* X11, GL and SDL Globals: */

Bool doublebuffer;
GLXContext cx;
Display * dpy;
Window win;
static GLuint city_textures[NUM_CITY_TEXS],
  gun_textures[1],
  crater_textures[1],
  moon_textures[1],
  explosion_textures[NUM_EXPLOSION_TEXS],
  cloud_textures[NUM_CLOUD_TEXS],
  button_textures[NUM_BUTTONS],
  pause_textures[1];
int channel, current_song;
PPMImage * title_image;


/* Local function prototypes: */

void setup(int argc, char * argv[]);
void game(void);
void dlinit(void);
void redraw(void);
void fatalerror(char * reason);
static PPMImage *LoadPPM(const char *filename, int use_alpha);
void addsmoke(float x, float y, float z, int owner);
void killmissile(int which);
float distance(float x1, float y1, float z1, float x2, float y2, float z2);
void firebullet(void);
void addexplosion(float x, float y, float z);
int title(int selected);
void addmissile(int splitable, float x, float y, float z);
void pause_screen(void);


/* External function prototypes: */

typedef unsigned short UWORD;


/* --- MAIN --- */

int main(int argc, char * argv[])
{
  int ret;
  
  setup(argc, argv);
  
  ret = BUTTON_BEGIN;
  
  do
    {
      ret = title(ret);
      
      if (ret == BUTTON_BEGIN)
	{
#ifdef SDL_USE_YES
	  Mix_HaltMusic();
#endif
	  level = 0;
	  wave = 0;
	  
	  game();
	}
      else if (ret == BUTTON_ABOUT)
	  ;
      else if (ret == BUTTON_SETUP)
	  ;
    }
  while (ret != BUTTON_QUIT);
  
  
  return(0);
}


/* Game: */

void game(void)
{
  XEvent event;
  KeySym keysym;
  XComposeStatus composestatus;
  int x, z, i, j, old_button, old_x, old_y, num_missiles,
    just_begun;
  float x_change, y_change, z_change;
  char key[128];
  int key_holds[NUM_KEYS];
  
  
  /* Init game: */
  
  /* (Guns) */
  
  for (i = 0; i < NUM_GUNS; i++)
    {
      guns[i].alive = 1;
      guns[i].x = -1.5 + (i / 2) * 3.0;
      guns[i].y = 0.0;
      guns[i].z = -1.5 + (i % 2) * 3.0;
      guns[i].bullets = 100;
    }
  
  
  /* (Missiles) */
  
  for (i = 0; i < NUM_MISSILES; i++)
    missiles[i].alive = 0;
  
  
  /* (Smoke) */
  
  for (i = 0; i < NUM_SMOKES; i++)
    smokes[i].alive = 0;
  
  
  /* (Bullets) */
  
  for (i = 0; i < NUM_BULLETS; i++)
    bullets[i].alive = 0;
  
  
  /* (Explosions) */
  
  for (i = 0; i < NUM_EXPLOSIONS; i++)
    explosions[i].alive = 0;
  
  
  /* (Cities) */
  
  for (z = 0; z < 4; z++)
    {
      for (x = 0; x < 4; x++)
	{
	  cities[z][x].alive = 1;
	  cities[z][x].color = rand() % NIGHT_CITY;
	  cities[z][x].x = x * 0.8 - 1.2;
	  cities[z][x].y = 0.0;
	  cities[z][x].z = z * 0.8 - 1.2;
	}
    }
  
  
  /* (Clouds) */
  
  for (i = 0; i < NUM_CLOUDS; i++)
    {
      clouds[i].tex = rand() % NUM_CLOUD_TEXS;
      clouds[i].a = (rand() % 360);
      clouds[i].y = (i + 2) % 3 + 3.0;
    }
  
  
  /* (Cursor) */

  target_x = 0.0;
  target_y = 2.0;
  target_z = 0.0;
  
  
  /* (View) */
  
  anglex = 0;
  angley = 20;
  zoom = -4.0;
  
  
  /* (X Input) */
  
  old_button = -1;
  old_x = -1;
  old_y = -1;
  strcpy(key, "");
  for (i = 0; i < 6; i++)
    key_holds[i] = KeyRelease;
  
  
  /* MAIN LOOP: */
  
  timer = 0;
  j = 0;
  
  just_begun = 1;
  
  do
    {
      x_change = 0;
      y_change = 0;
      z_change = 0;
      
      
      /* Handle Events: */
      
      if (XPending(dpy))
	{
	  do
	    {
	      XNextEvent(dpy, &event);
	      
	      if (event.type == ButtonPress)
		{
		  /* Keep track of buttons: */
		  
		  old_button = event.xbutton.button;
		  old_x = event.xbutton.x;
		  old_y = event.xbutton.y;
		}
	      else if (event.type == MotionNotify)
		{
		  /* Mouse Controls: */
		  
		  if (old_button == Button1)
		    {
		      /* Move left/right, up/down: */
		      
		      x_change = (event.xbutton.x - old_x) / 50.0;
		      y_change = -(event.xbutton.y - old_y) / 50.0;
		    }
		  else if (old_button == Button2)
		    {
		      /* Move left/right, in/out: */
		      
		      x_change = (event.xbutton.x - old_x) / 50.0;
		      z_change = (event.xbutton.y - old_y) / 50.0;
		    }
		  else if (old_button == Button3)
		    {
		      /* Rotate angle: */
		      
		      anglex = anglex + event.xbutton.x - old_x;
		      angley = angley + event.xbutton.y - old_y;
		    }
		  
		  
		  /* Keep track of old spot again: */
		  
		  old_x = event.xbutton.x;
		  old_y = event.xbutton.y;
		}
	      else if (event.type == KeyPress || event.type == KeyRelease)
		{
		  XLookupString(&event.xkey, key, 1, &keysym, &composestatus);
		  
		  if (XKeysymToString(keysym) != NULL)
		    strcpy(key, XKeysymToString(keysym));

		  
		  /* Movement keys (can be held down indefinitely) */
		  
		  if (strcmp(key, KEY_UP) == 0)
		    key_holds[HKEY_UP] = event.type;
		  else if (strcmp(key, KEY_DOWN) == 0)
		    key_holds[HKEY_DOWN] = event.type;
		  else if (strcmp(key, KEY_LEFT) == 0)
		    key_holds[HKEY_LEFT] = event.type;
		  else if (strcmp(key, KEY_RIGHT) == 0)
		    key_holds[HKEY_RIGHT] = event.type;
		  else if (strcmp(key, KEY_AWAY) == 0)
		    key_holds[HKEY_AWAY] = event.type;
		  else if (strcmp(key, KEY_TOWARDS) == 0)
		    key_holds[HKEY_TOWARDS] = event.type;
		  else if (strcmp(key, KEY_ROTATE_UP) == 0)
		    key_holds[HKEY_ROTATE_UP] = event.type;
		  else if (strcmp(key, KEY_ROTATE_DOWN) == 0)
		    key_holds[HKEY_ROTATE_DOWN] = event.type;
		  else if (strcmp(key, KEY_ROTATE_LEFT) == 0)
		    key_holds[HKEY_ROTATE_LEFT] = event.type;
		  else if (strcmp(key, KEY_ROTATE_RIGHT) == 0)
		    key_holds[HKEY_ROTATE_RIGHT] = event.type;
		  else if (strcmp(key, KEY_ZOOM_IN) == 0)
		    key_holds[HKEY_ZOOM_IN] = event.type;
		  else if (strcmp(key, KEY_ZOOM_OUT) == 0)
		    key_holds[HKEY_ZOOM_OUT] = event.type;
		  
		  
		  /* Normal keys (strike to activate) */
		  
		  if (event.type == KeyPress)
		    {
		      if (strcmp(key, KEY_FIRE) == 0)
			{
			  /* Space - FIRE: */
			  
			  firebullet();
			}
		      else if (strcmp(key, KEY_PAUSE) == 0)
			{
			  /* P - Pause: */
			  
			  pause_screen();
			}
		    }
		}
	    }
	  while (XPending(dpy));
	}


      /* Deal with held keys: */
      
      if (key_holds[HKEY_RIGHT] == KeyPress)
	x_change = x_change + 0.125;
      if (key_holds[HKEY_LEFT] == KeyPress)
	x_change = x_change - 0.125;
      if (key_holds[HKEY_UP] == KeyPress)
	y_change = y_change + 0.125;
      if (key_holds[HKEY_DOWN] == KeyPress)
	y_change = y_change - 0.125;
      if (key_holds[HKEY_TOWARDS] == KeyPress)
	z_change = z_change + 0.125;
      if (key_holds[HKEY_AWAY] == KeyPress)
	z_change = z_change - 0.125;
      
      if (key_holds[HKEY_ROTATE_UP] == KeyPress)
	angley = angley + 2.0;
      if (key_holds[HKEY_ROTATE_DOWN] == KeyPress)
	angley = angley - 2.0;
      if (key_holds[HKEY_ROTATE_LEFT] == KeyPress)
	anglex = anglex + 2.0;
      if (key_holds[HKEY_ROTATE_RIGHT] == KeyPress)
	anglex = anglex - 2.0;  
      if (key_holds[HKEY_ZOOM_IN] == KeyPress)
	zoom = zoom + 0.25;
      if (key_holds[HKEY_ZOOM_OUT] == KeyPress)
	zoom = zoom - 0.25;

      
      /* Move target: */
      
      target_x = target_x + x_change;
      target_y = target_y + y_change;
      target_z = target_z + z_change;
      
      
      /* Keep target within limits: */
      
      if (target_x < -1.8)
	target_x = -1.8;
      else if (target_x > 1.8)
	target_x = 1.8;
      
      if (target_y < 0.0)
	target_y = 0.0;
      else if (target_y > 4.0)
	target_y = 4.0;
      
      if (target_z < -1.8)
	target_z = -1.8;
      else if (target_z > 1.8)
	target_z = 1.8;
      
      
      /* Keep rotation angle sane: */
      
      if (anglex < -30)
	anglex = -30;
      else if (anglex > 30)
	anglex = 30;
      
      if (angley < -30)
	angley = -30;
      else if (angley > 40)
	angley = 40;
      

      /* Keep zoom good: */
      
      if (zoom < -4.0)
	zoom = -4.0;
      else if (zoom > -1.0)
	zoom = -1.0;
      
      
      /* Increment timer: */
      
      timer++;
      
      
      /* Handle missiles: */
      
      num_missiles = 0;
      
      for (i = 0; i < NUM_MISSILES; i++)
	{
	  if (missiles[i].alive == 1)
	    {
	      num_missiles++;
	      
	      if (missiles[i].wait > 0)
		missiles[i].wait--;
	      else
		{
		  /* Move missile: */
		  
		  missiles[i].x = missiles[i].x + missiles[i].xm;
		  missiles[i].y = missiles[i].y + missiles[i].ym;
		  missiles[i].z = missiles[i].z + missiles[i].zm;
		  
		  
		  /* Add smoke: */
		  
		  if ((rand() % 5) < 1)
		    {
		      addsmoke(missiles[i].x,
			       missiles[i].y + .15 - missiles[i].ym * 2.0,
			       missiles[i].z,
			       i);
		    }
		  
		  
		  /* Explode if an explosion hits it: */
		  
		  for (j = 0; j < NUM_EXPLOSIONS; j++)
		    {
		      if (explosions[j].alive == 1 && missiles[i].alive == 1)
			{
			  if (distance(missiles[i].x,
				       missiles[i].y,
				       missiles[i].z,
				       explosions[j].x,
				       explosions[j].y,
				       explosions[j].z) <=
			      explosions[j].radius)
			    killmissile(i);
			}
		    }
		  
		  
		  /* Explode if it hits the ground: */
		  
		  if (missiles[i].y <= 0.0 && missiles[i].alive == 1)
		    killmissile(i);
		}
	    }
	}
      
      
      /* Add new missiles? */
      
      if (num_missiles == 0)
	{
	  printf("Level: %d  Wave: %d   == %d\n",
		 level, wave, level_waves[level][wave]);
	  
	  for (i = 0; i < level_waves[level][wave]; i++)
	    addmissile(CANNOT_SPLIT, PICK, 4.0, PICK);
	  
	  wave++;
	  
	  if (wave >= 3)
	    {
	      level++;
	      wave = 0;
	      
	      if (level >= MAX_LEVELS)
		level = MAX_LEVELS - 1;
	    }
	}
      
      
      /* Handle smoke: */
      
      for (i = 0; i < NUM_SMOKES; i++)
	{
	  if (smokes[i].alive == 1)
	    {
	      /* Move randomly: */
	      
	      if (smokes[i].intensity < 0.4 && (rand() % 10) < 2)
		{
		  smokes[i].x = smokes[i].x +
		    (float) ((rand() % 10) - 5.0) / 1000.0;
		  smokes[i].z = smokes[i].z +
		    (float) ((rand() % 10) - 5.0) / 1000.0;
		}
	      
	      
	      /* Decrease intensity: */
	      
	      smokes[i].intensity = smokes[i].intensity - 0.00125;
	      
	      if (smokes[i].intensity <= 0.0)
		smokes[i].alive = 0;
	    }
	}
      
      
      /* Handle bullets: */
      
      for (i = 0; i < NUM_BULLETS; i++)
	{
	  if (bullets[i].alive == 1)
	    {
	      bullets[i].x = bullets[i].x + bullets[i].xm;
	      bullets[i].y = bullets[i].y + bullets[i].ym;
	      bullets[i].z = bullets[i].z + bullets[i].zm;
	      
	      if (distance(bullets[i].x, bullets[i].y, bullets[i].z,
			   bullets[i].destx,
			   bullets[i].desty,
			   bullets[i].destz) <= 0.2)
		{
		  bullets[i].alive = 0;
		  
#ifdef SDL_USE_YES
		  Mix_HaltChannel(bullets[i].channel);
#endif
		  addexplosion(bullets[i].destx,
			       bullets[i].desty,
			       bullets[i].destz);
		}
	    }
	}
      
      
      /* Handle explosions: */
      
      for (i = 0; i < NUM_EXPLOSIONS; i++)
	{
	  if (explosions[i].alive == 1)
	    {
	      explosions[i].radius = explosions[i].radius + explosions[i].rm;
	      
	      if (explosions[i].radius >= MAX_EXPLOSION_RADIUS)
		explosions[i].rm = -explosions[i].rm;
	      if (explosions[i].radius <= 0)
		explosions[i].alive = 0;
	    }
	}
      
      
      /* Handle cities: */
      
      for (z = 0; z < 4; z++)
	{
	  for (x = 0; x < 4; x++)
	    {
	      if (cities[z][x].alive == 1)
		{
		  /* Check to make sure we're not blown up: */
		  
		  for (i = 0; i < NUM_EXPLOSIONS; i++)
		    {
		      if (explosions[i].alive == 1 &&
			  distance(cities[z][x].x,
				   cities[z][x].y,
				   cities[z][x].z,
				   explosions[i].x,
				   explosions[i].y,
				   explosions[i].z) <= explosions[i].radius)
			{
			  cities[z][x].alive = 0;
			  cities[z][x].explosion_frame = 0;
			}
		    }
		}
	      
	      
	      /* Animate explosion: */
	      
	      if (cities[z][x].alive == 0 &&
		  cities[z][x].explosion_frame <= NUM_EXPLOSION_TEXS)
		{
		  if (timer % 2 == 0)
		    cities[z][x].explosion_frame++;
		}
	    }
	}

      
      /* Move clouds: */
      
      for (i = 0; i < NUM_CLOUDS; i++)
	{
	  clouds[i].a = clouds[i].a + 0.25;
	}
      
      
      /* Redraw window: */
      
      glMatrixMode(GL_MODELVIEW);
      glLoadIdentity();
      
      glTranslatef(0.0, -1.5, zoom);
      glRotatef(angley, 0.1, 0.0, 0.0);
      glRotatef(anglex, 0.0, 0.1, 0.0);
      
      redraw();
      
      
      /* Play music: */

#ifdef SDL_USE_YES
      if (!Mix_PlayingMusic() || just_begun == 1)
	{
	  just_begun = 0;
	  current_song = rand() % NUM_SONGS;
	  printf("%s\n", songfiles[current_song]);
	  Mix_PlayMusic(songs[current_song]);
	}
#endif
    }
  while (strcmp(key, "Escape") != 0);
  
  
  /* Stop sounds: */
  
#ifdef SDL_USE_YES
  Mix_HaltMusic();

  for (i = 0; i < MIX_CHANNELS; i++)
    Mix_HaltChannel(i);
#endif
}


/* Create display lists: */

void dlinit(void)
{
  PPMImage *image;
  char temp[1024];
  int i;
  float sweep, height, x, y, z;
  
  
  /* Ground: */
  
  glNewList(DL_GROUND, GL_COMPILE_AND_EXECUTE);
  {
    glColor3f(0.0, 0.2, 0.0);
    
    glBegin(GL_QUADS);
    {
      glVertex3f(-10, -0.001, -10);
      glVertex3f(-10, -0.001, 10);
      glVertex3f(10, -0.001, 10);
      glVertex3f(10, -0.001, -10);
    }
    glEnd();
  }
  glEndList();
  
  
  /* City: */
  
  glGenTextures(NUM_CITY_TEXS, city_textures);
  
  for (i = 0; i < NUM_CITY_TEXS; i++)
    {
      /* (Load skyscraper PPM) */
      
      sprintf(temp, "textures/city%d.ppm", i);
      
      image = LoadPPM(temp, 0);
      
      glBindTexture(GL_TEXTURE_2D, city_textures[i]);
      gluBuild2DMipmaps(GL_TEXTURE_2D, 3, image->sizeX, image->sizeY,
			GL_RGB, GL_UNSIGNED_BYTE, image->data);
      glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
      
      /* (Start display list) */
      
      glNewList(DL_CITY + i, GL_COMPILE_AND_EXECUTE);
      {
	glEnable(GL_TEXTURE_2D);  
	{
	  glBindTexture(GL_TEXTURE_2D, city_textures[i]);
	  
	  
	  /* (Front) */
	  
	  glBegin(GL_QUADS);
	  {
	    glTexCoord2f(0.0, 0.0);  glVertex3f(-0.1, 0.0, 0.1);
	    glTexCoord2f(1.0, 0.0);  glVertex3f(0.1, 0.0, 0.1);
	    glTexCoord2f(1.0, 1.0);  glVertex3f(0.1, 0.5, 0.1);
	    glTexCoord2f(0.0, 1.0);  glVertex3f(-0.1, 0.5, 0.1);
	  }
	  glEnd();
	  
	  
	  /* (Right) */
	  
	  glBegin(GL_QUADS);
	  {
	    glTexCoord2f(0.0, 1.0);  glVertex3f(0.1, 0.5, -0.1);
	    glTexCoord2f(1.0, 1.0);  glVertex3f(0.1, 0.5, 0.1);
	    glTexCoord2f(1.0, 0.0);  glVertex3f(0.1, 0.0, 0.1);
	    glTexCoord2f(0.0, 0.0);  glVertex3f(0.1, 0.0, -0.1);
	  }
	  glEnd();
	  
	  
	  /* (Left) */
	  
	  glBegin(GL_QUADS);
	  {
	    glTexCoord2f(0.0, 0.0);  glVertex3f(-0.1, 0.0, -0.1);
	    glTexCoord2f(1.0, 0.0);  glVertex3f(-0.1, 0.0, 0.1);
	    glTexCoord2f(1.0, 1.0);  glVertex3f(-0.1, 0.5, 0.1);
	    glTexCoord2f(0.0, 1.0);  glVertex3f(-0.1, 0.5, -0.1);
	  }
	  glEnd();
	  
	  
	  /* (Back) */
	  
	  /* glBegin(GL_QUADS);
	  {
	    glTexCoord2f(0.0, 0.0);  glVertex3f(-0.1, 0.0, -0.1);
	    glTexCoord2f(1.0, 0.0);  glVertex3f(0.1, 0.0, -0.1);
	    glTexCoord2f(1.0, 1.0);  glVertex3f(0.1, 0.5, -0.1);
	    glTexCoord2f(0.0, 1.0);  glVertex3f(-0.1, 0.5, -0.1);
	  }
	  glEnd(); */
	}
	glDisable(GL_TEXTURE_2D);
	
	
	/* (Top) */
	
	glBegin(GL_QUADS);
	{
	  if (i < NIGHT_CITY)
	    glColor3f(0.8, 0.8, 0.8);
	  else
	    glColor3f(0.1, 0.1, 0.1);

	  glVertex3f(-0.1, 0.5, 0.1);
	  glVertex3f(0.1, 0.5, 0.1);
	  glVertex3f(0.1, 0.5, -0.1);
	  glVertex3f(-0.1, 0.5, -0.1);
	}
	glEnd();
	
	
	/* (Shadow) */
	
	glBegin(GL_QUADS);
	{
	  glColor3f(0.0, 0.0, 0.0);
	  glVertex3f(0.1, 0.0, 0.1);
	  glVertex3f(0.3, 0.0, 0.1);
	  glVertex3f(0.3, 0.0, -0.1);
	  glVertex3f(0.1, 0.0, -0.1);
	}
	glEnd();
      }
      glEndList();
    }
  
  
  /* Gun: */
  
  glGenTextures(1, gun_textures);
  
  /* (Load gun texture PPM) */
  
  sprintf(temp, "textures/gun.ppm");
  
  image = LoadPPM(temp, 0);
  
  glBindTexture(GL_TEXTURE_2D, gun_textures[0]);
  gluBuild2DMipmaps(GL_TEXTURE_2D, 3, image->sizeX, image->sizeY,
		    GL_RGB, GL_UNSIGNED_BYTE, image->data);
  glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  
  /* (Start display list) */
  
  glNewList(DL_GUN, GL_COMPILE_AND_EXECUTE);
  {
    glEnable(GL_TEXTURE_2D);  
    {
      glBindTexture(GL_TEXTURE_2D, city_textures[i]);
      
      
      /* (Front) */
      
      glBegin(GL_QUADS);
      {
	glTexCoord2f(0.0, 0.0);  glVertex3f(-0.25, 0.0, 0.25);
	glTexCoord2f(1.0, 0.0);  glVertex3f(0.25, 0.0, 0.25);
	glTexCoord2f(1.0, 1.0);  glVertex3f(0.2, 0.25, 0.2);
	glTexCoord2f(0.0, 1.0);  glVertex3f(-0.2, 0.25, 0.2);
      }
      glEnd();


      /* (Right) */
      
      glBegin(GL_QUADS);
      {
	glTexCoord2f(0.0, 1.0);  glVertex3f(0.2, 0.25, -0.2);
	glTexCoord2f(1.0, 1.0);  glVertex3f(0.2, 0.25, 0.2);
	glTexCoord2f(1.0, 0.0);  glVertex3f(0.25, 0.0, 0.25);
	glTexCoord2f(0.0, 0.0);  glVertex3f(0.25, 0.0, -0.25);
      }
      glEnd();
      
      
      /* (Left) */
      
      glBegin(GL_QUADS);
      {
	glTexCoord2f(0.0, 0.0);  glVertex3f(-0.25, 0.0, -0.25);
	glTexCoord2f(1.0, 0.0);  glVertex3f(-0.25, 0.0, 0.25);
	glTexCoord2f(1.0, 1.0);  glVertex3f(-0.2, 0.25, 0.2);
	glTexCoord2f(0.0, 1.0);  glVertex3f(-0.2, 0.25, -0.2);
      }
      glEnd();


      /* (Top) */
      
      glBegin(GL_QUADS);
      {
	glTexCoord2f(0.0, 1.0);  glVertex3f(-0.2, 0.25, 0.2);
	glTexCoord2f(1.0, 1.0);  glVertex3f(0.2, 0.25, 0.2);
	glTexCoord2f(1.0, 0.0);  glVertex3f(0.2, 0.25, -0.2);
	glTexCoord2f(0.0, 0.0);  glVertex3f(-0.2, 0.25, -0.2);
      }
      glEnd();


      /* (Turret) */
      
      glBegin(GL_TRIANGLE_FAN);
      {
	glTexCoord2f(0.5, 0.0);  glVertex3f(0.0, 0.75, 0.0);
	glTexCoord2f(0.0, 1.0);  glVertex3f(-0.1, 0.25, 0.1);
	glTexCoord2f(1.0, 1.0);  glVertex3f(0.1, 0.25, 0.1);
	glTexCoord2f(0.0, 1.0);  glVertex3f(0.0, 0.25, -0.1);
	glTexCoord2f(0.5, 0.0);  glVertex3f(-0.1, 0.25, 0.1);
      }
      glEnd();
    }
    glDisable(GL_TEXTURE_2D);
  }
  glEndList();


  /* Crater: */
  
  glGenTextures(1, crater_textures);
  
  /* (Load crater texture PPM) */
  
  sprintf(temp, "textures/crater.ppm");
  
  image = LoadPPM(temp, 0);
  
  glBindTexture(GL_TEXTURE_2D, crater_textures[0]);
  gluBuild2DMipmaps(GL_TEXTURE_2D, 3, image->sizeX, image->sizeY,
		    GL_RGB, GL_UNSIGNED_BYTE, image->data);
  glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  
  /* (Start display list) */
  
  glNewList(DL_CRATER, GL_COMPILE_AND_EXECUTE);
  {
    glEnable(GL_TEXTURE_2D);  
    {
      glBindTexture(GL_TEXTURE_2D, crater_textures[0]);
      
      glBegin(GL_QUADS);
      {
	glTexCoord2f(0.0, 0.0);  glVertex3f(-0.2, 0.01, 0.2);
	glTexCoord2f(1.0, 0.0);  glVertex3f(0.2, 0.01, 0.2);
	glTexCoord2f(1.0, 1.0);  glVertex3f(0.2, 0.01, -0.2);
	glTexCoord2f(0.0, 1.0);  glVertex3f(-0.2, 0.01, -0.2);
      }
      glEnd();
    }
    glDisable(GL_TEXTURE_2D);
  }
  glEndList();
  
  
  /* Moon: */
  
  glGenTextures(1, moon_textures);
  
  /* (Load moon texture PPM) */
  
  sprintf(temp, "textures/moon.ppm");
  
  image = LoadPPM(temp, 0);
  
  glBindTexture(GL_TEXTURE_2D, moon_textures[0]);
  gluBuild2DMipmaps(GL_TEXTURE_2D, 3, image->sizeX, image->sizeY,
		    GL_RGB, GL_UNSIGNED_BYTE, image->data);
  glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  
  /* (Start display list) */
  
  glNewList(DL_MOON, GL_COMPILE_AND_EXECUTE);
  {
    glEnable(GL_TEXTURE_2D);  
    {
      glBindTexture(GL_TEXTURE_2D, moon_textures[0]);
      
      glBegin(GL_QUADS);
      {
	glTexCoord2f(0.0, 0.0);  glVertex3f(-3.0, 4.0, -4.0);
	glTexCoord2f(1.0, 0.0);  glVertex3f(-2.0, 4.0, -4.0);
	glTexCoord2f(1.0, 1.0);  glVertex3f(-2.0, 5.0, -4.0);
	glTexCoord2f(0.0, 1.0);  glVertex3f(-3.0, 5.0, -4.0);
      }
      glEnd();
    }
    glDisable(GL_TEXTURE_2D);
  }
  glEndList();
  
  
  /* Explosion: */
  
  glGenTextures(NUM_EXPLOSION_TEXS, explosion_textures);
  
  for (i = 0; i < NUM_EXPLOSION_TEXS; i++)
    {
      /* (Load explosion PPM) */
      
      sprintf(temp, "textures/explosion%d.ppm", i);
      
      image = LoadPPM(temp, 1);
      
      glBindTexture(GL_TEXTURE_2D, explosion_textures[i]);
      gluBuild2DMipmaps(GL_TEXTURE_2D, 3, image->sizeX, image->sizeY,
			GL_RGBA, GL_UNSIGNED_BYTE, image->data);
      glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
      
      /* (Start display list) */
      
      glNewList(DL_EXPLOSION + i, GL_COMPILE_AND_EXECUTE);
      {
	glEnable(GL_TEXTURE_2D);
	{
	  glBindTexture(GL_TEXTURE_2D, explosion_textures[i]);
	  glBlendFunc(GL_ONE, GL_ONE);
	  glEnable(GL_BLEND);
	  
	  
	  /* (Front) */
	  
	  glBegin(GL_QUADS);
	  {
	    glColor4f(1.0, 1.0, 1.0, 1.0);
	    glTexCoord2f(0.0, 1.0);  glVertex3f(-0.5, 0.0, 0.0);
	    glTexCoord2f(1.0, 1.0);  glVertex3f(0.5, 0.0, 0.0);
	    glTexCoord2f(1.0, 0.0);  glVertex3f(0.5, 1.0, 0.0);
	    glTexCoord2f(0.0, 0.0);  glVertex3f(-0.5, 1.0, 0.0);
	  }
	  glEnd();

	  glDisable(GL_BLEND);
	}
	glDisable(GL_TEXTURE_2D);
      }
      glEndList();
    }
  
  
  /* Clouds: */
  
  glGenTextures(NUM_CLOUD_TEXS, cloud_textures);
  
  for (i = 0; i < NUM_CLOUD_TEXS; i++)
    {
      /* (Load cloud PPM) */
      
      sprintf(temp, "textures/cloud%d.ppm", i);
      
      image = LoadPPM(temp, 0);
      
      glBindTexture(GL_TEXTURE_2D, cloud_textures[i]);
      gluBuild2DMipmaps(GL_TEXTURE_2D, 3, image->sizeX, image->sizeY,
			GL_RGB, GL_UNSIGNED_BYTE, image->data);
      glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
      
      /* (Start display list) */
      
      glNewList(DL_CLOUD + i, GL_COMPILE_AND_EXECUTE);
      {
	glEnable(GL_TEXTURE_2D);
	{
	  glBindTexture(GL_TEXTURE_2D, cloud_textures[i]);
	  
	  
	  /* (Front) */
	  
	  glBegin(GL_QUADS);
	  {
	    glColor4f(1.0, 1.0, 1.0, 1.0);
	    glTexCoord2f(0.0, 1.0);  glVertex3f(-1.5, 0.0, 0.0);
	    glTexCoord2f(1.0, 1.0);  glVertex3f(1.5, 0.0, 0.0);
	    glTexCoord2f(1.0, 0.0);  glVertex3f(1.5, 1.0, 0.0);
	    glTexCoord2f(0.0, 0.0);  glVertex3f(-1.5, 1.0, 0.0);
	  }
	  glEnd();
	}
	glDisable(GL_TEXTURE_2D);
      }
      glEndList();
    }


  /* Stars: */
  
  glNewList(DL_STARS, GL_COMPILE_AND_EXECUTE);
  {
    glColor3f(1.0, 1.0, 1.0);
    glBegin(GL_POINTS);
    {
      for (i = 0; i < NUM_STARS; i++)
	{
	  sweep = (rand() % 180) * 180.0 / M_PI;
	  height = (rand() % 90) * 180.0 / M_PI;
	  
	  x = 7.0 * cos(sweep) * cos(height);
	  y = abs(7.0 * sin(height));
	  z = -7.0 * (sin(sweep) * cos(height));
	  
	  glVertex3f(x, y, z);
	}
    }
    glEnd();
  }
  glEndList();
  
  
  /* Missile: */
  
  glNewList(DL_MISSILE, GL_COMPILE_AND_EXECUTE);
  {
    glBegin(GL_TRIANGLE_FAN);
    {
      glColor3f(1.0, 1.0, 0.0);  glVertex3f(0.0, 0.0, 0.0);
      /* glColor3f(0.0, 0.0, 0.0);  glVertex3f(-0.5, 1.5, -0.5); */
      glColor3f(1.0, 1.0, 0.0);  glVertex3f(0.5, 1.5, -0.5);
      glColor3f(0.0, 0.0, 0.0);  glVertex3f(0.0, 1.5, 0.5);
      glColor3f(0.5, 0.5, 0.0);  glVertex3f(-0.5, 1.5, -0.5);
    }
    glEnd();
  }
  glEndList();
  
  
  /* Target: */
  
  glNewList(DL_TARGET, GL_COMPILE_AND_EXECUTE);
  {
    glBegin(GL_LINES);
    {
      glVertex3f(-0.125, 0.0, 0.0);
      glVertex3f(0.125, 0.0, 0.0);
      
      glVertex3f(0.0, -0.125, 0.0);
      glVertex3f(0.0, 0.125, 0.0);
      
      glVertex3f(0.0, 0.0, -0.125);
      glVertex3f(0.0, 0.0, 0.125);
    }
    glEnd();
  }
  glEndList();


  /* Title screen: */
  
  sprintf(temp, "textures/title.ppm");
  title_image = LoadPPM(temp, 0);
  

  /* Button: */
  
  glGenTextures(NUM_BUTTONS, button_textures);
  
  for (i = 0; i < NUM_BUTTONS; i++)
    {
      /* (Load button PPM) */
      
      sprintf(temp, "textures/%s-button.ppm", button_names[i]);
      
      image = LoadPPM(temp, 1);
      
      glBindTexture(GL_TEXTURE_2D, button_textures[i]);
      gluBuild2DMipmaps(GL_TEXTURE_2D, 3, image->sizeX, image->sizeY,
			GL_RGBA, GL_UNSIGNED_BYTE, image->data);
      glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
      
      /* (Start display list) */
      
      glNewList(DL_BUTTONS + i, GL_COMPILE_AND_EXECUTE);
      {
	glEnable(GL_TEXTURE_2D);
	{
	  glBindTexture(GL_TEXTURE_2D, button_textures[i]);
	  
	  
	  glBegin(GL_QUADS);
	  {
	    /* (Front) */
	    
	    glTexCoord2f(0.0, 1.0);  glVertex3f(-0.375, -0.125, 0.125);
	    glTexCoord2f(1.0, 1.0);  glVertex3f(0.375, -0.125, 0.125);
	    glTexCoord2f(1.0, 0.0);  glVertex3f(0.375, 0.125, 0.125);
	    glTexCoord2f(0.0, 0.0);  glVertex3f(-0.375, 0.125, 0.125);
	    
	    /* (Bottom) */
	    
	    glTexCoord2f(1.0, 0.0);  glVertex3f(0.375, -0.125, 0.125);
	    glTexCoord2f(0.0, 0.0);  glVertex3f(-0.375, -0.125, 0.125);
	    glTexCoord2f(0.0, 1.0);  glVertex3f(-0.375, -0.125, -0.125);
	    glTexCoord2f(1.0, 1.0);  glVertex3f(0.375, -0.125, -0.125);

	    /* (Back) */
	    
	    glTexCoord2f(0.0, 1.0);  glVertex3f(-0.375, 0.125, -0.125);
	    glTexCoord2f(1.0, 1.0);  glVertex3f(0.375, 0.125, -0.125);
	    glTexCoord2f(1.0, 0.0);  glVertex3f(0.375, -0.125, -0.125);
	    glTexCoord2f(0.0, 0.0);  glVertex3f(-0.375, -0.125, -0.125);
	    
	    /* (Top) */
	    
	    glTexCoord2f(0.0, 1.0);  glVertex3f(-0.375, 0.125, 0.125);
	    glTexCoord2f(1.0, 1.0);  glVertex3f(0.375, 0.125, 0.125);
	    glTexCoord2f(1.0, 0.0);  glVertex3f(0.375, 0.125, -0.125);
	    glTexCoord2f(0.0, 0.0);  glVertex3f(-0.375, 0.125, -0.125);
	  }
	  glEnd();
	}
	glDisable(GL_TEXTURE_2D);
      }
      glEndList();
    }
}


/* Redraw game screen: */

void redraw(void)
{
  int x, z, i, near;
  

  /* Clear window, set drawing mode: */
  
  if (level % 2 == 0)
    {
      /* Blue sky during the day */
      
      glClearColor(0.2, 0.2, 0.8, 1.0);
    }
  else
    {
      /* Black sky at night */
      
      glClearColor(0.0, 0.0, 0.0, 1.0);
    }

  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  
  
  /* Clouds or stars/moon: */
  
  if (level % 2 == 0)
    {
      /* Clouds during the day: */
      
      for (i = 0; i < NUM_CLOUDS; i++)
	{
	  glPushMatrix();
	  {
	    glRotatef(clouds[i].a, 0.0, 1.0, 0.0);
	    glTranslatef(0, clouds[i].y, -6.0);
	    glCallList(DL_CLOUD + clouds[i].tex);
	  }
	  glPopMatrix();
	}
    }
  else
    {
      /* Stars and moon at night: */
      
      glCallList(DL_STARS);
      glCallList(DL_MOON);
    }
  
  
  /* Smoke: */
  
  glBegin(GL_LINES);
  {
    for (i = 0; i < NUM_SMOKES; i++)
      {
	if (smokes[i].alive == 1)
	  {
	    if (smokes[i].intensity > 0.45)
	      glColor3f(smokes[i].intensity + 0.5,
			smokes[i].intensity + 0.5,
			0.0);
	    else if (smokes[i].intensity > 0.4)
	      glColor3f(smokes[i].intensity + 0.5, 0.0, 0.0);
	    else
	      glColor3f(smokes[i].intensity,
			smokes[i].intensity,
			smokes[i].intensity);
	    
	    glVertex3f(smokes[i].x, smokes[i].y, smokes[i].z);
	    glVertex3f(smokes[i].x + 0.001, smokes[i].y - 0.1, smokes[i].z);
	  }
      }
  }
  glEnd();
  
  
  /* Bullets: */
  
  glBegin(GL_LINES);
  {
    for (i = 0; i < NUM_BULLETS; i++)
      {
	if (bullets[i].alive == 1)
	  {
	    /* Bullet itself: */
	    
	    glColor3f(1.0, 1.0, 0.0);
	    glVertex3f(bullets[i].x, bullets[i].y, bullets[i].z);
	    glVertex3f(bullets[i].x - bullets[i].xm,
		       bullets[i].y - bullets[i].ym,
		       bullets[i].z - bullets[i].zm);
	    
	    /* Bullet's target: */
	    
	    glColor3f(0.5, 0.0, 0.5);
	    glVertex3f(bullets[i].destx - 0.1, bullets[i].desty - 0.1,
		       bullets[i].destz);
	    glVertex3f(bullets[i].destx + 0.1, bullets[i].desty + 0.1,
		       bullets[i].destz);
	    glVertex3f(bullets[i].destx + 0.1, bullets[i].desty - 0.1,
		       bullets[i].destz);
	    glVertex3f(bullets[i].destx - 0.1, bullets[i].desty + 0.1,
		       bullets[i].destz);
	  }
      }
  }
  glEnd();
  
  
  /* Explosions: */
  
  for (i = 0; i < NUM_EXPLOSIONS; i++)
    {
      if (explosions[i].alive == 1)
	{
	  glPushMatrix();
	  {
	    glTranslatef(explosions[i].x, explosions[i].y, explosions[i].z);
	    glColor3f((explosions[i].radius / (MAX_EXPLOSION_RADIUS * 2.0) +
		       0.5),
		      0.5 * ((timer + i ) % 2),
		      0.0);
	    glutSolidSphere(explosions[i].radius, 8, 4);
	  }
	  glPopMatrix();
	}
    }
  
  
  /* The ground: */
  
  if (level % 2 == 0)
    {
      /* Green ground during the day (black at night) */
      
      glCallList(DL_GROUND);
    }
  
  
  /* Ground outline: */
  
  glColor3f(0.0, 0.4, 0.0);
  glBegin(GL_LINE_LOOP);
  glVertex3f(-1.5, 0.01, -1.5);
  glVertex3f(1.5, 0.01, -1.5);
  glVertex3f(1.5, 0.01, 1.5);
  glVertex3f(-1.5, 0.01, 1.5);
  glEnd();
  
  
  /* Guns: */
  
  for (i = 0; i < NUM_GUNS; i++)
    {
      glPushMatrix();
      {
	glTranslatef(guns[i].x, guns[i].y, guns[i].z);
	glCallList(DL_GUN);
      }
      glPopMatrix();
    }
  
  
  /* Missiles: */
  
  for (i = 0; i < NUM_MISSILES; i++)
    {
      if (missiles[i].alive == 1 && missiles[i].wait == 0)
	{
	  glPushMatrix();
	  {
	    glTranslatef(missiles[i].x, missiles[i].y, missiles[i].z);
	    glScalef(0.1, 0.1, 0.1);
	    glCallList(DL_MISSILE);
	  }
	  glPopMatrix();
	  
	  
	  /* (Targetter line) */
	  
	  glColor3f(0.5, 0.5, 0.5);
	  glEnable(GL_LINE_STIPPLE);
	  glLineStipple(1, 0xAAAA);
	  glBegin(GL_LINES);
	  {
	    glVertex3f(missiles[i].x, missiles[i].y, missiles[i].z);
	    glVertex3f(missiles[i].x, 0.0, missiles[i].z);
	  }
	  glEnd();
	  glDisable(GL_LINE_STIPPLE);
	}
    }
  
  
  /* Target: */
  
  /* (See if the target is near any missiles) */
  
  near = 0;
  
  for (i = 0; i < NUM_MISSILES; i++)
    {
      if (missiles[i].alive == 1 && missiles[i].wait == 0 &&
	  distance(target_x, target_y, target_z,
		   missiles[i].x, missiles[i].y, missiles[i].z) < 0.25)
	near = 1;
    }
  
  /* (Draw target) */
  
  glPushMatrix();
  {
    glTranslatef(target_x, target_y, target_z);
    if (near == 0)
      glColor3f(1.0, 1.0, 0.0);
    else
      glColor3f(1.0, 0.0, 0.0);
    
    glCallList(DL_TARGET);
  }
  glPopMatrix();
  
  /* (Shadow) */
  
  glColor3f(0.8, 0.8, 0.8);
  
  glBegin(GL_LINES);
  {
    glVertex3f(target_x - 0.125, 0.125, target_z);
    glVertex3f(target_x + 0.125, 0.125, target_z);
    
    glVertex3f(target_x, 0.125, target_z - 0.125);
    glVertex3f(target_x, 0.125, target_z + 0.125);
  }
  glEnd();
  
  
  /* Cities/Explosions/Craters: */

  for (z = 0; z < 4 ; z++)
    {
      for (x = 0; x <= 3; x++)
	{
	  glPushMatrix();
	  {
	    glTranslatef(cities[z][x].x, cities[z][x].y, cities[z][x].z);
	    
	    if (cities[z][x].alive == 1)
	      {
		/* City: */
		
		if (level % 2 == 0)
		  {
		    /* Normal cities during the day: */
		    
		    glCallList(DL_CITY + cities[z][x].color);
		  }
		else
		  {
		    /* Lit-up at night: */
		    
		    glCallList(DL_CITY + 2);
		}
	      }
	    else
	      {
		/* Crater */
		
		glCallList(DL_CRATER);
		
		
		if (cities[z][x].explosion_frame < NUM_EXPLOSION_TEXS)
		  {
		    /* Explosion! */
		    
		    glDisable(GL_DEPTH_TEST); 
		    {
		      glPushMatrix();
		      {
			glRotatef(360 - angley / 2.0, 0.1, 0.0, 0.0);
			glRotatef(360 - anglex, 0.0, 0.1, 0.0);
			glCallList(DL_EXPLOSION +
				   cities[z][x].explosion_frame);
		      }
		      glPopMatrix();
		    }
		    glEnable(GL_DEPTH_TEST); 
		  }
	      }
	  }
	  glPopMatrix();
	}
    }
  
  
  /* Swap or flush GL: */
  
  if (doublebuffer)
    glXSwapBuffers(dpy, win);
  else
    glFlush();
}


/* Set up X and OpenGL: */

void setup(int argc, char * argv[])
{
  XVisualInfo * vi;
  Colormap cmap;
  XSetWindowAttributes swa;
  int dummy, i;
  int singlebuf[] = {GLX_RGBA,
		     GLX_RED_SIZE, 1, GLX_GREEN_SIZE, 1, GLX_BLUE_SIZE, 1,
		     GLX_DEPTH_SIZE, 12, None};
  int doublebuf[] = {GLX_RGBA,
		     GLX_RED_SIZE, 1, GLX_GREEN_SIZE, 1, GLX_BLUE_SIZE, 1,
		     GLX_DEPTH_SIZE, 12, GLX_DOUBLEBUFFER, None};
  struct timeval tp;
  char temp[1024];
  
  
  /* Open a connection to the X Server: */
  
  dpy = XOpenDisplay(NULL);
  if (dpy == NULL)
    fatalerror("Could not open display!");
  
  
  /* Check for GLX extension support: */
  
  if (!glXQueryExtension(dpy, &dummy, &dummy))
    fatalerror("X server has no OpenGL GLX extension");
  
  
  /* Find a good OpenGL-capable visual: */
  
  vi = glXChooseVisual(dpy, DefaultScreen(dpy), doublebuf);
  
  
  /* No double-buffering available?  Shoot.  Try single-buffer: */
  
  if (vi == NULL)
    {
      vi = glXChooseVisual(dpy, DefaultScreen(dpy), singlebuf);
      
      /* This doesn't work either?  Give up! */
      
      if (vi == NULL)
	fatalerror("No RGB visual with depth buffer");
      
      doublebuffer = False;
    }
  else
    {
      /* Great!  Double buffering available! */
      
      doublebuffer = True;
    }
  
  
  /* TrueColor needed: */
  
  if (vi->class != TrueColor)
    fatalerror("TrueColor visual required");


  /* Create an OpenGL rendering context: */
  
  cx = glXCreateContext(dpy, vi,
			/* No display list sharing */ None,
			/* Direct rendering */ True);
  if (cx == NULL)
    fatalerror("Could not create a rendering context");
  
  
  /* Create a window with the selected visual: */
  
  /* (Create an X Colormap) */
  
  cmap = XCreateColormap(dpy, RootWindow(dpy, vi->screen),
			 vi->visual, AllocNone);
  
  /* (Set window attributes) */
  
  swa.colormap = cmap;
  swa.border_pixel = 0;
  swa.event_mask = ButtonMotionMask | ButtonPressMask | ButtonReleaseMask |
    KeyPressMask | KeyReleaseMask;
  
  
  /* (Create the window with the set attributes) */
  
  win = XCreateWindow(dpy, RootWindow(dpy, vi->screen),
		      0, 0, WIDTH, HEIGHT,
		      0, vi->depth, InputOutput, vi->visual,
		      CWBorderPixel | CWColormap | CWEventMask,
		      &swa);
  
  XSetStandardProperties(dpy, win, "ICBM3D/2", "ICBM3D/2", None,
			 argv, argc, NULL);
  
  
  /* Bind the rendering context (cx) to the window (win): */
  
  glXMakeCurrent(dpy, win, cx);
  
  
  /* Map the window to the screen! */
  
  XMapWindow(dpy, win);
  XFlush(dpy);
  
  
  /* Configure OpenGL context for rendering: */
  
  glEnable(GL_DEPTH_TEST); 
  glShadeModel(GL_FLAT);
  glEnable(GL_CULL_FACE);
  glCullFace(GL_BACK);
  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
  glPointSize(1);
  
  /* (Camera) */
  
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glViewport(0, 0, WIDTH, HEIGHT);
  glFrustum(-1.0, 1.0,
	    -1.0, 1.0,
	    1.0, 11.0);

  
  /* (Clear window) */
  
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glClearColor(0.0, 0.0, 0.0, 1.0);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glFlush();
  
  
  /* (Init preloaded shapes) */
  
  printf("Loading graphics");
  dlinit();
  printf("\n");
  fflush(stdout);
  
  
  /* Init. random function: */
  
  gettimeofday(&tp, NULL);
  srand(tp.tv_sec + tp.tv_usec);
  
  
  /* Set up audio: */
#ifdef SDL_USE_YES
  /* (Set up SDL) */
  
  if (SDL_Init(SDL_INIT_AUDIO) < 0)
    {
      fprintf(stderr, "Couldn't initialize SDL.\n%s\n",
	      SDL_GetError());
      exit(1);
    }
  
  
  /* (Open audio) */
  
  if (Mix_OpenAudio(11025, AUDIO_U8, 2, 512) < 0)
    {
      fprintf(stderr,
	      "Warning: Couldn't set 11025 Hz 8-bit stereo audio.\n%s\n",
	      SDL_GetError());
    }
  
  channel = 0;
  current_song = SONG_1;
  
  
  /* (Load audio files) */
  
  printf("Loading sounds..");
  for (i = 0; i < NUM_SOUNDS; i++)
    {
      printf(".");
      fflush(stdout);

      sprintf(temp, "sounds/%s.wav", soundfiles[i]);
      sounds[i] = Mix_LoadWAV(temp);
      if (sounds[i] == NULL)
	{
	  fprintf(stderr, "Couldn't load %s: %s\n", temp,
		  SDL_GetError());
	  exit(1);
	}
    }
  
  
  /* (Load songs) */
  
  for (i = 0; i < NUM_MODS; i++)
    {
      printf(".");
      fflush(stdout);
      
      sprintf(temp, "sounds/%s", songfiles[i]);
      songs[i] = Mix_LoadMUS(temp);
      if (songs[i] == NULL)
	{
	  fprintf(stderr, "Couldn't load %s: %s\n", temp,
		  SDL_GetError());
	  exit(1);
	}
    }
#endif
  printf("\n");
  fflush(stdout);
}


/* Display an error message and bail out: */

void fatalerror(char * reason)
{
  fprintf(stderr, "icbm3d2: %s\n", reason);
  exit(1);
}


/* Load a PPM file: */

static PPMImage *LoadPPM(const char *filename, int use_alpha)
{
  char buff[16];
  GLubyte c1, c2, c3;
  GLubyte * buf;
  PPMImage *result;
  FILE *fp;
  int maxval, x, y;
  
  printf(".");
  fflush(stdout);
  
  fp = fopen(filename, "rb");
  if (!fp)
    {
      fprintf(stderr, "Unable to open file `%s'\n", filename);
      exit(1);
    }
  
  if (!fgets(buff, sizeof(buff), fp))
    {
      perror(filename);
      exit(1);
    }
  
  if (buff[0] != 'P' || buff[1] != '6')
    {
      fprintf(stderr, "Invalid image format (must be `P6')\n");
      exit(1);
    }
  
  result = malloc(sizeof(PPMImage));
  if (!result)
    {
      fprintf(stderr, "Unable to allocate memory\n");
      exit(1);
    }
  
  if (fscanf(fp, "%d %d", &result->sizeX, &result->sizeY) != 2)
    {
      fprintf(stderr, "Error loading image `%s'\n", filename);
      exit(1);
    }
  
  if (fscanf(fp, "%d", &maxval) != 1)
    {
      fprintf(stderr, "Error loading image `%s'\n", filename);
      exit(1);
    }
  
  while (fgetc(fp) != '\n')
    {
    }
  
  result->data = malloc((3 + use_alpha) * result->sizeX * result->sizeY);
  if (!result)
    {
      fprintf(stderr, "Unable to allocate memory\n");
      exit(1);
    }
  
  buf = result->data;
  
  for (y = 0; y < result->sizeY; y++)
    for (x = 0; x < result->sizeX; x++)
      {
	c1 = fgetc(fp);
	c2 = fgetc(fp);
	c3 = fgetc(fp);
	
	if (c1 != 0 || c2 != 0 || c3 != 0)
	  {
	    *(buf++) = c1;
	    *(buf++) = c2;
	    *(buf++) = c3;
	    if (use_alpha == 1)
	      *(buf++) = 128;
	  }
	else
	  {
	    *(buf++) = 0;
	    *(buf++) = 0;
	    *(buf++) = 0;
	    if (use_alpha == 1)
	      *(buf++) = 0;
	  }
      }
  
  fclose(fp);
  
  return result;
}


/* Add smoke: */

void addsmoke(float x, float y, float z, int owner)
{
  int i, found;
  
  
  /* Look for an open slot: */
  
  found = -1;
  
  for (i = 0; i < NUM_SMOKES && found == -1; i++)
    {
      if (smokes[i].alive == 0)
	found = i;
    }
  
  
  if (found != -1)
    {
      /* Activate this smoke: */
      
      smokes[found].alive = 1;
      smokes[found].owner = owner;
      smokes[found].intensity = 0.5;
      smokes[found].x = x;
      smokes[found].y = y;
      smokes[found].z = z;
    }
}


/* Kill a missile and its smoke: */

void killmissile(int which)
{
  int i;
  
  
  /* Turn off missile: */
  
  missiles[which].alive = 0;
  
  
  /* Turn off missile's smoke: */
  
  for (i = 0; i < NUM_SMOKES; i++)
    {
      if (smokes[i].owner == which)
	smokes[i].alive = 0;
    }
  
  
  /* Add explosion: */
  
  addexplosion(missiles[which].x, missiles[which].y, missiles[which].z);
}


/* Distance: */

float distance(float x1, float y1, float z1, float x2, float y2, float z2)
{
  float xs, ys, zs, d;
  
  xs = (x1 - x2) * (x1 - x2);
  ys = (y1 - y2) * (y1 - y2);
  zs = (z1 - z2) * (z1 - z2);
  
  d = sqrt(xs + ys + zs);
  
  return(d);
}


/* Fire a bullet: */

void firebullet(void)
{
  float dist, this_dist;
  int which, i, found;
  
  
  /* Pick closest (alive) gun to fire from: */
  
  dist = 100000.0;
  which = -1;
  
  for (i = 0; i < 4; i++)
    {
      if (guns[i].alive == 1 && guns[i].bullets > 0)
	{
	  /* We've got a live one, here! */
	  
	  this_dist = distance(target_x, target_y, target_z,
			       guns[i].x, guns[i].y, guns[i].z);
	  
	  if (this_dist < dist)
	    {
	      dist = this_dist;
	      which = i;
	    }
	}
    }
  
  
  /* Fire! */
  
  if (which != -1)
    {
      /* Find a bullet slot: */
      
      found = -1;
      
      for (i = 0; i < NUM_BULLETS && found == -1; i++)
	{
	  if (bullets[i].alive == 0)
	    found = i;
	}
      
      
      if (found != -1)
	{
	  bullets[found].alive = 1;
	  
	  
	  /* Set it's starting position and destination: */
	  
	  bullets[found].x = guns[which].x;
	  bullets[found].y = guns[which].y + 0.75;
	  bullets[found].z = guns[which].z;
	  
	  bullets[found].destx = target_x;
	  bullets[found].desty = target_y;
	  bullets[found].destz = target_z;
	  
	  
	  /* Determine speed and direction: */
	  
	  dist = cbrt(((bullets[found].x - bullets[found].destx) *
		       (bullets[found].x - bullets[found].destx)) +
		      ((bullets[found].y - bullets[found].desty) *
		       (bullets[found].y - bullets[found].desty)) +
		      ((bullets[found].z - bullets[found].destz) *
		       (bullets[found].z - bullets[found].destz))) / 0.1;
          
          bullets[found].xm = (bullets[found].destx - bullets[found].x) / dist;
          bullets[found].ym = (bullets[found].desty - bullets[found].y) / dist;
          bullets[found].zm = (bullets[found].destz - bullets[found].z) / dist;
	  bullets[found].channel = channel;
	  
	  
	  /* Eat one of the base's bullets: */
	  
	  guns[which].bullets--;


	  /* Make sound effect: */
	  
#ifdef SDL_USE_YES
	  Mix_PlayChannel(channel, sounds[SND_FIRE]);
	  channel = (channel + 1) % MIX_CHANNELS;
#endif
	}
    }
}


/* Add a new explosion: */

void addexplosion(float x, float y, float z)
{
  int i, found;
  
  found = -1;
  
  for (i = 0; i < NUM_EXPLOSIONS && found == -1; i++)
    {
      if (explosions[i].alive == 0)
	found = i;
    }
  
  if (found != -1)
    {
      explosions[found].alive = 1;
      explosions[found].x = x;
      explosions[found].y = y;
      explosions[found].z = z;
      explosions[found].radius = 0;
      explosions[found].rm = 0.01;
    }

#ifdef SDL_USE_YES  
  Mix_PlayChannel(channel, sounds[SND_EXPLOSION]);
  channel = (channel + 1) % MIX_CHANNELS;
#endif
}


/* Title screen: */

int title(int selected)
{
  int done, quit, i, shrink;
  float scale;
  XEvent event;
  KeySym keysym;
  XComposeStatus composestatus;
  char key[128];
  int button_angles[NUM_BUTTONS];
  float button_scales[NUM_BUTTONS];
  
  
  /* Init. title screen values: */
  
  done = 0;
  quit = 0;
  shrink = 0;
  scale = 1.0;
  
  for (i = 0; i < NUM_BUTTONS; i++)
    {
      button_angles[i] = 0;
      button_scales[i] = 1.0;
    }
  
  
  
  /* Title screen loop: */
  
  do
    {
      /* Handle Events: */
      
      if (XPending(dpy) && shrink == 0)
	{
	  do
	    {
	      XNextEvent(dpy, &event);
	      
	      if (event.type == KeyPress)
		{
		  /* Key: */

		  XLookupString(&event.xkey, key, 1, &keysym, &composestatus);
		  
		  if (XKeysymToString(keysym) != NULL)
		    strcpy(key, XKeysymToString(keysym));
		  
		  
		  /* Movement keys (can be held down indefinitely) */
		  
		  if (strcmp(key, KEY_AWAY) == 0)
		    {
		      selected--;
		      if (selected < 0)
			selected = NUM_BUTTONS - 1;
#ifdef SDL_USE_YES
		      Mix_PlayChannel(0, sounds[SND_SELECT]);
#endif
		    }
		  else if (strcmp(key, KEY_TOWARDS) == 0)
		    {
		      selected++;
		      if (selected >= NUM_BUTTONS)
			selected = 0;
#ifdef SDL_USE_YES
		      Mix_PlayChannel(0, sounds[SND_SELECT]);
#endif
		    }
		  else if (strcmp(key, "Return") == 0)
		    {
		      shrink = 1;
#ifdef SDL_USE_YES
		      Mix_PlayChannel(0, sounds[SND_FIRE]);
#endif
		    }
		}
	    }
	  while (XPending(dpy));
	}
      
      
      if (shrink == 1)
	{
	  scale = scale - 0.05;
	  
	  if (scale <= 0)
	    done = 1;
	}
      
      
      /* Draw title screen: */
      
      glMatrixMode(GL_MODELVIEW);
      glLoadIdentity();
      glClearColor(0.0, 0.0, 0.0, 1.0);
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      
      
      /* (Background) */
      
      glPushMatrix();
      {
	glRasterPos3f(0.0, 0.0, -2.0);
	/* glDrawPixels(title_image->sizeX, title_image->sizeY,
	   GL_RGB, GL_UNSIGNED_BYTE, title_image->data);*/
      }
      glPopMatrix();
      
      
      /* (Buttons) */
      
      for (i = 0; i < NUM_BUTTONS; i++)
	{
	  glPushMatrix();
	  {
	    glTranslatef(0.0, 0.5 - i * 0.5, -1.5);
	    glRotatef(button_angles[i], 1.0, 0.0, 0.0);
	    
	    if (selected != i)
	      {
		/* Non-selected ones may get scaled: */
		
		glScalef(scale, scale, scale);
	      }

	    glScalef(button_scales[i], button_scales[i], button_scales[i]);
	    
	    glCallList(DL_BUTTONS + i);
	  }
	  glPopMatrix();
	}
      
      
      /* Rotation angles and scales for buttons: */
      
      for (i = 0; i < NUM_BUTTONS; i++)
	{
	  if (selected == i)
	    {
	      button_angles[i] = (button_angles[i] + 5) % 90;
	      
	      if (button_scales[i] < 1.5)
		button_scales[i] = button_scales[i] + 0.1;
	    }
	  else
	    {
	      if (button_angles[i] != 0)
		button_angles[i] = (button_angles[i] + 5) % 90;		

	      if (button_scales[i] > 1.0)
		button_scales[i] = button_scales[i] - 0.1;
	    }
	}
      
      
      /* Keep playing title music: */
      
#ifdef SDL_USE_YES
      if (!Mix_PlayingMusic())
	{
	  Mix_PlayMusic(songs[SONG_TITLE]);
	}
#endif
      
      /* Swap or flush GL: */
      
      if (doublebuffer)
	glXSwapBuffers(dpy, win);
      else
	glFlush();
    }
  while (done == 0);
  
  return(selected);
}


/* Add a missile to the game: */

void addmissile(int splitable, float x, float y, float z)
{
  int i, take_time, found;
  
  found = -1;
  
  for (i = 0; i < NUM_MISSILES && found == -1; i++)
    {
      if (missiles[i].alive == 0)
	found = i;
    }
  
  if (found != -1)
    {
      missiles[found].alive = 1;
      
      missiles[found].wait = rand() % 200;
      
      if (x == PICK)
	missiles[found].x = (rand() % 240) / 100.0 - 1.2;
      else
	missiles[found].x = x;
      
      if (y == PICK)
	missiles[found].y = 4.0;
      else
	missiles[found].y = y;
      
      if (z == PICK)
	missiles[found].z = (rand() % 240) / 100.0 - 1.2;
      else
	missiles[found].z = z;
      
      
      /* Pick a spot to aim for: */
      
      missiles[found].destx = (rand() % 240) / 100.0 - 1.2;
      missiles[found].destz = (rand() % 240) / 100.0 - 1.2;
      
      
      /* Pick a random amount of time to take to get there: */
      
      take_time = (rand() % 150) + 1000 - level * 20;
      
      
      /* Aim for it: */
      
      missiles[found].xm = (missiles[found].destx - missiles[found].x) / take_time;
      missiles[found].ym = (-missiles[found].y) / take_time;
      missiles[found].zm = (missiles[found].destz - missiles[found].z) / take_time;
      
      
      /* Does this missile split? */
      
      /* if (randnum(chance_of_split) < 1 && cansplit == 1)
	missiles[found].splitter = 1;
      else
      missiles[found].splitter = 0; */
      
      
      /* Does this missile spliral? */
      
      /* if (randnum(chance_of_spiral) < 1)
	missiles[found].spiraller = 1;
      else
      missiles[found].spiraller = 0; */
    }
}


/* Pause: */

void pause_screen(void)
{
  PPMImage image;
  int angle, done;
  XEvent event;
  float scale, scalem;
  
  
  /* Turn off music: */

#ifdef SDL_USE_YES  
  Mix_HaltMusic();
#endif
  
  /* Copy current screen into a buffer so we can texturemap it: */
  
  image.sizeX = WIDTH;
  image.sizeY = HEIGHT;
  image.data = malloc(image.sizeX * image.sizeY * 3);
  
  glDisable(GL_TEXTURE_2D);
  glReadPixels(0, 0, WIDTH, HEIGHT, GL_RGB, GL_UNSIGNED_BYTE, image.data);
  glEnable(GL_TEXTURE_2D);
  
  
  /* Create texture: */
  
  glGenTextures(1, pause_textures);
  glBindTexture(GL_TEXTURE_2D, pause_textures[0]);
  gluBuild2DMipmaps(GL_TEXTURE_2D, 3, WIDTH, HEIGHT,
		    GL_RGB, GL_UNSIGNED_BYTE, image.data);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
  glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  /* glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, WIDTH, HEIGHT, 0,
     GL_RGB, GL_UNSIGNED_BYTE, image.data); */
  
  
  /* Texturemap it onto our polygon: */
  
  glNewList(DL_PAUSE, GL_COMPILE_AND_EXECUTE);
  {
    glEnable(GL_TEXTURE_2D);
    {
      glBindTexture(GL_TEXTURE_2D, pause_textures[0]);
      
      glBegin(GL_QUADS);
      {
	/* (Front) */
	
	glTexCoord2f(0.0, 0.0);  glVertex3f(-0.5, -0.5, 0.5);
	glTexCoord2f(1.0, 0.0);  glVertex3f(0.5, -0.5, 0.5);
	glTexCoord2f(1.0, 1.0);  glVertex3f(0.5, 0.5, 0.5);
	glTexCoord2f(0.0, 1.0);  glVertex3f(-0.5, 0.5, 0.5);
	
	
	/* (Right) */
	
	glBegin(GL_QUADS);
	{
	  glTexCoord2f(0.0, 1.0);  glVertex3f(0.5, 0.5, -0.5);
	  glTexCoord2f(1.0, 1.0);  glVertex3f(0.5, 0.5, 0.5);
	  glTexCoord2f(1.0, 0.0);  glVertex3f(0.5, -0.5, 0.5);
	  glTexCoord2f(0.0, 0.0);  glVertex3f(0.5, -0.5, -0.5);
	}
	glEnd();
	
	
	/* (Left) */
	  
	glBegin(GL_QUADS);
	{
	  glTexCoord2f(0.0, 0.0);  glVertex3f(-0.5, -0.5, -0.5);
	  glTexCoord2f(1.0, 0.0);  glVertex3f(-0.5, -0.5, 0.5);
	  glTexCoord2f(1.0, 1.0);  glVertex3f(-0.5, 0.5, 0.5);
	  glTexCoord2f(0.0, 1.0);  glVertex3f(-0.5, 0.5, -0.5);
	}
	glEnd();
      }
      glEnd();
    }
    glDisable(GL_TEXTURE_2D);
  }
  glEndList();
  
  
  /* Pause loop! */
  
  angle = 0;
  scale = 2.0;
  scalem = -0.1;
  done = 0;
  
  do
    {
      /* Clear pause screen: */
      
      glMatrixMode(GL_MODELVIEW);
      glLoadIdentity();
      glClearColor(0.0, 0.0, 0.0, 1.0);
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      
      
      /* Draw pause screen's cube: */
      
      glTranslatef(0.0, 0.0, -2.0);
      glRotatef(angle, 0.0, 1.0, 0.0);
      glScalef(scale, scale, scale);
      glCallList(DL_PAUSE);
      
      
      /* Handle Events: */
      
      if (XPending(dpy) && scalem <= 0.0)
	{
	  do
	    {
	      XNextEvent(dpy, &event);
	      
	      if (event.type == KeyPress)
		{
		  /* Key: */
		  
		  scalem = 0.1;
		}
	    }
	  while (XPending(dpy));
	}
      
      
      /* Rotate: */
      
      angle = (angle + 4) % 90;
      scale = scale + scalem;
      
      if (scale <= 1.0)
	scalem = 0.0;
      else if (scale >= 2.0)
	done = 1;
      
      
      /* Swap or flush GL: */
      
      if (doublebuffer)
	glXSwapBuffers(dpy, win);
      else
	glFlush();
    }
  while (done == 0);
  
  free(image.data);
}
