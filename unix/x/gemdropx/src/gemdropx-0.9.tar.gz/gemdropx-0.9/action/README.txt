Gem Drop X - Action! Source - README
------------------------------------
  This directory ("action/") contains the original Atari 8-bit Action!
  source code for "Gem Drop."

  The C source for "Gem Drop X" was based directly on this source!

  You can download a disk image of the original "Gem Drop" (including the
  original ATASCII source files, support files, fonts, images, etc.)
  from http://www.newbreedsoftware.com/gemdrop/

  The origianl "Gem Drop" has been tested on a number of Atari 8-bit
  emulators (Rainbow for the MacOS, Atari800 for Linux) and seems to
  work fairly well!
