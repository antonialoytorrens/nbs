/* whip.c
   bill kendrick
   bill@newbreedsoftware.com

   2003.Mar.02
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include "SDL.h"


#define WIDTH 640
#define HEIGHT 480
#define NUM_CHAINS 20

#define GRAVITY 2.0

#define RUBBERY 1.0  /* Higher is less rubbery; closer to 1.0 is very rubbery */
#define STRETCHY 10 /* Higher is stretchier; closer to 5 is not stretchy */


void myabort(char * str);
float getdist(float x1, float y1, float x2, float y2);

typedef struct chain_type {
  float x, y;
  float xm, ym;
  float weight;
} chain_type;



int main(int argc, char * argv[])
{
  SDL_Surface * screen;
  SDL_Rect dest;
  int done, btn_down, x, y, i;
  float dist;
  SDL_Event event;
  chain_type whip[NUM_CHAINS];
  Uint32 black;
  
  
  if (SDL_Init(SDL_INIT_VIDEO) < 0)
    myabort("SDL_Init");
  
  screen = SDL_SetVideoMode(WIDTH, HEIGHT, 16, SDL_SWSURFACE);
  if (screen == NULL)
    myabort("SDL_SetVideoMode");

  black = SDL_MapRGB(screen->format, 0, 0, 0);


  done = 0;
  btn_down = 0;

  x = WIDTH / 2;
  y = HEIGHT / 4;

  for (i = 0; i < NUM_CHAINS; i++)
  {
    whip[i].x = x;
    whip[i].y = y;
    whip[i].xm = 0;
    whip[i].ym = 0;
    whip[i].weight = 1;
  }

  whip[NUM_CHAINS / 2].weight = 10;
  whip[NUM_CHAINS - 1].weight = 10;
  
  do
  {
    while (SDL_PollEvent(&event))
    {
      if (event.type == SDL_QUIT)
	done = 1;
      else if (event.type == SDL_KEYDOWN)
      {
	if (event.key.keysym.sym == SDLK_ESCAPE)
	  done = 1;
      }
      else if (event.type == SDL_MOUSEBUTTONUP)
        btn_down = 0;
      else if (event.type == SDL_MOUSEBUTTONDOWN)
      {
        btn_down = 1;
	x = event.button.x;
	y = event.button.y;
      }
      else if (event.type == SDL_MOUSEMOTION)
      {
	if (btn_down)
	{
	  x = event.button.x;
	  y = event.button.y;
	}
      }
    }


    whip[0].x = x;
    whip[0].y = y;

    for (i = 1; i < NUM_CHAINS; i++)
    {
      dist = getdist(whip[i].x, whip[i].y, whip[i - 1].x, whip[i - 1].y);

      whip[i].x = whip[i].x + whip[i].xm;
      whip[i].y = whip[i].y + whip[i].ym;

      if (whip[i].y >= HEIGHT)
	whip[i].y = HEIGHT;
      
      if (whip[i].y < 0)
	whip[i].y = 0;

      // if (dist > 10)
      {
	whip[i].xm += (whip[i - 1].x - whip[i].x) / (STRETCHY / whip[i].weight);
	whip[i].ym += (whip[i - 1].y - whip[i].y) / (STRETCHY / whip[i].weight);
	
	whip[i].x = (whip[i].x + whip[i - 1].x) / 2;
	whip[i].y = (whip[i].y + whip[i - 1].y) / 2;
      }
      // else
      {
	whip[i].xm = whip[i].xm / RUBBERY;
	whip[i].ym = whip[i].ym / RUBBERY;
      }
      
      whip[i].ym += GRAVITY;
    }


    SDL_FillRect(screen, NULL, black);

    for (i = NUM_CHAINS - 1; i >= 0; i--)
    {
      dest.x = whip[i].x - (whip[i].weight);
      dest.y = whip[i].y - (whip[i].weight);
      dest.w = (whip[i].weight * 2) + 1;
      dest.h = (whip[i].weight * 2) + 1;

      SDL_FillRect(screen, &dest,
		   SDL_MapRGB(screen->format,
			      i * (255 / NUM_CHAINS),
			      255 - i * (255 / NUM_CHAINS),
			      255 * (i % 2)));
    }

    SDL_Flip(screen);
    
    SDL_Delay(20);
  }
  while (!done);

  return (0);
}


void myabort(char * str)
{
  fprintf(stderr, "Error: %s: %s\n", str, SDL_GetError());
  exit(1);
}


float getdist(float x1, float y1, float x2, float y2)
{
  return sqrt(((x1 - x2) * (x1 - x2)) + ((y1 - y2) * (y1 - y2)));
}

