2kdemo

by Bill Kendrick <bill@newbreedsoftware.com>
2003.Feb.21

Music: "Intro number 33" by WOTW of Gothic (Elef Tsiroudis), Germany, May 1999.
(Available freely in the 'chiptunes' MOD collection)

A simple demo using Simple DirectMedia Layer.
Source is a little over 2K, even with whitespace stripped and function and
variable names shortened and #defines used.  (See: 2kdemo-small.c)

Features:
  * 320x200 software zooming and fading.
  * Digital-display style text 'scroller'
  * Graphics coordinated with music

Requires:
  * libSDL
  * SDL_mixer (optional; for music)

-bill!
