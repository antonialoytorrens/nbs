#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include"SDL.h"
#include"SDL_mixer.h"
int WW=320,WH=200,FPS=2,Z=255,Ww=160,Wh=100,ww=80,wh=50;
#define M SDL_MapRGB
#define SRF SDL_Surface *
#define UB Uint8
#define UW Uint32
#define rn return
#define fmt format
#define R rand()
#define r2 (R%2+1)
#define r8 R%256
#define shs SDL_HWSURFACE
#define pms Mix_PlayMusic(ms,0)
#define tck SDL_GetTicks()/10
int ox,oy,oX,oY;SRF sc,*t;Mix_Music*ms;char*slr[]={"HELLO","","I HOPE","YOU LIKE","MY DEMO","","IT IS","VERY","SIMPLE",0};setup();zi();UW gp(SRF sf,int x,int y);pp(SRF sf,int x,int y,UW _);DT(char*s);int main(){int dn;SDL_Event ev;SDL_Rect dt;UW l_t;int scw,chw,wt,f_ms;setup();dn=scw=chw=ox=oy=wt=f_ms=0;oX=oY=1;pms;do{l_t=tck;while(SDL_PollEvent(&ev)){if(ev.type==SDL_QUIT)dn=1;}pp(sc,R%Ww+ww,R%Wh+wh,M(sc->fmt,Z,Z,Z));if(l_t>=805){if(slr[scw]){if(((l_t-805)%100)<10){DT(slr[scw]);chw=0;}else if(((l_t-805)%100)>20&&!chw){scw++;chw=1;}}}if(l_t>=2330&&l_t<5434){dt.x=R%Ww+ww;dt.y=R%Wh+wh;dt.w=R%ww;dt.h=R%wh;SDL_FillRect(sc,&dt,M(sc->fmt,r8,r8,r8));}if(l_t>=3877&&l_t<5434){wt=!wt;if(wt){ox=ox+oX;oy=oy+oY;if(ox>10)oX=-r2;else if(ox<-10)oX=r2;if(oy>10)oY=-r2;else if(oy<-10)oY=r2;}}if(l_t>=5434){ox=oy=0;if(!f_ms){f_ms=1;Mix_FadeOutMusic(5000);}}zi();SDL_Flip(sc);if(tck<l_t+FPS)SDL_Delay((l_t+FPS)*10-tck);if(!Mix_PlayingMusic()){if(f_ms)dn=1;else pms;}}while(!dn);SDL_Quit();rn 0;}setup(){SDL_Init(SDL_INIT_VIDEO|SDL_INIT_AUDIO);Mix_OpenAudio(44100,AUDIO_S16,2,2048);ms=Mix_LoadMUS("m.mod");sc=SDL_SetVideoMode(WW,WH,16,shs);t=SDL_CreateRGBSurface(shs,WW,WH,16,0,0,0,0);}zi(){int x,y,nx,ny;UW _;UB r,g,b;SDL_LockSurface(t);for(y=0;y<WH;y++){for(x=0;x<WW;x++){_=gp(sc,x,y);nx=((x-Ww)*11)/10+Ww+ox;ny=((y-Wh)*11)/10+Wh+oy;if(_){SDL_GetRGB(_,t->fmt,&r,&g,&b);r=(r*7)/8;g=(g*7)/8;b=(b*7)/8;_=M(t->fmt,r,g,b);}pp(t,nx,ny,_);pp(t,nx+1,ny,_);pp(t,nx,ny+1,_);pp(t,nx+1,ny+1,_);}}SDL_UnlockSurface(t);SDL_BlitSurface(t,0,sc,0);}UW gp(SRF s,int x,int y){UB*p;p=(UB*)(s->pixels+y*s->pitch+x*2);rn*(Uint16*)p;}pp(SRF s,int x,int y,UW _){UB*p;p=(UB*)(s->pixels+y*s->pitch+x*2);if(x>=0&&y>=0&&x<s->w&&y<s->h){*(Uint16*)p=_;}}char ltr[]="1111110011111110110010100011111011011010110110001110111001111100001001000010111001111001010010101110110000001101111011101111100011101111111110011101011001011010011011100110010100001110111111110111011010111010";SDL_Rect e[8]={{0,0,10,2},{0,0,2,10},{8,0,2,10},{0,8,10,2},{0,10,2,10},{8,10,2,10},{0,18,10,2},{4,12,8,8}};DT(char*s){int i,j,x;SDL_Rect dt;for(i=0;s[i];i++){x=Ww-strlen(s)/2*16+i*16;if(s[i]!=32){for(j=0;j<8;j++){if(ltr[(s[i]-65)*8+j]==49){dt.x=e[j].x+x;dt.y=e[j].y+Wh-10;dt.w=e[j].w;dt.h=e[j].h;SDL_FillRect(sc,&dt,M(sc->fmt,Z,Z,0));}}}}}
