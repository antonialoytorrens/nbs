/* 2kdemo.c
   by Bill Kendrick <bill@newbreedsoftware.com>
   2003.Feb.20 - 2003.Feb.21
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "SDL.h"
#include "SDL_mixer.h"

#define WW 320
#define WH 200
#define FPS (1000/60)

/* Globals: */

int use_sound, ox, oy, oxm, oym;
SDL_Surface * screen, * tmp_surf;
Mix_Music * music;

char * scroller[] = {
  "HELLO",
  "", "I HOPE", "YOU LIKE", "MY DEMO",
  "", "IT IS", "VERY", "SIMPLE",
  "", "CREATED FOR THE",
  "LINUX", "GAME", "PUBLISHING", "SPONSORSHIP", "APPLICATION",
  NULL
};

/* Local func. protos: */

void setup(int argc, char * argv[]);
void abort2k(char * err);
void warn2k(char * err);
void zoomin(void);
Uint32 getpixel(SDL_Surface * surf, int x, int y);
void putpixel(SDL_Surface * surf, int x, int y, Uint32 pix);
void drawtext(char * str);

/* --- MAIN --- */

int main(int argc, char * argv[])
{
  int done;
  SDL_Event event;
  SDL_Rect dest;
  SDLKey key;
  Uint32 last_time;
  int scroller_word, changed_word, waveytime, fading_music;
 
  /* Setup: */

  setup(argc, argv);

  /* Main loop: */
  
  done = 0;
  scroller_word = 0;
  changed_word = 0;
  ox = 0;
  oy = 0;
  oxm = 1;
  oym = 1;
  waveytime = 0;
  fading_music = 0;
 
  if (use_sound)
    Mix_PlayMusic(music, 0);

  do
  {
    last_time = SDL_GetTicks();

    /* Handle events: */

    while (SDL_PollEvent(&event))
    {
      if (event.type == SDL_QUIT)
	done = 1;
      else if (event.type == SDL_KEYDOWN)
      {
	key = event.key.keysym.sym;

	if (key == SDLK_ESCAPE || key == SDLK_q)
	  done = 1;
	else if (key == SDLK_SPACE)
	  printf("%d\n", last_time);
      }
    }

    /* Stars: */
    
    putpixel(screen,
	     ((rand() % WW) / 2) + (WW / 4),
	     ((rand() % WH) / 2) + (WH / 4),
             SDL_MapRGB(screen->format, 255, 255, 255));

    if (last_time >= 8050)
    {
      /* Scroller: */

      if (scroller[scroller_word] != NULL)
      {
        if (((last_time - 8050) % 1000) < 100)
	{
	  drawtext(scroller[scroller_word]);
	  changed_word = 0;
	}
	else if (((last_time - 8050) % 1000) > 200 && !changed_word)
	{
	  scroller_word++;
	  changed_word = 1;
	}
      }
    }

    if (last_time >= 23300 && last_time < 54345)
    {
      /* Boxes: */

      dest.x = (rand() % (WW / 2)) + (WW / 4);
      dest.y = (rand() % (WH / 2)) + (WH / 4);
      dest.w = (rand() % (WW / 4));
      dest.h = (rand() % (WH / 4));
      SDL_FillRect(screen, &dest, SDL_MapRGB(screen->format,
			                     rand() % 256,
			                     rand() % 256,
			                     rand() % 256));
    }
    
    if (last_time >= 38770 && last_time < 54345)
    {
      /* Wavey: */

      waveytime = !waveytime;

      if (waveytime)
      {
        ox = ox + oxm;
        oy = oy + oym;

        if (ox > 10)
	  oxm = -((rand() % 2) + 1);
        else if (ox < -10)
	  oxm = ((rand() % 2) + 1);
      
        if (oy > 10)
	  oym = -((rand() % 2) + 1);
        else if (oy < -10)
	  oym = ((rand() % 2) + 1);
      }
    }

    if (last_time >= 54345)
    {
      /* The end! */

      ox = 0;
      oy = 0;

      if (!fading_music && use_sound)
      {
	fading_music = 1;

	Mix_FadeOutMusic(5000);
      }
    }

    /* Zoom: */

    zoomin();
    SDL_Flip(screen);
    
    /* Pause: */

    if (SDL_GetTicks() < last_time + FPS)
      SDL_Delay(last_time + FPS - SDL_GetTicks());

    /* Play music: */

    if (use_sound && !Mix_PlayingMusic())
    {
      if (fading_music)
        done = 1;
      else
	Mix_PlayMusic(music, 0);
    }
  }
  while (!done);
  
  SDL_Quit();

  return(0);
}

/* --- Setup --- */

void setup(int argc, char * argv[])
{
  use_sound = 1;

  if (SDL_Init(SDL_INIT_VIDEO) < 0)
    abort2k("SDL_Init(SDL_INIT_VIDEO)");

  if (use_sound)
  {
    if (SDL_Init(SDL_INIT_AUDIO) < 0)
    {
      warn2k("SDL_Init(SDL_INIT_AUDIO)");
      use_sound = 0;
    }
    else
    {
      if (Mix_OpenAudio(44100, AUDIO_S16, 2, 2048) < 0)
      {
        warn2k("Mix_OpenAudio(44100, AUDIO_S16, 2, 2048)");
        use_sound = 0;
      }
      else
      {
	music = Mix_LoadMUS("m.mod");
	if (music == NULL)
	{
	  warn2k("Mix_LoadMUS(\"m.mod\")");
	  use_sound = 0;
	}
      }
    }
  }

  screen = SDL_SetVideoMode(WW, WH, 16, SDL_SWSURFACE);
  if (screen == NULL)
    abort2k("SDL_SetVideoMode(...)");

  tmp_surf = SDL_CreateRGBSurface(SDL_HWSURFACE, WW, WH, 16, 0, 0, 0, 0);
  if (tmp_surf == NULL)
    abort2k("SDL_CreateRGBSurface(...)");
  
  SDL_WM_SetCaption("Bill Kendrick's 2K Demo", "2K Demo");
}

void abort2k(char * err)
{
  fprintf(stderr, "Error: %s\n%s\n", err, SDL_GetError());
  exit(1);
}

void warn2k(char * err)
{
  fprintf(stderr, "Warning: %s\n%s\n", err, SDL_GetError());
}

void zoomin(void)
{
  int x, y, nx, ny;
  Uint32 pix;
  Uint8 r, g, b;

  if (SDL_MUSTLOCK(tmp_surf))
    SDL_LockSurface(tmp_surf);

  /* Copy pixels: */
  
  for (y = 0; y < WH; y++)
  {
    for (x = 0; x < WW; x++)
    {
      pix = getpixel(screen, x, y);

      nx = ((x - (WW / 2)) * 11) / 10 + (WW / 2) + ox;
      ny = ((y - (WH / 2)) * 11) / 10 + (WH / 2) + oy;

      if (pix != 0)
      {
        SDL_GetRGB(pix, tmp_surf->format, &r, &g, &b);
        r = (r * 7) / 8;
        g = (g * 7) / 8;
        b = (b * 7) / 8;
        pix = SDL_MapRGB(tmp_surf->format, r, g, b);
      }

      putpixel(tmp_surf, nx, ny, pix);
      putpixel(tmp_surf, nx + 1, ny, pix);
      putpixel(tmp_surf, nx, ny + 1, pix);
      putpixel(tmp_surf, nx + 1, ny + 1, pix);
    }
  }

  if (SDL_MUSTLOCK(tmp_surf))
    SDL_UnlockSurface(tmp_surf);

  SDL_BlitSurface(tmp_surf, NULL, screen, NULL);
}


Uint32 getpixel(SDL_Surface * surf, int x, int y)
{
  int bpp;
  Uint8 * p;

  bpp = surf->format->BytesPerPixel;

  p = (Uint8 *) (surf->pixels + (y * surf->pitch) + (x * bpp));

  switch (bpp)
  {
    case 1: return *p; break;
    case 2: return *(Uint16 *)p; break;
    case 3:
      if (SDL_BYTEORDER == SDL_BIG_ENDIAN)
	return p[0] << 16 | p[1] << 8 | p[2];
      else
	return p[0] | p[1] << 8 | p[2] << 16;
      break;
    case 4: return *(Uint32 *)p;
  }

  return 0;
}


void putpixel(SDL_Surface * surf, int x, int y, Uint32 pix)
{
  int bpp;
  Uint8 * p;

  bpp = surf->format->BytesPerPixel;

  p = (Uint8 *) (surf->pixels + (y * surf->pitch) + (x * bpp));

  if (x >= 0 && y >= 0 && x < surf->w && y < surf->h)
  {
    switch(bpp)
    {
      case 1: *p = pix; break;
      case 2: *(Uint16 *)p = pix; break;
      case 3:
	if (SDL_BYTEORDER == SDL_BIG_ENDIAN)
	{
	  p[0] = (pix >> 16) & 0xFF;
	  p[1] = (pix >> 8) & 0xFF;
	  p[2] = pix & 0xFF;
	}
        else
	{
	  p[0] = pix & 0xFF;
	  p[1] = (pix >> 8) & 0xFF;
	  p[2] = (pix >> 16) & 0xFF;
	}
      case 4: *(Uint32 *)p = pix; break;
    }
  }
}


/*
  .1.
  2.3
  .4.
  5.6
  .78
*/

int letter[26][8] = {
  {1,1,1,1,1,1,0,0}, /* A */
  {1,1,1,1,1,1,1,0}, /* B */
  {1,1,0,0,1,0,1,0}, /* C */
  {0,0,1,1,1,1,1,0}, /* d */
  {1,1,0,1,1,0,1,0}, /* E */
  {1,1,0,1,1,0,0,0}, /* F */
  {1,1,1,0,1,1,1,0}, /* G */
  {0,1,1,1,1,1,0,0}, /* H */
  {0,0,1,0,0,1,0,0}, /* I */
  {0,0,1,0,1,1,1,0}, /* J */
  {0,1,1,1,1,0,0,1}, /* K */
  {0,1,0,0,1,0,1,0}, /* L */
  {1,1,1,0,1,1,0,0}, /* M */
  {0,0,0,0,1,1,0,1}, /* N */
  {1,1,1,0,1,1,1,0}, /* O */
  {1,1,1,1,1,0,0,0}, /* P */
  {1,1,1,0,1,1,1,1}, /* Q */
  {1,1,1,1,1,0,0,1}, /* R */
  {1,1,0,1,0,1,1,0}, /* S */
  {0,1,0,1,1,0,1,0}, /* t */
  {0,1,1,0,1,1,1,0}, /* U */
  {0,1,1,0,0,1,0,1}, /* V */
  {0,0,0,0,1,1,1,0}, /* w */
  {1,1,1,1,1,1,1,1}, /* X */ /* FIXME */
  {0,1,1,1,0,1,1,0}, /* y */
  {1,0,1,1,1,0,1,0}  /* Z */
};

SDL_Rect elements[8] = {
  {0, 0, 10, 2},
  {0, 0, 2, 10},
  {8, 0, 2, 10},
  {0, 8, 10, 2},
  {0, 10, 2, 10},
  {8, 10, 2, 10},
  {0, 18, 10, 2},
  {4, 12, 8, 8}
};


void drawtext(char * str)
{
  int i, j, x;
  SDL_Rect dest;
  
  for (i = 0; i < strlen(str); i++)
  {
    x = (WW / 2) - ((strlen(str) / 2) * 16) + (i * 16);

    if (str[i] >= 'A' && str[i] <= 'Z')
    {
      for (j = 0; j < 8; j++)
      {
	if (letter[str[i] - 'A'][j])
	{
	  dest.x = elements[j].x + x;
	  dest.y = elements[j].y + (WH / 2) - 10;
	  dest.w = elements[j].w;
	  dest.h = elements[j].h;

	  SDL_FillRect(screen, &dest,
		       SDL_MapRGB(screen->format, 255, 255, 0));
	}
      }
    }
  }
}

