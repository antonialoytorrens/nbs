2K Tetris

by Bill Kendrick <bill@newbreedsoftware.com>
http://www.newbreedsoftware.com/

February 21, 2003 - February 21, 2003


An attempt to make a Tetris-style game in 2048 bytes of C source code.
Uses libSDL (http://www.libsdl.org/)

Arrow keys to control:  Left/Right/Down to move piece.  Up to rotate.
Escape to quit.

Quits when game over (screen full), as well.

Prints final score to STDOUT upon exit.
