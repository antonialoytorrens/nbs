#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "SDL.h"
#define bk break
#define GT SDL_GetTicks()
int xx,yy,shp,rt,tm,done,i,s;SDL_Rect dst;SDL_Surface *scn;Uint8 bd[21][12];
char *of[7]={"20212223011121311011121302122232",
"10201121102011211020112110201121","10112122102001111011212210200111",
"20112112001011212011211200101121","01112112101121121001112110011112",
"01112102101112222001112100101112","00011121101102120111212210201112"};
dwsh(int n){for(i=0;i<8;i=i+2)bd[yy+of[shp][rt*8+i+1]-48][xx+of[shp][rt*8+i]-48]=n;}ers(int y){for(i=255;i>=0;i-=15){dst.x=12;dst.y=y*12;dst.w=120;dst.h=12;SDL_FillRect(scn,&dst,SDL_MapRGB(scn->format,i,i,i));SDL_Flip(scn);SDL_Delay(20);}for(y=y;y>1;y--)memcpy(bd[y]+1,bd[y-1]+1,10);memset(bd[0]+1,0,10);s+=50;}init(){for(yy=0;yy<20;yy++){int ln=1;for(xx=1;xx<11;xx++)if(bd[yy][xx]!=2)ln=0;if(ln)ers(yy);}xx=4;yy=tm=0;rt=rand()%4;shp=rand()%7;if(bmp())done=1;}bmp(){for(i=0;i<8;i=i+2)if(bd[yy+of[shp][rt*8+i+1]-48][xx+of[shp][rt*8+i]-48]>1)return 1;return 0;}hit(){if(yy>19||bmp()){yy--;dwsh(2);init();s+=5;}}
int main(void){SDL_Event ev;SDLKey k;Uint32 ltime,blk;int x,y;
SDL_Init(SDL_INIT_VIDEO);scn=SDL_SetVideoMode(144,252,16,SDL_HWSURFACE);
SDL_EnableKeyRepeat(60,30);srand(GT);blk=SDL_MapRGB(scn->format,0,0,0);
memset(bd,0,200);for(y=0;y<21;y++){bd[y][0]=bd[y][11]=bd[20][y/2+1]=3;}
s=done=0;init();do{ltime=GT;dwsh(0);
while(SDL_PollEvent(&ev)){if(ev.type==SDL_QUIT)done=1;
else if(ev.type==SDL_KEYDOWN){k=ev.key.keysym.sym;
switch(k){case SDLK_ESCAPE:done=1;bk;case SDLK_RIGHT:xx++;xx-=bmp();bk;
case SDLK_LEFT:xx--;xx+=bmp();bk;case SDLK_UP:rt=(rt+1)%4;if(bmp()){rt--;if(rt<0)rt=3;}bk;
case SDLK_DOWN:yy++;hit();tm=0;bk;default:;}}}
tm++;if(tm==20){yy++;tm=0;hit();}
dwsh(1);SDL_FillRect(scn,NULL,blk);
for(y=0;y<21;y++)for(x=0;x<12;x++)if(bd[y][x]){dst.x=(x*12);dst.y=(y*12);dst.w=12;dst.h=12;SDL_FillRect(scn,&dst,SDL_MapRGB(scn->format,bd[y][x]*64,dst.x,255-dst.y));}
SDL_Flip(scn);if (GT<ltime+50)SDL_Delay(ltime+50-GT);
}while (!done);SDL_Quit();printf("%d\n",s);return 0;}
