/*
  madbomber.c

  by Bill Kendrick
  bill@newbreedsoftware.com
  http://www.newbreedsoftware.com/

  October 25, 1999 - March 16, 2003
  November 6, 2004 (petrus@superwaba.com.br)
*/

/* $Id: madbomber.c,v 1.30 2004/12/06 06:01:54 petrus Exp $ */

/* Customizable defines (config.h?) */
#define EMBEDDED 1

#ifdef __palmos__
  #define PALMOS    1
  #define SCREEN_WIDTH  320
  #define SCREEN_HEIGHT 240
  #define SCALE_RATIO   2
  #define WANT_CONTINUE_OPTION 1
  #define HAVE_STDERR 1
  #define DATA_PREFIX  "/PALM/programs/madbomber/data/"
  #define SDL_MIXER_BUG
  #define WANT_SETICON 0
  #define HAVE_HOME_ENV 1
  #define WANT_HELP 0      /* Better read a help file */
  #define WANT_JOG_DIAL 0
  #define WANT_FLYING_NUMBERS 1
  #define WANT_SOUND 1
  #define WANT_MUSIC 1
  #define WANT_FULL_MUSICS 1
  #define SPRAY_SPEED 50
  #define WANT_OPTION_EFFECTS 0
  #define HAVE_SDL_IMAGE 1
#else

#ifndef EMBEDDED
  #define SCREEN_WIDTH  640
  #define SCREEN_HEIGHT 480
  #ifndef DATA_PREFIX
    #define DATA_PREFIX "../data"
  #endif
  #define HAVE_SDL_IMAGE 1
  #define HAVE_STDERR 1
  #define WANT_SETICON 1
  #define WANT_CONTINUE_OPTION 0
  #define WANT_SOUND 1
  #define WANT_OPTION_EFFECTS 1
  #define WANT_FULL_MUSICS 1
  #ifdef WIN32
    #define HAVE_HOME_ENV 0
  #else
    #define WANT_HELP 1
  #endif
  #define WANT_FLYING_NUMBERS 1
  #define WANT_JOG_DIAL 0
  #define SPRAY_SPEED 3
#else
  #define SCALE_RATIO 2    /* Use images scaled by 2 */
  #define SDL_MIXER_BUG
  #define HAVE_SDL_IMAGE 0
  #define HAVE_STDERR 0
  #define WANT_SETICON 0
  #define HAVE_HOME_ENV 1
  #define WANT_HELP 0      /* Better read a help file */
  #define WANT_CONTINUE_OPTION 1
  #if defined __SYMBIAN32__
    #define SCREEN_WIDTH  208
    #define SCREEN_HEIGHT 277
    #if defined __WINS__
      #define DATA_PREFIX "./system/Apps/madbomber/data/"
      #define WANT_JOG_DIAL 0
    #else
      #define DATA_PREFIX "../mbfiles/data/"
      #define WANT_JOG_DIAL 1
    #endif
    #define WANT_FLYING_NUMBERS 1
    #define WANT_SOUND 1
  #else  /* not SYMBIAN32, assume... WIN_CE? PALM? */
    #define SCREEN_WIDTH  240
    #define SCREEN_HEIGHT 320
    #define DATA_PREFIX "../mbfiles/data/"
    #define WANT_FLYING_NUMBERS 0
    #define WANT_JOG_DIAL 0
    #define WANT_SOUND 1
  #endif
  #define SPRAY_SPEED 50
  #define WANT_OPTION_EFFECTS 0
  #define WANT_FULL_MUSICS 0
#endif
#endif

/* internal defines */

#define VERSION "0.2.6"
#define OPTIONS_FILE_VERSION "# Mad Bomber options file -- version 18\n"
#define STATE_FILE_VERSION 18

/* two_player_vs and continue are currently mutually exclusive */
#define WANT_TWO_PLAYER_VS_OPTION !WANT_CONTINUE_OPTION

/* for legacy */
#ifdef NOSOUND
  #undef WANT_SOUND
  #define WANT_SOUND 0
#endif

/* Check consistency */
#if !WANT_SOUND
  #undef  WANT_OPTION_EFFECTS
  #define WANT_OPTION_EFFECTS 0
  #undef  WANT_FULL_MUSICS
  #define WANT_FULL_MUSICS 0
  #undef  WANT_MUSIC
  #define WANT_MUSIC 0
#endif

/*
| In theory, we could have scaled and rotated images independently
| Actually, we have either landscape/normal size and portrait/half_size
*/
#if SCREEN_WIDTH > SCREEN_HEIGHT
  #define LANDSCAPE_FORMAT 1
  #if SCREEN_WIDTH < 500
//     #define SCALE_RATIO 2
     #define PSEUDO_WIDTH  (SCREEN_WIDTH * SCALE_RATIO)
     #define PSEUDO_HEIGHT (SCREEN_HEIGHT * SCALE_RATIO)
  #else
//     #define SCALE_RATIO 1
     #define PSEUDO_WIDTH   SCREEN_WIDTH
     #define PSEUDO_HEIGHT  SCREEN_HEIGHT
  #endif
#else
  #define LANDSCAPE_FORMAT 0
  #if SCREEN_HEIGHT < 500
//     #define SCALE_RATIO 2
     #define PSEUDO_WIDTH   (SCREEN_HEIGHT * SCALE_RATIO)
     #define PSEUDO_HEIGHT  (SCREEN_WIDTH * SCALE_RATIO)
  #else
//     #define SCALE_RATIO 1
     #define PSEUDO_WIDTH   SCREEN_HEIGHT
     #define PSEUDO_HEIGHT  SCREEN_WIDTH
  #endif
#endif

/*
| if SCALE_RATIO is none of 1 or 2,
| scale and rotate_and_scale routines should be written
| to round up to the next SCALE_RATIO multiple.
*/

#define MAX_FLYING_NUMBERS_SCALE  (PSEUDO_HEIGHT / (2*12))

#define STATIC static

#ifndef NO_PATH
#define FILE_PATH(path, file)  (path "/" file)
#else
#define FILE_PATH(path, file)  (file)
#endif

/* #includes: */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#if !defined WIN32 && !defined PALMOS
#include <unistd.h>
#endif
#include "SDL.h"
#if HAVE_SDL_IMAGE
#include "SDL_image.h"
#endif
#include <math.h>

/* #ifdef WIN32 */
/* #include <windows.h> */
/* #endif */

#if WANT_SOUND
#include "SDL_mixer.h"
#endif

/* Image enumerations: */

enum {
  IMG_LOADING,
  IMG_BAR,
  IMG_TITLE_TITLE,
  IMG_TITLE_ONE_PLAYER,
  IMG_TITLE_ONE_PLAYER_OFF,
  IMG_TITLE_TWO_PLAYERS,
  IMG_TITLE_TWO_PLAYERS_OFF,
#if WANT_TWO_PLAYER_VS_OPTION
  IMG_TITLE_TWO_PLAYER_VS,
  IMG_TITLE_TWO_PLAYER_VS_OFF,
#endif
#if WANT_CONTINUE_OPTION
  IMG_TITLE_CONTINUE,
  IMG_TITLE_CONTINUE_OFF,
#endif
  IMG_TITLE_OPTIONS,
  IMG_TITLE_OPTIONS_OFF,
  IMG_TITLE_HIGHSCORE,
  IMG_TITLE_HIGHSCORE_OFF,
  IMG_TITLE_EXIT,
  IMG_TITLE_EXIT_OFF,
  IMG_OPTIONS_OPTIONS,
  IMG_OPTIONS_DETAIL,
  IMG_OPTIONS_NORMAL,
  IMG_OPTIONS_NORMAL_OFF,
  IMG_OPTIONS_ZEN,
  IMG_OPTIONS_ZEN_OFF,
  IMG_OPTIONS_PLAYER_ONE,
  IMG_OPTIONS_PLAYER_TWO,
  IMG_OPTIONS_DIFFICULTY,
  IMG_OPTIONS_HARD,
  IMG_OPTIONS_HARD_OFF,
#if WANT_OPTION_EFFECTS
  IMG_OPTIONS_EFFECTS,
  IMG_OPTIONS_MUSIC,
  IMG_OPTIONS_VOLUME,
#endif
  IMG_OPTIONS_0PERCENT,
  IMG_OPTIONS_0PERCENT_OFF,
  IMG_OPTIONS_25PERCENT,
  IMG_OPTIONS_25PERCENT_OFF,
  IMG_OPTIONS_50PERCENT,
  IMG_OPTIONS_50PERCENT_OFF,
  IMG_OPTIONS_75PERCENT,
  IMG_OPTIONS_75PERCENT_OFF,
  IMG_OPTIONS_100PERCENT,
  IMG_OPTIONS_100PERCENT_OFF,
  IMG_OPTIONS_OK,
  IMG_OPTIONS_OK_OFF,
  IMG_BACKGROUND,
  IMG_BUCKET1,
  IMG_BUCKET2,
  IMG_BUCKET3,
  IMG_BUCKET1RED,
  IMG_BUCKET2RED,
  IMG_BUCKET3RED,
  IMG_SMALL_BUCKET1,
  IMG_SMALL_BUCKET2,
  IMG_SMALL_BUCKET3,
  IMG_SMALL_BUCKET1RED,
  IMG_SMALL_BUCKET2RED,
  IMG_SMALL_BUCKET3RED,
  IMG_BOMB0,
  IMG_BOMB1,
  IMG_BOMB2,
  IMG_BOMB3,
  IMG_EXPLOSION1,
  IMG_EXPLOSION2,
  IMG_BOMBER_SAD,
  IMG_BOMBER_HAPPY,
  IMG_BOMBER_AMAZED,
  IMG_DROP_UP,
  IMG_DROP_RIGHT_UP,
  IMG_DROP_RIGHT,
  IMG_DROP_RIGHT_DOWN,
  IMG_DROP_DOWN,
  IMG_DROP_LEFT_DOWN,
  IMG_DROP_LEFT,
  IMG_DROP_LEFT_UP,
  IMG_0,
  IMG_1,
  IMG_2,
  IMG_3,
  IMG_4,
  IMG_5,
  IMG_6,
  IMG_7,
  IMG_8,
  IMG_9,
  IMG_0RED,
  IMG_1RED,
  IMG_2RED,
  IMG_3RED,
  IMG_4RED,
  IMG_5RED,
  IMG_6RED,
  IMG_7RED,
  IMG_8RED,
  IMG_9RED,
  IMG_HIGHSCORE,
  IMG_PAUSED,
  IMG_GAME_OVER,
  IMG_PRESS_FIRE,
  IMG_PRESS_ESCAPE,
  IMG_SPRAY_CYAN,
  IMG_SPRAY_BLACK,
  IMG_SPRAY_BLUE,
  IMG_HIGHSCORE_HIGHSCORE,
  IMG_HIGHSCORE_LETTERS
};


/* Image filenames: */

static char const * const image_names[] = {
   /* IMAGES_LIST_START+  Do not remove.  This line is used by make */
   FILE_PATH(".", "loading.bmp"),
   FILE_PATH(".", "bar.bmp"),
   FILE_PATH("title", "title.bmp"),
   FILE_PATH("title", "one-player.bmp"),
   FILE_PATH("title", "one-player-off.bmp"),
   FILE_PATH("title", "two-players.bmp"),
   FILE_PATH("title", "two-players-off.bmp"),
#if WANT_TWO_PLAYER_VS_OPTION
   FILE_PATH("title", "two-player-vs.bmp"),
   FILE_PATH("title", "two-player-vs-off.bmp"),
#endif
#if WANT_CONTINUE_OPTION
   FILE_PATH("title", "continue.bmp"),
   FILE_PATH("title", "continue-off.bmp"),
#endif
   FILE_PATH("title", "options.bmp"),
   FILE_PATH("title", "options-off.bmp"),
   FILE_PATH("title", "highscore.bmp"),
   FILE_PATH("title", "highscore-off.bmp"),
   FILE_PATH("title", "exit.bmp"),
   FILE_PATH("title", "exit-off.bmp"),
   FILE_PATH("options", "options.bmp"),
   FILE_PATH("options", "detail.bmp"),
   FILE_PATH("options", "normal.bmp"),
   FILE_PATH("options", "normal-off.bmp"),
   FILE_PATH("options", "zen.bmp"),
   FILE_PATH("options", "zen-off.bmp"),
   FILE_PATH("options", "player-one.bmp"),
   FILE_PATH("options", "player-two.bmp"),
   FILE_PATH("options", "difficulty.bmp"),
   FILE_PATH("options", "hard.bmp"),
   FILE_PATH("options", "hard-off.bmp"),
#if WANT_OPTION_EFFECTS
   FILE_PATH("options", "effects.bmp"),
   FILE_PATH("options", "music.bmp"),
   FILE_PATH("options", "volume.bmp"),
#endif
   FILE_PATH("options", "0percent.bmp"),
   FILE_PATH("options", "0percent-off.bmp"),
   FILE_PATH("options", "25percent.bmp"),
   FILE_PATH("options", "25percent-off.bmp"),
   FILE_PATH("options", "50percent.bmp"),
   FILE_PATH("options", "50percent-off.bmp"),
   FILE_PATH("options", "75percent.bmp"),
   FILE_PATH("options", "75percent-off.bmp"),
   FILE_PATH("options", "100percent.bmp"),
   FILE_PATH("options", "100percent-off.bmp"),
   FILE_PATH("options", "ok.bmp"),
   FILE_PATH("options", "ok-off.bmp"),
   FILE_PATH("game", "background.bmp"),
   FILE_PATH("game/bucket", "bucket1.bmp"),
   FILE_PATH("game/bucket", "bucket2.bmp"),
   FILE_PATH("game/bucket", "bucket3.bmp"),
   FILE_PATH("game/bucket", "bucket1red.bmp"),
   FILE_PATH("game/bucket", "bucket2red.bmp"),
   FILE_PATH("game/bucket", "bucket3red.bmp"),
   FILE_PATH("game/bucket", "small-bucket1.bmp"),
   FILE_PATH("game/bucket", "small-bucket2.bmp"),
   FILE_PATH("game/bucket", "small-bucket2.bmp"),
   FILE_PATH("game/bucket", "small-bucket1red.bmp"),
   FILE_PATH("game/bucket", "small-bucket2red.bmp"),
   FILE_PATH("game/bucket", "small-bucket2red.bmp"),
   FILE_PATH("game/bomb", "bomb0.bmp"),
   FILE_PATH("game/bomb", "bomb1.bmp"),
   FILE_PATH("game/bomb", "bomb2.bmp"),
   FILE_PATH("game/bomb", "bomb3.bmp"),
   FILE_PATH("game/bomb", "explosion1.bmp"),
   FILE_PATH("game/bomb", "explosion2.bmp"),
   FILE_PATH("game/bomber", "bomber-sad.bmp"),
   FILE_PATH("game/bomber", "bomber-happy.bmp"),
   FILE_PATH("game/bomber", "bomber-amazed.bmp"),
   FILE_PATH("game/drop", "drop-up.bmp"),
   FILE_PATH("game/drop", "drop-right-up.bmp"),
   FILE_PATH("game/drop", "drop-right.bmp"),
   FILE_PATH("game/drop", "drop-right-down.bmp"),
   FILE_PATH("game/drop", "drop-down.bmp"),
   FILE_PATH("game/drop", "drop-left-down.bmp"),
   FILE_PATH("game/drop", "drop-left.bmp"),
   FILE_PATH("game/drop", "drop-left-up.bmp"),
   FILE_PATH("game/numbers", "0.bmp"),
   FILE_PATH("game/numbers", "1.bmp"),
   FILE_PATH("game/numbers", "2.bmp"),
   FILE_PATH("game/numbers", "3.bmp"),
   FILE_PATH("game/numbers", "4.bmp"),
   FILE_PATH("game/numbers", "5.bmp"),
   FILE_PATH("game/numbers", "6.bmp"),
   FILE_PATH("game/numbers", "7.bmp"),
   FILE_PATH("game/numbers", "8.bmp"),
   FILE_PATH("game/numbers", "9.bmp"),
   FILE_PATH("game/numbers", "0red.bmp"),
   FILE_PATH("game/numbers", "1red.bmp"),
   FILE_PATH("game/numbers", "2red.bmp"),
   FILE_PATH("game/numbers", "3red.bmp"),
   FILE_PATH("game/numbers", "4red.bmp"),
   FILE_PATH("game/numbers", "5red.bmp"),
   FILE_PATH("game/numbers", "6red.bmp"),
   FILE_PATH("game/numbers", "7red.bmp"),
   FILE_PATH("game/numbers", "8red.bmp"),
   FILE_PATH("game/numbers", "9red.bmp"),
   FILE_PATH("game", "highscore.bmp"),
   FILE_PATH("game", "paused.bmp"),
   FILE_PATH("game", "game-over.bmp"),
   FILE_PATH("game", "press-fire.bmp"),
   FILE_PATH("game", "press-escape.bmp"),
   FILE_PATH(".", "spray-cyan.bmp"),
   FILE_PATH(".", "spray-black.bmp"),
   FILE_PATH(".", "spray-blue.bmp"),
   FILE_PATH("highscore", "highscore.bmp"),
   FILE_PATH("highscore", "letters.bmp")
   /* IMAGES_LIST_START-  Do not remove.  This line is used by make */
};

#define NUM_IMAGES (sizeof image_names / sizeof image_names[0])

/* Sound enumerations: */

enum {
  SND_SELECT,
  SND_CONFIRM,
  SND_FUSE,
  SND_EXPLOSION,
  SND_BIGEXPLOSION,
  SND_SPLASH1,
  SND_SPLASH2,
  SND_SPLASH3,
  SND_SPLASH4,
  SND_SPLASH5,
  SND_SPLASH6,
  SND_SPLASH7,
  SND_SPLASH8,
  SND_ONEUP,
  SND_LEVEL8,
  SND_HIGHSCORE,
  SND_SPRAY,
  SND_CAN_SHAKE
};


/* Sound filenames: */

static char const * const sound_names[] = {
  "select.wav",
  "confirm.wav",
  "fuse.wav",
  "explosion.wav",
  "bigexplosion.wav",
  "splash1.wav",
  "splash2.wav",
  "splash3.wav",
  "splash4.wav",
  "splash5.wav",
  "splash6.wav",
  "splash7.wav",
  "splash8.wav",
  "oneup.wav",
  "level8.wav",
  "highscore.wav",
  "spray.wav",
  "can-shake.wav"
};

#define NUM_SOUNDS (sizeof sound_names / sizeof sound_names[0])

/* Music filenames: */
#if WANT_MUSIC
#if WANT_FULL_MUSICS

//#define MUS_TITLE "bizjung.it"
#define MUS_TITLE "winterwi.mod"
#define MUS_HIGHSCORE "waterfal.mod"

static char const * const game_music_names[] = {
#ifndef PALMOS
  "fdn-arab.s3m",
  "gluppobe.mod",
#endif
  "astraltr.mod"
};

#else

#define MUS_TITLE "winterwi.mod"

static char const * const game_music_names[] = {
  "fdn-arab.s3m"
};

#endif

#define NUM_GAME_MUSICS (sizeof game_music_names / sizeof game_music_names[0])
#endif //WANT_MUSIC



/* Title Options: */

enum {
  TITLE_OPTION_ONE_PLAYER,
  TITLE_OPTION_TWO_PLAYERS,
#if WANT_TWO_PLAYER_VS_OPTION
  TITLE_OPTION_TWO_PLAYER_VS,
#endif
#if WANT_CONTINUE_OPTION
  TITLE_OPTION_CONTINUE,
#endif
  TITLE_OPTION_OPTIONS,
  TITLE_OPTION_HIGHSCORE,
  TITLE_OPTION_EXIT
};


/* Title option images: */

static int const title_option_images[] = {
  IMG_TITLE_ONE_PLAYER,
  IMG_TITLE_TWO_PLAYERS,
#if WANT_TWO_PLAYER_VS_OPTION
  IMG_TITLE_TWO_PLAYER_VS,
#endif
#if WANT_CONTINUE_OPTION
  IMG_TITLE_CONTINUE,
#endif
  IMG_TITLE_OPTIONS,
  IMG_TITLE_HIGHSCORE,
  IMG_TITLE_EXIT
};

#define NUM_TITLE_OPTIONS (sizeof title_option_images / sizeof title_option_images[0])

/* Option screen option enumerations: */

enum {
  OPTIONS_OPTION_DETAIL,
  OPTIONS_OPTION_PLAYER_ONE,
  OPTIONS_OPTION_PLAYER_TWO,
  OPTIONS_OPTION_EFFECTS,
  OPTIONS_OPTION_MUSIC,
  OPTIONS_OPTION_OK,
  NUM_OPTIONS_OPTIONS
};


#if WANT_FLYING_NUMBERS

/* Flying number layouts: */

static int const flying_number_layouts[8][7] = {
  {  0,
   0,  1,
     0,
   0,  1,
     0},

  {  1,
   0,  1,
     1,
   1,  0,
     1},

  {  1,
   0,  1,
     1,
   0,  1,
     1},

  {  0,
   1,  1,
     1,
   0,  1,
     0},

  {  1,
   1,  0,
     1,
   0,  1,
     1},

  {  1,
   1,  0,
     1,
   1,  1,
     1},

  {  1,
   0,  1,
     0,
   0,  1,
     0},

  {  1,
   1,  1,
     1,
   1,  1,
     1}
};

#endif


/* Graffiti letters: */

static int const graffiti[36][5][2][2] = {
  {
    /* 0 */
    { { 2, 0 }, { 0, 4 } },
    { { 0, 4 }, { 2, 8 } },
    { { 2, 8 }, { 4, 4 } },
    { { 4, 4 }, { 2, 0 } },
    { { 4, 0 }, { 0, 8 } }
  },
  {
    /* 1 */
    { { 0, 1 }, { 2, 0 } },
    { { 2, 0 }, { 2, 8 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* 2 */
    { { 1, 1 }, { 2, 0 } },
    { { 2, 0 }, { 3, 0 } },
    { { 3, 0 }, { 4, 3 } },
    { { 4, 3 }, { 0, 8 } },
    { { 0, 8 }, { 4, 8 } }
  },
  {
    /* 3 */
    { { 0, 0 }, { 4, 2 } },
    { { 4, 2 }, { 1, 4 } },
    { { 1, 4 }, { 4, 6 } },
    { { 4, 6 }, { 0, 8 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* 4 */
    { { 1, 0 }, { 0, 4 } },
    { { 0, 4 }, { 4, 4 } },
    { { 4, 0 }, { 2, 8 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* 5 */
    { { 4, 0 }, { 0, 0 } },
    { { 0, 0 }, { 0, 5 } },
    { { 0, 5 }, { 3, 4 } },
    { { 3, 4 }, { 4, 6 } },
    { { 4, 6 }, { 0, 8 } }
  },
  {
    /* 6 */
    { { 4, 0 }, { 0, 6 } },
    { { 0, 6 }, { 2, 8 } },
    { { 2, 8 }, { 4, 6 } },
    { { 4, 6 }, { 2, 4 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* 7 */
    { { 0, 1 }, { 4, 0 } },
    { { 4, 0 }, { 1, 8 } },
    { { 1, 4 }, { 4, 3 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* 8 */
    { { 0, 1 }, { 4, 0 } },
    { { 4, 0 }, { 0, 5 } },
    { { 0, 5 }, { 2, 8 } },
    { { 2, 8 }, { 4, 5 } },
    { { 4, 5 }, { 0, 1 } }
  },
  {
    /* 9 */
    { { 4, 0 }, { 1, 1 } },
    { { 1, 1 }, { 0, 4 } },
    { { 0, 4 }, { 2, 3 } },
    { { 2, 3 }, { 4, 0 } },
    { { 4, 0 }, { 3, 8 } }
  },
  {
    /* A */
    { { 0, 8 }, { 2, 0 } },
    { { 2, 0 }, { 4, 8 } },
    { { 0, 7 }, { 4, 4 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* B */
    { { 0, 8 }, { 0, 0 } },
    { { 0, 0 }, { 4, 2 } },
    { { 4, 2 }, { 0, 4 } },
    { { 0, 4 }, { 4, 6 } },
    { { 4, 6 }, { 0, 8 } }
  },
  {
    /* C */
    { { 4, 0 }, { 0, 4 } },
    { { 0, 4 }, { 4, 8 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* D */
    { { 0, 0 }, { 0, 8 } },
    { { 0, 8 }, { 4, 4 } },
    { { 4, 4 }, { 0, 0 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* E */
    { { 4, 0 }, { 0, 2 } },
    { { 0, 2 }, { 3, 4 } },
    { { 3, 4 }, { 0, 6 } },
    { { 0, 6 }, { 4, 8 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* F */
    { { 4, 0 }, { 0, 1 } },
    { { 0, 1 }, { 1, 8 } },
    { { 0, 4 }, { 4, 3 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* G */
    { { 4, 0 }, { 0, 4 } },
    { { 0, 4 }, { 4, 8 } },
    { { 4, 8 }, { 4, 4 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* H */
    { { 1, 0 }, { 0, 8 } },
    { { 4, 0 }, { 4, 8 } },
    { { 0, 4 }, { 5, 3 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* I */
    { { 3, 0 }, { 2, 8 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* J */
    { { 4, 0 }, { 4, 6 } },
    { { 4, 6 }, { 2, 8 } },
    { { 2, 8 }, { 0, 5 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* K */
    { { 0, 0 }, { 0, 8 } },
    { { 3, 0 }, { 0, 4 } },
    { { 0, 4 }, { 4, 8 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* L */
    { { 0, 0 }, { 0, 8 } },
    { { 0, 8 }, { 4, 7 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* M */
    { { 0, 8 }, { 1, 0 } },
    { { 1, 0 }, { 2, 4 } },
    { { 2, 4 }, { 4, 0 } },
    { { 4, 0 }, { 4, 8 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* N */
    { { 0, 8 }, { 0, 0 } },
    { { 0, 0 }, { 4, 8 } },
    { { 4, 8 }, { 4, 1 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* O */
    { { 2, 0 }, { 0, 4 } },
    { { 0, 4 }, { 2, 8 } },
    { { 2, 8 }, { 4, 4 } },
    { { 4, 4 }, { 2, 0 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* P */
    { { 0, 8 }, { 0, 0 } },
    { { 0, 0 }, { 4, 2 } },
    { { 4, 2 }, { 0, 4 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* Q */
    { { 2, 0 }, { 0, 4 } },
    { { 0, 4 }, { 2, 8 } },
    { { 2, 8 }, { 4, 4 } },
    { { 4, 4 }, { 2, 0 } },
    { { 2, 4 }, { 4, 8 } }
  },
  {
    /* R */
    { { 0, 8 }, { 0, 0 } },
    { { 0, 0 }, { 4, 2 } },
    { { 4, 2 }, { 0, 4 } },
    { { 0, 4 }, { 4, 8 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* S */
    { { 4, 0 }, { 0, 3 } },
    { { 0, 2 }, { 4, 5 } },
    { { 4, 5 }, { 0, 8 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* T */
    { { 0, 0 }, { 4, 0 } },
    { { 2, 0 }, { 1, 8 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* U */
    { { 0, 0 }, { 0, 8 } },
    { { 0, 8 }, { 4, 7 } },
    { { 4, 7 }, { 4, 0 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* V */
    { { 0, 0 }, { 2, 8 } },
    { { 2, 8 }, { 4, 0 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* W */
    { { 0, 0 }, { 1, 8 } },
    { { 1, 8 }, { 2, 5 } },
    { { 2, 5 }, { 3, 8 } },
    { { 3, 8 }, { 4, 0 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* X */
    { { 0, 0 }, { 4, 8 } },
    { { 4, 0 }, { 0, 8 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* Y */
    { { 0, 0 }, { 2, 4 } },
    { { 4, 0 }, { 0, 8 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } }
  },
  {
    /* Z */
    { { 0, 0 }, { 4, 0 } },
    { { 4, 0 }, { 0, 8 } },
    { { 0, 8 }, { 4, 8 } },
    { { -1, -1 }, { -1, -1 } },
    { { -1, -1 }, { -1, -1 } }
  }
};


/* Bomb per level: */

static int const bombs_per_level[8] = {
  10,
  20,
  30,
  40,
  50,
  75,
  100,
  150
};


/* Bombs: */

#define MAX_BOMBS 128

typedef struct t_Bomb {
  int alive, x, y;
} Bomb;


/* Drops: */

#define MAX_DROPS 256

typedef struct t_Drop {
  int alive, timer, x, y, xm, ym;
} Drop;


/* Spray drips: */

#define MAX_SPRAYDRIPS 16

typedef struct t_Spraydrip {
  int alive, timer, img, x, y;
} Spraydrip;

/* File types: */

enum WhatFile {
   OPTION_FILE,
   STATE_FILE
};


/* Non-const static globals: */

#if WANT_SOUND
static int use_sound;
#endif
static Uint16 pseudo_widths[NUM_IMAGES];
static Uint16 pseudo_heights[NUM_IMAGES];
static int use_fullscreen, zen, effects_volume, music_volume,
  num_rects, highscore, bomber_x, bomber_y, player, frame, vs_mode, spray_count,
  quick_spray;

#if WANT_CONTINUE_OPTION
static int can_continue;
#endif

static int level[2], past_level_8[2], half_level[2],
  old_x[2], one_up_score[2], have_highscore[2];
static int bomber_go, bomber_happy, bombs_left, no_active_bombs,
  bomber_xm, bomber_xm_time,
  left_down, right_down, bomber_left_down, bomber_right_down,
  bomber_left_left_down, bomber_right_right_down,
  img, explode_the_bombs, game_over, drop_bomb, num_players;

static int x[2], width[2], num_buckets[2], score[2];

static char highscorer[13];
static SDL_Surface * screen;
static SDL_Surface * images[NUM_IMAGES] = { 0 };
static SDL_Rect option_box;
static SDL_Rect rects[(MAX_BOMBS + MAX_DROPS + 4) * 2 + 128];
STATIC Bomb bombs[MAX_BOMBS];
STATIC Drop drops[MAX_DROPS];
STATIC Spraydrip spraydrips[MAX_SPRAYDRIPS];
#ifdef __palmos__
static SDL_Joystick *joystick;
#endif

#if WANT_SOUND
static Mix_Chunk * sounds[NUM_SOUNDS] = { 0 };
#if WANT_MUSIC
static Mix_Music * title_music = 0;
#if WANT_FULL_MUSICS
static Mix_Music * highscore_music = 0;
static Mix_Music * game_musics[NUM_GAME_MUSICS] = { 0 };
#endif
#endif //WANT_MUSIC
#endif //WANT_SOUND

#if !HAVE_STDERR
#ifdef stderr
#undef stderr
#endif
STATIC FILE * errstd;
#define stderr errstd
#endif

/* Local function prototypes: */

static int game(int mode);
static int title();
static int setup();
static void show_sdl_error();
static void mb_shutdown();
static void addrect(SDL_Rect rect);
static void addbomb(int x);
static void addsplash(int x, int y);
static void adddrop(int x, int y, int xm);
#if WANT_SOUND
static void playsound(int snd, int chan);
#endif
static void drawscore(int score, int player);
static int pausescreen();
static void explodebombs();
static void erase(SDL_Rect dest);
static int intersects(SDL_Rect const r1, SDL_Rect const r2, SDL_Rect * r);
static int parse_args(int argc, char ** argv);
static void read_options();
static void write_options();
#if WANT_CONTINUE_OPTION
static void read_state();
static void write_state();
#endif
static FILE * open_file(enum WhatFile whatFile, char * mode);
static int optionscreen();
static void show_option_img(int horiz, int y, int img);
static void show_option_meter(int horiz, int value, int selected);
#if WANT_FLYING_NUMBERS
static void draw_flying_numbers(int number, int scale, Uint8 r, Uint8 g, Uint8 b);
static void erase_flying_numbers(int scale);
#endif
static int highscorescreen();
static int spraytext(char * str, int y, int img, int scale);
static void sprayline(int x1, int y1, int x2, int y2, int img);
static void spraydot(int x, int y, int img);
static void handle_spraydrips();
static void add_spraydrip(int x, int y, int img);
static int sign_highscore();
#if WANT_SETICON
static int seticon();
#endif
static void my_blit(SDL_Surface * src_img, SDL_Rect * src_rect,
		    SDL_Surface * dest_img, SDL_Rect * dest_rect);
static void my_updaterect(SDL_Surface * surf, SDL_Rect * dest);
static void my_fillrect(SDL_Surface * surf, SDL_Rect * dest, Uint32 color);
#if !LANDSCAPE_FORMAT
static void rotate_and_scale(SDL_Rect const * src, SDL_Rect * tgt);
#else
static void scale(SDL_Rect const * src, SDL_Rect * tgt);
#endif


/* --- MAIN --- */

int main(int argc, char * argv[])
{
  int mode, quit = 0;

#if !HAVE_STDERR
  stderr = fopen("stderr.txt", "wb");
#endif

  /* Initialization: */

  if ((quit = parse_args(argc, argv)) == 0)
    {
      read_options();
#if WANT_CONTINUE_OPTION
      read_state();
#endif
      if (!setup()) quit = -3;
    }

  if (quit)
    {
      if (quit == -3)
        {
          show_sdl_error();
          mb_shutdown();
        }
      return quit+1;
    }


  /* Set volumes: */

#if WANT_SOUND
  if (use_sound)
    {
      Mix_Volume(-1, effects_volume * 16);
      Mix_VolumeMusic(music_volume * 16);
    }
#endif


  /* MAIN INTERFACE LOOP! */

  do
    {
      /* Display title screen: */

      mode = title();


      /* Decide what to based on title screen command: */

      switch (mode)
        {
#if WANT_CONTINUE_OPTION
	case TITLE_OPTION_CONTINUE:
           if (!can_continue) break;  /* else, fall thru */
#endif
#if WANT_TWO_PLAYER_VS_OPTION
	case TITLE_OPTION_TWO_PLAYER_VS:
#endif
	case TITLE_OPTION_ONE_PLAYER:
	case TITLE_OPTION_TWO_PLAYERS:
          /* Stop music: */
#if WANT_SOUND
	  if (use_sound == 1)
	    Mix_HaltMusic();
#endif
	  quit = game(mode);
	  break;

	case TITLE_OPTION_OPTIONS:
	  quit = optionscreen();
          break;
	
	case TITLE_OPTION_EXIT:
	  quit = 1;
          break;
	
	case TITLE_OPTION_HIGHSCORE:
	  quit = highscorescreen();
          break;

	default:
	  break;
        }
    }
  while (quit == 0);


  /* Save options: */
  write_options();


#if WANT_CONTINUE_OPTION
  /* Save state file: */
  write_state();
#endif

  /* Shut down and quit: */
  mb_shutdown();

  return 0;
}


/* Game loop: */

static int game(int mode)
{
  SDL_Event event;
  int done, quit, i, fire;
  int old_bomber_x = 0;  /* GCC warning */
#if WANT_FLYING_NUMBERS
  int flying_numbers_scale;
#endif
  SDL_Rect dest;
  Uint32 last_time;


#if WANT_TWO_PLAYER_VS_OPTION
  if (mode == TITLE_OPTION_TWO_PLAYER_VS)
    vs_mode = 1;
  else
     vs_mode = 0;
#else
  vs_mode = 0;
#endif

#if WANT_CONTINUE_OPTION
  if (mode != TITLE_OPTION_CONTINUE)
    can_continue = 0;
#endif


  /* Draw background screen: */

  dest.x = 0;
  dest.y = 0;
  dest.w = PSEUDO_WIDTH;
  dest.h = 480;
  erase(dest);


#if WANT_CONTINUE_OPTION
  if (can_continue == 0)
#endif
    {
      /* Init. game variables: */

      for (i = 0; i < 2; i++)
	{
	  score[i] = 0;
	  one_up_score[i] = 1000;
	  level[i] = 1;
	  half_level[i] = 0;
	  past_level_8[i] = 0;
	  x[i] = 32;
	  old_x[i] = 32;
	  have_highscore[i] = 0;
	}

      if (mode == TITLE_OPTION_TWO_PLAYERS)
	num_players = 2;
      else
	num_players = 1;

      num_buckets[0] = 3;
      if (num_players == 2)
	num_buckets[1] = 3;
      else
	num_buckets[1] = 0;

      player = 0;

      bomber_x = PSEUDO_WIDTH-64;
      old_bomber_x = PSEUDO_WIDTH-64;
      bomber_go = 0;
      bomber_happy = 1;
      bombs_left = 0;
      bomber_xm = 0;
      bomber_xm_time = 0;
      explode_the_bombs = 0;

      for (i = 0; i < MAX_BOMBS; i++)
	bombs[i].alive = 0;

      for (i = 0; i < MAX_DROPS; i++)
	drops[i].alive = 0;
    }

  drawscore(score[player], player);
  my_updaterect(screen, 0);


  /* Main game loop! */

  frame = 0;
  left_down = 0;
  right_down = 0;
  bomber_left_left_down = 0;
  bomber_left_down = 0;
  bomber_right_down = 0;
  bomber_right_right_down = 0;
  drop_bomb = 0;
  done = 0;
  quit = 0;
  game_over = 0;
#if WANT_FLYING_NUMBERS
  flying_numbers_scale = 1;
#endif


#if WANT_CONTINUE_OPTION
  can_continue = 1;
#endif


  do
    {
      num_rects = 0;
      last_time = SDL_GetTicks();
      frame++;


      /* Get events: */

      fire = 0;

      while (SDL_PollEvent(&event))
	{
	  switch (event.type)
	    {
	      case SDL_KEYDOWN:   /* A keypress! */
		switch (event.key.keysym.sym)
		  {
#if WANT_JOG_DIAL
                  case SDLK_RETURN:
#endif
		  case SDLK_ESCAPE: /* Quit the game and return to main menu */
		    done = 1;
		    break;

#if !WANT_JOG_DIAL
                  case SDLK_SPACE:
                  case SDLK_RETURN:
                    fire = 1;
                    break;
#if LANDSCAPE_FORMAT
		  case SDLK_LEFT:
#else
		  case SDLK_UP:
#endif
		    left_down = 1;
		    break;

#if LANDSCAPE_FORMAT
		  case SDLK_RIGHT:
#else
		  case SDLK_DOWN:
#endif
		    right_down = 1;
		    break;
#endif
		  case SDLK_1:
		    bomber_left_left_down = 1;
		    break;
		  case SDLK_2:
		    bomber_left_down = 1;
		    break;
		  case SDLK_3:
		    bomber_right_down = 1;
		    break;
		  case SDLK_4:
		    bomber_right_right_down = 1;
		    break;

#if WANT_JOG_DIAL
		  case SDLK_UP:
		  case SDLK_DOWN:
#endif
		  case SDLK_TAB:
		  case SDLK_p:
		    /* Tab or P pauses: */
		    if (game_over == 0)
		      {
			done = pausescreen();
	
			if (done == 2)
			 quit = 1;
	
			left_down = 0;
			right_down = 0;
		      }
		    break;

		  default:
		    break;
		  }

		break;

	      case SDL_KEYUP:    /* A key-release (for movement keys): */
                switch (event.key.keysym.sym)
                  {
#if !WANT_JOG_DIAL
#if LANDSCAPE_FORMAT
		  case SDLK_LEFT:
#else
		  case SDLK_UP:
#endif
		    left_down = 0;
		    break;
#if LANDSCAPE_FORMAT
		  case SDLK_RIGHT:
#else
		  case SDLK_DOWN:
#endif
		    right_down = 0;
		    break;
#endif
		  case SDLK_1:
		    bomber_left_left_down = 0;
		    break;
		  case SDLK_2:
		    bomber_left_down = 0;
		    break;
		  case SDLK_3:
		    bomber_right_down = 0;
		    break;
		  case SDLK_4:
		    bomber_right_right_down = 0;
		    break;
                  default:
                    break;
		  }
		break;

	      case SDL_MOUSEMOTION: /* Mouse movement - move the bucket: */
	
#if LANDSCAPE_FORMAT
		x[player] = (event.motion.x * SCALE_RATIO) - (16 * width[player]);
#else
		x[player] = (event.motion.y * SCALE_RATIO) - (16 * width[player]);
#endif
		if (x[player] < 32)
		  x[player] = 32;
		else if (x[player] > PSEUDO_WIDTH - 32 - (width[player] * 32))
		  x[player] = PSEUDO_WIDTH - 32 - (width[player] * 32);
		break;

	      case SDL_MOUSEBUTTONDOWN:  /* Mouse click - fire! */
		fire = 1;
		break;
	
    case SDL_JOYBUTTONDOWN:
    	fire = 1;
    	break;
	      	
	      case SDL_QUIT:  /* Window close - quit the program completely: */
		quit = 1;
		break;

	      default:
		break;
	    }
	}


      /* Fire button activates the bomber: */

      if (fire == 1)
	{
	  if (num_buckets[0] != 0 || num_buckets[1] != 0)
	    {
	      if (bomber_go == 0 && no_active_bombs == 1)
		{
		  /* Decide how many we're to drop this turn: */

		  bombs_left = bombs_per_level[level[player] - 1];
		  drop_bomb = 0;


		  /* (On a half-level?) */

		  if (half_level[player])
		    bombs_left = bombs_left / 2;

		  half_level[player] = 0;


		  /* Turn on the mad bomber! */

		  bomber_go = 1;
		  frame = 0;
		  bomber_happy = 0;


		  /* Erase the "Press Fire" message: */

		  dest.w = pseudo_widths[IMG_PRESS_FIRE];
		  dest.h = pseudo_heights[IMG_PRESS_FIRE];
		  dest.x = (PSEUDO_WIDTH - dest.w) / 2;
		  dest.y = PSEUDO_HEIGHT - dest.h;
		  erase(dest);
		  addrect(dest);
		}
	    }
	}


      /* Move bucket(s): */

      if (left_down == 1 && right_down == 0)
	{
	  x[player] = x[player] - 24;
	  if (x[player] < 32)
	    x[player] = 32;
	}
      else if (right_down == 1 && left_down == 0)
	{
	  x[player] = x[player] + 24;
	  if (x[player] > PSEUDO_WIDTH - 32 - (width[player] * 32))
	    x[player] = PSEUDO_WIDTH - 32 - (width[player] * 32);
	}


      /* Move the bomber: */

#if WANT_TWO_PLAYER_VS_OPTION
      if (mode == TITLE_OPTION_TWO_PLAYER_VS)
	{
	  if (bomber_left_left_down == 1)
	    bomber_x = bomber_x - 32;
	  else if (bomber_left_down == 1)
	    bomber_x = bomber_x - 16;
	
	  if (bomber_x < 32)
	    bomber_x = 32;
	
	  if (bomber_right_right_down == 1)
	    bomber_x = bomber_x + 32;
	  else if (bomber_right_down == 1)
	    bomber_x = bomber_x + 16;
	
	  if (bomber_x > PSEUDO_WIDTH - 64)
	    bomber_x = PSEUDO_WIDTH - 64;
	}
      else
#endif
	{
	  if (bomber_go == 1 && bombs_left > 0)
	    {
	      bomber_x = bomber_x + bomber_xm;
	
	      if (bomber_x < 32)
		{
		  bomber_x = 32;
		  bomber_xm_time = 0;
		}
	      else if (bomber_x > PSEUDO_WIDTH - 64)
		{
		  bomber_x = PSEUDO_WIDTH - 64;
		  bomber_xm_time = 0;
		}
	
	      bomber_xm_time--;
	      if (bomber_xm_time <= 0)
		{
		  do
		    {
		      bomber_xm = ((rand() % 8) - 4) * (level[player] * 2);
		    }
		  while (bomber_xm == 0);
		
		  bomber_xm_time = (rand() % (level[player] * 10)) + 5;
		}
	    }
	}


      /* Drop bombs: */

      if (bomber_go == 1 && bombs_left > 0)
	{
	  if ((frame % (10 - level[player])) == 0)
	    {
	      if ((level[player] % 2) == 1)
		drop_bomb = 1 - drop_bomb;
	      else
		drop_bomb = 1;

	      if (drop_bomb == 1)
		{
		  addbomb(bomber_x);
		  bombs_left--;
		}
	    }
	}


      /* Go to next level? */

      no_active_bombs = 1;
      for (i = 0; i < MAX_BOMBS; i++)
	{
	  if (bombs[i].alive)
	    no_active_bombs = 0;
	}

      if (bomber_go == 1 && bombs_left == 0 && no_active_bombs == 1)
	{
	  bomber_go = 0;
	  level[player]++;
	
	  if (level[player] > 8)
	    {
	      level[player] = 8;
	      if (past_level_8[player] == 0)
		{
		  past_level_8[player] = 1;
#if WANT_SOUND
		  playsound(SND_LEVEL8, 3);
#endif
		}
	    }
#if WANT_FLYING_NUMBERS
	  else
	    {
	      flying_numbers_scale = 1;
	    }
#endif
	}


      /* Erase bombs: */

      for (i = 0; i < MAX_BOMBS; i++)
	{
	  if (bombs[i].alive == 1)
	    {
	      dest.x = bombs[i].x;
	      dest.y = bombs[i].y;
	      dest.w = 32;
	      dest.h = 32;

	      erase(dest);
	      addrect(dest);
	    }
	}


      /* Erase drops: */

      for (i = 0; i < MAX_DROPS; i++)
	{
	  if (drops[i].alive == 1)
	    {
	      dest.x = drops[i].x;
	      dest.y = drops[i].y;
	      dest.w = 8;
	      dest.h = 8;
	
	      erase(dest);
	      addrect(dest);
	    }
	}


      /* Erase bucket(s): */

      if (x != old_x)
	{
	  dest.x = old_x[player];
	  dest.y = PSEUDO_HEIGHT-128;
	  dest.w = 64;
	  dest.h = 96;

	  erase(dest);
	  addrect(dest);
	
	  old_x[player] = x[player];
	}


      /* Erase the mad bomber: */

      if (bomber_x != old_bomber_x)
	{
	  dest.x = old_bomber_x;
	  dest.y = bomber_y;
	  dest.w = 32;
	  dest.h = 64;

	  erase(dest);
	  addrect(dest);
	
	  old_bomber_x = bomber_x;
	}


#if WANT_FLYING_NUMBERS
      /* Erase and resize flying numbers: */

      if (flying_numbers_scale != 0 && game_over == 0)
	{
	  erase_flying_numbers(flying_numbers_scale);

	  if (half_level[player] == 0)
	    flying_numbers_scale++;
	  else
	    flying_numbers_scale--;
	
	  if (flying_numbers_scale > MAX_FLYING_NUMBERS_SCALE)
	    flying_numbers_scale = 0;
	}
#endif


      /* Move bombs: */

      for (i = 0; i < MAX_BOMBS; i++)
	{
	  if (bombs[i].alive)
	    {
	      /* Move bomb downwards: */

	      bombs[i].y = bombs[i].y + (level[player] + 1) * 2;


	      /* Blow bombs up when they hit bottom! */

	      if (bombs[i].y >= PSEUDO_HEIGHT-64)
		{
		  explode_the_bombs = 1;
		}
	
	
	      /* Catch bombs: */

	      if (bombs[i].y >= (PSEUDO_HEIGHT-144) &&
		  bombs[i].y <= (PSEUDO_HEIGHT-144) + (num_buckets[player] * 32) &&
		  bombs[i].x >= x[player] - 32 &&
		  bombs[i].x <= x[player] + (32 * width[player]))
		{
		  /* Get rid of the bomb: */

		  bombs[i].alive = 0;


		  /* Make a splash: */

		  addsplash(bombs[i].x + 16,
			    (((bombs[i].y - (PSEUDO_HEIGHT-144)) / 32) * 32) + PSEUDO_HEIGHT-128);
#if WANT_SOUND
		  playsound(SND_SPLASH1 + level[player] - 1, 1);
		  {
		    int posn = (bombs[i].x * 255) / screen->w;
		    Mix_SetPanning(1, 255 - posn, posn);
		  }
#endif


		  /* Add some score and update the score display: */

		  score[player] = score[player] + level[player];
		  drawscore(score[player], player);


		  /* Did they get a high score? */

		  if (score[player] >= highscore
#if WANT_TWO_PLAYER_VS_OPTION
		      && mode != TITLE_OPTION_TWO_PLAYER_VS
#endif
		      )
		    {
		      highscore = score[player];


		      /* Did they just get the high score? */
		
		      if (have_highscore[player] == 0)
			{
			  have_highscore[player] = 1;
#if WANT_SOUND
			  playsound(SND_HIGHSCORE, 3);
#endif
			}
		    }
		  else
		    {
		      have_highscore[player] = 0;
		    }


		  /* Add a one-up if we hit the 1000 mark! */

		  if (score[player] >= one_up_score[player])
		    {
		      /* Add another bucket! */

		      if (num_buckets[player] < 3)
			num_buckets[player]++;


#if WANT_SOUND
		      /* Play a sound: */
		      playsound(SND_ONEUP, 3);
#endif

		      /* Set the next higher one-up threshold: */
		
		      one_up_score[player] = one_up_score[player] + 1000;
		    }
		}
	    }
	}


      /* Move drops: */

      for (i = 0; i < MAX_DROPS; i++)
	{
	  if (drops[i].alive)
	    {
	      /* Move drops: */
	
	      drops[i].x = drops[i].x + drops[i].xm;
	      drops[i].y = drops[i].y + drops[i].ym;
	
	
	      /* Be influenced by gravity: */
	
	      drops[i].ym++;
	
	
	      /* Count-down: */
	
	      drops[i].timer--;
	
	
	      /* Kill drop */
	
	      if (drops[i].y >= (PSEUDO_HEIGHT - 40) || drops[i].timer <= 0 ||
		  drops[i].x < 32 || drops[i].x >= (PSEUDO_WIDTH - 40))
		drops[i].alive = 0;
	    }
	}


      /* Draw bucket(s): */

      for (i = 0; i < num_buckets[player]; i++)
	{
	  dest.x = x[player];
	  dest.y = PSEUDO_HEIGHT-128 + i * 32;
	  dest.w = 32 * width[player];
	  dest.h = 32;
	
	  my_blit(images[IMG_BUCKET1 + (((frame / 3) + i) % 3) +
		  (player * 3) + 12 - (width[player] * 6)],
		  NULL, screen, &dest);
	  addrect(dest);
	}


      /* Draw the mad bomber: */

      dest.x = bomber_x;
      dest.y = bomber_y;
      dest.w = 32;
      dest.h = 64;

      if (score[player] < 10000 || vs_mode == 1)
	my_blit(images[IMG_BOMBER_SAD + bomber_happy],
		NULL, screen, &dest);
      else
	my_blit(images[IMG_BOMBER_AMAZED],
		NULL, screen, &dest);
      addrect(dest);


      /* Draw a bomb in the bomber's hand: */

      if (bomber_happy == 0 && bomber_go == 0)
	{
	  dest.x = bomber_x;
	  dest.y = 99;
	  dest.w = 32;
	  dest.h = 32;
	
	  my_blit(images[IMG_BOMB0], NULL, screen, &dest);
	}


      /* Draw bombs: */

      for (i = 0; i < MAX_BOMBS; i++)
	{
	  if (bombs[i].alive == 1)
	    {
	      dest.x = bombs[i].x;
	      dest.y = bombs[i].y;
	      dest.w = 32;
	      dest.h = 32;
	
	      if (((frame + i) % 2) == 0)
		my_blit(images[IMG_BOMB0], NULL, screen, &dest);
	      else
		my_blit(images[IMG_BOMB1 + (rand() % 3)],
				NULL, screen, &dest);
	
	      addrect(dest);
	    }
	}


      /* Draw drops: */

      for (i = 0; i < MAX_DROPS; i++)
	{
	  if (drops[i].alive == 1)
	    {
	      dest.x = drops[i].x;
	      dest.y = drops[i].y;
	      dest.w = 8;
	      dest.h = 8;
	
	      if (drops[i].xm > 1)
		{
		  if (drops[i].ym >= 0)
		    img = IMG_DROP_RIGHT_DOWN;
		  else
		    img = IMG_DROP_RIGHT_UP;
		}
	      else if (drops[i].xm < -1)
		{
		  if (drops[i].ym >= 0)
		    img = IMG_DROP_LEFT_DOWN;
		  else
		    img = IMG_DROP_LEFT_UP;
		}
	      else
		{
		  if (drops[i].ym < 0)
		    img = IMG_DROP_UP;
		  else
		    img = IMG_DROP_DOWN;
		}
	
	      my_blit(images[img], NULL, screen, &dest);
	      addrect(dest);
	    }
	}


      /* If everyone's died, make the bomber happy and show score(s): */

      if (num_buckets[0] == 0 && num_buckets[1] == 0)
	{
	  /* Display "GAME OVER" text: */
	
	  if (game_over == 0)
	    {
	      game_over = 1;
	      bomber_happy = 1;
	      dest.w = pseudo_widths[IMG_GAME_OVER];
	      dest.h = pseudo_heights[IMG_GAME_OVER];
	      dest.x = (PSEUDO_WIDTH - dest.w) / 2;
	      dest.y = (PSEUDO_HEIGHT - dest.h) / 2;
	
	      my_blit(images[IMG_GAME_OVER], NULL, screen, &dest);
	      addrect(dest);

#if WANT_CONTINUE_OPTION
	      can_continue = 0;
#endif
	    }
	
	
	  /* Toggle between player one's and two's scores: */
	
	  if (num_players == 2 && (frame % 40) == 0)
	    {
	      player = 1 - player;
	      drawscore(score[player], player);
	    }
	
	
	  /* Flash "Press ESCAPE" message: */
	
	  if ((frame % 30) == 0)
	    {
	      dest.w = pseudo_widths[IMG_PRESS_ESCAPE];
	      dest.h = pseudo_heights[IMG_PRESS_ESCAPE];
	      dest.x = (PSEUDO_WIDTH - dest.w) / 2;
	      dest.y = (PSEUDO_HEIGHT - dest.h);
	      my_blit(images[IMG_PRESS_ESCAPE], NULL, screen, &dest);
	      addrect(dest);
	    }
	  else if ((frame % 15) == 0)
	    {
	      dest.w = pseudo_widths[IMG_PRESS_ESCAPE];
	      dest.h = pseudo_heights[IMG_PRESS_ESCAPE];
	      dest.x = (PSEUDO_WIDTH - dest.w) / 2;
	      dest.y = (PSEUDO_HEIGHT - dest.h);
	      erase(dest);
	      addrect(dest);
	    }
	}


#if WANT_FLYING_NUMBERS
      /* Draw flying numbers: */

      if (flying_numbers_scale != 0 && game_over == 0)
	{
	  draw_flying_numbers(level[player] - 1, flying_numbers_scale,
			      (Uint8)((rand() % 128) + 128),	
			      (Uint8)((rand() % 128) + 128),
			      (Uint8)((rand() % 128) + 128));
	}
#endif


      /* Flash "Press Fire" message: */

      if (bomber_go == 0 && (num_buckets[0] != 0 || num_buckets[1] != 0) &&
	  no_active_bombs == 1)
	{
	  if ((frame % 30) == 0)
	    {
	      dest.w = pseudo_widths[IMG_PRESS_FIRE];
	      dest.h = pseudo_heights[IMG_PRESS_FIRE];
	      dest.x = (PSEUDO_WIDTH - dest.w) / 2;
	      dest.y = (PSEUDO_HEIGHT - dest.h);
	
	      my_blit(images[IMG_PRESS_FIRE], NULL, screen, &dest);
	      addrect(dest);
	    }
	  else if ((frame % 15) == 0)
	    {
	      dest.w = pseudo_widths[IMG_PRESS_FIRE];
	      dest.h = pseudo_heights[IMG_PRESS_FIRE];
	      dest.x = (PSEUDO_WIDTH - dest.w) / 2;
	      dest.y = (PSEUDO_HEIGHT - dest.h);
	
	      erase(dest);
	      addrect(dest);
	    }
	}


      /* Did the bombs hit the ground? Deal with it! */

      if (explode_the_bombs == 1)
	{
	  /* Update the screen: */
	
	  SDL_UpdateRects(screen, num_rects, rects);
	  num_rects = 0;
	
	  explode_the_bombs = 0;
	
	
	  /* Draw happy bomber: */
	
	  dest.x = bomber_x;
	  dest.y = bomber_y;
	  dest.w = 32;
	  dest.h = 64;
	
	  if (score[player] < 10000 || vs_mode == 1)
	    my_blit(images[IMG_BOMBER_HAPPY], NULL, screen, &dest);
	  else
	    my_blit(images[IMG_BOMBER_AMAZED], NULL, screen, &dest);
	  my_updaterect(screen, &dest);
	
	
	  /* Explode the bombs! */
	
	  explodebombs();
	
	
	  /* Turn off all bombs: */
	
	  for (i = 0; i < MAX_BOMBS; i++)
	    bombs[i].alive = 0;
	
	
	  /* Turn off the mad bomber: */
	
	  bomber_go = 0;
	
	
	  /* Jump back a level: */
	
	  if (level[player] > 1)
	    {
	      level[player]--;
	      half_level[player] = 1;
#if WANT_FLYING_NUMBERS
	      flying_numbers_scale = MAX_FLYING_NUMBERS_SCALE;
#endif
	    }
	
	
	  /* Remove a bucket: */
	
	  num_buckets[player]--;
	
	
	  /* Switch to the other player: */
	
	  if (num_players == 2)
	    {
	      /* If the other player is still alive... */
	
	      if (num_buckets[1 - player])
		{
		  /* Erase the last player's bucket bucket: */
		
		  dest.x = x[player];
		  dest.y = PSEUDO_HEIGHT-128;
		  dest.w = 64;
		  dest.h = 96;
		
		  erase(dest);
		  addrect(dest);
		
		
		  /* Switch to the new player: */
		
		  player = 1 - player;
		
		
		  /* Draw the new player's score: */
		
		  drawscore(score[player], player);
		}
	    }
	}


      /* Update the screen: */

      SDL_UpdateRects(screen, num_rects, rects);


#if WANT_SOUND
      /* Play hissing noise: */

      if (use_sound == 1)
	{
	  if (no_active_bombs == 0)
	    {
	      if ((frame % 5) == 0 || Mix_Playing(2) == 0)
		playsound(SND_FUSE, 2);
	    }
	  else
	    {
#ifndef SDL_MIXER_BUG
	      if (Mix_Playing(2) != 0)
		Mix_HaltChannel(2);
#endif
	    }
	}


      /* Keep playing music: */
#if WANT_FULL_MUSICS
      if (use_sound == 1)
	{
	  if (!Mix_PlayingMusic())
	    {
	      Mix_PlayMusic(game_musics[rand() % NUM_GAME_MUSICS], 0);
	      Mix_VolumeMusic(music_volume * 16);
	    }
	}
#endif //WANT_FULL_MUSIC
#endif //WANT_SOUND

      /* Pause: */

      if (SDL_GetTicks() < last_time + 33)
	SDL_Delay(last_time + 45 - SDL_GetTicks());
    }
  while (done == 0 && quit == 0);


#if WANT_SOUND
  /* Stop sound effects: */

  if (use_sound == 1)
    Mix_HaltChannel(-1);

  /* Stop music: */
#if WANT_MUSIC
  if (use_sound == 1)
    Mix_HaltMusic();
#endif //WANT_MUSIC
#endif


  /* Did anyone get the high score? */

  if (have_highscore[0] || (num_players == 2 && have_highscore[1]))
    quit = sign_highscore();


#if WANT_SOUND
  /* Stop sound effects: */

  if (use_sound == 1)
    Mix_HaltChannel(-1);

  /* Stop music: */
#if WANT_MUSIC
  if (use_sound == 1)
    Mix_HaltMusic();
#endif //WANT_MUSIC
#endif

  return quit;
}


/* Title loop: */

static int title()
{
  SDL_Rect dest;
  SDL_Event event;
  int i, y, option, done, old_option, k;
  int bx, by;
  int title_option_y[NUM_TITLE_OPTIONS];
#ifdef __palmos__
	int hatpos = SDL_HAT_CENTERED;
#endif

  /* Draw title screen: */
  dest.x = 0;
  dest.y = 0;
  dest.w = PSEUDO_WIDTH;
  dest.h = PSEUDO_HEIGHT;

  my_fillrect(screen, &dest,
	      SDL_MapRGB(screen->format, 0x00, 0x00, 0x00));

  dest.w = pseudo_widths[IMG_TITLE_TITLE];
  k = dest.h = pseudo_heights[IMG_TITLE_TITLE];
  dest.x = (PSEUDO_WIDTH - dest.w) / 2;
  dest.y = 0;
  my_blit(images[IMG_TITLE_TITLE], NULL, screen, &dest);

  /* Draw controls: */

  y = option_box.y + 2;

  for (i = 0; i < NUM_TITLE_OPTIONS; i++)
    {
      int j;
      dest.w = pseudo_widths[title_option_images[i]];
      j = dest.h = pseudo_heights[title_option_images[i]];
      dest.x = (PSEUDO_WIDTH - dest.w) / 2;
      dest.y = y;

#if WANT_CONTINUE_OPTION
      if (can_continue || (i != TITLE_OPTION_CONTINUE))
#endif
        my_blit(images[title_option_images[i] + 1], NULL, screen, &dest);

      title_option_y[i] = y;
      y += j;
    }


  my_updaterect(screen, 0);


  /* Title screen loop: */

  option = 0;
  old_option = -1;
  done = 0;

  do
    {
      while (SDL_PollEvent(&event))
	{
	  switch (event.type)
	    {
	    case SDL_KEYDOWN:
	      switch (event.key.keysym.sym)
	        {

#if LANDSCAPE_FORMAT || WANT_JOG_DIAL
	        case SDLK_UP:
#else
	        case SDLK_RIGHT:
#endif
		  if (option > 0) --option;
#if WANT_CONTINUE_OPTION
		  if (option == TITLE_OPTION_CONTINUE && !can_continue) --option;
#endif
		  break;

#if LANDSCAPE_FORMAT || WANT_JOG_DIAL
	        case SDLK_DOWN:
#else
	        case SDLK_LEFT:
#endif
		  if (option < NUM_TITLE_OPTIONS - 1) ++option;
#if WANT_CONTINUE_OPTION
		  if (option == TITLE_OPTION_CONTINUE && !can_continue) ++option;
#endif
		  break;

	        case SDLK_ESCAPE:
		  done = 1;
		  option = TITLE_OPTION_EXIT;
		  break;

		case SDLK_RETURN:
		case SDLK_SPACE:
		  done = 1;
		  break;

		default:
		  break;
	        }
	      break;
	
	    case SDL_MOUSEBUTTONDOWN:
#if LANDSCAPE_FORMAT
	      bx = event.button.x * SCALE_RATIO;
	      by = event.button.y * SCALE_RATIO;
#else
	      bx = event.button.y * SCALE_RATIO;
	      by = PSEUDO_HEIGHT - event.button.x * SCALE_RATIO;
#endif

	      if (bx >= option_box.x &&
		  bx <= (int)(option_box.x + option_box.w))
		{
		  for (i = 0; i < NUM_TITLE_OPTIONS; i++)
		    {
		      if (by >= title_option_y[i] &&
			  (by <=
			   (title_option_y[i] +
			    pseudo_heights[title_option_images[i]])))
			{
#if WANT_CONTINUE_OPTION
			  if (i != TITLE_OPTION_CONTINUE || can_continue)
#endif
		            {
			      option = i;
			      done = 1;
			    }
			}
		    }
		}
	      break;

#ifdef __palmos__
			case SDL_JOYBUTTONDOWN:
			  done = 1;
			  break;

			case SDL_JOYHATMOTION:
				if(event.jhat.value == SDL_HAT_UP && hatpos != SDL_HAT_UP)
				{
				  if (option > 0) --option;
#if WANT_CONTINUE_OPTION
				  if (option == TITLE_OPTION_CONTINUE && !can_continue) --option;
#endif
				}
				if(event.jhat.value == SDL_HAT_DOWN && hatpos != SDL_HAT_DOWN)
				{
				  if (option < NUM_TITLE_OPTIONS - 1) ++option;
#if WANT_CONTINUE_OPTION
				  if (option == TITLE_OPTION_CONTINUE && !can_continue) ++option;
#endif
				}
				hatpos = event.jhat.value;
			  break;
#endif

	    case SDL_QUIT:
	      option = TITLE_OPTION_EXIT;
	      done = 1;
	      break;

	    default:
	      break;
	    }
	}


      /* Update the control box: */

      if (old_option != option)
	{
	  if (old_option != -1)
	    {
	      /* Unhighlight the old option: */
	
	      dest.w = pseudo_widths[title_option_images[old_option]];
	      dest.h = pseudo_heights[title_option_images[old_option]];
	      dest.x = (PSEUDO_WIDTH - dest.w) / 2;
	      dest.y = title_option_y[old_option];
	
	      my_blit(images[title_option_images[old_option] + 1],
		      NULL, screen, &dest);
              my_updaterect(screen, &dest);
	    }
	
	
	  /* Highlight the new option: */
	
	  dest.w = pseudo_widths[title_option_images[option]];
	  dest.h = pseudo_heights[title_option_images[option]];
	  dest.x = (PSEUDO_WIDTH - dest.w) / 2;
	  dest.y = title_option_y[option];

	
	  my_blit(images[title_option_images[option]],
		  NULL, screen, &dest);
	  my_updaterect(screen, &dest);
	
	
#if WANT_SOUND
	  if (old_option != -1)
	    {
	      /* Play selection sound: */
	      playsound(SND_SELECT, -1);
	    }
#endif
	

	  /* Keep track of old option: */
	
	  old_option = option;
	}


      /* Keep playing music: */

#if WANT_SOUND
#if WANT_MUSIC
      if (use_sound == 1)
	{
	  if (!Mix_PlayingMusic())
	    {
	      Mix_PlayMusic(title_music, 0);
	      Mix_VolumeMusic(music_volume * 16);
	    }
	}
#endif //WANT_MUSIC
#endif


      /* Pause: */

      SDL_Delay(50);
    }
  while (!done);


  /* Confirm sound! */

#if WANT_SOUND
  playsound(SND_CONFIRM, -1);
#endif

  return option;
}


/* Initialize SDL, load graphics and sound: */

static int setup()
{
  int i;
  int imgloading_h = 0; /* GCC warning */
#ifndef NO_PATH
  char file_path[300] = DATA_PREFIX;
#else
  char file_path[50];
#endif
  int path_ofs;
  SDL_Rect dest;
  SDL_Surface * image;

  /* Init SDL Video: */
#ifdef __palmos__
  if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_JOYSTICK) < 0)
#else
  if (SDL_Init(SDL_INIT_VIDEO) < 0)
#endif
    {
      fprintf(stderr, "\nError: I could not initialize video!");
      return 0;
    }
#ifdef __palmos__
	joystick = SDL_JoystickOpen(0);
#endif


#if WANT_SOUND
  /* Init SDL Audio: */

  if (use_sound == 1)
    {
      if (SDL_Init(SDL_INIT_AUDIO) < 0)
	{
	  fprintf(stderr, "\nWarning: I could not initialize audio!");
	  show_sdl_error();
	  use_sound = 0;
	}
    }
#endif


  /* Open display: */
  screen = SDL_SetVideoMode(SCREEN_WIDTH, SCREEN_HEIGHT, 16,
                            use_fullscreen? SDL_FULLSCREEN : 0);

  if (screen == NULL)
    {
      fprintf(stderr,
	      "\nError: I could not set up %svideo for %dx%d mode.",
	      use_fullscreen? "fullscreen " : "",
	      SCREEN_WIDTH, SCREEN_HEIGHT);
      return 0;
    }
#if WANT_SETICON
  if (!seticon())
    {
      return 0;
    }
#endif

  /* Set window manager stuff: */

  SDL_WM_SetCaption("Mad Bomber", "Mad Bomber");
  /* SDL_ShowCursor(0); */

#if WANT_SOUND
  /* Open sound: */

  if (use_sound == 1)
    {
      if (Mix_OpenAudio(22050, AUDIO_S16, 2, 512) < 0)
	{
	  fprintf(stderr,
		  "\nWarning: I could not set up audio for 22050 Hz "
		  "16-bit stereo");
	  show_sdl_error();
	  use_sound = 0;
	}
    }

#endif


  /* Load graphics: */
  
#ifndef NO_PATH
  strcpy(file_path + strlen(DATA_PREFIX), "images/");
  path_ofs = strlen(file_path);
#else
  path_ofs = 0;
#endif
  for (i = 0; i < NUM_IMAGES; ++i)
    {
      /* Load image file: */
      strcpy(file_path+path_ofs, image_names[i]);
#if HAVE_SDL_IMAGE
      image = IMG_Load(file_path);
#else
      image = SDL_LoadBMP(file_path);
#endif

      if (image == NULL)
	{
	  fprintf(stderr,
                  "\nError: I couldn't load a graphics file:\n%s",
                  file_path);
	  return 0;
	}


      /* Center the background */
      if (i == IMG_BACKGROUND)
        {
	  dest.x = (image -> w - SCREEN_WIDTH) / 2;
	  dest.y = (image -> h - SCREEN_HEIGHT) / 2;
#if LANDSCAPE_FORMAT
	  bomber_y = 67 - (dest.y * SCALE_RATIO);
#else
	  bomber_y = 67 - (dest.x * SCALE_RATIO);
#endif
	 dest.w = SCREEN_WIDTH;
	 dest.h = SCREEN_HEIGHT;
	 SDL_BlitSurface(image, &dest, image, NULL);
       }


      /* Set transparency: */

//#ifdef PALMOS
      /* background image too big and can cause a memory problem on palmos */
//      images[i] = (i != IMG_BACKGROUND) ? SDL_DisplayFormat(image) : image;
//#else
      images[i] = SDL_DisplayFormat(image);
//#endif

      if (images[i] == NULL)
	{
	  fprintf(stderr,
		  "\nError: I couldn't convert a file to the display format:\n%s",
		  file_path);
	  return 0;
	}
#ifdef __palmos__
  SDL_MoveToStorage(images[i]);
#endif

      if (SDL_SetColorKey(images[i], (SDL_SRCCOLORKEY | SDL_RLEACCEL),
			  SDL_MapRGB(images[i] -> format,
				     0xFF, 0xFF, 0xFF)) == -1)
	{
	  fprintf(stderr,
		  "\nError: I could not set the color key for the file:\n%s",
		  file_path);
	  return 0;
	}

#if LANDSCAPE_FORMAT
      pseudo_widths[i] = image->w * SCALE_RATIO;
      pseudo_heights[i] = image->h * SCALE_RATIO;
#else
      pseudo_widths[i] = image->h * SCALE_RATIO;
      pseudo_heights[i] = image->w * SCALE_RATIO;
#endif

//#ifdef PALMOS
//      if (i != IMG_BACKGROUND) SDL_FreeSurface(image);
//#else
      SDL_FreeSurface(image);
//#endif

      /* Show "loading" and percentage bar: */

      if (i == IMG_LOADING)
	{
#ifdef __SYMBIAN32__
	  SDL_Event event;   /* let us a chance to gain focus */
	  SDL_PollEvent(&event);
#endif
	  dest.w = pseudo_widths[IMG_LOADING];
	  imgloading_h = dest.h = pseudo_heights[IMG_LOADING];
	  dest.x = (PSEUDO_WIDTH - dest.w) / 2;
	  dest.y = (PSEUDO_HEIGHT - dest.h) / 2;
	
	  my_blit(images[IMG_LOADING], NULL, screen, &dest);
	  my_updaterect(screen, &dest);
          SDL_FreeSurface(images[IMG_LOADING]);
          images[IMG_LOADING] = 0;  /* not used anymore */
	}
      else if (i >= IMG_BAR)
	{
	  dest.w = pseudo_widths[IMG_BAR];
	  dest.h = pseudo_heights[IMG_BAR];
#if WANT_SOUND
	  dest.x = (((PSEUDO_WIDTH - dest.w) * i) / (NUM_IMAGES + NUM_SOUNDS));
#else
	  dest.x = (((PSEUDO_WIDTH - dest.w) * i) / NUM_IMAGES);
#endif
	  dest.y = (((PSEUDO_HEIGHT - dest.h) / 2) + imgloading_h);
	
	  my_blit(images[IMG_BAR], NULL, screen, &dest);
	  my_updaterect(screen, &dest);
	}
    }


  /* Determine widest title screen option image: */

  option_box.w = pseudo_widths[IMG_TITLE_ONE_PLAYER];
  if (pseudo_widths[IMG_TITLE_TWO_PLAYERS] > option_box.w)
     option_box.w = pseudo_widths[IMG_TITLE_TWO_PLAYERS];
#if WANT_TWO_PLAYER_VS_OPTION
  if (pseudo_widths[IMG_TITLE_TWO_PLAYER_VS] > option_box.w)
     option_box.w = pseudo_widths[IMG_TITLE_TWO_PLAYER_VS];
#endif
#if WANT_CONTINUE_OPTION
  if (pseudo_widths[IMG_TITLE_CONTINUE] > option_box.w)
     option_box.w = pseudo_widths[IMG_TITLE_CONTINUE];
#endif
  if (pseudo_widths[IMG_TITLE_OPTIONS] > option_box.w)
     option_box.w = pseudo_widths[IMG_TITLE_OPTIONS];
  if (pseudo_widths[IMG_TITLE_HIGHSCORE] > option_box.w)
     option_box.w = pseudo_widths[IMG_TITLE_HIGHSCORE];
  if (pseudo_widths[IMG_TITLE_HIGHSCORE] > option_box.w)
     option_box.w = pseudo_widths[IMG_TITLE_HIGHSCORE];
  if (pseudo_widths[IMG_TITLE_EXIT] > option_box.w)
     option_box.w = pseudo_widths[IMG_TITLE_EXIT];
  option_box.w += 4;

  option_box.h = pseudo_heights[IMG_TITLE_ONE_PLAYER] +
       pseudo_heights[IMG_TITLE_TWO_PLAYERS] +
#if WANT_TWO_PLAYER_VS_OPTION
       pseudo_heights[IMG_TITLE_TWO_PLAYER_VS] +
#endif
#if WANT_CONTINUE_OPTION
       pseudo_heights[IMG_TITLE_CONTINUE] +
#endif
       pseudo_heights[IMG_TITLE_OPTIONS] +
       pseudo_heights[IMG_TITLE_HIGHSCORE] +
       pseudo_heights[IMG_TITLE_EXIT];

  option_box.x = (PSEUDO_WIDTH - option_box.w) / 2;
  option_box.y = (PSEUDO_HEIGHT + pseudo_heights[IMG_TITLE_TITLE] - option_box.h) / 2;

#if WANT_SOUND
  /* Load sounds: */

  if (use_sound == 1)
    {
#ifndef NO_PATH
      strcpy(file_path + strlen(DATA_PREFIX), "sounds/");
      path_ofs = strlen(file_path);
#endif
      for (i = 0; i < NUM_SOUNDS; i++)
	{
          strcpy(file_path+path_ofs, sound_names[i]);
	  sounds[i] = Mix_LoadWAV(file_path);
	  if (sounds[i] == NULL)
	    {
	      fprintf(stderr,
		      "\nError: I could not load the sound file:\n%s",
		      file_path);
	      return 0;
	    }

	  /* Draw percentage bar: */

	  dest.w = pseudo_widths[IMG_BAR];
	  dest.h = pseudo_heights[IMG_BAR];
	  dest.x = ((PSEUDO_WIDTH - dest.w) * (i+NUM_IMAGES))/(NUM_IMAGES+NUM_SOUNDS);
	  dest.y = ((PSEUDO_HEIGHT - dest.h) / 2) + imgloading_h;

	  my_blit(images[IMG_BAR], NULL, screen, &dest);
	  my_updaterect(screen, &dest);
	}
    }


  /* Load music: */
#if WANT_MUSIC
  if (use_sound == 1)
    {
#ifndef NO_PATH
     strcpy(file_path + strlen(DATA_PREFIX), "music/");
     path_ofs = strlen(file_path);
#endif
      strcpy(file_path+path_ofs, MUS_TITLE);
      title_music = Mix_LoadMUS(file_path);
      if (title_music == NULL)
	{
	  fprintf(stderr,
		  "\nError: I could not load the title music file:\n%s",
		  file_path);
	  return 0;
	}

#if WANT_FULL_MUSICS
      strcpy(file_path+path_ofs, MUS_HIGHSCORE);
      highscore_music = Mix_LoadMUS(file_path);
      if (highscore_music == NULL)
	{
	  fprintf(stderr,
		  "\nError: I could not load the music file:\n%s",
		  file_path);
	  return 0;
	}

      for (i = 0; i < NUM_GAME_MUSICS; i++)
	{
	  strcpy(file_path+path_ofs, game_music_names[i]);
	  game_musics[i] = Mix_LoadMUS(file_path);
	  if (game_musics[i] == NULL)
	    {
	      fprintf(stderr,
		      "\nError: I could not load the game music file:\n%s",
		      file_path);
	      return 0;
	    }
	}
#endif //WANT_FULL_MUSIC
    }
#endif //WANT_MUSIC
#endif

  /* Seed random generator: */

  srand(SDL_GetTicks());

  spray_count = 0;
  return 1;
}

static void show_sdl_error()
{
  fprintf(stderr,
          "\nThe Simple DirectMedia error that occured was:\n"
          "%s\n\n", SDL_GetError());
}

/* Clean up and prepare to quit: */

static void mb_shutdown()
{
  int i;

  /* Not really necessary, but.. I'm nice: */

  for (i = 0; i < NUM_IMAGES; ++i)
    {
      if (images[i]) SDL_FreeSurface(images[i]);
    }


  /* Close sound: */

#if WANT_SOUND
  if (use_sound == 1)
    {
#if WANT_MUSIC
      Mix_HaltMusic();
#endif
      Mix_HaltChannel(-1);  /* halt all channels */

      for (i = 0; i < NUM_SOUNDS; ++i)
        {
          if (sounds[i]) Mix_FreeChunk(sounds[i]);
        }
#if WANT_MUSIC
      Mix_FreeMusic(title_music);
#if WANT_FULL_MUSICS
      Mix_FreeMusic(highscore_music);
      for (i = 0; i < NUM_GAME_MUSICS; i++)
        {
          Mix_FreeMusic(game_musics[i]);
        }
#endif
#endif //WANT_MUSIC
      Mix_CloseAudio();
    }
#endif

#if !HAVE_STDERR
    fclose(stderr);
#endif
	
#ifdef __palmos__
	if(joystick != 0)
		SDL_JoystickClose(joystick);
#endif

  SDL_Quit();
}


/* Add another rectangle: */

static void addrect(SDL_Rect rect)
{
#if LANDSCAPE_FORMAT
  rects[num_rects].x = rect.x / SCALE_RATIO;
  rects[num_rects].y = rect.y / SCALE_RATIO;
  rects[num_rects].w = rect.w / SCALE_RATIO;
  rects[num_rects].h = rect.h / SCALE_RATIO;
#else
  rects[num_rects].x = (PSEUDO_HEIGHT - rect.y - rect.h) / SCALE_RATIO; /* symmetric */
  rects[num_rects].y = rect.x / SCALE_RATIO;
  rects[num_rects].w = rect.h / SCALE_RATIO;
  rects[num_rects].h = rect.w / SCALE_RATIO;
#endif

  ++num_rects;
}


/* Add a bomb: */

static void addbomb(int x)
{
  int i, found;


  /* Find a free slot: */

  found = -1;
  for (i = 0; i < MAX_BOMBS && found == -1; i++)
    {
      if (bombs[i].alive == 0)
	found = i;
    }


  /* Add a bomb: */

  if (found != -1)
    {
      bombs[found].alive = 1;
      bombs[found].x = x;
      bombs[found].y = bomber_y + 29;
    }
}


/* Make a splash (add a bunch of drops): */

static void addsplash(int x, int y)
{
  int i, offset;

  for (i = 0; i < 8; i++)
    {
      offset = (rand() % 32) - 16;

      adddrop(x + offset, y, offset / 6);
    }
}


/* Add one drop: */

static void adddrop(int x, int y, int xm)
{
  int i, found;


  /* Find a free slot: */

  found = -1;
  for (i = 0; i < MAX_DROPS && found == -1; i++)
    {
      if (drops[i].alive == 0)
	found = i;
    }


  /* Add a drop: */

  if (found != -1)
    {
      drops[found].alive = 1;
      drops[found].x = x;
      drops[found].y = y;
      drops[found].xm = xm;
      drops[found].ym = -((rand() % 6) + 2);
      drops[found].timer = (rand() % 15) + 30;
    }
}


/* Play a sound file: */

#if WANT_SOUND
static void playsound(int snd, int chan)
{
  if (use_sound == 1)
    {
#ifdef SDL_MIXER_BUG
      chan = -1;
#endif
      Mix_PlayChannel(chan, sounds[snd], 0);
      Mix_SetPanning(chan, 255, 255);
    }
}
#endif


/* Draw score: */

static void drawscore(int score, int player)
{
  SDL_Rect dest;
  int i;
  char str[10];


  /* Erase where the score was: */

  dest.x = PSEUDO_WIDTH-224;
  dest.y = 2;
  dest.w = 192;
  dest.h = 32;

  erase(dest);
  addrect(dest);


  /* Draw the score: */

  sprintf(str, "%6d", score);

  for (i = 0; i < 6; i++)
    {
      dest.x = PSEUDO_WIDTH-224 + (i * 32);
      dest.y = 2;
      dest.w = 32;
      dest.h = 32;

      if (str[i] != ' ')
	{
	  my_blit(images[IMG_0 + (str[i] - '0') + (player * 10)],
			  NULL, screen, &dest);
	}
    }


  /* Draw (or erase) high score message: */

  dest.w = pseudo_widths[IMG_HIGHSCORE];
  dest.h = pseudo_heights[IMG_HIGHSCORE];
  dest.x = PSEUDO_WIDTH-224 - dest.w;
  dest.y = 2;

  if (score >= highscore)
    my_blit(images[IMG_HIGHSCORE], NULL, screen, &dest);
  else
    erase(dest);

  addrect(dest);
}


/* Pause screen: */

static int pausescreen()
{
  SDL_Event event;
  SDL_Rect dest;
  int done, quit;


  /* Stop sound effects: */

#if WANT_SOUND
  if (use_sound == 1)
    Mix_HaltChannel(-1);
#endif


  /* Draw "PAUSED" message: */

  dest.w = pseudo_widths[IMG_PAUSED];
  dest.h = pseudo_heights[IMG_PAUSED];
  dest.x = (PSEUDO_WIDTH - dest.w) / 2;
  dest.y = (PSEUDO_HEIGHT - dest.h) / 2;

  my_blit(images[IMG_PAUSED], NULL, screen, &dest);
  my_updaterect(screen, &dest);


  /* Pause loop: */

  done = 0;
  quit = 0;

  do
    {
      /* TAB or "P" key unpause: */

      while (SDL_PollEvent(&event))
	{
	  switch (event.type)
	    {
            case SDL_KEYDOWN:
	      switch (event.key.keysym.sym)
                {
#if WANT_JOG_DIAL
		case SDLK_UP:
		case SDLK_DOWN:
#endif
	        case SDLK_TAB:
                case SDLK_p:
		  done = 1;
                  break;

#if WANT_JOG_DIAL
                case SDLK_RETURN:
#endif
	        case SDLK_ESCAPE:
		  done = 1;
		  quit = 1;
                  break;

                default:
                  break;
		}
	      break;

	    case SDL_QUIT:
	      done = 1;
	      quit = 2;
              break;

            default:
              break;
	    }
	}

      SDL_Delay(50);


#if WANT_SOUND
#if WANT_FULL_MUSIC
      if (use_sound == 1)
	{
	  if (!Mix_PlayingMusic())
	    {
	      Mix_PlayMusic(game_musics[rand() % NUM_GAME_MUSICS], 0);
	      Mix_VolumeMusic(music_volume * 16);
	    }
	}
#endif
#endif
    }
  while (done == 0);


  /* Erase "PAUSED" message: */

  dest.w = pseudo_widths[IMG_PAUSED];
  dest.h = pseudo_heights[IMG_PAUSED];
  dest.x = (PSEUDO_WIDTH - dest.w) / 2;
  dest.y = (PSEUDO_HEIGHT - dest.h) / 2;

  erase(dest);
  my_updaterect(screen, &dest);


  /* Return whether or not we ended pause because we're quitting: */

  return quit;
}



/* Explode all of the bombs (self-contained animation loop): */

static void explodebombs()
{
  int i, bottom_most, lowest;
  SDL_Rect dest;


  /* Explode each bomb, one at a time: */

  do
    {
      /* Find the bottom-most bomb: */

      bottom_most = -1;
      lowest = 0;

      for (i = 0; i < MAX_BOMBS; i++)
	{
	  if (bombs[i].alive == 1)
	    {
	      if (bombs[i].y > lowest)
		{
		  lowest = bombs[i].y;
		  bottom_most = i;
		}
	    }
	}


      /* Explode it! */

      if (bottom_most != -1)
	{
	  /* Turn the bomb off: */
	
	  bombs[bottom_most].alive = 0;
	
	
	  /* Play an explosion sound: */
	
#if WANT_SOUND
	  playsound(SND_EXPLOSION, 1);
          {
	    int posn = (bombs[bottom_most].x * 255) / screen->w;
	    Mix_SetPanning(1, 255 - posn, posn);
          }
#endif
	
	
	  /* Draw the explosion animation: */
	
	  for (i = 0; i < 4; i++)
	    {
	      dest.x = bombs[bottom_most].x;
	      dest.y = bombs[bottom_most].y;
	      dest.w = 32;
	      dest.h = 32;
	
	      my_blit(images[IMG_EXPLOSION1 + (i % 2)],
			      NULL, screen, &dest);
	      my_updaterect(screen, &dest);
	
	      SDL_Delay(30);
	    }
	
	
	  /* Erase the explosion animation: */
	
	  dest.x = bombs[bottom_most].x;
	  dest.y = bombs[bottom_most].y;
	  dest.w = 32;
	  dest.h = 32;
	
	  erase(dest);
	  my_updaterect(screen, &dest);
	
	
	  /* Make sure the bomber doesn't get cropped: */
	
	  dest.x = bomber_x;
	  dest.y = bomber_y;
	  dest.w = 32;
	  dest.h = 64;
	
	  if (score[player] < 10000 || vs_mode == 1)
	    my_blit(images[IMG_BOMBER_HAPPY],
			    NULL, screen, &dest);
	  else
	    my_blit(images[IMG_BOMBER_AMAZED],
			    NULL, screen, &dest);
	  my_updaterect(screen, &dest);


	  /* Make sure the buckets don't get cropped: */
	
	  for (i = 0; i < num_buckets[player]; i++)
	    {
	      dest.x = x[player];
	      dest.y = PSEUDO_HEIGHT-128 + i * 32;
	      dest.w = 32 * width[player];
	      dest.h = 32;
	
	      my_blit(images[IMG_BUCKET1 + (((frame / 3) + i) % 3) +
				    (player * 3) + 12 - (width[player] * 6)],
			      NULL, screen, &dest);
	      my_updaterect(screen, &dest);
	    }
	}
    }
  while (bottom_most != -1);

#if WANT_SOUND
  Mix_SetPanning(1, 255, 255);

  /* Play a BIG explosion sound: */

  playsound(SND_BIGEXPLOSION, 1);
#endif


  /* Flash screen: */

  dest.x = 0;
  dest.y = 0;
  dest.w = PSEUDO_WIDTH;
  dest.h = PSEUDO_HEIGHT;


  /* (draw white) */

  my_fillrect(screen, &dest, SDL_MapRGB(screen->format, 0xFF, 0xFF, 0xFF));
  my_updaterect(screen, 0);


  /* (wait a brief moment) */

  SDL_Delay(50);


  /* (return to normal) */

  /* ((redraw background)) */

  erase(dest);


  /* ((redraw bomber)) */

  dest.x = bomber_x;
  dest.y = bomber_y;
  dest.w = 32;
  dest.h = 64;

  if (score[player] < 10000 || vs_mode == 1)
    my_blit(images[IMG_BOMBER_HAPPY],
	    NULL, screen, &dest);
  else
    my_blit(images[IMG_BOMBER_AMAZED],
	    NULL, screen, &dest);


  /* ((redraw buckets)) */

  for (i = 0; i < num_buckets[player] - 1; i++)
    {
      dest.x = x[player];
      dest.y = PSEUDO_HEIGHT-128 + i * 32;
      dest.w = 32 * width[player];
      dest.h = 32;

      my_blit(images[IMG_BUCKET1 + (((frame / 3) + i) % 3) +
			    (player * 3) + 12 - (width[player] * 6)],
		      NULL, screen, &dest);
    }


  /* ((redraw score)) */

  drawscore(score[player], player);


  /* ((update it all)) */

  my_updaterect(screen, 0);


#if WANT_SOUND
  if (use_sound == 1)
    {
      do
	{
	  /* Wait... */
	  SDL_Delay(30);
	}
      while (Mix_Playing(1));
    }
#endif
}


/* Erase part of the screen back to the background: */

static void erase(SDL_Rect dest)
{
  /* Copy the background bitmap onto the screen: */

  if (zen == 0)
    {
      my_blit(images[IMG_BACKGROUND],
	      &dest, screen, &dest);
    }
  else
    {
      SDL_Rect temp;

      /* Paint zen background: */
      temp.x = 0;
      temp.y = 0;
      temp.w = PSEUDO_WIDTH;
      temp.h = PSEUDO_HEIGHT;
      if (intersects(temp, dest, &temp))
        {
          my_fillrect(screen, &temp,
                      SDL_MapRGB(screen->format, 0x00, 0x00, 0x00));
        }

      temp.x = 31;
      temp.y = 39;
      temp.w = PSEUDO_WIDTH-(2*31);
      temp.h = bomber_y + 21;
      if (intersects(temp, dest, &temp))
        {
          my_fillrect(screen, &temp,
                      SDL_MapRGB(screen->format, 165, 165, 165));
        }
      temp.x = 31;
      temp.y = 60 + bomber_y;
      temp.w = PSEUDO_WIDTH-(2*31);
      temp.h = 246 + bomber_y;  /* not too sure... */

      if (intersects(temp, dest, &temp))
        {
          my_fillrect(screen, &temp,
                      SDL_MapRGB(screen->format, 74, 115, 24));
        }
    }
}

/* Get the intersection of r1 and r2 into r.  returns 0 if none exists */

static int intersects(SDL_Rect const r1, SDL_Rect const r2, SDL_Rect * r)
{
  Sint16 i, j;
  i = (r1.x > r2.x)? r1.x : r2.x;
  j = (((r1.x + r1.w) < (r2.x + r2.w))? (r1.x + r1.w) : (r2.x + r2.w)) - i;
  if (j <= 0) return 0;
  r->x = i;
  r->w = (Uint16)j;
  i = (r1.y > r2.y)? r1.y : r2.y;
  j = (((r1.y + r1.h) < (r2.y + r2.h))? (r1.y + r1.h) : (r2.y + r2.h)) - i;
  if (j <= 0) return 0;
  r->y = i;
  r->h = (Uint16)j;
  return 1;
}


/* parse command line arguments */

int parse_args(int argc, char ** argv)
{
#if WANT_SOUND
  use_sound = 1;     /* (Use sound, by default): */
#endif

  use_fullscreen = 0;


  if (argc == 2)
    {
#if WANT_HELP
      if (strcmp(argv[1], "--help") == 0 || strcmp(argv[1], "-?") == 0)
	{
	  /* Display help stuff: */
	
	  printf("\n"
		 "-------------------------------------"
		 "------------------------------\n"
		 "Mad Bomber version " VERSION "\n"
		 "Copyright (C) 1999-2002 by Bill Kendrick, "
		 "bill@newbreedsoftware.com\n"
		 "-------------------------------------"
		 "------------------------------\n"
		 "\n"
		 "This program is free software; you can redistribute it\n"
		 "and/or modify it under the terms of the GNU General Public\n"
		 "License as published by the Free Software Foundation;\n"
		 "either version 2 of the License, or (at your option) any\n"
		 "later version.\n"
		 "\n"
		 "This program is distributed in the hope that it will be\n"
		 "useful and entertaning, but WITHOUT ANY WARRANTY; without\n"
		 "even the implied warranty of MERCHANTABILITY or FITNESS\n"
		 "FOR A PARTICULAR PURPOSE.  See the GNU General Public\n"
		 "License for more details.\n"
		 "\n"
		 "You should have received a copy of the GNU General Public\n"
		 "License along with this program; if not, write to the Free\n"
		 "Software Foundation, Inc., 59 Temple Place, Suite 330,\n"
		 "Boston, MA  02111-1307  USA\n"
		 "\n");
	
	  printf("Usage: %s [OPTION]\n\n", argv[0]);
	
	  printf("Game options\n"
#if WANT_SOUND
		 "  --disable-sound    Disable sound\n"
#endif
		 "  --fullscreen       (Try to) run in fullscreen\n"
		 "\n"
		 "Help options\n"
		 "  -?, --help         Show this help message\n"
		 "  --usage            Display brief usage message\n"
		 "\n"
		 "Title screen controls\n"
		 "  Up/Down            Choose option\n"
#ifndef EMBEDDED
		 "  Space/Return       Activate option\n"
		 "  Mouse-click        Activate option under mouse pointer\n"
		 "  Escape             Quit program\n"
#else
		 "  Selector           Activate option\n"
		 "  Stylus-tap         Activate option under stylus\n"
		 "  Cancel             Quit program\n"
#endif
		 "\n"
		 "Option screen controls\n"
		 "  Up/Down Arrows     Choose option\n"
#ifndef EMBEDDED
		 "  Space/Return       Activate option\n"
		 "  Mouse-click        Activate option under mouse pointer\n"
		 "  Escape             Return to title screen\n"
#else
		 "  Selector           Activate option\n"
		 "  Stylus-tap         Activate option under stylus\n"
		 "  Cancel             Return to title screen\n"
#endif
		 "\n"
		 "Game controls\n"
		 "  Left/Right Arrows  Move buckets\n"
#ifndef EMBEDDED
		 "  Mouse-motion       Move buckets\n"
		 "  Space/Return       Fire\n"
		 "  Mouse-click        Fire\n"
		 "  1/2/3/4            (in Vs. mode) Move Mad Bomber\n"
		 "                     (1 = left, fast\n"
		 "                      2 = left, slow\n"
		 "                      3 = right, slow\n"
		 "                      4 = right, fast)\n"
		 "  Tab/P              Pause\n"
#else
		 "  Stylus-drag        Move buckets\n"
		 "  Ok/Selector        Fire\n"
#endif
		 "  Escape             Quit game (return to title screen)\n"
		 "\n");
	  return -1;
	}
      else
#endif /* WANT_HELP */

      if (strcmp(argv[1], "--usage") == 0)
	{
	  /* Display usage: */
	
	  printf("Usage: %s [-?] [--help] [--usage] [--disable-sound] "
		 "[--fullscreen]\n",
		 argv[0]);
	  return -1;
	}
#if WANT_SOUND
      else if (strcmp(argv[1], "--disable-sound") == 0)
	{
	  /* Turn off sound: */
	
	  use_sound = 0;
	}
#endif
      else if (strcmp(argv[1], "--fullscreen") == 0)
	{
	  /* Turn on fullscreen mode: */
	
	  use_fullscreen = 1;
	}
      else
	{
	  /* Display usage (as an error!): */
	
	  fprintf(stderr,
		  "Usage: %s [-?] [--help] [--usage] [--disable-sound] "
		  "[--fullscreen]\n",
		  argv[0]);
	  return -2;
	}
    }
  else if (argc > 2)
    {
      /* Display usage (as an error!): */

      fprintf(stderr, "Usage: %s [-?] [--help] [--usage] [--disable-sound] "
	      "[--fullscreen]\n",
	      argv[0]);
      return -2;
   }
  return 0;
}

/* read the options file */

static void read_options()
{
  FILE * fi;
  char temp[512];

  /* Set defaults: */

  highscore = 500;
  strcpy(highscorer, "LARRY KAPLAN");
  zen = 0;
  width[0] = 2;
  width[1] = 2;
  effects_volume = 7;
  music_volume = 6;

#ifndef NO_STREAMS

  /* Load options: */

  fi = open_file(OPTION_FILE, "r");

  if (fi != NULL)
    {
      fgets(temp, sizeof temp, fi);
      if (0 == strcmp(temp, OPTIONS_FILE_VERSION))
        {
          do
            {
              fgets(temp, sizeof(temp), fi);

              if (!feof(fi))
                {
                  temp[strlen(temp) - 1] = '\0';


                  /* Parse each line: */

                  if (strstr(temp, "highscore=") == temp)
                    {
                      highscore = atoi(temp + 10);

                      if (highscore == 0)
                        highscore = 500;
                    }
                  else if (strstr(temp, "highscorer=") == temp)
                    {
                      if (strlen(temp) > 11 + sizeof(highscorer))
                        temp[11 + sizeof(highscorer)] = '\0';

                      strcpy(highscorer, temp + 11);
                    }
                  else if (strstr(temp, "details=") == temp)
                    {
                      if (strcmp(temp + 8, "zen") == 0)
                        zen = 1;
                    }
                  else if (strstr(temp, "diff1=") == temp)
                    {
                      if (strcmp(temp + 6, "hard") == 0)
                        width[0] = 1;
                    }
                  else if (strstr(temp, "diff2=") == temp)
                    {
                      if (strcmp(temp + 6, "hard") == 0)
                        width[1] = 1;
                    }
                  else if (strstr(temp, "effects=") == temp)
                    {
                      effects_volume = atoi(temp + 8);

                      if (effects_volume < 0)
                        effects_volume = 0;
                      else if (effects_volume > 8)
                        effects_volume = 8;
                    }
                  else if (strstr(temp, "music=") == temp)
                    {
                      music_volume = atoi(temp + 6);

                      if (music_volume < 0)
                        music_volume = 0;
                      else if (music_volume > 8)
                        music_volume = 8;
                    }
                }
            }
          while (!feof(fi));
        }
      fclose(fi);
    }
#endif
}

/* write the options file */

static void write_options()
{
#ifndef NO_STREAMS

  FILE * fi;
  int i;

  fi = open_file(OPTION_FILE, "w");
  if (fi != NULL)
    {
      /* Comment at the top (I wish _everyone_ did this!) */
      fprintf(fi, "%s\n", OPTIONS_FILE_VERSION);


      /* High score: */

      fprintf(fi, "# Highscore:\n\n");
      fprintf(fi, "highscore=%d\n\n", highscore);
      fprintf(fi, "highscorer=%s\n\n\n", highscorer);


      /* Background details: */

      fprintf(fi,
	      "# Set \"details\" to \"zen\" for plain background,\n"
	      "# or \"normal\" for photorealistic background.\n\n"
	      "# (Default: normal)\n\n");

      if (zen == 1)
	fprintf(fi, "details=zen\n\n\n");
      else
	fprintf(fi, "details=normal\n\n\n");


      /* Difficulty levels: */

      fprintf(fi,
	      "# Set \"diff#\" to \"hard\" for thin buckets, or\n"
	      "# \"normal\" for wide buckets.\n"
	      "# Where \"#\" is \"1\" or \"2\", for player one or two.\n\n"
	      "# (Default: normal)\n\n");

      for (i = 0; i < 2; i++)
	{
	  fprintf(fi, "diff%d=", i + 1);
	
	  if (width[i] == 1)
	    fprintf(fi, "hard\n");
	  else
	    fprintf(fi, "normal\n");
	}

      fprintf(fi, "\n");


      /* Volume levels: */

      fprintf(fi,
	      "# Set \"effects\" and \"music\" to a value between 0 and 8.\n"
	      "# Where \"0\" is silent and \"8\" is maximum volume (loud).\n"
	      "# Where \"effects\" sets sound effects volume, and\n"
	      "# where \"music\" sets music volume.\n\n"
	      "# (Default: 7 and 5, respectively)\n\n");

      fprintf(fi, "effects=%d\n", effects_volume);
      fprintf(fi, "music=%d\n\n", music_volume);


      /* The end! */

      fprintf(fi, "# (File automatically created.)\n");

      fclose(fi);
    }
#endif
}


/* read the state file */

#if WANT_CONTINUE_OPTION
static void read_state()
{
  FILE * fi;
  int version;
  /* Load state file: */

  can_continue = 0;


  /* Load state: */

  fi = open_file(STATE_FILE, "r");

  if (fi != NULL)
    {
      fread(&version, sizeof version, 1, fi);
      if (version == STATE_FILE_VERSION)
        fread(&can_continue, sizeof can_continue, 1, fi);

      if (can_continue)
      {
        fread(&num_players, sizeof num_players, 1, fi);
        fread(&player, sizeof player, 1, fi);

        fread(&bomber_x, sizeof bomber_x, 1, fi);

        fread(level, sizeof level[0], sizeof level / sizeof level[0], fi);
        fread(past_level_8, sizeof(int), 2, fi);
        fread(half_level, sizeof half_level[0], sizeof half_level / sizeof half_level[0], fi);
        fread(old_x, sizeof old_x[0], sizeof old_x / sizeof old_x[0], fi);
        fread(one_up_score, sizeof one_up_score[0], sizeof one_up_score / sizeof one_up_score[0], fi);
        fread(have_highscore, sizeof have_highscore[0], sizeof have_highscore / sizeof have_highscore[0], fi);
        fread(&bomber_go, sizeof bomber_go, 1, fi);
        fread(&bomber_happy, sizeof bomber_happy, 1, fi);
        fread(&bombs_left, sizeof bombs_left, 1, fi);
        fread(&no_active_bombs, sizeof no_active_bombs, 1, fi);
        fread(&bomber_xm, sizeof bomber_xm, 1, fi);
        fread(&bomber_xm_time, sizeof bomber_xm_time, 1, fi);
        fread(&img, sizeof img, 1, fi);
        fread(&explode_the_bombs, sizeof explode_the_bombs, 1, fi);
        fread(&drop_bomb, sizeof drop_bomb, 1, fi);

        fread(x, sizeof x[0], sizeof x / sizeof x[0], fi);
        fread(width, sizeof width[0], sizeof width / sizeof width[0], fi);
        fread(num_buckets, sizeof num_buckets[0], sizeof num_buckets / sizeof num_buckets[0], fi);
        fread(score, sizeof score[0], sizeof score / sizeof score[0], fi);

        fread(bombs, sizeof bombs[0], sizeof bombs / sizeof bombs[0], fi);
        fread(drops, sizeof drops[0], sizeof drops / sizeof drops[0], fi);
      }

      fclose(fi);
    }
}
#endif

/* write the state file */

#if WANT_CONTINUE_OPTION
static void write_state()
{
  FILE * fi;
  int version = STATE_FILE_VERSION;

  fi = open_file(STATE_FILE, "w");

  if (fi != NULL)
    {
      fwrite(&version, sizeof version, 1, fi);
      fwrite(&can_continue, sizeof can_continue, 1, fi);

      if (can_continue)
      {
        fwrite(&num_players, sizeof num_players, 1, fi);
        fwrite(&player, sizeof player, 1, fi);

        fwrite(&bomber_x, sizeof bomber_x, 1, fi);

        fwrite(level, sizeof level[0], sizeof level / sizeof level[0], fi);
        fwrite(past_level_8, sizeof(int), 2, fi);
        fwrite(half_level, sizeof half_level[0], sizeof half_level / sizeof half_level[0], fi);
        fwrite(old_x, sizeof old_x[0], sizeof old_x / sizeof old_x[0], fi);
        fwrite(one_up_score, sizeof one_up_score[0], sizeof one_up_score / sizeof one_up_score[0], fi);
        fwrite(have_highscore, sizeof have_highscore[0], sizeof have_highscore / sizeof have_highscore[0], fi);
        fwrite(&bomber_go, sizeof bomber_go, 1, fi);
        fwrite(&bomber_happy, sizeof bomber_happy, 1, fi);
        fwrite(&bombs_left, sizeof bombs_left, 1, fi);
        fwrite(&no_active_bombs, sizeof no_active_bombs, 1, fi);
        fwrite(&bomber_xm, sizeof bomber_xm, 1, fi);
        fwrite(&bomber_xm_time, sizeof bomber_xm_time, 1, fi);
        fwrite(&img, sizeof img, 1, fi);
        fwrite(&explode_the_bombs, sizeof explode_the_bombs, 1, fi);
        fwrite(&drop_bomb, sizeof drop_bomb, 1, fi);

        fwrite(x, sizeof x[0], sizeof x / sizeof x[0], fi);
        fwrite(width, sizeof width[0], sizeof width / sizeof width[0], fi);
        fwrite(num_buckets, sizeof num_buckets[0], sizeof num_buckets / sizeof num_buckets[0], fi);
        fwrite(score, sizeof score[0], sizeof score / sizeof score[0], fi);

        fwrite(bombs, sizeof bombs[0], sizeof bombs / sizeof bombs[0], fi);
        fwrite(drops, sizeof drops[0], sizeof drops / sizeof drops[0], fi);
      }

      fclose(fi);
    }
}
#endif

/* Open the option or the state file: */

static FILE * open_file(enum WhatFile whatFile, char * mode)
{
#ifdef NO_STREAMS
  return 0;
#else
  char * filepath;
  FILE * fi;

#if HAVE_HOME_ENV
  char const * filename;
  char * home;

  /* Get home directory (from $HOME variable)... if we can't determine it,
     use the current directory ("."): */

  if (getenv("HOME") != NULL)
    home = getenv("HOME");
  else
#ifdef PALMOS
    home = "/PALM/programs/madbomber";
#else
    home = ".";
#endif

  /* Create the buffer for the filepath: */

  filename = (whatFile == OPTION_FILE)? "/.madbomber" : "/.madbomber-state";
  filepath = (char *)malloc(strlen(home) + strlen(filename) + 1);
  if (!filepath)
    {
      fprintf(stderr, "\nError: Memory full\n");
      return 0;
    }
  strcpy(filepath, home);
  strcat(filepath, filename);
#else
  filepath = (whatFile == OPTION_FILE)? "madbomber.dat" : "madbomber-state.dat";
#endif


  /* Try opening the file: */

  fi = fopen(filepath, mode);

  if (fi == NULL)
    {
      fprintf(stderr,
              "\nWarning: I could not open the %s file ",
             (whatFile == OPTION_FILE)? "options" : "state");
      if (strcmp(mode, "r") == 0)
	fprintf(stderr, "for read:");
      else if (strcmp(mode, "w") == 0)
	fprintf(stderr, "for write:");
      fprintf(stderr, "\n%s\n"
	      "The error that occured was:\n"
	      "%s\n\n", filepath, strerror(errno));
    }
#if HAVE_HOME_ENV
  free(filepath);
#endif
  return fi;
#endif /* NO_STREAMS */
}


/* Option screen: */

static int optionscreen()
{
  SDL_Event event;
  SDL_Rect dest;
  int done, quit, which_option, old_which_option;
  int bx, by;
#ifdef __palmos__
	int hatpos = SDL_HAT_CENTERED;
#endif


  /* Erase screen: */

  dest.x = 0;
  dest.y = 0;
  dest.w = PSEUDO_WIDTH;
  dest.h = PSEUDO_HEIGHT;

  my_fillrect(screen, &dest,
	       SDL_MapRGB(screen->format, 0x00, 0x00, 0x00));


  /* Draw "OPTIONS" title: */

  dest.w = pseudo_widths[IMG_OPTIONS_OPTIONS];
  dest.h = pseudo_heights[IMG_OPTIONS_OPTIONS];
  dest.x = (PSEUDO_WIDTH - dest.w) / 2;
  dest.y = 0;
  my_blit(images[IMG_OPTIONS_OPTIONS], NULL, screen, &dest);


  /* Draw "Detail": */

  dest.x = 0;
  dest.y = 84;
  dest.w = pseudo_widths[IMG_OPTIONS_DETAIL];
  dest.h = pseudo_heights[IMG_OPTIONS_DETAIL];
  my_blit(images[IMG_OPTIONS_DETAIL], NULL, screen, &dest);

  show_option_img(1, 84, IMG_OPTIONS_NORMAL + zen * 2);


  /* Draw "Player One" and "Player Two": */

  show_option_img(0, 198 - (pseudo_heights[IMG_OPTIONS_PLAYER_ONE]),
		  IMG_OPTIONS_PLAYER_ONE);
  show_option_img(1, 198 - (pseudo_heights[IMG_OPTIONS_PLAYER_TWO]),
		  IMG_OPTIONS_PLAYER_TWO);


  /* Draw "Difficulty": */

  dest.x = 0;
  dest.y = 198;
  dest.w = pseudo_widths[IMG_OPTIONS_DIFFICULTY];
  dest.h = pseudo_heights[IMG_OPTIONS_DIFFICULTY];
  my_blit(images[IMG_OPTIONS_DIFFICULTY], NULL, screen, &dest);


  /* Draw players' difficulty settings: */

  if (width[0] == 1)
    show_option_img(0, 198, IMG_OPTIONS_HARD_OFF);
  else
    show_option_img(0, 198, IMG_OPTIONS_NORMAL_OFF);

  if (width[1] == 1)
    show_option_img(1, 198, IMG_OPTIONS_HARD_OFF);
  else
    show_option_img(1, 198, IMG_OPTIONS_NORMAL_OFF);


#if WANT_OPTION_EFFECTS
  if (use_sound)
    {
      /* Draw "Effects" and "Music": */

      show_option_img(0, PSEUDO_HEIGHT-168 - (pseudo_heights[IMG_OPTIONS_EFFECTS]),
		      IMG_OPTIONS_EFFECTS);
      show_option_img(1, PSEUDO_HEIGHT-168 - (pseudo_heights[IMG_OPTIONS_MUSIC]),
		      IMG_OPTIONS_MUSIC);


      /* Draw "Volume": */

      dest.x = 0;
      dest.y = PSEUDO_HEIGHT-168;
      dest.w = pseudo_widths[IMG_OPTIONS_VOLUME];
      dest.h = pseudo_heights[IMG_OPTIONS_VOLUME];
      my_blit(images[IMG_OPTIONS_VOLUME], NULL, screen, &dest);


      /* Draw volume settings: */

      show_option_meter(0, effects_volume, 0);
      show_option_meter(1, music_volume, 0);
    }
#endif


  /* Draw OK button: */

  dest.w = pseudo_widths[IMG_OPTIONS_OK];
  dest.h = pseudo_heights[IMG_OPTIONS_OK];
  dest.x = (PSEUDO_WIDTH - dest.w) / 2;
  dest.y = PSEUDO_HEIGHT - dest.h;

  my_blit(images[IMG_OPTIONS_OK_OFF], NULL, screen, &dest);


  /* Update screen: */

  my_updaterect(screen, 0);


  /* Pause loop: */

  done = 0;
  quit = 0;
  which_option = OPTIONS_OPTION_DETAIL;
  old_which_option = OPTIONS_OPTION_DETAIL;

  do
    {
      while (SDL_PollEvent(&event))
	{
	  switch (event.type)
            {

            case SDL_KEYDOWN:
	      switch (event.key.keysym.sym)
	        {
	        case SDLK_ESCAPE:
		  which_option = OPTIONS_OPTION_OK;
		  done = 1;
                  break;

#if LANDSCAPE_FORMAT || WANT_JOG_DIAL
	        case SDLK_UP:
#elif !WANT_JOG_DIAL
	        case SDLK_RIGHT:
#endif
		  if (which_option > 0)
		    which_option--;


		  /* Don't select sound options if we have no sound! */
		
#if WANT_OPTION_EFFECTS
		  if (use_sound == 0)
#endif
		  if (which_option >= OPTIONS_OPTION_EFFECTS &&
		      which_option != OPTIONS_OPTION_OK)
		    which_option = OPTIONS_OPTION_EFFECTS - 1;
                  break;


#if LANDSCAPE_FORMAT || WANT_JOG_DIAL
		case SDLK_DOWN:
#elif !WANT_JOG_DIAL
		case SDLK_LEFT:
#endif
		  if (which_option < NUM_OPTIONS_OPTIONS - 1)
		    which_option++;
		
		
		  /* Don't select sound options if we have no sound! */
		
#if WANT_OPTION_EFFECTS
		  if (use_sound == 0)
#endif
		  if (which_option >= OPTIONS_OPTION_EFFECTS &&
		      which_option != OPTIONS_OPTION_OK)
		    which_option = OPTIONS_OPTION_OK;
		  break;

#if !WANT_JOG_DIAL
#if LANDSCAPE_FORMAT
		case SDLK_LEFT:
		case SDLK_RIGHT:
#else
		case SDLK_DOWN:
		case SDLK_UP:
#endif
		case SDLK_SPACE:
#endif
		case SDLK_RETURN:

		  /* Any of the keys control toggles: */
		
		  if (which_option == OPTIONS_OPTION_DETAIL)
		    zen = 1 - zen;
		  else if (which_option == OPTIONS_OPTION_PLAYER_ONE)
		    width[0] = 3 - width[0];
		  else if (which_option == OPTIONS_OPTION_PLAYER_TWO)
		    width[1] = 3 - width[1];
		
		
		  if (which_option == OPTIONS_OPTION_OK)
		    done = 1;
		
#if WANT_OPTION_EFFECTS
		  if (use_sound)
		    {
                      switch (event.key.keysym.sym)
                        {
		        case SDLK_LEFT:
			  /* Left reduces volumes: */
			  if (which_option == OPTIONS_OPTION_EFFECTS)
			    {
			      effects_volume--;
			      if (effects_volume < 0)
				effects_volume = 0;
			    }
			  else if (which_option == OPTIONS_OPTION_MUSIC)
			    {
			      music_volume--;
			      if (music_volume < 0)
				music_volume = 0;
			    }
                          break;
		        case SDLK_RIGHT:
			  /* Right increases volumes: */
			  if (which_option == OPTIONS_OPTION_EFFECTS)
			    {
			      effects_volume++;
			      if (effects_volume > 8)
				effects_volume = 8;
			    }
			  else if (which_option == OPTIONS_OPTION_MUSIC)
			    {
			      music_volume++;
			      if (music_volume > 8)
				music_volume = 8;
			    }
                          break;
			
			      default:
			        break;
			}
		
		      /* Adjust sound: */
		      if (which_option == OPTIONS_OPTION_EFFECTS)
			{
			  Mix_Volume(-1, effects_volume * 16);
			}
		      else if (which_option == OPTIONS_OPTION_MUSIC)
			{
			  Mix_VolumeMusic(music_volume * 16);
			}
		    }
#endif

		  old_which_option = -1;
                  break;

                default:
                  break;
                }
              break;

#ifdef __palmos__
			case SDL_JOYBUTTONDOWN:
				done = 1;
			  break;

			case SDL_JOYHATMOTION:
				if(event.jhat.value == SDL_HAT_UP && hatpos != SDL_HAT_UP)
				{
				  if (which_option > 0)
				    which_option--;

				  /* Don't select sound options if we have no sound! */
#if WANT_OPTION_EFFECTS
				  if (use_sound == 0)
#endif
					  if (which_option >= OPTIONS_OPTION_EFFECTS && which_option != OPTIONS_OPTION_OK)
		    			which_option = OPTIONS_OPTION_EFFECTS - 1;
				}
				if(event.jhat.value == SDL_HAT_DOWN && hatpos != SDL_HAT_DOWN)
				{
				  if (which_option < NUM_OPTIONS_OPTIONS - 1)
				    which_option++;
	
				  /* Don't select sound options if we have no sound! */
#if WANT_OPTION_EFFECTS
				  if (use_sound == 0)
#endif
		  			if (which_option >= OPTIONS_OPTION_EFFECTS && which_option != OPTIONS_OPTION_OK)
		    			which_option = OPTIONS_OPTION_OK;
				}
				hatpos = event.jhat.value;
			  break;
#endif
	
	    case SDL_MOUSEBUTTONDOWN:
#if LANDSCAPE_FORMAT
	      bx = event.button.x * SCALE_RATIO;
	      by = event.button.y * SCALE_RATIO;
#else
              bx = event.button.y * SCALE_RATIO;
	      by = PSEUDO_HEIGHT - event.button.x * SCALE_RATIO;
#endif
	      /* Click - figure out where! */
	
	      if (by >= 84 &&
		  by <= 84 + (pseudo_heights[IMG_OPTIONS_NORMAL]) &&
		  bx >= PSEUDO_WIDTH - (pseudo_widths[IMG_OPTIONS_NORMAL]))
		{
		  /* Detail: */
		
		  zen = 1 - zen;
		
		  which_option = OPTIONS_OPTION_DETAIL;
		  if (old_which_option == which_option)
		    old_which_option = -1;
		}
	      else if (by >= 198 &&
		       by <= (198 + (pseudo_heights[IMG_OPTIONS_NORMAL])))
		{
		  /* Difficulty: */
		
		  if (bx >= 220 &&
		      bx <= (220 + (pseudo_widths[IMG_OPTIONS_NORMAL])))
		    {
		      /* Player one: */
		
		      width[0] = 3 - width[0];
		
		      which_option = OPTIONS_OPTION_PLAYER_ONE;
		      if (old_which_option == which_option)
			old_which_option = -1;
		    }
		  else if (bx >= (PSEUDO_WIDTH - (pseudo_widths[IMG_OPTIONS_NORMAL])))
		    {
		      /* Player two: */
		
		      width[1] = 3 - width[1];
		
		      which_option = OPTIONS_OPTION_PLAYER_TWO;
		      if (old_which_option == which_option)
			old_which_option = -1;
		    }
		}
	      else if (by >= PSEUDO_HEIGHT - (pseudo_heights[IMG_OPTIONS_OK]) &&
		       bx >= (PSEUDO_WIDTH - (pseudo_widths[IMG_OPTIONS_OK])) / 2 &&
		       bx <= ((PSEUDO_WIDTH - (pseudo_widths[IMG_OPTIONS_OK]))
		                        / 2) + (pseudo_widths[IMG_OPTIONS_OK]))
		{
		  /* OK button: */
		
		  which_option = OPTIONS_OPTION_OK;
		  if (old_which_option == which_option)
		    old_which_option = -1;
		
		  done = 1;
		}
	
	
#if WANT_OPTION_EFFECTS
	      if (use_sound == 1)
		{
		  if (event.button.y >= PSEUDO_HEIGHT-168 &&
		      event.button.y <= (PSEUDO_HEIGHT-168 +
					 (pseudo_heights[IMG_OPTIONS_0PERCENT])))
		    {
		      /* Volume controls: */
		
		      if (event.button.x >= 220 &&
			  event.button.x <= (220 +
					     (pseudo_widths[IMG_OPTIONS_0PERCENT]
					     * 9)))
			{
			  /* Effects: */
			
			  effects_volume = ((event.button.x - 220) /
					    (images[IMG_OPTIONS_0PERCENT] ->
					     w));
			  Mix_Volume(-1, effects_volume * 16);
			
			  which_option = OPTIONS_OPTION_EFFECTS;
			  if (old_which_option == which_option)
			    old_which_option = -1;
			}
		      else if (event.button.x >= (PSEUDO_WIDTH -
						  ((images[IMG_OPTIONS_0PERCENT]
						    -> w) * 9)))
			{
			  /* Music: */
			
			  music_volume = ((event.button.x -
					   (PSEUDO_WIDTH - ((images[IMG_OPTIONS_0PERCENT]
						    -> w) * 9))) /
					  (pseudo_widths[IMG_OPTIONS_0PERCENT]));
			
			  Mix_VolumeMusic(music_volume * 16);

			  which_option = OPTIONS_OPTION_MUSIC;
			  if (old_which_option == which_option)
			    old_which_option = -1;
			}
		    }
		}
#endif
              break;

	    case SDL_QUIT:
	      done = 1;
	      quit = 1;
              break;

            default:
              break;
	    }
	}


      /* Draw a new option? */

      if (which_option != old_which_option)
	{
	  /* Erase the previously-selected option: */
	  switch (old_which_option)
            {
            case OPTIONS_OPTION_DETAIL:
	      show_option_img(1, 84, IMG_OPTIONS_NORMAL_OFF + zen * 2);
              break;

	    case OPTIONS_OPTION_PLAYER_ONE:
	      if (width[0] == 1)
		show_option_img(0, 198, IMG_OPTIONS_HARD_OFF);
	      else
		show_option_img(0, 198, IMG_OPTIONS_NORMAL_OFF);
              break;
	

	    case OPTIONS_OPTION_PLAYER_TWO:
	      if (width[1] == 1)
		show_option_img(1, 198, IMG_OPTIONS_HARD_OFF);
	      else
		show_option_img(1, 198, IMG_OPTIONS_NORMAL_OFF);
              break;
	
	    case OPTIONS_OPTION_EFFECTS:
	      show_option_meter(0, effects_volume, 0);
              break;
	
	    case OPTIONS_OPTION_MUSIC:
	      show_option_meter(1, music_volume, 0);
              break;
	
	    case OPTIONS_OPTION_OK:
	      dest.w = pseudo_widths[IMG_OPTIONS_OK];
	      dest.h = pseudo_heights[IMG_OPTIONS_OK];
	      dest.x = (PSEUDO_WIDTH - dest.w) / 2;
	      dest.y = PSEUDO_HEIGHT - dest.h;
	
	      my_blit(images[IMG_OPTIONS_OK_OFF], NULL, screen, &dest);
	      /* my_updaterect(screen, &dest); */
	      my_updaterect(screen, 0);
              break;

            default:
              break;
	    }
	
	
	  /* Draw the newly-selected option: */
	
	  switch (which_option)
            {
            case OPTIONS_OPTION_DETAIL:
	      show_option_img(1, 84, IMG_OPTIONS_NORMAL + zen * 2);
              break;

	    case OPTIONS_OPTION_PLAYER_ONE:
	      if (width[0] == 1)
		show_option_img(0, 198, IMG_OPTIONS_HARD);
	      else
		show_option_img(0, 198, IMG_OPTIONS_NORMAL);
              break;

	    case OPTIONS_OPTION_PLAYER_TWO:
	      if (width[1] == 1)
		show_option_img(1, 198, IMG_OPTIONS_HARD);
	      else
		show_option_img(1, 198, IMG_OPTIONS_NORMAL);
              break;
	
	    case OPTIONS_OPTION_EFFECTS:
	      show_option_meter(0, effects_volume, 1);
              break;
	
	    case OPTIONS_OPTION_MUSIC:
	      show_option_meter(1, music_volume, 1);
              break;
	
	    case OPTIONS_OPTION_OK:
	      dest.w = pseudo_widths[IMG_OPTIONS_OK];
	      dest.h = pseudo_heights[IMG_OPTIONS_OK];
	      dest.x = (PSEUDO_WIDTH - dest.w) / 2;
	      dest.y = PSEUDO_HEIGHT - dest.h;

	      my_blit(images[IMG_OPTIONS_OK], NULL, screen, &dest);
	      /* my_updaterect(screen, &dest); */
	      my_updaterect(screen, 0);
              break;

            default:
              break;
	    }
	
	
	  /* Play selection sound: */
	
#if WANT_SOUND
	  playsound(SND_SELECT, -1);
#endif
	  old_which_option = which_option;
	}


#if WANT_SOUND
      /* Keep playing music: */
#if WANT_MUSIC
      if ((use_sound == 1) && !Mix_PlayingMusic())
	{
	  Mix_PlayMusic(title_music, 0);
	  Mix_VolumeMusic(music_volume * 16);
	}
#endif //WANT_MUSIC
#endif


      /* Pause: */

      SDL_Delay(50);
    }
  while (done == 0);


  /* Return whether or not we ended pause because we're quitting: */

  return quit;
}


/* Show an option image: */

static void show_option_img(int horiz, int y, int img)
{
  SDL_Rect dest;


  /* Determine horizontal location: */

  if (horiz == 0)
    dest.x = 220;
  else
    dest.x = PSEUDO_WIDTH - pseudo_widths[img];

  dest.y = y;
  dest.w = pseudo_widths[img];
  dest.h = pseudo_heights[img];

  /* Draw or erase the spot: */

  my_blit(images[img], NULL, screen, &dest);
  my_updaterect(screen, &dest);
}


/* Display a volume meter: */

static void show_option_meter(int horiz, int value, int selected)
{
  int img, i, x;
  SDL_Rect dest;


  /* Determine horizontal location: */

  if (horiz == 0)
    x = 220;
  else
    x = PSEUDO_WIDTH - ((pseudo_widths[IMG_OPTIONS_0PERCENT]) * 9);


  /* Erase meter: */

  dest.x = x;
  dest.y = PSEUDO_HEIGHT-168;
  dest.w = pseudo_widths[IMG_OPTIONS_0PERCENT] * 9;
  dest.h = pseudo_heights[IMG_OPTIONS_0PERCENT];

  my_fillrect(screen, &dest,
  	       SDL_MapRGB(screen->format, 0x00, 0x00, 0x00));


  /* Draw the meter: */

  for (i = 0; i <= value; i++)
    {
      img = IMG_OPTIONS_0PERCENT + ((i / 2) * 2) + (1 - selected);

      dest.x = x + (i * pseudo_widths[IMG_OPTIONS_0PERCENT]);
      dest.y = PSEUDO_HEIGHT-168;
      dest.w = pseudo_widths[IMG_OPTIONS_0PERCENT];
      dest.h = pseudo_heights[IMG_OPTIONS_0PERCENT];

      my_blit(images[img], NULL, screen, &dest);
    }


  /* Update the screen: */

  dest.x = x;
  dest.y = PSEUDO_HEIGHT-168;
  dest.w = pseudo_widths[IMG_OPTIONS_0PERCENT];
  dest.h = pseudo_heights[IMG_OPTIONS_0PERCENT];
  my_updaterect(screen, &dest);
}


#if WANT_FLYING_NUMBERS

/* Draw flying numbers on the screen: */

static void draw_flying_numbers(int number, int scale, Uint8 r, Uint8 g, Uint8 b)
{
  SDL_Rect dest;
  int i;

  for (i = 0; i < 7; i++)
    {
      /* If this "light" of the LED is on, then draw it: */

      if (flying_number_layouts[number][i])
	{
	  /* Determine where the "light" is: */
	
	  if (i == 0 || i == 1 || i == 3 || i == 4 || i == 6)
	    dest.x = (PSEUDO_WIDTH/2) + (-scale * 5);
	  else
	    dest.x = (PSEUDO_WIDTH/2) + (scale * 5);
	
	  if (i == 0 || i == 1 || i == 2)
	    dest.y = (PSEUDO_HEIGHT/2) + (-scale * 10);
	  else if (i == 3 || i == 4 || i == 5)
	    dest.y = (PSEUDO_HEIGHT/2);
	  else if (i == 6)
	    dest.y = (PSEUDO_HEIGHT/2) + (scale * 10);
	
	
	  /* ...And what shape it is: */
	
	  if (i == 0 || i == 3 || i == 6)
	    {
	      dest.w = scale * 8;
	      dest.h = scale * 2;
	    }
	  else
	    {
	      dest.w = scale * 2;
	      dest.h = scale * 8;
	    }
	
	
	  /* Draw it: */
	
	  my_fillrect(screen, &dest,
		       SDL_MapRGB(screen->format, r, g, b));
	  addrect(dest);
	}
    }
}


/* Erase flying numbers: */

static void erase_flying_numbers(int scale)
{
  SDL_Rect dest;

  dest.x = (PSEUDO_WIDTH/2) + (-scale * 5);
  dest.y = (PSEUDO_HEIGHT/2) + (-scale * 10);
  dest.w = scale * 15;
  dest.h = scale * 22;

  erase(dest);
  addrect(dest);
}

#endif


/* High Score Screen: */

static int highscorescreen()
{
  int done, i, img, y, kh, kw;
  char temp[10];
  SDL_Event event;
  SDL_Rect src, dest;


  /* Draw game background: */

  my_blit(images[IMG_BACKGROUND], NULL, screen, NULL);
  my_updaterect(screen, 0);


  /* Clear all spray drips: */

  for (i = 0; i < MAX_SPRAYDRIPS; i++)
    {
      spraydrips[i].alive = 0;
    }


  /* Draw text onto it: */

  quick_spray = 0;

  done = spraytext("HIGH SCORE", 175, IMG_SPRAY_CYAN, 5);

  if (done == 0)
    done = spraytext(highscorer, 225, IMG_SPRAY_BLACK, 7);

  if (done == 0)
    {
      sprintf(temp, "%d", highscore);
      done = spraytext(temp, 300, IMG_SPRAY_BLUE, 7);
    }


  /* Which bomber will we draw? */

  if (highscore >= 10000)
    img = IMG_BOMBER_AMAZED;
  else if (highscore > 5000)
    img = IMG_BOMBER_SAD;
  else
    img = IMG_BOMBER_HAPPY;

  kh = images[img] -> h;
  kw = images[img] -> w;
  y = 0;


  if (done == 0)
    {
      do
	{
	  /* Handle events: */
	
	  while (SDL_PollEvent(&event))
	    {
	      switch (event.type)
                {
	        case SDL_KEYDOWN:
#if WANT_JOG_DIAL
                  if (event.key.keysym.sym == SDLK_RETURN)
#else
		  if (event.key.keysym.sym == SDLK_ESCAPE)
#endif
		    done = 1;
                  break;
		
#ifdef __palmos__
			case SDL_JOYBUTTONDOWN:
				done = 1;
			  break;
#endif

	        case SDL_QUIT:
		  done = 2;
                  break;

	        case SDL_MOUSEBUTTONDOWN:
		  done = 1;
		  break;

		default:
		  break;
               }
	    }


	  /* Handle spray drips: */

	  handle_spraydrips();


	  /* Draw bomber: */

#if LANDSCAPE_FORMAT
	  if (y++ < kh)
	    {
	      src.x = 0;
	      src.y = 0;
	      src.w = kw;
	      src.h = y;

	      dest.x = (PSEUDO_WIDTH - 140) / SCALE_RATIO;
	      if (y <= (kh - 4)) /* draw a raising bomber */
		dest.y = (59 + bomber_y - y) / SCALE_RATIO;
	      else               /* draw the hands over the wall */
		dest.y = (59 + bomber_y - (kh - 4)) / SCALE_RATIO;

#else
          if (y++ < kw)
            {
	      src.x = kw - y;
	      src.y = 0;
	      src.w = y;
	      src.h = kh;

	      dest.y = (PSEUDO_WIDTH-140) / SCALE_RATIO;
	      if (y <= (kw - 2)) /* draw a raising bomber */
	        dest.x = (PSEUDO_HEIGHT - (59 + bomber_y)) / SCALE_RATIO;
	      else               /* draw the hands over the wall */
		dest.x = ((PSEUDO_HEIGHT - (59 + bomber_y)) / SCALE_RATIO)
                         - (y - (kw - 2));
#endif
	      dest.w = src.w;
	      dest.h = src.h;

	      SDL_BlitSurface(images[IMG_BACKGROUND], &dest, screen, &dest);
	      SDL_BlitSurface(images[img], &src, screen, &dest);
	      SDL_UpdateRect(screen, dest.x, dest.y, dest.w, dest.h);
	    }
	

#if WANT_SOUND
	  /* Keep playing music: */
#if WANT_MUSIC	
	  if (use_sound == 1)
	    {
	      if (!Mix_PlayingMusic())
		{
		  Mix_PlayMusic(title_music, 0);
		  Mix_VolumeMusic(music_volume * 16);
		}
	    }
#endif //WANT_MUSIC
#endif
	
	
	  SDL_Delay(33);
	}
      while (done == 0);
    }


  /* Return whether or not we're done because the user requested a quit: */

  if (done == 0 || done == 1)
    return 0;
  else
    return 1;
}


/* Animate spraying of text onto the screen: */

static int spraytext(char * str, int y, int img, int scale)
{
  unsigned int ltr;
  int line, c, x, z;
  SDL_Event event;


  /* Play shaking-can noise: */

#if WANT_SOUND
  if (use_sound == 1)
    {
      if (quick_spray == 0)
	{
	  playsound(SND_CAN_SHAKE, 2);
	
	  do
	    {
	      SDL_Delay(100);
	    }
	  while (Mix_Playing(2));
	}
    }
#endif


  /* Place our virtual cursor (we want each line centered): */

  x = (PSEUDO_WIDTH - (strlen(str) * (scale * 6))) / 2;


  /* Draw each letter: */

  for (ltr = 0; ; ++ltr)
    {
      c = str[ltr];
      if (!c) break;


      /* Where in our graffiti array is this particular character? */

      if (c >= 'A' && c <= 'Z')
	c = c - 'A' + 10;
      else if (c >= '0' && c <= '9')
	c = c - '0';
      else
	c = -1;


      /* If it's a valid character, draw it! */

      if (c != -1)
	{
	  for (line = 0; line < 5 && graffiti[c][line][0][0] != -1; line++)
	    {
	      z = rand() % 6;
	
	      sprayline(graffiti[c][line][0][0] * scale + x,
			graffiti[c][line][0][1] * scale + y + z,
			graffiti[c][line][1][0] * scale + x,
			graffiti[c][line][1][1] * scale + y + z, img);
	    }
	}


      /* Move the virtual cursor over one character: */

      x = x + (scale * 6);

#ifndef EMBEDDED
      SDL_Delay(30);
#endif


      /* Handle events: */

      while (SDL_PollEvent(&event))
        {
          switch (event.type)
            {
            case SDL_KEYDOWN:
              if (event.key.keysym.sym == SDLK_ESCAPE)
                {
                  return 1;
                }
              else
                {
                  quick_spray = 1;
                  break;
                }

            case SDL_QUIT:
              return 2;

            case SDL_MOUSEBUTTONDOWN:
              quick_spray = 1;
              break;

            default:
              break;
           }
        }
    }

  SDL_Delay(100);

#if WANT_SOUND
#ifndef SDL_MIXER_BUG
  if (use_sound == 1)
    Mix_HaltChannel(2);
#endif
#endif

  return 0;
}


/* Draw a line with spray paint: */

static void sprayline(int x1, int y1, int x2, int y2, int img)
{
  int x, y, z, steep, e, dx, dy, i;


  /* Play spraying noise: */

#if WANT_SOUND
  if (use_sound == 1)
    {
      if (quick_spray == 0)
	{
	  if (!Mix_Playing(2))
	    playsound(SND_SPRAY, 2);
	}
    }
#endif


  /* Draw the line: */

  if (x1 == x2)
    {
      /* Vertical line: */

      if (y1 > y2)
	{
	  z = y1;
	  y1 = y2;
	  y2 = z;
	}

      for (y = y1; y <= y2; y++)
	spraydot(x1, y, img);
    }
  else if (y1 == y2)
    {
      /* Horizontal line: */

      if (x1 > x2)
	{
	  z = x1;
	  x1 = x2;
	  x2 = z;
	}

      for (x = x1; x <= x2; x++)
	spraydot(x, y1, img);
    }
  else
    {
      /* Angled line: */

      steep = 0;

      dx = abs(x2 - x1);
      x = ((x2 - x1) > 0) ? 1 : -1;

      dy = abs(y2 - y1);
      y = ((y2 - y1) > 0) ? 1 : -1;


      if (dy > dx)
	{
	  steep = 1;
	
	  z = x1;
	  x1 = y1;
	  y1 = z;
	
	  z = dy;
	  dy = dx;
	  dx = z;
	
	  z = y;
	  y = x;
	  x = z;
	}

      e = 2 * dy - dx;

      for (i = 0; i < dx; i++)
	{
	  if (steep == 1)
	    spraydot(y1, x1, img);
	  else
	    spraydot(x1, y1, img);
	
	  while (e >= 0)
	    {
	      y1 = y1 + y;
	      e = e - 2 * dx;
	    }
	
	  x1 = x1 + x;
	  e = e + 2 * dy;
	}

      spraydot(x2, y2, img);
    }

#ifdef EMBEDDED
  SDL_Flip(screen);
#endif
}


/* Spray one dot: */

static void spraydot(int x, int y, int img)
{
  SDL_Rect src, dest;


  /* Pick a semi-random spot with a random spray bit: */

#ifndef EMBEDDED
  dest.x = x + (rand() % 3);
  dest.y = y + (rand() % 4);
  dest.w = 4;
  dest.h = 4;

  src.x = rand() % pseudo_widths[img];
  src.y = rand() % (pseudo_heights[img] - 4);
  src.w = 4;
  src.h = 4;

  SDL_BlitSurface(images[img], &src, screen, &dest);
  SDL_UpdateRect(screen, dest.x, dest.y, dest.w, dest.h);
#else
#if !LANDSCAPE_FORMAT
  dest.x = ((PSEUDO_HEIGHT - y) / SCALE_RATIO) - (4 / SCALE_RATIO);
  dest.y = x / SCALE_RATIO;
#else
  dest.x = x / SCALE_RATIO;
  dest.y = y / SCALE_RATIO;
#endif
  dest.w = 4 / SCALE_RATIO;
  dest.h = 4 / SCALE_RATIO;

  src.x = rand() % 6;
  src.y = rand() % 6;
  src.w = 4 / SCALE_RATIO;
  src.h = 4 / SCALE_RATIO;

  SDL_BlitSurface(images[img], &src, screen, &dest);
  /* SDL_UpdateRect(screen, dest.x, dest.y, dest.w, dest.h); */
#endif


  /* Pause: */

  if (!quick_spray  && ((++spray_count % SPRAY_SPEED) == 0))
    SDL_Delay(10);


  /* Make a drip: */

  if ((rand() % 10) == 0)
    {
#ifndef EMBEDDED
      add_spraydrip(dest.x, dest.y, img);
#else
      add_spraydrip(x, y, img);
#endif
    }


  /* Handle spray drips: */

  handle_spraydrips();
}


static void handle_spraydrips()
{
  int i;
  SDL_Rect src, dest;


  for (i = 0; i < MAX_SPRAYDRIPS; i++)
    {
      if (spraydrips[i].alive)
	{
	  /* Move drip: */
	
	  spraydrips[i].y++;
	
	
	  /* Make drip run out of time: */
	
	  spraydrips[i].timer--;
	
	  if (spraydrips[i].timer <= 0)
	    spraydrips[i].alive = 0;
	
	
	  /* Draw spraydrip: */
	
#ifndef EMBEDDED
	  src.x = (rand() % ((pseudo_widths[spraydrips[i].img]) - 2));
	  src.y = (rand() % ((pseudo_heights[spraydrips[i].img]) - 2));
	  src.w = 2;
	  src.h = 2;
	
	  dest.x = spraydrips[i].x;
	  dest.y = spraydrips[i].y;
	  dest.w = 2;
	  dest.h = 2;
	
	  SDL_BlitSurface(images[spraydrips[i].img], &src, screen, &dest);
	  SDL_UpdateRect(screen, dest.x, dest.y, dest.w, dest.h);
#else
#if !LANDSCAPE_FORMAT
	  dest.x = (PSEUDO_HEIGHT - spraydrips[i].y) / SCALE_RATIO - 1;
	  dest.y = spraydrips[i].x / SCALE_RATIO;
#else
	  dest.x = spraydrips[i].x / SCALE_RATIO;
	  dest.y = spraydrips[i].y / SCALE_RATIO;
#endif
	  dest.w = 1;
	  dest.h = 1;

	  src.x = (rand() % 6);
	  src.y = (rand() % 6);
	  src.w = 1;
	  src.h = 1;


	  SDL_BlitSurface(images[spraydrips[i].img], &src, screen, &dest);
/*        SDL_UpdateRect(screen, dest.x, dest.y, dest.w, dest.h); */
#endif
	}
    }
}


/* Turn a spraydrip on: */

static void add_spraydrip(int x, int y, int img)
{
  int found;

  found = (rand() % MAX_SPRAYDRIPS);

  spraydrips[found].alive = 1;
  spraydrips[found].timer = (rand() % 10) + 5;
  spraydrips[found].img = img;
  spraydrips[found].x = x;
  spraydrips[found].y = y;
}


/* Have player sign their name for a high score: */

static int sign_highscore()
{
  SDL_Rect src, dest;
  int done, l, draw_text, i;
  SDL_Event event;
  SDLKey key;


  /* Draw high score signature screen: */

  dest.x = 0;
  dest.y = 0;
  dest.w = PSEUDO_WIDTH;
  dest.h = PSEUDO_HEIGHT;

  my_fillrect(screen, &dest,
	       SDL_MapRGB(screen->format, 0, 0, 0));


  dest.x = 0;
  dest.y = 0;
  dest.w = PSEUDO_WIDTH;
  dest.h = pseudo_heights[IMG_HIGHSCORE_HIGHSCORE];

  my_blit(images[IMG_HIGHSCORE_HIGHSCORE], NULL, screen, &dest);

  my_updaterect(screen, 0);

  strcpy(highscorer, "");
  l = 0;

  done = 0;
  draw_text = 1;

  do
    {
      /* Handle events: */

      while (SDL_PollEvent(&event))
	{
	  switch (event.type)
    {
      case SDL_KEYDOWN:
	      key = event.key.keysym.sym;
        switch (key)
        {
	        case SDLK_ESCAPE:
		        return 0;
	        case SDLK_DELETE:
          case SDLK_BACKSPACE:
      		  if (l > 0)
		        {
		          highscorer[--l] = '\0';
    		      draw_text = 1;
#if WANT_SOUND
		          playsound(SND_CONFIRM, 0);
#endif
		        }
            break;
		
          default:
	          if ((key >= SDLK_a && key <= SDLK_z) || (key >= SDLK_0 && key <= SDLK_9) || key == SDLK_SPACE)
    		    {
		          if (l < sizeof (highscorer))
		          {
		            if (key >= SDLK_a && key <= SDLK_z)
		              key = key - SDLK_a + 'A';
		
		            highscorer[l] = key;
		            l++;
		            highscorer[l] = '\0';
		
		            draw_text = 1;
#if WANT_SOUND
		            playsound(SND_SELECT, 0);
#endif
		          }
		        }
	          else if (key == SDLK_RETURN)
		        {
		          done = 1;
#if WANT_SOUND
		          playsound(SND_EXPLOSION, 0);
#endif
		        }
            break;
        }
              break;

	    case SDL_QUIT:
	      return 2;

            default:
              break;
            }
	}


      /* Draw text? */

  if (draw_text == 1)
	{
	  /* Erase first: */
	  dest.x = 0;
	  dest.y = 200;
	  dest.w = PSEUDO_WIDTH;
	  dest.h = pseudo_heights[IMG_HIGHSCORE_LETTERS];
	  my_fillrect(screen, &dest, SDL_MapRGB(screen->format, 0, 0, 0));
	
	  /* Now draw each letter: */
	
	  for (i = 0; (unsigned int)i < strlen(highscorer); i++)
    {
      if (highscorer[i] != ' ')
  		{
#if LANDSCAPE_FORMAT
	  	  if (highscorer[i] >= '0' && highscorer[i] <= '9')
		      src.x = ((highscorer[i] - '0') * pseudo_widths[IMG_HIGHSCORE_LETTERS]) / 36;
		    else if (highscorer[i] >= 'A' && highscorer[i] <= 'Z')
		      src.x = ((highscorer[i] - 'A' + 10) * pseudo_widths[IMG_HIGHSCORE_LETTERS]) / 36;

  		  src.y = 0;
	  	  src.w = pseudo_widths[IMG_HIGHSCORE_LETTERS] / 36;
		    src.h = pseudo_heights[IMG_HIGHSCORE_LETTERS];

		    dest.x = ((PSEUDO_WIDTH - (strlen(highscorer) *
				    ((pseudo_widths[IMG_HIGHSCORE_LETTERS]) / 36))) / 2) + (i * (pseudo_widths[IMG_HIGHSCORE_LETTERS]) / 36);
		    dest.y = 200;

#else
		  if (highscorer[i] >= '0' && highscorer[i] <= '9')
		    src.y = ((highscorer[i] - '0') *
			     pseudo_widths[IMG_HIGHSCORE_LETTERS]) / 36;
		  else if (highscorer[i] >= 'A' && highscorer[i] <= 'Z')
		    src.y = ((highscorer[i] - 'A' + 10) *
			     pseudo_widths[IMG_HIGHSCORE_LETTERS]) / 36;
		  src.x = 0;
		  src.h = pseudo_widths[IMG_HIGHSCORE_LETTERS] / 36;
		  src.w = pseudo_heights[IMG_HIGHSCORE_LETTERS];
		
		  dest.y = ((SCREEN_HEIGHT - (strlen(highscorer) *
				    ((pseudo_widths[IMG_HIGHSCORE_LETTERS]) /
				     36)))
			    / 2) + (i * (pseudo_widths[IMG_HIGHSCORE_LETTERS]) /
				    36);
		  dest.x = 200 / SCALE_RATIO;
#endif

		  dest.w = src.w;
		  dest.h = src.h;
		  my_blit(images[IMG_HIGHSCORE_LETTERS] , &src, screen, &dest);
		
		}
	    }
	
	
	  /* Update the screen: */
	
	  dest.x = 0;
	  dest.y = 200;
	  dest.w = PSEUDO_WIDTH;
	  dest.h = pseudo_heights[IMG_HIGHSCORE_LETTERS];
	
	  my_updaterect(screen, &dest);
	  draw_text = 0;
	}


#if WANT_FULL_MUSICS
      /* Keep playing music: */
#if WANT_MUSIC
      if (use_sound == 1)
	{
	  if (!Mix_PlayingMusic())
	    {
	      Mix_PlayMusic(highscore_music, 0);
	      Mix_VolumeMusic(music_volume * 16);
	    }
	}
#endif //WANT_MUSIC
#endif


      /* Pause: */

      SDL_Delay(50);
    }
  while (done == 0);

  if (done == 0 || done == 1)
    return 0;
  else
    return 1;
}


/* Set the application's icon: */

#if WANT_SETICON
static int seticon()
{
  int masklen;
  Uint8 * mask;
  SDL_Surface * icon;
#ifndef NO_PATH
  char const * file_path = DATA_PREFIX "images/icon.bmp";
#else
  char const * file_path = "icon.bmp";
#endif


  /* Load icon into a surface: */

  icon = IMG_Load(file_path);
  if (icon == NULL)
    {
      fprintf(stderr,
	      "\nError: I could not load the icon image: %s",
	      file_path);
      return 0;
    }


  /* Create mask: */

  masklen = (((icon -> w) + 7) / 8) * (icon -> h);
  mask = malloc(masklen * sizeof(Uint8));
  memset(mask, 0xFF, masklen);


  /* Set icon: */

  SDL_WM_SetIcon(icon, mask);


  /* Free icon surface & mask: */

  free(mask);
  SDL_FreeSurface(icon);
  return 1; /* OK! */
}
#endif


static void my_blit(SDL_Surface * src_img, SDL_Rect * src_rect,
		    SDL_Surface * dest_img, SDL_Rect * dest_rect)
{
#if !LANDSCAPE_FORMAT
  SDL_Rect src_rect2, dest_rect2;

  if (src_rect != NULL)
    {
      rotate_and_scale(src_rect, &src_rect2);
      src_rect = &src_rect2;
    }

  if (dest_rect != NULL)
    {
      rotate_and_scale(dest_rect, &dest_rect2);
      dest_rect = &dest_rect2;
    }
#elif (SCALE_RATIO != 1)
  SDL_Rect src_rect2, dest_rect2;

  if (src_rect != NULL)
    {
      scale(src_rect, &src_rect2);
      src_rect = &src_rect2;
    }

  if (dest_rect != NULL)
    {
      scale(dest_rect, &dest_rect2);
      dest_rect = &dest_rect2;
    }
#endif
  SDL_BlitSurface(src_img, src_rect, dest_img, dest_rect);
}


static void my_updaterect(SDL_Surface * surf, SDL_Rect * dest)
{
  if (!dest)
    {
      SDL_UpdateRect(surf, 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    }
  else
    {
#if !LANDSCAPE_FORMAT
      SDL_Rect dest2;
      rotate_and_scale(dest, &dest2);
      SDL_UpdateRect(surf, dest2.x, dest2.y, dest2.w, dest2.h);
#elif (SCALE_RATIO != 1)
      SDL_Rect dest2;
      scale(dest, &dest2);
      SDL_UpdateRect(surf, dest2.x, dest2.y, dest2.w, dest2.h);
#else
      SDL_UpdateRect(surf, dest->x, dest->y, dest->w, dest->h);
#endif
    }
}


static void my_fillrect(SDL_Surface * surf, SDL_Rect * dest, Uint32 color)
{
#if !LANDSCAPE_FORMAT
  SDL_Rect dest2;
  rotate_and_scale(dest, &dest2);
  dest = &dest2;
#elif (SCALE_RATIO != 1)
  SDL_Rect dest2;
  scale(dest, &dest2);
  dest = &dest2;
#endif
  SDL_FillRect(surf, dest, color);
}


#if !LANDSCAPE_FORMAT
/* rotate and scale, rounding up to the next SCALE_RATIO remainder. */
#if SCALE_RATIO == 1
static void rotate_and_scale(SDL_Rect const * src, SDL_Rect * tgt)
{
  tgt->x = (PSEUDO_HEIGHT - src->y - src->h);
  tgt->w = src->h / SCALE_RATIO;
  tgt->y = src->x / SCALE_RATIO;
  tgt->h = src->w / SCALE_RATIO;
}

#else
static void rotate_and_scale(SDL_Rect const * src, SDL_Rect * tgt)
{
  int i = (PSEUDO_HEIGHT - src->y - src->h);
  tgt->x = i / SCALE_RATIO;
  tgt->w = (src->h / SCALE_RATIO) + ((i & 1) | (src->h & 1));
  tgt->y = src->x / SCALE_RATIO;
  tgt->h = (src->w / SCALE_RATIO) + ((src->x & 1) | (src->w & 1));
}
#endif


#else /* LANDSCAPE FORMAT */
/* just divide and round up to the next SCALE_RATIO remainder. */
static void scale(SDL_Rect const * src, SDL_Rect * tgt)
{
  tgt->x = src->x / SCALE_RATIO;
  tgt->w = (src->w / SCALE_RATIO) + ((src->x & 1) | (src->w & 1));
  tgt->y = src->y / SCALE_RATIO;
  tgt->h = (src->h / SCALE_RATIO) + ((src->y & 1) | (src->h & 1));
}

#endif
/*===========================================================================*/
