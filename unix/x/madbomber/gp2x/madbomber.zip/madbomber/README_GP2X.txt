By Bill Kendrick
bill@newbreedsoftware.com
http://www.newbreedsoftware.com/madbomber/

Version 0.2.5

--------------------
Mad Bomber for GP2X
--------------------
Ported by Uprising using paeryn's SDL, SDL_Image and SDL_Mixer.  You may need to install these on your gp2x if you 
have not got firmware 2.0 i think(unless static works anyway).

for more infomation on the game please read the other README file or visit http://www.newbreedsoftware.com/madbomber/.

------------
Installation
------------

Move the madbomber folder anywhere onto your sd card directory, then select the madbomber.gpe from the games menu.

------------
Controls
------------
Volume:

Vol up / Vol down buttons


Menu:

Button B to select
Up and Down / Left and Right to change options.
L shoulder button to exit from menus or from pause ingame.


Ingame:

B to 'fire'.
Left and right to change direction.
Start to pause game.
L shoulder button to go back to main menu.
Select to capture screenshot.


High Score:

Left / Right to change letter.
Y to delete last letter.
B to select letter or if you get to the 12 characters accept name.
Start or A to accept name.
Select to capture screenshot, only when shown high score.

------------
Changes
------------

Remapped controls to joystick.
Changed highscore input so that you can select letters for name.
Set it up to exit properly back to gp2x menu.
Edited the save file to appear as dat in the same directory.After about 4 hours finally realised that i had to
call the sync() function for it to save properly.:)
Lowered the volume of the fuse sound.
Some other very very small changes.
