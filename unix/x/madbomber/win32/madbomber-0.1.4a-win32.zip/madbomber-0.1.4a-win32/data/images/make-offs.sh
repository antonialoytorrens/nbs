#!/bin/sh

echo "Creating '-off' bitmaps..."

for i in \
  title/one-player \
  title/two-players \
  title/two-player-vs \
  title/options \
  title/highscore \
  title/exit \
  options/normal \
  options/zen \
  options/hard \
  options/0percent \
  options/25percent \
  options/50percent \
  options/75percent \
  options/100percent \
  options/ok
do
  echo $i
  bmptoppm $i.bmp | ppmbrighten -value -50 | ppmquant 256 | ppmtobmp > \
    $i-off.bmp
done

echo "All done"
echo
