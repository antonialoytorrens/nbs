
 			Mad Bomber Wii port, by MiniK (minik.h4x@gmail.com) 

		Please see the original readme for information about the game. 

USAGE 
===== 
Copy madbomber to the apps folder on your SD card. (Hard coded path, do not rename!) 
Launch with the Homebrew Channel. 



CONTROLS 
======== 
Hold the Wiimote(s) sideways 

Home	Exit to loader 
+	Pause/Return to menu
2	Start Game



Thanks 
====== 
New Breed Software 
Team Twiizers 
DevkitPro Authors 
The Wii homebrew community as a whole. 

Last but not least, thank YOU for downloading! =D 

 
 
CHANGELOG 
========= 
Version 0.2.5 
	Initial Port