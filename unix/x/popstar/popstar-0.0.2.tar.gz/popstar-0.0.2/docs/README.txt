README.txt for popstar

"Pop Star"

by Bill Kendrick
bill@newbreedsoftware.com
http://www.newbreedsoftware.com/

June 27, 2006 - September 30, 2007

About
-----
"Pop Star" is a simple puzzle game where you must use floating stars to
form polygons.  The stars are continuously moving, which makes this tricky.
Various opportunities exist to gain bonus points.

FIXME: No scoring has been coded yet!

Playing
-------
  Controls
  --------
  Use the arrow keys ([Up], [Down], [Left] and [Right]) to move the flashing
  cursor from one star to the next.  The cursor will try to move to the next
  closest star in the direction you pressed.

  Press [Enter] or [Space] to 'select' the star that the cursor is following.

  Alternatively, you can use the mouse and click stars to select them.

  Forming Polygons
  ----------------
  As you select the stars, they are connected by lines.  When the lines
  form a polygon (that is, three or more stars connected), the stars
  disappear ('pop'), and you earn points.  The more stars involved in the
  formation, the more points you earn.  FIXME.

  Breaking Formations
  -------------------
  As the stars move around the screen, the shape of the polygon you're
  forming changes.  If two lines intersect (not counting the line between
  the last selected star, and the cursor, which flashes), they'll be
  destroyed, and the stars will break free.

  Capturing Stars
  ---------------
  Bonus points are scored for any stars that are 'caught' by the polygon.
  FIXME.

  Completing the Level
  --------------------
  If at least three stars remain on the screen, the cursor is automatically
  moved to the closest one.  If less than three remain, you advance to the next
  level.

  If all stars have been destroyed, either by being used to form polygons, or
  being captured by polygon formations, you receive bonus points at the end
  of the level, and "Level Complete" appears on the screen.  FIXME.

  If only one or two stars are left at the end of a level (not enough to
  form another polygon), you don't receive any bonus points, and
  "You Missed Some" appears on the screen.

Scoring
-------
FIXME: No scoring has been coded yet!

Credits
-------
See AUTHORS.txt.

