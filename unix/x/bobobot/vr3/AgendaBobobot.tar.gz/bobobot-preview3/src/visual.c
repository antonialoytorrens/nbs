/*
   visual.c

   Bill Kendrick & Mike Hufnagel
   Last modified: 11/18/95 (clean up)
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "visual.h"

int SetUpVisual(Display *display, int screen, Visual **visual, int *depth)
{
  int number_visuals;
  XVisualInfo *visual_array;
  XVisualInfo visual_info_template;
  int status;
  
  status = False;
  
  /* Will the default visual work? */
    {
      *visual = DefaultVisual(display,screen);
      *depth = DefaultDepth(display,screen);
      status = True;
    }
  
  return(status);
}
