Circus Linux!

DESCRIPTION
-----------
This is a PSP adoptation of "Circus Linux!"  game by Bill Kendrick (http://www.newbreedsoftware.com/circus-linux/)
"Circus Linux!" is based on the Atari 2600 game "Circus Atari" by Atari,
  released in 1980.  Gameplay is similar to "Breakout" and "Arkanoid"- you
  slide a device left and right to bounce objects into the air which destroy
  a wall.


STORY
---------
  The clowns are trying to pop balloons to score points!
  You control a  teeter-totter with a clown on it. (refer to the original documentation for details)

INSTALLATION
------------------
1.5 users:
Copy folders from 1.5 folder to ms:/PSP/GAME
1.0 users:
Use EBOOT.PBP from 1.0 folder& data files from 1.5/circuslinux/data folder
2.0 users:
Please test if either version works with the recent versions of eboot loader for 2.0 (try 1.5 first)

CONTROLS
----------------
[X]		START 1 PLAYER GAME; LAUNCH CLOWN; ENTER INITIALS
[O]		START 2 PLAYER GAME
[TRIANGLE]	START 2 PLAYER COOP GAME
[SQUARE]	TOGGLE BARRIERS
[LEFT]		TOGGLE BOUNCY BALLONS; TEETER-TOOTER LEFT; DELETE LETTER IN INITIALS ENTRY
[RIGHT]		TOGGLE CLEAR ALL; TEETER-TOOTER RIGHT; NEXT LETTER IN INITIALS ENTRY
[UP]		MUSIC CONTROL; CHOSE LETTER IN INITIALS ENTRY
[DOWN]		SFX CONTROL; CHOSE LETTER IN INITIALS ENTRY
[R.TRIGGER]	DISPLAY HISCORES
[SELECT]		BACK / EXIT
[START]		PAUSE

Enjoy,

DENIS