	
 
                        Defendguin Wii port, by MiniK (minik.h4x@gmail.com) 
 
                Please see the original readme for information about the game. 
 
USAGE 
===== 
Copy defendguin-11b to the apps folder on your SD card. (Hard coded path, do not rename!) 
Launch with the Homebrew Channel. 
 
 
 
CONTROLS 
======== 
Hold the Wiimote(s) sideways 
 
+        Pause 
-        Return to menu 
Home        Exit to loader 
1        Smart Bomb 
2        Laser 
 
 
 
Thanks 
====== 
New Breed Software 
Team Twiizers 
DevkitPro Authors 
The Wii homebrew community as a whole. 
 
Last but not least, thank YOU for downloading! =D 
 
 
 
CHANGELOG 
========= 
Version 0.11b 
        Initial Port