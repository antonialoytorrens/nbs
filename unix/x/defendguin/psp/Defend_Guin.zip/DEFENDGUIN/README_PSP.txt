This is PSP adoptation of "Defendguin" by by Bill Kendrick (bill@newbreedsoftware.com; http://www.newbreedsoftware.com/defendguin)

Defendguin is based loosely on William's classic arcade game, "Defender."
Some recognizable stars in the realm of modern operating systems should be fairly obvious.

FEATURES:
- 20 levels with final boss (guess who? ;-))
- original sound fx & soundtrack
- modable graphics

INSTALLATION
--------

1.5 users: copy contents of 1.5 folder to ms:/PSP/GAME
1.0 use EBOOT.PBP from 1.0 folder with data files from 1.5 folder
2.0 Please let me know if either version works with the latest eboot loader for 2.0 firmware

CONTROLS
----------------

[ANALOG PAD]		MENU NAVIGATION & SHIP'S IN GAME MOVEMENTS
[START]			PAUSE
[X]			SELECT/FIRE 
[O]			SMART BOMB

Enjoy,

DENIS