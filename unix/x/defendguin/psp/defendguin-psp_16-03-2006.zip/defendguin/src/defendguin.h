#define WIDTH 480
#define HEIGHT 272

#ifndef M_PI
#define M_PI  3.14159265358979323846  /* mmm... pi... */
#endif /* #ifndef M_PI */

#define DATA_PREFIX "./data/"


/* Image enumerations: */

enum {
  IMG_LOADING,
  IMG_LOADING_TEXT,
  IMG_PRESS_A_KEY,
  IMG_TITLE_TITLE,
  IMG_TITLE_ONE_PLAYER,
  IMG_TITLE_TWO_PLAYERS,
  IMG_TITLE_OPTIONS,
  IMG_TITLE_QUIT,
  IMG_TITLE_ARROW0,
  IMG_TITLE_ARROW1,
  IMG_TITLE_ARROW2,
  IMG_TITLE_STARFIELD,
  IMG_TUX_L0,
  IMG_TUX_L1,
  IMG_TUX_L2,
  IMG_TUX_L3,
  IMG_TUX_L4,
  IMG_TUX_L5,
  IMG_TUX_L6,
  IMG_TUX_L7,
  IMG_TUX_R0,
  IMG_TUX_R1,
  IMG_TUX_R2,
  IMG_TUX_R3,
  IMG_TUX_R4,
  IMG_TUX_R5,
  IMG_TUX_R6,
  IMG_TUX_R7,
  IMG_TUX_FALL0,
  IMG_TUX_FALL1,
  IMG_TUX_LFLAG,
  IMG_TUX_RFLAG,
  IMG_UFO0,
  IMG_UFO1,
  IMG_BEAM0,
  IMG_BEAM1,
  IMG_BEAM2,
  IMG_BEAM3,
  IMG_MUTANT0,
  IMG_MUTANT1,
  IMG_POD0,
  IMG_POD1,
  IMG_POD2,
  IMG_SWARMER,
  IMG_BOMBER,
  IMG_BOMBER_BULGE0,
  IMG_BOMBER_BULGE1,
  IMG_MINE,
  IMG_MINE_FLASH,
  IMG_MINE_POP,
  IMG_BAITER0,
  IMG_BAITER1,
  IMG_BAITER2,
  IMG_BAITER3,
  IMG_BAITER4,
  IMG_EVILBILL1,
  IMG_EVILBILL2,
  IMG_EVILBILL_SHOOT,
  IMG_EVILBILL_HURT1,
  IMG_EVILBILL_HURT2,
  IMG_EVILBILL_FLAME1,
  IMG_EVILBILL_FLAME2,
  IMG_EVILBILL_FLAME3,
  IMG_BULLET0,
  IMG_BULLET1,
  IMG_BULLET2,
  IMG_BULLET3,
  IMG_BULLET4,
  IMG_LAND_LEFT,
  IMG_LAND_CENTER,
  IMG_LAND_RIGHT,
  IMG_SHIP_LEFT,
  IMG_SHIP_RIGHT,
  IMG_SHIP_LEFT2,
  IMG_SHIP_RIGHT2,
  IMG_SHIP_LEFT_DYING,
  IMG_SHIP_RIGHT_DYING,
  IMG_SHIP_WIN_0,
  IMG_SHIP_WIN_1,
  IMG_SHIP_WIN_2,
  IMG_DISCO_1,
  IMG_DISCO_2,
  IMG_FLAME_LEFT_0,
  IMG_FLAME_LEFT_1,
  IMG_FLAME_RIGHT_0,
  IMG_FLAME_RIGHT_1,
  IMG_LASERS,
  IMG_STATUS_AREA,
  IMG_MAP_LAND,
  IMG_MAP_PENG,
  IMG_MAP_ALERT,
  IMG_MAP_UFO,
  IMG_MAP_MUTANT,
  IMG_MAP_BOMBER,
  IMG_MAP_MINE,
  IMG_MAP_POD,
  IMG_MAP_SWARMER,
  IMG_MAP_BAITER,
  IMG_MAP_EVILBILL,
  IMG_MAP_SHIP,
  IMG_SHIPS1,
  IMG_SHIPS2,
  IMG_PLAYER1,
  IMG_PLAYER2,
  IMG_SMART_BOMB,
  IMG_GET_READY,
  IMG_PENGUINOID_IN_TROUBLE,
  IMG_PENGUINOID_MUTATED,
  IMG_CATCH_THE_PENGUINOID,
  IMG_PENGUINOID_DROPPED,
  IMG_PENGUINOID_SAVED,
  IMG_PENGUINOID_SHOT,
  IMG_PLANET_DESTROYED,
  IMG_LEVEL_BONUS,
  IMG_NO_BONUS,
  IMG_GAME_OVER,
  IMG_NUMBERS,
  IMG_100,
  IMG_150,
  IMG_200,
  IMG_250,
  IMG_1000,
  IMG_CIRCLE,
  IMG_OPTION_TEXT,
  NUM_IMAGES
};


/* Image filenames: */

const char * image_names[NUM_IMAGES] = {
  DATA_PREFIX "images/loader/loading.bmp",
  DATA_PREFIX "images/loader/loading-text.bmp",
  DATA_PREFIX "images/loader/press-a-key.bmp",
  DATA_PREFIX "images/title/title.bmp",
  DATA_PREFIX "images/title/one-player.bmp",
  DATA_PREFIX "images/title/two-players.bmp",
  DATA_PREFIX "images/title/options.bmp",
  DATA_PREFIX "images/title/quit.bmp",
  DATA_PREFIX "images/title/arrow0.bmp",
  DATA_PREFIX "images/title/arrow1.bmp",
  DATA_PREFIX "images/title/arrow2.bmp",
  DATA_PREFIX "images/title/starfield.bmp",
  DATA_PREFIX "images/tux/l0.bmp",
  DATA_PREFIX "images/tux/l1.bmp",
  DATA_PREFIX "images/tux/l2.bmp",
  DATA_PREFIX "images/tux/l3.bmp",
  DATA_PREFIX "images/tux/l4.bmp",
  DATA_PREFIX "images/tux/l5.bmp",
  DATA_PREFIX "images/tux/l6.bmp",
  DATA_PREFIX "images/tux/l7.bmp",
  DATA_PREFIX "images/tux/r0.bmp",
  DATA_PREFIX "images/tux/r1.bmp",
  DATA_PREFIX "images/tux/r2.bmp",
  DATA_PREFIX "images/tux/r3.bmp",
  DATA_PREFIX "images/tux/r4.bmp",
  DATA_PREFIX "images/tux/r5.bmp",
  DATA_PREFIX "images/tux/r6.bmp",
  DATA_PREFIX "images/tux/r7.bmp",
  DATA_PREFIX "images/tux/fall0.bmp",
  DATA_PREFIX "images/tux/fall1.bmp",
  DATA_PREFIX "images/tux/lflag.bmp",
  DATA_PREFIX "images/tux/rflag.bmp",
  DATA_PREFIX "images/ufo/ufo0.bmp",
  DATA_PREFIX "images/ufo/ufo1.bmp",
  DATA_PREFIX "images/ufo/beam0.bmp",
  DATA_PREFIX "images/ufo/beam1.bmp",
  DATA_PREFIX "images/ufo/beam2.bmp",
  DATA_PREFIX "images/ufo/beam3.bmp",
  DATA_PREFIX "images/mutant/mutant0.bmp",
  DATA_PREFIX "images/mutant/mutant1.bmp",
  DATA_PREFIX "images/pod/pod0.bmp",
  DATA_PREFIX "images/pod/pod1.bmp",
  DATA_PREFIX "images/pod/pod2.bmp",
  DATA_PREFIX "images/swarmer/swarmer.bmp",
  DATA_PREFIX "images/bomber/bomber.bmp",
  DATA_PREFIX "images/bomber/bomber-bulge0.bmp",
  DATA_PREFIX "images/bomber/bomber-bulge1.bmp",
  DATA_PREFIX "images/bomber/mine.bmp",
  DATA_PREFIX "images/bomber/mine-flash.bmp",
  DATA_PREFIX "images/bomber/mine-pop.bmp",
  DATA_PREFIX "images/baiter/baiter0.bmp",
  DATA_PREFIX "images/baiter/baiter1.bmp",
  DATA_PREFIX "images/baiter/baiter2.bmp",
  DATA_PREFIX "images/baiter/baiter3.bmp",
  DATA_PREFIX "images/baiter/baiter4.bmp",
  DATA_PREFIX "images/evilbill/evilbill1.bmp",
  DATA_PREFIX "images/evilbill/evilbill2.bmp",
  DATA_PREFIX "images/evilbill/evilbill-shoot.bmp",
  DATA_PREFIX "images/evilbill/evilbill-hurt1.bmp",
  DATA_PREFIX "images/evilbill/evilbill-hurt2.bmp",
  DATA_PREFIX "images/evilbill/flame1.bmp",
  DATA_PREFIX "images/evilbill/flame2.bmp",
  DATA_PREFIX "images/evilbill/flame3.bmp",
  DATA_PREFIX "images/bullet/bullet0.bmp",
  DATA_PREFIX "images/bullet/bullet1.bmp",
  DATA_PREFIX "images/bullet/bullet2.bmp",
  DATA_PREFIX "images/bullet/bullet3.bmp",
  DATA_PREFIX "images/bullet/bullet4.bmp",
  DATA_PREFIX "images/land/left.bmp",
  DATA_PREFIX "images/land/center.bmp",
  DATA_PREFIX "images/land/right.bmp",
  DATA_PREFIX "images/ship/ship-left.bmp",
  DATA_PREFIX "images/ship/ship-right.bmp",
  DATA_PREFIX "images/ship/ship-left2.bmp",
  DATA_PREFIX "images/ship/ship-right2.bmp",
  DATA_PREFIX "images/ship/ship-left-dying.bmp",
  DATA_PREFIX "images/ship/ship-right-dying.bmp",
  DATA_PREFIX "images/ship/ship-win-0.bmp",
  DATA_PREFIX "images/ship/ship-win-1.bmp",
  DATA_PREFIX "images/ship/ship-win-2.bmp",
  DATA_PREFIX "images/ship/disco-1.bmp",
  DATA_PREFIX "images/ship/disco-2.bmp",
  DATA_PREFIX "images/ship/flame-left-0.bmp",
  DATA_PREFIX "images/ship/flame-left-1.bmp",
  DATA_PREFIX "images/ship/flame-right-0.bmp",
  DATA_PREFIX "images/ship/flame-right-1.bmp",
  DATA_PREFIX "images/ship/lasers.bmp",
  DATA_PREFIX "images/status/status-area.bmp",
  DATA_PREFIX "images/status/map-land.bmp",
  DATA_PREFIX "images/status/map-peng.bmp",
  DATA_PREFIX "images/status/map-alert.bmp",
  DATA_PREFIX "images/status/map-ufo.bmp",
  DATA_PREFIX "images/status/map-mutant.bmp",
  DATA_PREFIX "images/status/map-bomber.bmp",
  DATA_PREFIX "images/status/map-mine.bmp",
  DATA_PREFIX "images/status/map-pod.bmp",
  DATA_PREFIX "images/status/map-swarmer.bmp",
  DATA_PREFIX "images/status/map-baiter.bmp",
  DATA_PREFIX "images/status/map-evilbill.bmp",
  DATA_PREFIX "images/status/map-ship.bmp",
  DATA_PREFIX "images/status/ships1.bmp",
  DATA_PREFIX "images/status/ships2.bmp",
  DATA_PREFIX "images/status/player1.bmp",
  DATA_PREFIX "images/status/player2.bmp",
  DATA_PREFIX "images/status/smart-bomb.bmp",
  DATA_PREFIX "images/status/get-ready.bmp",
  DATA_PREFIX "images/status/penguinoid-in-trouble.bmp",
  DATA_PREFIX "images/status/penguinoid-mutated.bmp",
  DATA_PREFIX "images/status/catch-the-penguinoid.bmp",
  DATA_PREFIX "images/status/penguinoid-dropped.bmp",
  DATA_PREFIX "images/status/penguinoid-saved.bmp",
  DATA_PREFIX "images/status/penguinoid-shot.bmp",
  DATA_PREFIX "images/status/planet-destroyed.bmp",
  DATA_PREFIX "images/status/level-bonus.bmp",
  DATA_PREFIX "images/status/no-bonus.bmp",
  DATA_PREFIX "images/status/game-over.bmp",
  DATA_PREFIX "images/status/numbers.bmp",
  DATA_PREFIX "images/points/100.bmp",
  DATA_PREFIX "images/points/150.bmp",
  DATA_PREFIX "images/points/200.bmp",
  DATA_PREFIX "images/points/250.bmp",
  DATA_PREFIX "images/points/1000.bmp",
  DATA_PREFIX "images/status/circle.bmp",
  DATA_PREFIX "images/status/option-text.bmp"
};


/* Sound enumerations: */

enum {
  SND_SELECT,
  SND_CONFIRM,
  SND_IMPATIENCE,
  SND_THRUST,
  SND_LASER,
  SND_SMARTBOMB,
  SND_ONEUP,
  SND_DIE1,
  SND_DIE2,
  SND_MATERIALIZE,
  SND_PENG_CAPTURE,
  SND_PENG_SAVE,
  SND_PENG_DROP0,
  SND_PENG_DROP1,
  SND_PENG_DROP2,
  SND_PENG_KILL,
  SND_PENG_SPLAT,
  SND_PENG_MUTATE,
  SND_EXPLODE,
  SND_SWARMERS,
  SND_BAITER,
  SND_BULLET,
  SND_EVILBILL_INTRO,
  SND_EVILBILL_SUCCESS1,
  SND_EVILBILL_SUCCESS2,
  SND_EVILBILL_SUCCESS3,
  SND_EVILBILL_SHOOT,
  SND_EVILBILL_MINE,
  SND_EVILBILL_HURT,
  SND_EVILBILL_LOW,
  SND_EVILBILL_DIE,
  SND_PLANET_DEATH,
  SND_GAMEOVER0,
  SND_GAMEOVER1,
  SND_GAMEOVER2,
  NUM_SOUNDS
};


/* Sound filenames: */

const char * sound_names[NUM_SOUNDS] = {
  DATA_PREFIX "sounds/title/select.wav",
  DATA_PREFIX "sounds/title/confirm.wav",
  DATA_PREFIX "sounds/title/impatience.wav",
  DATA_PREFIX "sounds/ship/thrust.wav",
  DATA_PREFIX "sounds/ship/laser.wav",
  DATA_PREFIX "sounds/ship/smartbomb.wav",
  DATA_PREFIX "sounds/ship/oneup.wav",
  DATA_PREFIX "sounds/ship/die1.wav",
  DATA_PREFIX "sounds/ship/die2.wav",
  DATA_PREFIX "sounds/materialize.wav",
  DATA_PREFIX "sounds/peng/capture.wav",
  DATA_PREFIX "sounds/peng/save.wav",
  DATA_PREFIX "sounds/peng/drop0.wav",
  DATA_PREFIX "sounds/peng/drop1.wav",
  DATA_PREFIX "sounds/peng/drop2.wav",
  DATA_PREFIX "sounds/peng/kill.wav",
  DATA_PREFIX "sounds/peng/splat.wav",
  DATA_PREFIX "sounds/peng/mutate.wav",
  DATA_PREFIX "sounds/explode.wav",
  DATA_PREFIX "sounds/swarmers.wav",
  DATA_PREFIX "sounds/baiter.wav",
  DATA_PREFIX "sounds/bullet.wav",
  DATA_PREFIX "sounds/evilbill/intro.wav",
  DATA_PREFIX "sounds/evilbill/success1.wav",
  DATA_PREFIX "sounds/evilbill/success2.wav",
  DATA_PREFIX "sounds/evilbill/success3.wav",
  DATA_PREFIX "sounds/evilbill/shoot.wav",
  DATA_PREFIX "sounds/evilbill/mine.wav",
  DATA_PREFIX "sounds/evilbill/hurt.wav",
  DATA_PREFIX "sounds/evilbill/low.wav",
  DATA_PREFIX "sounds/evilbill/die.wav",
  DATA_PREFIX "sounds/planet_death.wav",
  DATA_PREFIX "sounds/gameover/darn.wav",
  DATA_PREFIX "sounds/gameover/finish.wav",
  DATA_PREFIX "sounds/gameover/lose.wav"
};


#define MUS_TITLE DATA_PREFIX "music/child.mod"
#define MUS_LAST DATA_PREFIX "music/confusio.mod"
#define MUS_WIN DATA_PREFIX "music/easytrip.mod"

#define NUM_GAME_MUSICS 5

const char * game_music_names[NUM_GAME_MUSICS] = {
  DATA_PREFIX "music/no!inhi1.mod",
  DATA_PREFIX "music/wormhole.mod",
  DATA_PREFIX "music/ants.mod",
  DATA_PREFIX "music/summerpa.mod",
  DATA_PREFIX "music/blowmind.mod"
};


#define NUM_QUOTES 9

const char * quotes[NUM_QUOTES] = {
  "ABOUT TO EXPLODE",
  "ARE YOU READY",
  "JUST PRESS THE RIGHT BUTTON",
  "NO   LET ME FINISH",
  "DARN  THATS THE END",
  "I DONT LIKE TO LOSE",
  "WRITTEN IN EMACS",
  "I DONT PUT ANY RESTRICTIONS",
  "ACHEM"
};


/* Ship directions: */

enum {
  DIR_LEFT,
  DIR_RIGHT
};


/* Penguinoid modes: */

enum {
  PENG_MODE_WALKING,
  PENG_MODE_BEAMING,
  PENG_MODE_CAPTURED,
  PENG_MODE_FALLING,
  PENG_MODE_SAVED
};


/* Alien types: */

enum {
  ALIEN_UFO,
  ALIEN_MUTANT,
  ALIEN_BOMBER,
  ALIEN_MINE,
  ALIEN_POD,
  ALIEN_SWARMER,
  ALIEN_BAITER,
  ALIEN_EVILBILL
};


/* Alien modes: */

enum {
  ALIEN_MODE_BEAM_IN,
  ALIEN_MODE_NORMAL,
  ALIEN_MODE_HOME_PENG,
  ALIEN_MODE_BEAMING_PENG,
  ALIEN_MODE_CAPTURED_PENG,
  ALIEN_MODE_HOME_SHIP,
  ALIEN_MODE_SHOOTING,
  ALIEN_MODE_HURTING,
  ALIEN_MODE_DYING
};


/* Title Options: */

enum {
  TITLE_OPTION_ONE_PLAYER,
  TITLE_OPTION_TWO_PLAYERS,
  TITLE_OPTION_QUIT,
  NUM_TITLE_OPTIONS
};


/* Title option images: */

const int title_option_images[NUM_TITLE_OPTIONS] = {
  IMG_TITLE_ONE_PLAYER,
  IMG_TITLE_TWO_PLAYERS,
//  IMG_TITLE_OPTIONS,
  IMG_TITLE_QUIT
};


/* Arbitrary constraints: */

#define MAX_ALIENS 32
#define MAX_PENGUINOIDS 16
#define MAX_BULLETS 64
#define MAX_LASERS 16
#define MAX_STARS 128
#define MAX_STARFIELDS 512
#define MAX_EXPLOSION_BITS 2048
#define MAX_POINTS 16
#define MAX_FLAMES 8

#define LASER_SPEED 128

#define LAND_WIDTH 70
#define LAND_HEIGHT 10
#define LAND_MIN_HEIGHT 5

#define CHANCE_UFO_HOME_PENG 1000
#define CHANCE_UFO_SHOOT_NORMAL 150
#define CHANCE_UFO_SHOOT_HOME 20
#define CHANCE_MUTANT_SHOOT 100
#define CHANCE_SWARMER_SHOOT 100
#define CHANCE_BAITER_SHOOT 50
#define CHANCE_EVILBILL_SHOOT 20
#define CHANCE_EVILBILL_MINE 100


/* Joystick defaults: */

/* Typedefs: */

typedef struct alien_type {
  int alive, type, mode, timer, shields;
  int x, y, xm, ym, xmm, ymm;
  int home_peng, beam_height;
} alien_type;

typedef struct bullet_type {
  int alive, timer, owner;
  int x, y, xm, ym;
} bullet_type;

typedef struct penguinoid_type {
  int alive, mode, being_homed;
  int x, y, xm, ym;
} penguinoid_type;

typedef struct laser_type {
  int alive;
  int x1, x2, y;
} laser_type;

typedef struct star_type {
  int x, y;
} star_type;

typedef struct starfield_type {
  int time;
  float radius;
  int angle;
} starfield_type;

typedef struct explosion_bit_type {
  int alive, time, img;
  int x, y, xm, ym;
} explosion_bit_type;

typedef struct points_type {
  int alive, time, img;
  int x, y;
} points_type;

typedef struct flame_type {
  int alive, time, x, y, xm;
} flame_type;

/* Globals: */

int x[2], y[2], xm[2], scroll[2], dir[2], lives[2], bombs[2], planet_dead[2],
  dying[2], dancing[2], safe[2], level[2];
Uint32 score[2];
int player;
int dontblockchan[4];
float my_cos[32];
int highscore, num_players, vol_effects, vol_music,
  joy_x, joy_y, joy_fire, joy_bomb;
int mesg_img, mesg_timer, flash, flash_colors, oneup_effect,
  oneup_effect_counter;
int use_fullscreen, use_sound, use_joystick, num_joysticks;
SDL_Surface * screen;
SDL_Surface * images[NUM_IMAGES];
int land[2][LAND_WIDTH][LAND_HEIGHT];
alien_type aliens[2][MAX_ALIENS];
penguinoid_type penguinoids[2][MAX_PENGUINOIDS];
bullet_type bullets[MAX_BULLETS];
laser_type lasers[MAX_LASERS];
star_type stars[MAX_STARS];
explosion_bit_type explosion_bits[MAX_EXPLOSION_BITS];
points_type points[MAX_POINTS];
flame_type flames[MAX_FLAMES];
starfield_type starfields[MAX_STARFIELDS];

#ifndef NOSOUND
Mix_Chunk * sounds[NUM_SOUNDS];
Mix_Music * title_music, * last_music, * win_music;
Mix_Music * game_musics[NUM_GAME_MUSICS];
#endif /* #ifndef NOSOUND */

SDL_Joystick *js;

char tmpStr[256];

/* Local function prototypes: */

int game(int mode);
int option_screen(void);
int title(void);
void setup(void);
SDL_Surface * set_vid_mode(unsigned flags);
void my_shutdown(void);
void create_land(int ply);
void create_penguinoids(int ply, int num);
void draw_number(int x, int y, int n);
void add_alien(int x, int y, int type, int mode, int timer);
void create_stars(void);
void add_laser(int x, int y, int dir);
void playsound(int snd, int chan, int blocking);
void add_explosion(int x, int y, int img);
void add_explosion_bit(int x, int y, int xm, int ym, int img);
void add_points(int xx, int yy, int img);
void add_flame(int x, int y);
void kill_alien(int i);
void add_bullet(int xx, int yy, int owner);
void set_message(int img);
void kill_player(void);
void add_score(int add);
void smartbomb(void);
void usage(int err);
void pause_screen(void);
void write_text(int x, int y, char * str);
void write_text_inv(int x, int y, char * str);
void write_centered_text(int y, char * str);
void write_num(int x, int y, int v);
int option_value(int opt_line);
void load_options(void);
void save_options(void);
