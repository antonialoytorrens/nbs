/*
   damagewin.h
   
   For Final Battle
   
   Mike Hufnagel & Bill Kendrick
   Previously modified: 12/5/95
   Last modified: 11/2/97

   Routines related to the damage window.
*/

#ifndef DAMAGEWIN_H
#define DAMAGEWIN_H

void drawdamagewin(int pln);
/* 
   Draws player "pln"'s damage window areas (names, etc.).
*/

void updatedamagewin(int pln);
/*
   Fills in player "pln"'s damage window's values.
*/

void updatedefense(int pln);
/*
   Fills in only player "pln"'s armor/shields/energy values.
*/

#endif /* DAMAGEWIN_H */
