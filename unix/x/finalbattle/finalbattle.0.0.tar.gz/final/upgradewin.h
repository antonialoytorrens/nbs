/*
  upgradewin.h
  
  for Final Battle
  
  Bill Kendrick
  Last modified: 11/3/97
  
  Routines related to the damage window.
*/

#ifndef UPGRADEWIN_H
#define UPGRADEWIN_H

void drawupgradewin(int pln);
/* 
   Draws player "pln"'s upgrade window areas (names, etc.).
*/

void updateupgradewin(int pln);
/*
   Fills in player "pln"'s upgrade window's values.
*/

#endif /* UPGRADEWIN_H */
