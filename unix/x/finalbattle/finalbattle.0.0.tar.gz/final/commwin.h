/*
  commwin.h
  
  for Final Battle
  
  By Mike Hufnagel and Bill Kendrick
  Last modified: 11/18/95 (clean up)
  
  Communications window routines.
*/

#ifndef COMMWIN_H
#define COMMWIN_H

void complain(int pln, char *text);
/*
   Send a complaint message to pln and beep.
*/

void drawcomm(int pln);
/* 
   Draws the comm window.
*/

void message(int pln, char *from, char *text);
/*
   Sends a message to pln.
*/

void message_all(char *from, char *text);
/*
   Sends a message to all players.
*/

void update_message_str(int pln);
/*
  Draws the user's message string (bottom of comm window)
*/

#endif /* COMMWIN_H */
