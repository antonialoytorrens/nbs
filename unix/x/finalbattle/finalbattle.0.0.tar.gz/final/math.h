/*
  math.h
  
  For Final Battle
  
  Bill Kendrick & Mike Hufnagel
  Previously modified: 11/18/95
  Last modified: 11/2/97

  Final Battle math functions.
*/

#ifndef MATH_H
#define MATH_H

int sign(int n);
/*
   Returns the sign of a number, 1 if positive, -1 if negative, 0 if 0.
*/

#endif /* MATH */
