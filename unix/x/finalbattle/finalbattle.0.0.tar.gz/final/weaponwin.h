/*
   weaponwin.h
   
   for FInal Battle
   
   Mike Hufnagel & Bill Kendrick
   Last modified: 11/28/95

   Routines related to the weapons window.
*/

#ifndef WEAPONWIN_H
#define WEAPONWIN_H

void drawweaponwin(int pln);
/* 
   Draws player "pln"'s weapon window icons and names.
*/

void updateweaponwin(int pln);
/*
   Fills in player "pln"'s weapon window's values and selected weapon.
*/

#endif /* WEAPONWIN_H */
