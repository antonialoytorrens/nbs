/*
   weapons.h
   
   for Final Battle
   
   Mike Hufnagel & Bill Kendrick
   Previously modified: 11/18/95 (created)
   Last modified: 11/3/97

   Game weapon related functions.
*/

#ifndef WEAPONS_H
#define WEAPONS_H

void adjustweapon(int which);
/*
   Changes the direction of a weapon.
*/

void fireweapon(int pln);
/*
   Fires player "pln"'s weapon.
*/

void dronefireweapon(int d, int pln);
/*
   Fires drone "d"'s weapon at player "pln".
*/

#endif /* WEAPONS_H */
