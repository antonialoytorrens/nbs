/*
  math.c
  
  for Final Battle
  
  Bill Kendrick & Mike Hufnagel
  Previously modified: 11/18/95 (created)
  Last modified: 11/3/97
*/


int sign(int v)
{
  if (v < 0)
    return(-1);
  else if (v > 0)
    return(1);
  else
    return(0);
}
