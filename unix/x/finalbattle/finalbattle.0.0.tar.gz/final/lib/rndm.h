/*
   rndm.h

   Bill Kendrick & Mike Hufnagel
   Last modified: 11/18/95 (clean up)

   Random number routines.
*/

#ifndef RNDM_H
#define RNDM_H

void initrndm(void);
/*
   Seeds the random number generator.
*/

int rndm(int max);
/*
   Return a random number between 0 and 'max-1'.
*/

#endif /* RNDM_H */
