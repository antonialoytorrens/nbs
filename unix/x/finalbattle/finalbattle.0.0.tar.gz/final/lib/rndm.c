/*
   rndm.c

   By Bill Kendrick & Mike Hufnagel
   Last modified: 11/18/95 (clean up)
*/

#include <sys/time.h>
#include <sys/types.h>
#include <stdlib.h>
#include "rndm.h"

void initrndm(void)
{
  struct timeval t;

  time(&t);
  srandom(t.tv_sec);
}

int rndm(int max)
{
  return(random() % max);
}
