"Final Battle"   A space battle simulation for X

By Mike Hufnagel and Bill Kendrick
Sonoma State University, Rohnert Park, California, USA

December 1995 - April 2, 1998

Version 0.0  First Release

Compiling:
----------
  Simply type "make".  If you have any problems, edit the "makefile"
  accordingly.  Definitions for your compiler (CC) and X library switches
  (XLIB) as well as your postprocessing command (typically "strip") are
  in the "makefile", making simple changes easy.

Game Description:
-----------------
  This is a multiplayer space battle game for the X Window System written in C
  for Unix.  Each player has a number of windows presenting different
  information and controls, including a short range viewscreen showing your
  ship in the center and other objects near it, a long range "map"
  (aka "radar") showing all players, a damage report and repair window,
  a weapon selection window, a ship's-computer and player-to-player
  communications window, and a ship upgrade status window.

  The game uses the X network protocol to display graphics and receive player
  input from mulitple servers.  Only one client is running and is in control
  of the entire game.  Temporary clients can also be ran which simply send
  a message to the main client telling it to add a server to the game.  If
  there is space in the game, and the main client can access your server,
  then a new player is "born" onto that server.  (Usage: "final -add ...")

Game Objective:
---------------
  Some time in the distanct future, a great Space Alliance was formed.  One
  of its tasks is bettering life for sentient-kind.  As part of this task,
  the Space Alliance has large asteroid mining facilities.  One of these
  facilities is in the gamma sector.

  The gamma sector of the galaxy is a relatively unprotected goldmine of
  resources: energy, raw materials, even (working!) components of ancient
  alien craft!  Groups of space hunters, such as yourself, have recently
  aquired a taste for these riches and have been moving in on the gamma
  sector.

  Nowadays, the gamma sector is full of space hunters, mining drones,
  and of course the asteroids that contain all of this mineable wealth.
  You, being one of the more ruthless space hunters, are not only
  interested in the materials available, but in complete and total
  control over the sector.

  Of course, the other space hunters don't happen to like this, but also
  happen to have the same plans themselves.  Fair's fair, right?  And as
  for the Space Alliance?  Well, they're obviously a BIT more than annoyed,
  but being a relatively peaceful group, they can't do much about it.

  "So, what do I do?" you ask?  Well, conquer, destroy, wreak havok, and all
  that good space shoot-em-up stuff!  Just remember, we the authors aren't
  responsible for what your friends do to you when you kick their butts at
  this game. :)

General Keyboard Controls:
--------------------------
  Movement:
    Up -         Thrust.  Change your momentum depending on the direction
                 your ship is facing.
    Down-        Unthrust.  Slow your ship down, or reverse thrust,
                 depending on how the game was compiled.
    Left/Right - Rotate.  Change the direction your ship is facing.

  Attack:
    Space      - Fire projectile weapon.  Fire a bullet from your ship.
    S          - Switch weapons.  (Or click in weapons window).

  Repair:
    R          - Assign crew to repair damaged ship components.
                 (Or left-click in the damage window to decide who goes where.)
    U          - Unassign all crew. (Or right-click one at a time.)

  Communication:
    M          - Begin typing a message.
    Return     - Send the message you have been typing.  Return to normal.
    Escape     - Abort message.  Don't send and return to normal.

  Game:
    Q          - Quit the game.

Upgrades:
---------
  Speed        - (A small ship icon with "thrust" coming out of it.)
                 Your maximum cruising speed is increased until you die.
  Armor        - (A small rotating shield with a cross on it.)
                 You gain (back) some armor.
  Shields      - (A small ship with a glowing circle around it.)
                 When you have shields, when you get hit, your armor is not
                 damaged, your ship's direction isn't affected, and your
                 ship's components aren't damaged.  Your shields will
                 of course wear away as you get hit.
                 (You'll have a glowing circle around your ship while you
                 have shields.)
  Cloak        - (A small empty radar screen icon.)
                 Use the [C] key to cloak/uncloak.  While cloaked, your
                 ship is not visible on anyone else's radar screen.
                 (On your radar screen, your location has an "X" instead
                 of a ball.)
  Total Cloak  - (An icon of a ship vanishing.)
                 Use the [X] key to totally-cloak/uncloak.  While totally-
                 cloaked, your ship is not visible on anyone else's radar
                 OR normal visual.
                 (On your radar, your location has an "X", and on your
                 visual, your flashing.)
  Cloak Radar  - (An icon of a radar screen with an "X" and the word
                 "Cloak" in it.)
                 With this, you can see cloaked ships on your radar.
                 (They appear as "X"'s.)
  Auto Pilot   - (An icon of a ship changing direction, and the word "Auto".)
                 Click in the radar and your ship will begin flying towards
                 that location.  A "+" will appear where you clicked.
                 Auto-Pilot will disengage if you try to move, click in the
                 radar, or get to your destination.
  Homing       - (An icon of a ship changing many directions, and the word
                 "Home".)
                 Click in the radar and your ship will begin flying towards
                 and following opponent closest to where you had clicked.
                 A square will appear on their ship in your radar.
                 Homing diesngages if you try to move, click in the radar,
                 or get close to your opponent.
  Warp         - (An icon of a ship disappearing on one side, and appearing
                 on the other, with an arrow in between.)
                 Warp allows you to INSTANTLY reposition yourself in the
                 game.  Simply click in the radar window where you'd like
                 to appear.
  Energy       - (A small rotating battery with a lightning bolt symbol on it.)
                 This replenishes some of your ship's energy.

Drones:
-------

  Drones are purple UFO-shaped ships which fly around randomly, occassionally
  homing in on particular players.  They will fire at players when they're
  nearby.  Like asteroids, they contain upgrades which you can collect.

  Drones appear as tiny dots on the radar.

Wormholes:
----------

  Wormholes pop up on occassion.  They suck things in (bullets, upgrades,
  asteroids, players and drones) at one end, and spit them out at another.
  They appear as concentric circles, either going inwards or outwards,
  depending on which end you're on.

  On the radar, they appear as a bubble (the "in" end) with a line
  going to the "out" end.

  Wormholes disappear after a while, or immediately when a player travels
  through them.  (Other objects don't cause the wormhole to collapse.)


Bugs:
-----

  There are probably some... I can't remember right off.  Please e-mail
  me any you find:  kendrick@zippy.sonoma.edu


Future Releases:
----------------

  More things need to be tweaked, so consider this a VERY beta version.
  Also, as you can see, the documentation needs major help!  Here are
  some planned features:

    * Score
    * New, better graphics
    * Color bitmap support
    * Sound
    * Support for more players at a time
    * more...    


Credits:
--------

  By Bill Kendrick and Mike Hufnagel, originally under the
  watchful eye of Prof. David Butcher.

  1995 - 1998.

  Released by New Breed Software (Bill Kendrick), 1998.


Make Contact:
-------------

  Send comments, donations, questions and suggestions to:

  E-mail:   kendrick@zippy.sonoma.edu

  Postal:   Bill Kendrick
            7673 Melody Drive
            Rohnert Park, CA 94928 USA

  Fax:      +1-707-795-5678

  Website:  http://zippy.sonoma.edu/kendrick/nbs/unix/x/finalbattle/
