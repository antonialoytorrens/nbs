/*
  radarwin.h
  
  for Final Battle
  
  Mike Hufnagel & Bill Kendrick
  Previously modified: 11/19/95 (clean up)
  Last modified: 11/2/97
  
  Routines related to the radar window.
*/

#ifndef RADAR_H
#define RADAR_H

void drawradar(int pln);
/* 
   Draws a blip in player "pln"'s radar window where the other players are
   in the universe.   You show up as a small circle.
   If you are cloaked, you are a small circle with an "x" through it.  If
   another player is cloaked, they don't show up, unless you have cloak-radar
   in which case they are a blip with "x"'s through them.
   If you are homing-in on a ship, it is covered with a small square.
*/

#endif /* RADAR_H */
