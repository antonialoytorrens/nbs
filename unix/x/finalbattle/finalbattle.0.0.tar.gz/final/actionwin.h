/*
  actionwin.h
  
  for Final Battle
  
  Mike Hufnagel & Bill Kendrick
  Previously modified: 11/18/95 (created)
  Last modified: 11/3/97
  
  Handles the action window routines.
*/

#ifndef ACTIONWIN_H
#define ACTIONWIN_H

void drawactionwin(int pln);
/*
   Draws the actionwin.
*/


void actionmessage(int pln, char * message);
/*
  Sends a message to the action window.
*/


void actionmessage_all(char * message);
/*
  Sends a message to the action window.
*/

#endif /* ACTIONWIN_H */
