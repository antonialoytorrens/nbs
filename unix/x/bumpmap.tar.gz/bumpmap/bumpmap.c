/* flamethrower.c
   bill kendrick
   bill@newbreedsoftware.com

   2003.Mar.08
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include "SDL.h"
#include "SDL_image.h"


#define WIDTH 320
#define HEIGHT 240

#define NUM_OBJECTS 10
#define NUM_KINDS 2

typedef struct obj_type {
  int x, y;
  int kind;
} obj_type;


SDL_Surface * screen;
obj_type objects[NUM_OBJECTS];
int environmentmap[256][256];


void myabort(char * str);
void add_object(int x, int y);
SDL_Surface * my_img_load(char * fname);
void show_obj(int ox, int oy, int lx, int ly,
	      SDL_Surface * img, SDL_Surface * bmp);
void getpixel(SDL_Surface * src, int x, int y,
	      Uint8 * r, Uint8 * g, Uint8 * b, Uint8 * a);
void putpixel(SDL_Surface * dst, int x, int y,
	      Uint8 r, Uint8 g, Uint8 b, Uint8 a);
void init_env_map();


int main(int argc, char * argv[])
{
  SDL_Surface * img_obj[NUM_KINDS], * img_bmp[NUM_KINDS];
  int done, btn_down, x, y, i;
  SDL_Event event;
  Uint32 last_time, now_time, black;

  
  if (SDL_Init(SDL_INIT_VIDEO) < 0)
    myabort("SDL_Init");
  
  screen = SDL_SetVideoMode(WIDTH, HEIGHT, 16, SDL_SWSURFACE);
  if (screen == NULL)
    myabort("SDL_SetVideoMode");

  black = SDL_MapRGB(screen->format, 0, 0, 0);

  img_obj[0] = my_img_load("cherry.png");
  img_bmp[0] = my_img_load("cherry_bump.png");

  img_obj[1] = my_img_load("pyramid.png");
  img_bmp[1] = my_img_load("pyramid_bump.png");

  srand(SDL_GetTicks());

  for (i = 0; i < NUM_OBJECTS; i++)
  {
    objects[i].kind = (rand() % NUM_KINDS);
    objects[i].x = (rand() % (WIDTH - 32));
    objects[i].y = (rand() % (HEIGHT - 32));
  }

  init_env_map();


  done = 0;
  btn_down = 0;

  x = WIDTH / 2;
  y = HEIGHT / 2;
  
  do
  {
    last_time = SDL_GetTicks();

    while (SDL_PollEvent(&event))
    {
      if (event.type == SDL_QUIT)
	done = 1;
      else if (event.type == SDL_KEYDOWN)
      {
	if (event.key.keysym.sym == SDLK_ESCAPE)
	  done = 1;
      }
      else if (event.type == SDL_MOUSEBUTTONUP)
        btn_down = 0;
      else if (event.type == SDL_MOUSEBUTTONDOWN)
      {
        btn_down = 1;
	x = event.button.x;
	y = event.button.y;
      }
      else if (event.type == SDL_MOUSEMOTION)
      {
	if (btn_down)
	{
	  x = event.button.x;
	  y = event.button.y;
	}
      }
    }

    
    SDL_FillRect(screen, NULL, black);

    for (i = 0; i < NUM_OBJECTS; i++)
    {
      show_obj(objects[i].x, objects[i].y, x, y,
	       img_obj[objects[i].kind], img_bmp[objects[i].kind]);

      objects[i].y++;
      if (objects[i].y >= HEIGHT - 32)
	objects[i].y = 0;
    }

    SDL_Flip(screen);
   
    now_time = SDL_GetTicks();
    if (now_time < last_time + 30)
    {
      SDL_Delay(now_time - last_time + 30);
    }
  }
  while (!done);

  return (0);
}


void myabort(char * str)
{
  fprintf(stderr, "Error: %s: %s\n", str, SDL_GetError());
  exit(1);
}


SDL_Surface * my_img_load(char * fname)
{
  SDL_Surface * tmp, * tmp2;

  tmp = IMG_Load(fname);
  if (tmp == NULL)
    return NULL;

  tmp2 = SDL_DisplayFormatAlpha(tmp);
  SDL_FreeSurface(tmp);

  return tmp2;
}


void show_obj(int ox, int oy, int lx, int ly,
	      SDL_Surface * img, SDL_Surface * bmp)
{
  int x, y;
  Uint8 r, g, b, a, G1, G2;
  int rr, gg, bb;
  int nX, nY, lX, lY;

  for (y = 1; y < img->h - 1; y++)
  {
    for (x = 1; x < img->w - 1; x++)
    {
      lX = (ox + x) - lx;
      lY = (oy + y) - ly;

      getpixel(img, x, y, &r, &g, &b, &a);

      getpixel(bmp, x + 1, y, &G1, &G1, &G1, &a);
      getpixel(bmp, x - 1, y, &G2, &G2, &G2, &a);
      nX = ((G1 - G2) - lX) * 2 + 128;

      getpixel(bmp, x, y + 1, &G1, &G1, &G1, &a);
      getpixel(bmp, x, y - 1, &G2, &G2, &G2, &a);
      nY = ((G1 - G2) - lY) * 2 + 128;

      if (nX < 0 || nX > 255)
        nX = 0;

      if (nY < 0 || nY > 255)
        nY = 0;

      rr = (r + environmentmap[nX][nY]) / 2;
      gg = (g + environmentmap[nX][nY]) / 2;
      bb = (b + environmentmap[nX][nY]) / 2;

      if (rr > 255)
        rr = 255;
      if (gg > 255)
        gg = 255;
      if (bb > 255)
        bb = 255;

      putpixel(screen, x + ox, y + oy, rr, gg, bb, a);
    }
  }
}

void getpixel(SDL_Surface * src, int x, int y,
	      Uint8 * r, Uint8 * g, Uint8 * b, Uint8 * a)
{
  int bpp;
  Uint8 * p;
  Uint32 pixel;

  bpp = src->format->BytesPerPixel;

  p = (Uint8 *) (((Uint8 *)src->pixels) +
		 (y * src->pitch) +
		 (x * bpp));

  if (bpp == 1)
    pixel = *(Uint8 *)p;
  else if (bpp == 2)
    pixel = *(Uint16 *)p;
  else if (bpp == 3)
  {
    if (SDL_BYTEORDER == SDL_BIG_ENDIAN)
      pixel = p[0] << 16 | p[1] << 8 | p[2];
    else
      pixel = p[0] | p[1] << 8 | p[2] << 16;
  }
  else if (bpp == 4)
    pixel = *(Uint32 *)p;
  else
    pixel = 0;

  SDL_GetRGBA(pixel, src->format, r, g, b, a);
}

void putpixel(SDL_Surface * dst, int x, int y,
	      Uint8 r, Uint8 g, Uint8 b, Uint8 a)
{
  int bpp;
  Uint8 * p;
  Uint32 pixel;

  bpp = dst->format->BytesPerPixel;

  pixel = SDL_MapRGBA(dst->format, r, g, b, a);
  
  p = (Uint8 *) (((Uint8 *)dst->pixels) +
	         (y * dst->pitch) +
	         (x * bpp));

  if (bpp == 1)
    *p = pixel;
  else if (bpp == 2)
    *(Uint16 *)p = pixel;
  else if (bpp == 3)
  {
    if (SDL_BYTEORDER == SDL_BIG_ENDIAN)
    {
      p[0] = (pixel >> 16) & 0xff;
      p[1] = (pixel >> 8) & 0xff;
      p[2] = pixel & 0xff;
    }
    else
    {
      p[0] = pixel & 0xff;
      p[1] = (pixel >> 8) & 0xff;
      p[2] = (pixel >> 16) & 0xff;
    }
  }
  else if (bpp == 4)
    *(Uint32 *)p = pixel;
}


void init_env_map()
{
  int x, y;
  float nX, nY, nZ;
  
  /* Taken from: http://gamedev.net/reference/articles/article327.asp */
  
  for (y=0;y<256;y++)
  {
    for (x=0;x<256;x++)
    {
      nX=(x-128)/128;
      nY=(y-128)/128;
      nZ=1.0-sqrt(nX*nX + nY*nY);
      
      if (nZ<0)
	nZ=0;
      
      environmentmap[x][y]=nZ*256;
    }
  }
}

