/**********************************************************************
 *    Copyright (C) 1998 Anders Johansson (andersjo@lysator.liu.se)
 * 
 * This  program is free software; you can redistribute it and/or modify it
 * under the  terms  of  the GNU General Public License as published by the
 * Free Software Foundation version 2 of the License.
 * 
 * This  program  is  distributed  in  the hope that it will be useful, but
 * WITHOUT   ANY   WARRANTY;   without   even  the   implied   warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details (see enclosed file COPYING).
 * 
 * You  should have received a copy of the GNU General Public License along
 * with this  program; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 ***********************************************************************/

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <linux/kd.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#define TERMINATESTR	"Program (and child) terminated.\n"
#define NUMLOCKLED      1
#define CAPSLOCKLED     2
#define SCROLLLOCKLED   3
#define KEYBOARDDEVICE	"/dev/console"

typedef enum { CLEAR = 0, SET = 1, TOGGLE = 2 } LedMode;
int tflag = 0;

void		led (int what, LedMode mode);
inline void	clear_led (int what) { led(what, CLEAR); }
inline void	set_led (int what) { led(what, SET); }
void		toggle_led (int what);
void		my_exit (int sig);

static int	keyboardDevice = 0;
int led_num;


int main(int argc, char** argv)
{
  int i,num;
  sigset_t sigset;

  assert(!sigemptyset(&sigset));
  assert(!sigaddset(&sigset, SIGINT));
  assert(!sigaddset(&sigset, SIGTERM));
  assert(!sigprocmask(SIG_BLOCK, &sigset, NULL));
  
  if (geteuid()) {
    fprintf(stderr, "led must be run as root!\n");
    exit(1);
  }
  
  if (argc!=3) {
    fprintf(stderr, "led: Wrong number of arguments\n");
    exit(1);
  }

  led_num=strtol(argv[1], (char **)NULL, 10);
  num=strtol(argv[2], (char **)NULL, 10);

  if (num <= 0)
    exit(0);  /* What's the point? */

  {
    struct sigaction act;
    memset(&act, 0, sizeof(struct sigaction));
    act.sa_handler = my_exit;
    act.sa_flags |= SA_RESTART;
    sigfillset(&act.sa_mask);
    assert(!sigaction(SIGINT, &act, NULL));
    assert(!sigaction(SIGTERM, &act, NULL));
    assert(!sigprocmask(SIG_UNBLOCK, &sigset, NULL));
  }

  if (! geteuid()) {	/* We are running as EUID root - CONSOLE */
    if (-1 == (keyboardDevice = open(KEYBOARDDEVICE, O_RDONLY))) {
      perror(KEYBOARDDEVICE);
      fprintf(stderr, TERMINATESTR);
      exit(1);
    }
  }

  while(1) {
    i = getppid();    /*  Check if parent is dead, then go kill your self */
    if (i == 1 || kill(i, 0)==(-1)) {
      exit(0);
    }
    
    
    for (i = 0; i < num / 10; i++)
      {
	toggle_led(led_num);
	usleep(500000);
	toggle_led(led_num);
	usleep(150000);
      }
    
    for (i = 0; i < num % 10; i++) {
      toggle_led(led_num);
      usleep(100000);
      toggle_led(led_num);
      usleep(150000);
    }
    usleep(1000000);
  }
}

void my_exit(int sig)
{
  /* clear_led(led_num); */
  if( tflag ) toggle_led(led_num);

  if (keyboardDevice) {	/* EUID root - CONSOLE */
    close(keyboardDevice);
  }
  exit(0);
}

void	led (int led, LedMode mode)
{
  char	ledVal;

  if (ioctl(keyboardDevice, KDGETLED, &ledVal)) {
    perror("KDGETLED");
    exit(1);
  }

  switch (led) {
  case SCROLLLOCKLED:
    if (mode == SET)
      ledVal |= LED_SCR;
    else if ( mode == CLEAR )
      ledVal &= ~LED_SCR;
    else
      ledVal ^= LED_SCR;
    break;
  case NUMLOCKLED:
    if (mode == SET)
      ledVal |= LED_NUM;
    else if ( mode == CLEAR )
      ledVal &= ~LED_NUM;
    else
      ledVal ^= LED_NUM;
    break;
  case CAPSLOCKLED:
    if (mode == SET)
      ledVal |= LED_CAP;
    else if ( mode == CLEAR )
      ledVal &= ~LED_CAP;
    else
      ledVal ^= LED_CAP;
    break;
  default:
    perror("Invalid led-value");
    exit(1);
  }

  if (ioctl(keyboardDevice, KDSETLED, ledVal)) {
    perror ("KDSETLED");
    exit(1);
  }
}

void toggle_led(int what)
{
  sigset_t sigset;

  /* block signals while we adjust the led */
  sigemptyset(&sigset);
  sigaddset(&sigset, SIGINT);
  sigaddset(&sigset, SIGTERM);
  sigprocmask(SIG_BLOCK, &sigset, NULL);

  led(what, TOGGLE);
  tflag ^= 1;

  /* deliver any pending signals */
  sigprocmask(SIG_UNBLOCK, &sigset, NULL);
}
