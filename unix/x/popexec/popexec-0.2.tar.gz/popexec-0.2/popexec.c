/*
  popexec.c 0.0
  
  Pop-Exec
  Executes a command whenever new mail arrives for some POP mail account
  
  by Bill Kendrick
  bill@newbreedsoftware.com
  http://www.newbreedsoftware.com/
  
  July 11, 1999 - July 13, 1999
*/


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pwd.h>
#include <ctype.h>
#include "Pop3Client.h"


#define POPEXECVERSION "0.0 - 1999.July.13"
/* #define DEBUG */


/* Usage message: */

void usage(char * progname, FILE * stream, int xit)
{
  fprintf(stream, "Usage: %s\n", progname);
  fprintf(stream, "Options: -s | --server   pop-server       (localhost)\n");
  fprintf(stream, "         -p | --port     pop-port         (110)\n");
  fprintf(stream, "         -u | --user     username         ($USER|$LOGNAME)\n");
  fprintf(stream, "         -w | --wait     wait-in-secs     (60)\n");
  fprintf(stream, "         -x | --exec     cmd-to-exec      (echo New Mail)\n");
  fprintf(stream, "         -y | --execnone cmd-to-exec      ()\n");
  fprintf(stream, "         -f | --fork     fork-cmd\n");
  fprintf(stream, "         -h | --help\n");
  fprintf(stream, "         -v | --version\n");
  fprintf(stream, "Variables: %%s            pop-server\n");
  fprintf(stream, "           %%p            port\n");
  fprintf(stream, "           %%u            username\n");
  fprintf(stream, "           %%m            num-new-mesgs\n");
  fprintf(stream, "           %%%%            %%\n");
  
  exit(xit);
}


/* Version message: */

void version(void)
{
  printf("popexec version " POPEXECVERSION " Copyright (c) 1999\n\n");

  printf("by Bill Kendrick <bill@newbreedsoftware.com>\n");
  printf("POP3 code by Scott Holden <scotth@thezone.net>\n\n");

  printf("popexec comes with ABSOLUTELY NO WARRANTY.\n");
  printf("This is free software, and you are welcome to redistribute it\n");
  printf("under certain conditions; a copy of the GNU Public License has\n");
  printf("been included with this program.  Or get a copy at www.fsf.org\n\n");
  
#ifdef DEBUG
  printf("( Debugging code compiled in! )\n\n");
#endif
  
  
  exit(0);
}


/* --- MAIN --- */

int main(int argc, char * argv[])
{
  int num_mesgs, old_num_mesgs, wait, port, i, found, do_fork, pid, args, len,
    escape;
  Pop3 pc;
  char * server, * username, * password, * cmd, * cmd_none, * cmdx;
  char * shargs[512];
  char temp[1024], keyword[1024], value[1024], prog[1024], temp2[1024];
  FILE * fi;
  
  
  /* Some easy-to-determine option defaults: */
  
  server = "localhost";
  cmd = "echo New Mail";
  cmd_none = NULL;
  username = NULL;
  password = NULL;
  port = 110;
  wait = 60;
  do_fork = 0;
  
  
  /* Parse argument list for options: */
  
  for (i = 1; i < argc; i++)
    {
#ifdef DEBUG
      printf("Option: %s\n", argv[i]);
#endif

      if (i + 1 < argc)
	{
#ifdef DEBUG
	  printf("Value: %s\n", argv[i + 1]);
#endif

	  if (strcmp(argv[i], "--server") == 0 ||
	      strcmp(argv[i], "-s") == 0)
	    server = argv[++i];
	  else if (strcmp(argv[i], "--user") == 0 ||
		   strcmp(argv[i], "-u") == 0)
	    username = argv[++i];
	  else if (strcmp(argv[i], "--wait") == 0 ||
		   strcmp(argv[i], "-w") == 0)
	    {
	      wait = atoi(argv[++i]);
	      if (wait == 0)
		{
		  fprintf(stderr, "Illegal wait value: %s\n", argv[i]);
		  usage(argv[0], stderr, 1);
		}
	    }
	  else if (strcmp(argv[i], "--exec") == 0 ||
		   strcmp(argv[i], "-x") == 0)
	    cmd = argv[++i];
	  else if (strcmp(argv[i], "--execnone") == 0 ||
		   strcmp(argv[i], "-y") == 0)
	    cmd_none = argv[++i];
	  else if (strcmp(argv[i], "--fork") == 0 ||
		   strcmp(argv[i], "-f") == 0)
	    do_fork = 1;
	  else if (strcmp(argv[i], "--help") == 0 ||
		   strcmp(argv[i], "-h") == 0)
	    usage(argv[0], stdout, 0);
	  else if (strcmp(argv[i], "--version") == 0 ||
		   strcmp(argv[i], "-v") == 0)
	    version();
	  else
	    {
	      fprintf(stderr, "Unknown option: %s\n", argv[i]);
	      usage(argv[0], stderr, 1);
	    }
	}
      else if (strcmp(argv[i], "--fork") == 0 ||
	       strcmp(argv[i], "-f") == 0)
	do_fork = 1;
      else if (strcmp(argv[i], "--help") == 0 ||
	       strcmp(argv[i], "-h") == 0)
	usage(argv[0], stdout, 0);
      else if (strcmp(argv[i], "--version") == 0 ||
	       strcmp(argv[i], "-v") == 0)
	version();
      else
	{
	  fprintf(stderr, "Unknown option: %s\n", argv[i]);
	  usage(argv[0], stderr, 1);
	}
    }
  
  
  /* See if we can determine password from a .netrc file: */
  
  if (password == NULL)
    {
      if (getenv("HOME") != NULL)
	{
	  sprintf(temp, "%s/.netrc", getenv("HOME"));
	  
#ifdef DEBUG
	  printf("Opening .netrc file: %s\n", temp);
#endif
	  
	  fi = fopen(temp, "r");
	  if (fi != NULL)
	    {
	      found = 0;
	      
	      do
		{
		  /* Read .netrc keyword and value pair: */
		  
		  if (!feof(fi))
		    {
		      fscanf(fi, "%s %s", keyword, value);
		      
#ifdef DEBUG
		      printf("Read .netrc pair: %s:%s\n", keyword, value);
#endif
		      
		      if (strcmp(keyword, "machine") == 0)
			{
			  /* Same server as we want?  Set our flag! */
			  
			  if (strcmp(value, server) == 0)
			    found = 1;
			  else
			    found = 0;
			}
		      else if (strcmp(keyword, "login") == 0)
			{
			  if (found == 1)
			    {
			      if (username == NULL)
				{
				  /* Username not set? Set it! */
				  
				  username = strdup(value);
				}
			      else
				{
				  /* Username was already set.  Is this
				     different? */
				  
				  if (strcmp(username, value) != 0)
				    found = 0;
				}
			    }
			}
		      else if (strcmp(keyword, "password") == 0)
			{
			  if (found == 1)
			    password = strdup(value);
			}
		      else
			{
			  fprintf(stderr, "Unknown .netrc keyword: %s\n",
				  keyword);
			}
		    }
		}
	      while (!feof(fi) && password == NULL);
	      
	      fclose(fi);
	    }
	}
    }
  
  
  /* Grab username, if necessary: */
  
  if (username == NULL)
    {
      if (getenv("USER") != NULL)
	username = getenv("USER");
      else if (getenv("LOGNAME") != NULL)
	username = getenv("LOGNAME");
      else
	{
	  printf("Username: ");
	  fgets(temp, 128, stdin);
	  temp[strlen(temp) - 1] = '\0';
	  username = strdup(temp);
	}
#ifdef DEBUG
      printf("Username determined to be: %s\n", username);
#endif
    }
  
  

  if (password == NULL)
    {
      sprintf(temp, "Password for POP account %s@%s: ",
	      username, server);
      password = getpass(temp);
    }
  
  
  /* Create pop3 structure: */
  
  do
    {
      pc = pop3Create();
      if (pc == NULL)
	{
	  fprintf(stderr, "Cannot create Pop3 structure.\n");
	  sleep(1);
	}
    }
  while (pc == NULL);
  
  
  /* Check for messages: */
  
  old_num_mesgs = -2;
  pid = -1;
  
  do
    {
#ifdef DEBUG
      printf("Connecting to %s:%d...\n", server, port);
#endif

      if (pop3MakeConnection(pc, server, port) != -1)
	{
#ifdef DEBUG
	  printf("Logging in as: %s\n", username);
#endif

	  if (pop3Login(pc, username, password) != -1)
	    {  
	      if (pop3CheckMail(pc) != -1)
		{
		  /* New messages!? */
		  
		  num_mesgs = pop3GetNumberOfUnreadMessages(pc);
#ifdef DEBUG
		  printf("Number of Unread Messages: %d\n", num_mesgs);
#endif
		  
		  if (num_mesgs != old_num_mesgs)
		    {
		      if (do_fork == 1)
			{
			  /* Kill the running command: */
			  
			  if (pid != -1)
			    {
#ifdef DEBUG
			      printf("Killing old process (pid %d)\n", pid);
#endif
			      
			      if (kill(pid, SIGINT) == -1)
				perror("kill()");
			    }
			}
		      
		      
		      /* Which command to run? */
		      
		      if (num_mesgs > 0)
			cmdx = cmd;
		      else
			cmdx = cmd_none;
		      
		      
		      /* Execute the command! */
		      
		      if (cmdx != NULL)
			{
			  strcpy(prog, cmdx);
			  if (strchr(prog, ' ') != NULL)
			    strcpy(strchr(prog, ' '), "\0");
			  
			  args = 0;
			  len = 0;
			  escape = 0;
			  
			  for (i = 0; i <= strlen(cmdx); i++)
			    {
			      if (isspace(cmdx[i]) || i == strlen(cmdx))
				{
				  /* End this argument... */
				  
				  temp[len] = '\0';
				  len = 0;
				  shargs[args] = strdup(temp);
				  args++;
				}
			      else
				{
				  /* Append this character: */
				  
				  if (cmdx[i] == '%' && escape == 0)
				    {
				      /* "%" escapes! */
				      
				      escape = 1;
				    }
				  else
				    {
				      if (escape == 1)
					{
					  /* Handle escapables! */
					  
					  escape = 0;
					  temp[len] = '\0';
					  
					  if (cmdx[i] == 's')
					    strcat(temp, server);
					  else if (cmdx[i] == 'p')
					    {
					      sprintf(temp2, "%d", port);
					      strcat(temp, temp2);
					    }
					  else if (cmdx[i] == 'u')
					    strcat(temp, username);
					  else if (cmdx[i] == 'm')
					    {
					      sprintf(temp2, "%d", num_mesgs);
					      strcat(temp, temp2);
					    }
					  else
					    {
					      sprintf(temp2, "%%%c",
						      cmdx[i]);
					      strcat(temp, temp2);
					    }
					  
					  len = strlen(temp);
					}
				      else
					{
					  /* Not escaped, just append: */
					  
					  temp[len] = cmdx[i];
					  len++;
					}
				    }
				}
			    }
			  
			  shargs[args] = NULL;
			  
#ifdef DEBUG
			  printf("COMMAND: %s...\n", prog);
			  
			  for (i = 0; shargs[i] != NULL; i++)
			    printf("ARG%d: %s\n", i, shargs[i]);
#endif
			  
			  
			  /* Reconstruct string: */
			  
			  strcpy(temp, prog);
			  for (i = 1; i < args; i++)
			    {
			      strcat(temp, " ");
			      strcat(temp, shargs[i]);
			    }
			  
			  
#ifdef DEBUG
			  printf("Executing: %s\n", temp);
#endif
			  
			  if (do_fork == 0)
			    {
			      fflush(stdout);
			      system(temp);
			      fflush(stdout);
			    }
			  else
			    {
			      pid = fork();
			      
			      if (pid == -1)
				perror("fork()");
			      else
				{
				  if (pid == 0)
				    {
				      /* I'm the child - run the command! */

#ifdef DEBUG
				      printf("I'm the child!");
#endif
				  
				      if (execvp(prog, shargs) == -1)
					{
					  fprintf(stderr,
						  "execvp failed...\n");
					  perror(cmdx);
					  exit(1);
					}
				    }
				  else
				    {
				      /* I'm the parent: */
				      
#ifdef DEBUG
				      printf("Child's PID is %d\n", pid);
#endif
				    }
				}
			    }
			}
		    }
		  
		  old_num_mesgs = num_mesgs;
		  
		  pop3Quit(pc);
		}
	    }
	}
      
      sleep(wait);
    }
  while (1);
}
