/*
  vidslide.c
  
  VidSlide - A sliding animation puzzle.
  
  by Bill Kendrick
  bill@newbreedsoftware.com
  http://www.newbreedsoftware.com/vidslide/
  
  December 2, 1999 - June 4, 2000
  
  Based on: plaympeg - Sample MPEG player using the SMPEG library
  Copyright (C) 1999 Loki Entertainment Software
  
  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <SDL/SDL.h>
#include <smpeg/smpeg.h>
#ifndef NOSOUND
#include <SDL/SDL_mixer.h>
#endif

/* About string: */

char * about[] = {
  "",
  "VIDSLIDE",
  "",
  "BY BILL KENDRICK",
  "NEW BREED SOFTWARE : 2000",
  "",
  "CONCEPT BASED ON:",
  "VIDGRID FOR THE ATARI JAGUAR",
  "C 1995 GEFFEN RECORDS INC",
  "AND JASMINE MULTIMEDIA PUBLISHING",
  "",
  "CODE BASED ON:",
  "PLAYMPEG USING SMPEG",
  "C 2000 LOKI ENTERTAINMENT SOFTWARE",
  "",
  "CLICK ANYWHERE TO CONTINUE",
  NULL
};


/* Game constraint definitions: */

#define MAX_DIVISIONS 8
#define WIDTH 480
#define HEIGHT 480
#define FPS 60

#define PAUSE (1000 / FPS)


/* Game modes: */

enum {
  GAME_DRAG,
  GAME_SLIDE,
  GAME_PERFECTION
};


/* Main menus: */

enum {
  MENU_FILE,
  MENU_SIZE,
  MENU_GAME,
  MENU_FLIP,
  MENU_VOLUME,
  NUM_MENUS
};

char * menu_names[NUM_MENUS] = {
  "FILE", "SIZE", "GAME", "FLIP", "VOLUME"
};


/* Menu items: */

#define MAX_MENUITEMS 6

char * menu_items[NUM_MENUS][MAX_MENUITEMS] = {
  { "LOAD MPEG", "LOAD MOD", "PAUSE", "ABOUT", "QUIT", NULL },
  { "3 X 3", "4 X 4", "5 X 5", "6 X 6", "7 X 7", "8 X 8" },
  { "DRAG", "SLIDE", "PERFECTION", NULL, NULL, NULL },
  { "NORMAL", "FLIPPED", NULL, NULL, NULL, NULL },
  { "100", "75", "50", "25", "0", NULL }
};


/* Images: */

enum {
  IMG_0,
  IMG_1,
  IMG_2,
  IMG_3,
  IMG_4,
  IMG_5,
  IMG_6,
  IMG_7,
  IMG_8,
  IMG_9,
  IMG_COLON,
  IMG_A,
  IMG_B,
  IMG_C,
  IMG_D,
  IMG_E,
  IMG_F,
  IMG_G,
  IMG_H,
  IMG_I,
  IMG_J,
  IMG_K,
  IMG_L,
  IMG_M,
  IMG_N,
  IMG_O,
  IMG_P,
  IMG_Q,
  IMG_R,
  IMG_S,
  IMG_T,
  IMG_U,
  IMG_V,
  IMG_W,
  IMG_X,
  IMG_Y,
  IMG_Z,
  IMG_BACK,
  NUM_IMAGES
};

const char * image_names[NUM_IMAGES] = {
  DATA_PREFIX "/images/0.bmp",
  DATA_PREFIX "/images/1.bmp",
  DATA_PREFIX "/images/2.bmp",
  DATA_PREFIX "/images/3.bmp",
  DATA_PREFIX "/images/4.bmp",
  DATA_PREFIX "/images/5.bmp",
  DATA_PREFIX "/images/6.bmp",
  DATA_PREFIX "/images/7.bmp",
  DATA_PREFIX "/images/8.bmp",
  DATA_PREFIX "/images/9.bmp",
  DATA_PREFIX "/images/colon.bmp",
  DATA_PREFIX "/images/a.bmp",
  DATA_PREFIX "/images/b.bmp",
  DATA_PREFIX "/images/c.bmp",
  DATA_PREFIX "/images/d.bmp",
  DATA_PREFIX "/images/e.bmp",
  DATA_PREFIX "/images/f.bmp",
  DATA_PREFIX "/images/g.bmp",
  DATA_PREFIX "/images/h.bmp",
  DATA_PREFIX "/images/i.bmp",
  DATA_PREFIX "/images/j.bmp",
  DATA_PREFIX "/images/k.bmp",
  DATA_PREFIX "/images/l.bmp",
  DATA_PREFIX "/images/m.bmp",
  DATA_PREFIX "/images/n.bmp",
  DATA_PREFIX "/images/o.bmp",
  DATA_PREFIX "/images/p.bmp",
  DATA_PREFIX "/images/q.bmp",
  DATA_PREFIX "/images/r.bmp",
  DATA_PREFIX "/images/s.bmp",
  DATA_PREFIX "/images/t.bmp",
  DATA_PREFIX "/images/u.bmp",
  DATA_PREFIX "/images/v.bmp",
  DATA_PREFIX "/images/w.bmp",
  DATA_PREFIX "/images/x.bmp",
  DATA_PREFIX "/images/y.bmp",
  DATA_PREFIX "/images/z.bmp",
  DATA_PREFIX "/images/back.bmp"
};


/* Sounds: */

enum {
  SND_MENU_OPEN,
  SND_HIGHLIGHT,
  SND_ITEM_SELECT,
  SND_WON,
  SND_NOT_PERFECT,
  NUM_SOUNDS
};


char * sound_names[NUM_SOUNDS] = {
  DATA_PREFIX "/sounds/menu-open.wav",
  DATA_PREFIX "/sounds/highlight.wav",
  DATA_PREFIX "/sounds/item-select.wav",
  DATA_PREFIX "/sounds/won.wav",
  DATA_PREFIX "/sounds/not-perfect.wav"
};


/* Globals: */

SDL_Surface * images[NUM_IMAGES];
SMPEG_Info info;
SDL_Surface * screen, * surf, * surf2;
#ifndef NOSOUND
Mix_Chunk * sounds[NUM_SOUNDS];
Mix_Music * mod;
#endif
int use_audio, fullscreen, volume, slider_size, game_mode, flip_mode,
  paused;
int from_x, from_y, carrying_x, carrying_y, offset_x, offset_y,
  pos_x, pos_y, new_x, new_y, vlm, complete, flash, game_running,
  menu, top, left;
Uint32 start_time, cur_time;
int x_pos[MAX_DIVISIONS][MAX_DIVISIONS], y_pos[MAX_DIVISIONS][MAX_DIVISIONS],
  flipped[MAX_DIVISIONS][MAX_DIVISIONS];
SMPEG * mpeg;
char err_mesg[128];
Uint8 mixdata[WIDTH];


/* Local function prototypes: */

void update(SDL_Surface *screen, Sint32 x, Sint32 y, Uint32 w, Uint32 h);
void usage(FILE * stream, char * progname);
Uint8 pitchs_volume(Uint8 pitch);
void drawtext(int x, int y, char * text);
void setup(int argc, char * argv[]);
void init_board(void);
void restart_mpeg(int rescrambling);
int max_strlen(int which_menu);
int max_menuitem(int which_menu);
void create_animation_surface(void);
void load_mpeg(void);
void draw_piece(int src_x, int src_y, int dest_x, int dest_y, int flip,
		int carrying);
void playsound(int snd);
void postmixfunc(void * udata, Uint8 * stream, int len);
void point(SDL_Surface * surf, int x, int y, Uint32 r, Uint32 g, Uint32 b);


/* --- MAIN! --- */

int main(int argc, char *argv[])
{
  SDL_Event event;
  int i, x, y, item, selected_item, quit, cursor_x, cursor_y, frame, h,
    new_menu, menu_highlighted, item_highlighted, highlighted_one, show_about;
  SDL_Rect dest;
  Uint16 * srcrow, * destrow;
  Uint32 r, g, b, last_time;
  char temp[20];
  
  
  setup(argc, argv);
  
  init_board();
  
  complete = 0;
  flash = 0;
  quit = 0;
  cursor_x = 0;
  cursor_y = 0;
  frame = 0;
  last_time = 0;
  menu_highlighted = -1;
  item_highlighted = -1;
  show_about = 0;
  h = 0;
  
  
  /* --- MAIN GAME LOOP! --- */
  
  while (!SDL_QuitRequested() && !quit)
    {
      frame++;
      
      
      /* Handle mouse events: */
      
      while (SDL_PollEvent(&event))
	{
	  if (event.type == SDL_MOUSEBUTTONDOWN)
	    {
	      /* _ANY_ clicking turns off the about display: */
	      
	      show_about = 0;
	      
	      
	      /* To select a menu, or not to select a menu!?  That's
		 this if's question: */
	      
	      if (event.button.y < 16)
		{
		  /* Which menu did they click? */
		  
		  new_menu = -1;
		  for (i = 0; i < NUM_MENUS; i++)
		    {
		      if (event.button.x >= (WIDTH / NUM_MENUS) * i &&
			  event.button.x <= (((WIDTH / NUM_MENUS) * i) +
					     (strlen(menu_names[i]) * 12)))
			{
			  new_menu = i;
			  playsound(SND_MENU_OPEN);
			}
		    }
		  
		  
		  /* If they clicked the same menu that's opened, close it: */
		  
		  if (new_menu == menu)
		    menu = -1;
		  else
		    menu = new_menu;
		}
	      else if (menu != -1)
		{
		  /* Did they click inside a menu? */
		  
		  if (event.button.x >= (WIDTH / NUM_MENUS) * menu &&
		      event.button.x <= (((WIDTH / NUM_MENUS) * menu) +
					 ((max_strlen(menu) + 1) * 12)) &&
		      event.button.y >= 16 &&
		      event.button.y <= (max_menuitem(menu) * 16) + 16)
		    {
		      /* Which item was clicked? */
		      
		      item = ((event.button.y - 16) / 16);
		      
		      
		      /* Deal with the menu's item: */
		      
		      if (menu == MENU_FILE)
			{
			  if (item == 0)
			    {
			      /* Foobar! */

			      if (mpeg != NULL)
				{
				  SMPEG_stop(mpeg);
				  SMPEG_delete(mpeg);
				  mpeg = NULL;
				}
			      
			      vlm = 0;
			      load_mpeg();
			      
			      if (mpeg != NULL)
				{
				  game_running = 1;
				  init_board();
				  restart_mpeg(0);
				}
			    }
			  else if (item == 1)
			    {
			      /* Foobar! */
			      
			      if (mpeg != NULL)
				{
				  SMPEG_stop(mpeg);
#ifndef NOSOUND
				  if (use_audio)
				    Mix_HookMusic(NULL, NULL);
#endif
				  
				  SMPEG_delete(mpeg);
				  mpeg = NULL;
				}

#ifndef NOSOUND			      
			      mod = Mix_LoadMUS("samples/atlantis.s3m");
			      
			      Mix_PlayMusic(mod, -1);
			      Mix_SetPostMix(&postmixfunc, NULL);
#endif
			      
			      vlm = 1;
			      info.width = 320;
			      info.height = 320;
			      create_animation_surface();
			      game_running = 1;
			      init_board();
			      restart_mpeg(0);
			    }
			  else if (item == 2 && game_running == 1 &&
				   complete == 0)
			    {
			      /* Toggle pause: */
			      
			      paused = 1 - paused;
			      
			      if (paused)
				strcpy(err_mesg, "PAUSED");
			      else
				strcpy(err_mesg, "UNPAUSED");
			      
			      
			      /* Pause the MPEG, if any: */
			      
			      if (mpeg != NULL)
				SMPEG_pause(mpeg);
#ifndef NOSOUND
			      else if (mod != NULL)
				{
				  if (paused == 1)
				    Mix_PauseMusic();
				  else
				    Mix_ResumeMusic();
				}
#endif
			    }
			  else if (item == 3)
			    {
			      /* Pause, if playing and not paused: */
			      
			      if (game_running == 1 && complete == 0 &&
				  paused == 0)
				{
				  paused = 1;
				  if (mpeg != NULL)
				    SMPEG_pause(mpeg);
#ifndef NOSOUND
				  else if (mod != NULL)
				    Mix_PauseMusic();
#endif
				}
			      
			      
			      /* Set flag to show "About" info: */
			      
			      show_about = 1 - show_about;
			    }
			  else if (item == 4)
			    {
			      quit = 1;
			    }
			}
		      else if (menu == MENU_SIZE)
			{
			  /* If we weren't already playing at this size,
			     change to it and reset the board: */
			  
			  if (slider_size != item + 3)
			    {
			      slider_size = item + 3;
			      
			      sprintf(err_mesg, "%s SIZE SELECTED\n",
				      menu_items[menu][item]);
			      
			      init_board();
			      restart_mpeg(1);
			    }
			}
		      else if (menu == MENU_GAME)
			{
			  /* If we weren't already playing in this mode,
			     change to it and reset the board: */
			  
			  if (game_mode != item)
			    {
			      game_mode = item;
			      
			      sprintf(err_mesg, "%s GAME SELECTED\n",
				      menu_items[menu][item]);
			      
			      
			      /* Leave the board alone if we're switching
				 from 'perfect' to 'drag' or vice-versa: */
			      
			      init_board();
			      restart_mpeg(1);
			    }
			}
		      else if (menu == MENU_FLIP)
			{
			  /* If we weren't already playing in this mode,
			     change to it and reset the board: */
			  
			  if (flip_mode != item)
			    {
			      flip_mode = item;
			      
			      sprintf(err_mesg, "%s GAME SELECTED\n",
				      menu_items[menu][item]);
			      
			      init_board();
			      restart_mpeg(1);
			    }
			}
		      else if (menu == MENU_VOLUME)
			{
			  /* Change the volume: */
			  
			  if (item == 0 && volume != 100)
			    {
			      volume = 100;
			      
			      strcpy(err_mesg, "VOLUME: LOUDEST");
			    }
			  else if (item == 1 && volume != 75)
			    {
			      volume = 75;
			      
			      strcpy(err_mesg, "VOLUME: 75 PERCENT");
			    }
			  else if (item == 2 && volume != 50)
			    {
			      volume = 50;
			      
			      strcpy(err_mesg, "VOLUME: 50 PERCENT");
			    }
			  else if (item == 3 && volume != 25)
			    {
			      volume = 25;
			      
			      strcpy(err_mesg, "VOLUME: 25 PERCENT");
			    }
			  else if (item == 4 && volume != 0)
			    {
			      volume = 0;
			      
			      strcpy(err_mesg, "SOUND OFF");
			    }
			  
			  
			  /* If audio is off, override! */
			  
			  if (use_audio == 0)
			    {
			      volume = 0;
			      
			      strcpy(err_mesg, "SOUND DISABLED");
			    }
			  
			  
			  /* Set the volume! */
			  
			  if (mpeg != NULL)
			    SMPEG_setvolume(mpeg, volume);
#ifndef NOSOUND
			  else if (mod != NULL)
			    Mix_VolumeMusic(volume);
#endif
			}
		    }
		  
		  
		  /* Play a sound and close the menu: */
		  
		  playsound(SND_ITEM_SELECT);
		  menu = -1;
		}
	      else if (game_running == 1 &&
		       event.button.x >= left &&
		       event.button.x < left + info.width &&
		       event.button.y >= top &&
		       event.button.y < top + info.height)
		{
		  if (complete == 0)
		    {
		      if (event.button.button == 1)
			{
			  /* Left button: grab a particular sliding piece: */
			  
			  from_x = ((event.button.x - left) /
				    (info.width / slider_size));
			  from_y = ((event.button.y - top) /
				    (info.height / slider_size));
			  
			  offset_x = ((event.button.x - left) %
				      (info.width / slider_size));
			  offset_y = ((event.button.y - top) %
				      (info.height / slider_size));
			  
			  carrying_x = x_pos[from_y][from_x];
			  carrying_y = y_pos[from_y][from_x];
			  
			  pos_x = ((event.button.x - left) - offset_x);
			  pos_y = ((event.button.y - top) - offset_y);
			}
		      else if (event.button.button > 1)
			{
			  /* Right button: flip a piece: */
			  
			  if (flip_mode == 1)
			    {
			      from_x = ((event.button.x - left) /
					(info.width / slider_size));
			      from_y = ((event.button.y - top) /
					(info.height / slider_size));
			      
			      flipped[from_y][from_x] = (1 -
							 (flipped[from_y]
							  [from_x]));
			      
			      from_x = -1;
			      from_y = -1;
			      carrying_x = -1;
			      carrying_y = -1;
			    }
			}
		    }
		}
	    }
	  else if (event.type == SDL_MOUSEBUTTONUP)
	    {
	      if (game_running == 1 && menu == -1 && complete == 0 &&
		  carrying_x != -1 && carrying_y != -1)
		{
		  /* Let go of the piece we're carrying */
		  
		  if (event.button.x >= left &&
		      event.button.x < left + info.width &&
		      event.button.y >= top &&
		      event.button.y < top + info.height)
		    {
		      /* (Move shape from the new spot to the old spot): */
		      
		      new_x = ((event.button.x - left) /
			       (info.width / slider_size));
		      new_y = ((event.button.y - top) /
			       (info.height / slider_size));
		      
		      x_pos[from_y][from_x] = x_pos[new_y][new_x];
		      y_pos[from_y][from_x] = y_pos[new_y][new_x];
		      
		      x_pos[new_y][new_x] = carrying_x;
		      y_pos[new_y][new_x] = carrying_y;
		      
		      
		      /* If this is not the spot it was supposed to be
			 at, and we're in perfection mode, rescramble the
			 board! */
		      
		      if (game_mode == GAME_PERFECTION)
			{
			  if (carrying_x == new_x && carrying_y == new_y)
			    {
			      /* Right place! */
			      
			      strcpy(err_mesg, "CORRECT");
			    }
			  else if (from_x == new_x &&
				   from_y == new_y)
			    {
			      /* Where we picked it up from: */
			      
			      /* Nothing special... */
			    }
			  else
			    {
			      /* Wrong place !*/
			      
			      strcpy(err_mesg, "WRONG : RESCRAMBLING");
			      init_board();
			      playsound(SND_NOT_PERFECT);
			    }
			}
		    }
		  
		  
		  /* ("Let go" of the piece): */
		  
		  carrying_x = -1;
		  carrying_y = -1;
		  
		  from_x = -1;
		  from_y = -1;
		  
		  
		  /* Is the board complete? */
		  
		  complete = 1;
		  
		  for (y = 0; y < slider_size; y++)
		    {
		      for (x = 0; x < slider_size; x++)
			{
			  if (x_pos[y][x] != x ||
			      y_pos[y][x] != y ||
			      flipped[y][x] != 0)
			    complete = 0;
			}
		    }
		  
		  
		  /* If it's complete, flash and play a noise! */
		      
		  if (complete == 1)
		    {
		      flash = 255;
		      sprintf(err_mesg, "PUZZLE COMPLETED");
		      playsound(SND_WON);
		    }
		}
	    }
	  else if (event.type == SDL_MOUSEMOTION)
	    {
	      cursor_x = event.motion.x;
	      cursor_y = event.motion.y;
	      
	      if (menu == -1 && game_running == 1 && complete == 0)
		{
		  /* Slide the piece we're grabbing (if any) around: */
		  
		  if (carrying_x != -1 && carrying_y != -1)
		    {
		      pos_x = ((cursor_x - left) - offset_x);
		      pos_y = ((cursor_y - top) - offset_y);
		    }
		}
	    }
	}
      
      
      /* Do VLM stuff! */
      
      if (vlm == 1)
	{
	  if (SDL_LockSurface(surf) == 0)
	    {
	      if (1 == 1)
		{
		  /* Melt: */
		  
		  for (y = info.height - 3; y >= 0; y--)
		    {
		      srcrow = (Uint16 *) ((Uint8 *) (surf->pixels) +
					   (y * (surf->pitch)));
		      destrow = (Uint16 *) ((Uint8 *) (surf->pixels) +
					    ((y + 2) * (surf->pitch)));
		      
		      for (x = 0; x < info.width; x++)
			{
			  r = ((*srcrow) >> 11) & 0x1F;
			  g = ((*srcrow) >> 5) & 0x3F;
			  b = ((*srcrow) >> 0) & 0x1F;
			  
			  r = (r * 15) >> 4;
			  g = (g * 15) >> 4;
			  b = (b * 15) >> 4;
			  
			  *destrow = (Uint16) ((r << 11) +
					       (g << 5) +
					       (b << 0));
			  
			  srcrow++;
			  destrow++;
			}
		    }
		}
	      else if (0 == 1)
		{
		  /* Zoom In: */
		  
		  for (y = 0; y < info.height; y++)
		    {
		      srcrow = (Uint16 *) ((Uint8 *) (surf->pixels) +
					   ((y / 2 + (info.height / 4)) *
					    (surf->pitch))) + (info.width / 4);
		      destrow = (Uint16 *) ((Uint8 *) (surf2->pixels) +
					    (y * (surf2->pitch)));
		      
		      for (x = 0; x < info.width; x++)
			{
			  g = ((*srcrow) >> 11) & 0x1F;
			  b = ((*srcrow) >> 5) & 0x3F;
			  r = ((*srcrow) >> 0) & 0x1F;
			  
			  r = (r * 7) >> 3;
			  g = (g * 7) >> 3;
			  b = (b * 7) >> 3;

			  
			  *destrow = (Uint16) ((r << 11) +
					       (g << 5) +
					       (b << 0));
			  
			  if (x % 2)
			    srcrow++;
			  
			  destrow++;
			}
		    }
		  
		  SDL_BlitSurface(surf2, NULL,
				  surf, NULL);
		}
	      else
		{
		  /* Zoom Out: */
		  
		  for (y = 0; y < info.height; y++)
		    {
		      srcrow = (Uint16 *) ((Uint8 *) (surf->pixels) +
					   (y * (surf2->pitch)));
		      destrow = (Uint16 *) ((Uint8 *) (surf2->pixels) +
					    ((y / 2 + (info.height / 4)) *
					     (surf2->pitch))) +
			(info.width / 4);
		      
		      for (x = 0; x < info.width; x++)
			{
			  r = ((*srcrow) >> 11) & 0x1F;
			  g = ((*srcrow) >> 5) & 0x3F;
			  b = ((*srcrow) >> 0) & 0x1F;
			  
			  r = r + 4;
			  g = g + 4;
			  b = b + 4;
			  
			  *destrow = (Uint16) ((r << 11) +
					       (g << 5) +
					       (b << 0));
			  
			  srcrow++;

			  if (x % 2)
			    destrow++;
			}
		    }
		  
		  SDL_BlitSurface(surf2, NULL,
				  surf, NULL);
		}
	      
	      
	      SDL_UnlockSurface(surf);
	    }
	  
	  
	  if (1 == 1)
	    {
	      /* Oscillascope: */
	      
	      for (x = 0; x < info.width; x++)
		{
		  /* Convert the Uint8 unsigned byte into a signed byte: */
		  
		  if (mixdata[x] < 128)
		    h = mixdata[x];
		  else
		    h = 255 - mixdata[x];
		  
		  
		  /* Make sure we stay in the window's bounds: */
		  
		  if (h > (surf->h) / 2)
		    h = (surf->h) / 2;
		  
		  
		  /* Draw the line: */
		  
		  dest.x = x;
		  dest.y = ((surf->h) / 2) - (h / 2);
		  dest.w = 1;
		  dest.h = h;
		  
		  SDL_FillRect(surf, &dest,
			       SDL_MapRGB(surf->format,
					  x, h * 2 + 16, h * 2 + 16));
		}
	    }
	  else
	    {
	      /* Points: */
	      
	      if (SDL_LockSurface(surf) == 0)
		{
		  for (i = 0; i < 90; i++)
		    {
		      x = (info.width / 2) + (cos(M_PI * i / 180) *
					      mixdata[i]);
		      y = (info.height / 2) - (sin(M_PI * i / 180) *
					       mixdata[i]);
		      
		      point(surf, x, y, i, i, i);
		    }
		  
		  SDL_UnlockSurface(surf);
		}
	    }
	}
      
      
      /* Erase the background: */
      
      for (y = 0; y < HEIGHT; y = y + 24)
	{
	  for (x = 0; x < WIDTH; x = x + 32)
	    {
	      dest.x = x;
	      dest.y = y;
	      dest.w = 32;
	      dest.h = 24;
	      
	      SDL_BlitSurface(images[IMG_BACK], NULL, screen, &dest);
	    }
	}
      
      
      /* Draw flash: */
      
      if (flash != 0)
	{
	  flash = flash - 32;
	  
	  if (flash <= 0)
	    flash = 0;
	  
	  dest.x = left;
	  dest.y = top;
	  dest.w = info.width;
	  dest.h = info.height;
	  
	  SDL_FillRect(screen, &dest,
		       SDL_MapRGB(screen->format, flash, flash, flash));
	}
      
      
      /* Draw the pieces of the puzzle! (if we're not flashing) */
      
      if (flash == 0 && game_running == 1)
	{
	  if (paused == 0)
	    {
	      for (y = 0; y < slider_size; y++)
		{
		  for (x = 0; x < slider_size; x++)
		    {
		      if (from_x != x || from_y != y)
			{
			  /* If this isn't the piece we're holding: */
			  
			  draw_piece((info.width / slider_size) * x_pos[y][x],
				     (info.height / slider_size) * y_pos[y][x],
				     (info.width / slider_size) * x + left,
				     (info.height / slider_size) * y + top,
				     flipped[y][x], 0);
			}			  
		    }
		}
	      
	      
	      /* ALWAYS draw the one we're carrying on top of the rest: */
	      
	      if (from_x != -1 && from_y != -1)
		{
		  draw_piece((info.width / slider_size) * carrying_x,
			     (info.height / slider_size) * carrying_y,
			     pos_x + 4 + left, pos_y + 4 + top,
			     flipped[from_y][from_x], 1);
		}
	    }
	  else
	    {
	      /* Draw grey: */
	      
	      dest.x = left;
	      dest.y = top;
	      dest.w = info.width;
	      dest.h = info.height;

	      SDL_FillRect(screen, &dest,
			   SDL_MapRGB(screen->format,
				      64, 64, 64));
	    }
	}
      
      
      /* Draw the clock: */
      
      if (game_running == 1)
	{
	  if (complete == 0)
	    cur_time = SDL_GetTicks() - start_time;
	  
	  sprintf(temp, "%.2d:%.2d",
		  cur_time / 60000, (cur_time / 1000) % 60);
	  
	  for (i = 0; i < 5; i++)
	    {
	      if (temp[i] >= '0' && temp[i] <= ':')
		{
		  dest.x = WIDTH - 12 * (5 - i);
		  dest.y = HEIGHT - 16;
		  dest.w = 12;
		  dest.h = 16;
		  
		  SDL_BlitSurface(images[temp[i] - '0' + IMG_0],
				  NULL, screen, &dest);
		}
	    }
	}
      
      
      /* Draw the about display: */
      
      if (show_about == 1)
	{
	  for (i = 0; about[i] != NULL && i < ((480 - 32) / 16); i++)
	    {
	      drawtext((WIDTH - (strlen(about[i]) * 12)) / 2, (i + 2) * 16,
		       about[i]);
	    }
	}
      
      
      /* Draw menus onto the screen: */
      
      dest.x = 0;
      dest.y = 0;
      dest.w = WIDTH;
      dest.h = 16;
      
      SDL_FillRect(screen, &dest,
		   SDL_MapRGB(screen->format,
			      48, 48, 48));
      
      for (i = 0; i < NUM_MENUS; i++)
	{
	  drawtext((WIDTH / (NUM_MENUS)) * i, 0, menu_names[i]);
	}
      
      
      /* Draw the menu items: */
      
      highlighted_one = 0;
      
      if (menu != -1)
	{
	  /* Is one of these items selected? */
	  
	  selected_item = -1;
	  
	  if (menu == MENU_FILE)
	    {
	      if (paused == 1)
		selected_item = 2;
	    }
	  else if (menu == MENU_SIZE)
	    selected_item = slider_size - 3;
	  else if (menu == MENU_GAME)
	    selected_item = game_mode;
	  else if (menu == MENU_FLIP)
	    selected_item = flip_mode;
	  else if (menu == MENU_VOLUME)
	    {
	      if (volume == 100)
		selected_item = 0;
	      else if (volume == 75)
		selected_item = 1;
	      else if (volume == 50)
		selected_item = 2;
	      else if (volume == 25)
		selected_item = 3;
	      else if (volume == 0)
		selected_item = 4;
	    }
	  
	  
	  /* Draw the background grey: */
	  
	  dest.x = (WIDTH / (NUM_MENUS)) * menu;
	  dest.y = 16;
	  dest.w = (max_strlen(menu) + 1) * 12;
	  dest.h = max_menuitem(menu) * 16;
	  
	  SDL_FillRect(screen, &dest,
		       SDL_MapRGB(screen->format, 32, 32, 32));
	  
	  
	  /* Draw each item: */
	  
	  for (i = 0; i < MAX_MENUITEMS && menu_items[menu][i] != NULL; i++)
	    {
	      /* Highlight behind it if the mouse is over it: */
	      
	      if (cursor_x >= (WIDTH / NUM_MENUS) * menu &&
		  cursor_x < (((WIDTH / NUM_MENUS) * menu) +
			       (max_strlen(menu) + 1) * 12) &&
		  cursor_y >= (i + 1) * 16 &&
		  cursor_y < (i + 2) * 16)
		{
		  dest.x = (WIDTH / NUM_MENUS) * menu;
		  dest.y = (i + 1) * 16;
		  dest.w = (max_strlen(menu) + 1) * 12;
		  dest.h = 16;
		  
		  SDL_FillRect(screen, &dest,
			       SDL_MapRGB(screen->format, 64, 64, 64));
		  
		  if (menu_highlighted != menu || item_highlighted != i)
		    {
		      playsound(SND_HIGHLIGHT);
		    }
		  
		  menu_highlighted = menu;
		  item_highlighted = i;
		  
		  highlighted_one = 1;
		}
	      
	      
	      drawtext((WIDTH / NUM_MENUS) * menu + 12, (i + 1) * 16,
		       menu_items[menu][i]);
	      
	      
	      /* Point out the selected one: */
	      
	      if (selected_item == i)
		drawtext((WIDTH / (NUM_MENUS)) * menu, (i + 1) * 16, ":");
	    }
	}
      
      
      /* If nothing was highlighted, make a note! */
      
      if (highlighted_one == 0)
	{
	  menu_highlighted = -1;
	  item_highlighted = -1;
	}
      
      
      /* Draw message onto the screen: */
      
      drawtext((WIDTH - (strlen(err_mesg) * 12)) / 2, HEIGHT - 16, err_mesg);
      
      
      /* Pause: */
      
      if (SDL_GetTicks() < last_time + PAUSE)
	{
	  sprintf(temp, "%d\n", last_time + PAUSE - SDL_GetTicks());
	  drawtext(0, 16, temp);
	  
	  SDL_Delay(last_time + PAUSE - SDL_GetTicks());
	}
      
      last_time = SDL_GetTicks();
      
      
      /* Update the window: */
      
      SDL_Flip(screen);
    }
  
  exit(0);
}


/* Callback function needed by the SMPEG_display(): */

void update(SDL_Surface *screen, Sint32 x, Sint32 y, Uint32 w, Uint32 h)
{
  SDL_UpdateRect(screen, x, y, w, h);
}


/* Complain about usage: */

void usage(FILE * stream, char * progname)
{
  fprintf(stream,
	  "Usage: %s [options]\n"
	  "Where the options are one of:\n"
	  "  --noaudio           Don't play audio stream\n"
	  "  --fullscreen        Play in fullscreen mode\n", progname);
}


/* Return the volume of a particular pitch of the audio being played: */

Uint8 pitchs_volume(Uint8 pitch)
{
  /* Blah! There's no way how, yet!? */
  
  return(pitch);
}


/* Draw text on the screen: */

void drawtext(int x, int y, char * text)
{
  int i;
  SDL_Rect dest;
  
  
  for (i = 0; i < strlen(text); i++)
    {
      dest.x = x + (i * 12);
      dest.y = y;
      dest.w = 12;
      dest.h = 16;
      
      if (text[i] >= 'A' && text[i] <= 'Z')
	SDL_BlitSurface(images[text[i] - 'A' + IMG_A], NULL, screen, &dest);
      else if (text[i] >= '0' && text[i] <= ':')
	SDL_BlitSurface(images[text[i] - '0' + IMG_0], NULL, screen, &dest);
    }
}


/* Setup game: */

void setup(int argc, char * argv[])
{
  int i;
  SDL_Surface * image;
  Uint32 video_flags;
  
  
  /* Initialize SDL */
  
  if (SDL_Init(SDL_INIT_AUDIO|SDL_INIT_VIDEO) < 0)
    {
      fprintf(stderr, "Couldn't init SDL: %s\n", SDL_GetError());
      exit(1);
    }
  
  atexit(SDL_Quit);
  
  
  /* Get the command line options */
  
  use_audio = 1;
  fullscreen = 0;
  
  for (i=1; argv[i] && (argv[i][0] == '-'); i++)
    {
      if (strcmp(argv[i], "--disable-sound") == 0)
	use_audio = 0;
      else if (strcmp(argv[i], "--fullscreen") == 0)
	fullscreen = 1;
      else if (strcmp(argv[i], "--help") == 0 ||
	       strcmp(argv[i], "-h") == 0)
	{
	  /* Foobar! */
	  
	  printf("HELP GOES HERE!\n");
	  exit(0);
	}
      else if (strcmp(argv[i], "--usage") == 0)
	{
	  usage(stdout, argv[0]);
	  exit(0);
	}
      else
	{
	  usage(stderr, argv[0]);
	  exit(1);
        }
    }
  

  /* Determine flags for the display: */
  
  video_flags = SDL_SWSURFACE;
  
  if (fullscreen)
    {
      video_flags = SDL_FULLSCREEN|SDL_DOUBLEBUF|SDL_HWSURFACE;
    }
  
  
  /* Open up the display: */
  
  screen = SDL_SetVideoMode(WIDTH, HEIGHT, 0, video_flags);
  SDL_WM_SetCaption("VidSlide", "VidSlide");
  
  
  /* Load images: */
  
  for (i = 0; i < NUM_IMAGES; i++)
    {
      image = SDL_LoadBMP(image_names[i]);
      
      if (image == NULL)
        {
          fprintf(stderr,
                  "\nError: I couldn't load a graphics file:\n"
                  "%s\n"
                  "The Simple DirectMedia error that occured was:\n"
                  "%s\n\n", image_names[i], SDL_GetError());
          exit(1);
        }

      
      /* Set transparency: */
      
      if (SDL_SetColorKey(image, (SDL_SRCCOLORKEY),
			  SDL_MapRGB(image -> format,
				     0xFF, 0xFF, 0xFF)) == -1)
	{
	  fprintf(stderr,
		  "\nError: I could not set the color key for the file:\n"
		  "%s\n"
		  "The Simple DirectMedia error that occured was:\n"
		  "%s\n\n", image_names[i], SDL_GetError());
	  exit(1);
	}
      
      
      /* Convert to display format: */
      
      images[i] = SDL_DisplayFormat(image);
      

      if (images[i] == NULL)
        {
          fprintf(stderr,
                  "\nError: I couldn't convert a file to the display format:\n"
                  "%s\n"
                  "The Simple DirectMedia error that occured was:\n"
                  "%s\n\n", image_names[i], SDL_GetError());
          exit(1);
        }
      
      SDL_FreeSurface(image);
    }


  /* Open sound: */
  
#ifndef NOSOUND
  if (use_audio == 1)
    {
      if (Mix_OpenAudio(MIX_DEFAULT_FREQUENCY, MIX_DEFAULT_FORMAT,
			/* MIX_DEFAULT_CHANNELS, */
			1, 512) < 0)
        {
          fprintf(stderr,
                  "\nWarning: I could not set up audio.\n"
                  "The Simple DirectMedia error that occured was:\n"
                  "%s\n\n", SDL_GetError());
          use_audio = 0;
        }
    }
#endif
  
  
  /* Load sounds: */

#ifndef NOSOUND  
  if (use_audio == 1)
    {
      for (i = 0; i < NUM_SOUNDS; i++)
	{
	  sounds[i] = Mix_LoadWAV(sound_names[i]);
	  if (sounds[i] == NULL)
	    {
	      fprintf(stderr,
		      "\nError: I could not load the sound file:\n"
		      "%s\n"
		      "The Simple DirectMedia error that occured was:\n"
		      "%s\n\n", sound_names[i], SDL_GetError());
	      exit(1);
	    }
	}
    }
#endif

  
  /* Set a random seed: */
  
  srand(SDL_GetTicks());
  
  
  /* Defaults: */
  
  slider_size = 4;
  volume = 100;
  start_time = 0;
  cur_time = 0;
  game_mode = GAME_DRAG;
  paused = 0;
  game_running = 0;
  menu = -1;
  strcpy(err_mesg, "WELCOME TO VIDSLIDE");
  surf = NULL;
  mpeg = NULL;
  top = 50;
  left = 50;
}


/* Initialize the board: */

void init_board(void)
{
  int x, y, xx1, yy1, xx2, yy2, i;
  
  
  /* Reset board: */
  
  for (y = 0; y < slider_size; y++)
    {
      for (x = 0; x < slider_size; x++)
	{
	  x_pos[y][x] = x;
	  y_pos[y][x] = y;
	  
	  if (flip_mode == 1 && (rand() % 2) == 0)
	    flipped[y][x] = 1;
	  else
	    flipped[y][x] = 0;
	}
    }
  
  
  if (game_mode == GAME_DRAG || game_mode == GAME_PERFECTION)
    {
      /* Scramble the board!: */
      
      for (i = 0; i < 100; i++)
	{
	  xx1 = rand() % slider_size;
	  yy1 = rand() % slider_size;
	  
	  xx2 = rand() % slider_size;
	  yy2 = rand() % slider_size;
	  
	  x = x_pos[yy1][xx1];
	  y = y_pos[yy1][xx1];
	  
	  x_pos[yy1][xx1] = x_pos[yy2][xx2];
	  y_pos[yy1][xx1] = y_pos[yy2][xx2];
	  
	  x_pos[yy2][xx2] = x;
	  y_pos[yy2][xx2] = y;
	}
    }
  
  
  /* Initialize the carrying-related variables: */
  
  carrying_x = -1;
  carrying_y = -1;
  
  from_x = -1;
  from_y = -1;
  
  pos_x = 0;
  pos_y = 0;
  
  offset_x = 0;
  offset_y = 0;
  
  new_x = 0;
  new_y = 0;
  
  complete = 0;
  

  /* Set the clock! */
  
  start_time = SDL_GetTicks();
  cur_time = (Uint32) 0;
}


/* Restart the animation from the beginning: */

void restart_mpeg(int rescrambling)
{
  /* Rewind the animation! (Don't restart audio-only unless we're not
     simply rescrambling the board) */
  
  if (mpeg != NULL)
    {
      if (rescrambling == 0 || info.has_video == 1)
	{
	  SMPEG_rewind(mpeg);
	  SMPEG_loop(mpeg, 1);
	  SMPEG_play(mpeg);
	  
	  if (paused == 1)
	    SMPEG_pause(mpeg);
	}
    }
}


/* Returns the length of the name of the longest menu item in a menu: */

int max_strlen(int which_menu)
{
  int i, max;
  
  max = 0;
  
  for (i = 0; i < MAX_MENUITEMS; i++)
    {
      if (menu_items[which_menu][i] != NULL)
	{
	  if (strlen(menu_items[which_menu][i]) > max)
	    max = strlen(menu_items[which_menu][i]);
	}
    }
  
  return(max);
}


/* How many menu items does a menu contain? */

int max_menuitem(int which_menu)
{
  int i;
  
  for (i = 0; i < MAX_MENUITEMS && menu_items[which_menu][i] != NULL; i++)
    ;
  
  return(i);
}


/* Create animation surface: */

void create_animation_surface(void)
{
  SDL_Surface * temp_surf;
  
  
  /* Delete old surface: */
  
  if (surf != NULL)
    SDL_FreeSurface(surf);
  
  
  /* Create a surface for the animation: */
  
  temp_surf = SDL_AllocSurface(screen->flags,
			       info.width, info.height,
			       screen->format->BitsPerPixel,
			       screen->format->Rmask,
			       screen->format->Gmask,
			       screen->format->Bmask,
			       0 /* screen->format->Amask */);
  
  if (temp_surf == NULL)
    {
      fprintf(stderr, "Couldn't create temporary surface: %s\n",
	      SDL_GetError());
      exit(1);
    }

  
  /* Convert it to our display's native format: */
  
  surf = SDL_DisplayFormat(temp_surf);
  
  SDL_FreeSurface(temp_surf);


  /* Create a 2nd surface for the animation: */
  
  temp_surf = SDL_AllocSurface(screen->flags,
			       info.width, info.height,
			       screen->format->BitsPerPixel,
			       screen->format->Rmask,
			       screen->format->Gmask,
			       screen->format->Bmask,
			       0 /* screen->format->Amask */);
  
  if (temp_surf == NULL)
    {
      fprintf(stderr, "Couldn't create temporary surface: %s\n",
	      SDL_GetError());
      exit(1);
    }

  
  /* Convert it to our display's native format: */
  
  surf2 = SDL_DisplayFormat(temp_surf);
  
  SDL_FreeSurface(temp_surf);
  
  
  /* Determine origin on the larger screen for this surface when we
     deal with it later: */
  
  left = (WIDTH - info.width) / 2;
  top = (((HEIGHT - 16) - info.height) / 2) + 16;
}


/* Load MPEG file: */

void load_mpeg(void)
{
  int i;
  char file[1024];
#ifndef NOSOUND
  SDL_AudioSpec audiofmt;
  Uint16 format;
  int freq, channels;
#endif
  
  
  /* Erase old mpeg data: */
  
  if (mpeg != NULL)
    {
      SMPEG_delete(mpeg);
      mpeg = NULL;
    }
  
  
  /* Create the MPEG stream */
  
  strcpy(file, "samples/gatespie.mpg");
  
  mpeg = SMPEG_new(file, &info, 0);
  if (SMPEG_error(mpeg))
    {
      sprintf(err_mesg, "%s", SMPEG_error(mpeg));
      
      for (i = 0; i < strlen(err_mesg); i++)
	err_mesg[i] = toupper(err_mesg[i]);
      
      SMPEG_delete(mpeg);
      mpeg = NULL;
    }
  else
    {
      SMPEG_enableaudio(mpeg, 0);
      
      if (use_audio)
	{
	  /* Tell SMPEG what the audio format is: */
	  
#ifndef NOSOUND
	  Mix_QuerySpec(&freq, &format, &channels);
	  audiofmt.format = format;
	  audiofmt.freq = freq;
	  audiofmt.channels = channels;
	  
	  SMPEG_actualSpec(mpeg, &audiofmt);
	  
	  
	  /* Hook in the MPEG music mixer: */
	  
	  Mix_HookMusic(SMPEG_playAudio, mpeg);
	  SMPEG_enableaudio(mpeg, 1);
#endif
	}
      
      SMPEG_enablevideo(mpeg, 1);
      SMPEG_setvolume(mpeg, volume);
      
      
      /* Is there video and/or audio streams? */
      
      if (info.has_video)
	{
	  /* There's video! */
	  
	  if (info.width <= (WIDTH / 2) && info.height <= (HEIGHT / 2))
	    {
	      /* Double the size if it's very small: */
	      
	      SMPEG_double(mpeg, 1);
	      info.width *= 2;
	      info.height *= 2;
	    }
	  
	  game_running = 1;
	  vlm = 0;
	}
      else if (info.has_audio)
	{
	  if (use_audio == 1)
	    {
	      /* There's audio, but no video.
		 Virtual Light Machine mode: */
	      
	      info.width = 320;
	      info.height = 320;
	      
	      game_running = 1;
	      vlm = 1;
	      
	      create_animation_surface();
	    }
	  else
	    {
	      /* There's only audio, but audio is turned off! */
	      
	      strcpy(err_mesg, "MPEG IS AUDIO ONLY BUT AUDIO DISABLED");
	      
	      SMPEG_delete(mpeg);
	      mpeg = NULL;
	      game_running = 0;
	      vlm = 0;
	    }
	}
      else
	{
	  /* There's NEITHER?! */
	  
	  strcpy(err_mesg, "MPEG HAS NEITHER VIDEO NOR AUDIO");
	  
	  SMPEG_delete(mpeg);
	  mpeg = NULL;
	  game_running = 0;
	  vlm = 0;
	}
      
      
      /* If we still have an MPEG to DO something with... */
      
      if (mpeg != NULL)
	{
	  /* If there was video, stream it onto animation surface: */
	  
	  if (info.has_video)
	    {
	      create_animation_surface();
	      SMPEG_setdisplay(mpeg, surf, NULL, update);
	    }
	  
	  
	  /* Play the MPEG, and wait for playback to complete */
	  
	  if (info.has_video || info.has_audio)
	    {
	      SMPEG_loop(mpeg, 1);
	      SMPEG_play(mpeg);
	      /* SMPEG_playAudio(mpeg ... ??? ); */
	    }
	}
    }
}


/* Draw a piece on the screen: */

void draw_piece(int src_x, int src_y, int dest_x, int dest_y, int flip,
		int carrying)
{
  SDL_Rect src, dest;
  int i;
  
  
  if (flip == 0)
    {
      /* Draw it normal: */
      
      src.x = src_x;
      src.y = src_y;
      src.w = (info.width / slider_size);
      src.h = (info.height / slider_size);
      
      dest.x = dest_x;
      dest.y = dest_y;
      dest.w = (info.width / slider_size);
      dest.h = (info.height / slider_size);
      
      SDL_BlitSurface(surf, &src, screen, &dest);
    }
  else
    {
      /* Draw it horizontally flipped: */
      
      for (i = 0; i < (info.width / slider_size); i++)
	{
	  src.x = src_x + (info.width / slider_size) - i - 1;
	  src.y = src_y;
	  src.w = 1;
	  src.h = (info.height / slider_size);
	  
	  dest.x = dest_x + i;
	  dest.y = dest_y;
	  dest.w = 1;
	  dest.h = (info.height / slider_size);
	  
	  SDL_BlitSurface(surf, &src, screen, &dest);
	}
    }
  
  
  /* Outline it, if we're carrying it: */
  
  if (carrying)
    {
      /* Top line: */
      
      dest.x = dest_x;
      dest.y = dest_y;
      dest.w = (info.width / slider_size);
      dest.h = 1;
      
      SDL_FillRect(screen, &dest,
		   SDL_MapRGB(screen->format, 255, 255, 255));


      /* Bottom line: */
      
      dest.x = dest_x;
      dest.y = dest_y + (info.height / slider_size) - 1;
      dest.w = (info.width / slider_size);
      dest.h = 1;
      
      SDL_FillRect(screen, &dest,
		   SDL_MapRGB(screen->format, 255, 255, 255));


      /* Left line: */
      
      dest.x = dest_x;
      dest.y = dest_y;
      dest.w = 1;
      dest.h = (info.height / slider_size);
      
      SDL_FillRect(screen, &dest,
		   SDL_MapRGB(screen->format, 255, 255, 255));


      /* Right line: */
      
      dest.x = dest_x + (info.width / slider_size) - 1;
      dest.y = dest_y;
      dest.w = 1;
      dest.h = (info.height / slider_size);
      
      SDL_FillRect(screen, &dest,
		   SDL_MapRGB(screen->format, 255, 255, 255));
    }
}


/* Play a sound: */

void playsound(int snd)
{
#ifndef NOSOUND
  if (use_audio == 1)
    {
      Mix_PlayChannel(-1, sounds[snd], 0);
    }
#endif
}


/* Postmix function... Fills a buffer with stuff from the mixer: */

void postmixfunc(void * udata, Uint8 * stream, int len)
{
  /* Copy data from the stream into our vertical positions buffer: */
  
  memcpy(mixdata, stream, sizeof(Uint8) * (surf->w));
}


/* Draw one point: */

void point(SDL_Surface * surf, int x, int y, Uint32 r, Uint32 g, Uint32 b)
{
  Uint16 * dest;
  
  if (x >= 0 && y >= 0 && x < surf->w && y < surf->h)
    {
      dest = (Uint16 *) ((Uint8 *) (surf->pixels) +
			 (y * (surf->pitch))) + x;
      
      *dest = (Uint16) ((r << 11) +
			(g << 5) +
			(b << 0));
    }
}
