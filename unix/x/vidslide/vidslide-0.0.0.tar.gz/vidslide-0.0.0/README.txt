README for VidSlide

by Bill Kendrick
bill@newbreedsoftware.com
http://www.newbreedsoftware.com/vidslide/

Version 0.0.0 (ALPHA RELEASE)

June 4, 2000


DESCRIPTION
-----------
  "VidSlide" is based on the Atari Jaguar game "VidGrid(tm)", copyright
  1994-1995 Geffen Records, Inc. and Jasmine Multimedia Publishing,
  programmed by Brian McGroarty and Rick Mirsky.

  The object of the game is to take an image that has been broken into
  pieces and scrambled, and place them back in the right order.

FEATURES
--------
  GAME MODES
  ----------
    Animated image can be broken up into 3x3, 4x4, 5x5, 6x6, 7x7 or 8x8 pieces,
    and there are three game modes: two 'drag-and-drop' games, and a
    'sliding puzzle' game, similar to sliding 4x4 number puzzle toys.

  SUPPORTED FILE FORMATS
  ----------------------
    "VidSlide" can load MPEG-format (Moving Picture Experts Group) files
    containing video and/or audio streams.  It can also load as MOD-format
    audio files containing audio information.

    The supported file formats are typically described with the following
    filename extensions:

    MPEGS
    -----
      MPG / MPEG - MPEG-1 and MPEG-2 files with Audio and/or Video streams
      MP2        - MPEG Layer 2 Audio stream files
      MP3        - MPEG Layer 3 Audio stream files

    MODS
    ----
      MOD - Noise-, Fast-, Pro-, Star-, Sound-, etc. Trackers
      MTM - Multitracker
      STM - Scream Tracker 2
      S3M - Scream Tracker 3
      XM  - Fasttracker II
      IT  - Impulse Tracker files

    Support for these file formats are derived from the libraries used,
    the SDL "SMPEG" library and "MikMod" (via the SDL "mixer" library).

    Your mileage may vary depending on the versions of these libraries you
    have installed.

  GRAPHICS MODES
  --------------
    When playing an MPEG containing a video stream, the puzzle pieces will,
    as you may have guessed, contain pieces of that movie animation.

    However, when playing audio-only MPEG files or MOD music files, the
    puzzle pieces will instead be parts of a realtime animation that
    "VidSlide" will draw, based on the music being played.

    This is similar to the extremely cool "Virtual Light Machine" ("VLM")
    software which was part of the Atari Jaguar CD Drive accessory.
    VLM was created by "The Yak," Jeff Minter.


DOCUMENTATION
-------------
  Important documentation for "VidSlide" is contained in multiple files.
  Please see them:

    AUTHORS        - Credits for who made this game.
    CHANGES        - Changes since the previous versions of "VidSlide."
    COPYING        - The GNU Public License, which "VidSlide" is under.
    INSTALL        - Instructions on requirements, compiling and installing.
    README         - (This file.)  Game story, usage, rules and controls.
    TODO           - A wish-list for this version of "VidSlide."


RUNNING THE GAME
----------------
  Just type "./vidslide" to get started.

  The program accepts some options:

    --disable-sound     - If sound support was compiled in, this will
                          disable it for this session of the game.

    --fullscreen        - Run in fullscreen mode.
                          (Note: Under Linux, if this doesn't work, 
                          you will need to run the game as root.)

    --help              - Display a help message summarizing command-line
                          options, copyright, and game controls.

    --usage             - Display a brief message summarizing command-line
                          options.

  A screen will appear with a menu bar at the top.


MENUS
-----
  At the top of the "VidSlide" window (or your screen, if you're running
  in fullscreen mode) has a number of menus.

  Use the mouse pointer to point at a menu and click once (and then let go
  of the mouse button).  The options accessable from that menu will appear
  and you will hear a "pop" sound.

  To select an option, move the mouse over the option's name.  (As you do
  this, any options under the mouse pointer will become highlighted, and
  you will hear a "click" sound.)  Click the mouse button to select an
  option.

  To cancel using a menu, simply click anywhere outside of the list of
  options.  (ie, make sure no option is highlighted).

  Note: If you click the name of the menu currently being display, it will
  close.  However, if you click a different menu's name, the current menu
  will close, and the menu whose name you clicked will appear.

  Many menus have a selection of options, one of which will describe a
  current setting.  Any settings which are currently activate will appear
  with a check symbol on the left of their item name in a menu.

  FILE
  ----
    This menu is used to load MPEG and MOD files, pause and quit the game,
    and display the "About" screen.

    LOAD MPEG
    ---------
      Foobar!

    LOAD MOD
    --------
      Foobar!

    PAUSE
    -----
      If a file has been loaded and you have not yet completed the puzzle,
      this menu option will pause and unpause the game.

      When the game is paused, the puzzle will appear as a grey rectangle
      (so that you cannot cheat the clock by examining a freeze-frame of
      the puzzle image).  Also, the "PAUSE" option of the "FILE" menu will
      be checked.

    ABOUT
    -----
      This will display some information about the game.
      If a game was being played, the pause option will also activate.

      Click the mouse to remove the about display.  (If a game was being
      played, you will need to manually unpause it using the "PAUSE" option
      in the file menu.)

    QUIT
    ----
      This will quit the game and close the window.

  SIZE
  ----
    This menu lets you select how many pieces a puzzle will be made out of.
    The options include 3x3, 4x4, 5x5, 6x6, 7x7 and 8x8.

    The current size of the puzzle will be checked.

    When you select a size from the menu (unless it's the current, checked
    setting), the game will reset!

  GAME
  ----
    This menu lets you select how the pieces of the puzzle can be moved.

    The current game mode will be checked.

    When you select a game mode from the menu (unless it's the current,
    checked setting), the game will reset!

    DRAG
    ----
      In this mode, you move the pieces around by clicking on them with
      the left mouse button, and then "dragging" them to a different spot.
      The piece you're holding will move along with the mouse pointer, and
      the spot where it came from will be blank.

      When you place a piece on a new spot, the piece you're holding, and
      the piece in the spot where you wish to drop the piece you're holding,
      will trade places.

      If you let go of a piece outside of the puzzle area or on top of the
      place where you picked it up from, it will simply go back where you
      picked it up from.

    SLIDE
    -----
      Foobar!

    PERFECTION
    ----------
      This game is just like "DRAG," except that whenever you place a piece
      in a spot where it does not belong, the entire puzzle will be
      rescrambled!

      If you let go of a piece outside of the puzzle area or on top of the
      place where you picked it up from, it will simply go back where you
      picked it up from.  Even if the spot it came from is wrong, the puzzle
      will not rescramble.


  FLIP
  ----
    This menu controls whether or not some pieces in the game will appear
    flipped horizontally.

    The current flip mode will be checked.

    When you select a flip mode from the menu (unless it's the current,
    checked setting), the game will reset!

    NORMAL
    ------
      In this mode, no pieces will be flipped.

    FLIPPED
    -------
      In this mode, some pieces will be flipped.  You must have them
      flipped in the correct direction for the puzzle to be completed.

      You can flip pieces by clicking on them with the middle or right
      mouse buttons.

  VOLUME
  ------
    This menu controls the sound volume (of both the animation file and
    sound effects).

    The settings are percentages of volume of the original file.
    The current volume setting will be checked.

      100 - Full sound
      75
      50
      25
      0   - Sound off

   Note: If sound was disabled using the "--disable-sound" flag, the
   volume will always stay at the "0" setting, even if you try to change it.


CONTROLS
--------
  The game is played completely with the mouse.

  MOUSE CONTROLS
  --------------
    MOVEMENT
    --------
      Moving the mouse moves the cursor on the screen.

    LEFT (BUTTON 1) CLICK
    ---------------------
      This can open menus and select menu items.

      In "DRAG" and "PERFECTION" game modes, it can pick up puzzle pieces.

    LEFT (BUTTON 1) RELEASE
    -----------------------
      In "DRAG" and "PERFECTION" game modes, it drops puzzle pieces.

    MIDDLE CLICK (BUTTON 2)
    RIGHT CLICK (BUTTON 3)
    ----------------------
      This can open menus and select menu items.

      In the "FLIPPED" flip mode, it can flip a piece.

  KEYBOARD CONTROLS
  -----------------
    Foobar!

  WINDOW MANAGER CONTROLS
  -----------------------
    Closing the "VidSlide" window will quit the game.  This is similar to
    selecting the "QUIT" option from the "FILE" menu.


Foobar!
