/*
  soundmgr.h
  
  socket-based sound manager for /dev/audio
  
  by Bill Kendrick
  kendrick@zippy.sonoma.edu
  http://zippy.sonoma.edu/kendrick/
  
  April 22, 1998 - April 22, 1998
  */


#ifndef SOUNDMGR_H
#define SOUNDMGR_H

#define SOUND_BUF 102400  /* size of sound buffer: */

int pipefds[2];
int devaudio_fd;
unsigned char sound_data[SOUND_BUF];


/* Creates the sound manager process: */

FILE * soundmgr(int num_sounds, char * * files);


/* Plays a sound: */

void playsound(FILE * fs, int which_sound);


/* Silences sound manager: */

void silence(FILE * fs);

#endif
