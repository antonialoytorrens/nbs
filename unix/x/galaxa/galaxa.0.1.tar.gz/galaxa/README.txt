README.txt for "GalaXa"

GalaXa

version 0.1, April 22, 1998

by Bill Kendrick
New Breed Software
(c) 1998

kendrick@zippy.sonoma.edu
http://zippy.sonoma.edu/kendrick/


CHANGES
-------
Changes since v.0.0 (April 10, 1998)

NEW FEATURES:

* High score / High level / High hit-ratio tables
* Pause has been added (press [P])
* You can only shoot three bullets at a time. (6 if you've got two ships)
* Cool explosion graphics
* Planets in the background (starfield)
* Asteroids (find out where!)
* Sound effects (use "-sound")

FIXED BUGS:

* The left "Master" was in the wrong place. :)
* Sometimes bugs would already be in place when starting out the first
  level of a new game.  This has been fixed.


ABOUT GALAXA
------------
GalaXa is Freeware.  If you like it, please send your comments, a donation,
a postcard, anything!  See the "CONTACT" section at the end of this document
to find out how to reach me.

GalaXa is a space game based loosely on "Galaga," an arcade classic
released by NAMCO in the 1981.  GalaXa is an X-Window game written in
C in my spare time.


STORY
-----
You are a lone starfighter pilot battling the evil race of
GalaXans, giant bug-like creatures who have been meanacing the
peaceful inhabitants of your solar system.


REQUIREMENTS
------------
GalaXa requires an X-Server with at least 4-bit greyscale depth.
16-bit or higher color depth is recommended, but hopefully shouldn't
be required.  If you have problems running the game, please e-mail me
and I'll see if I can help:  kendrick@zippy.sonoma.edu


INSTALLING
----------
To install GalaXa, simply type:

  make

The "makefile" contains defaults which you may need to change.
(Most likely, you may need to change the "XLIB" and "CFLAGS" to
conform to your system's setup.)


RUNNING
-------
You can run GalaXa by simply typing

  galaxa

Some useful command line arguements are, in this order:

  display   - for example, "$DISPLAY" or "computer:0.0"
  level     - for example, "-l10" or "-L5"
  greyscale - use "-grey" or "-g"
  sound     - use "-sound" or "-s"

Some example calls:

  ./galaxa $DISPLAY -l15 -grey
  galaxa home.computer.net:0.0 &
  galaxa my.server:0.0 -l3 &
  galaxa -sound

etc.


After a moment, a screen will appear with a count-down from 10 to 1,
the text "ONE MOMENT", and a percentage bar.

At this point, the game is loading all of the graphics onto your X-Server.
Once the counter reaches 0 and the percentage bar reaches "full",
the title screen will appear.


THE TITLE SCREEN
----------------
The title screen will display the title graphic, credits, and the
currently-selected level.  Use the following keystrokes:

[L]      - Select the next higher level.
[K]      - Select the previous level.
[Space]  - Begin the game at the selected level.
[Q]      - Quit the program.
[1]      - Next title screen
[2]      - Jump to high scores title screen

If you wait for a few moments, a number of useful help screens will appear,
explaining things like what each object in the game is.  The high score
will also appear.

If you wish to page through these manually (rather than wait), you can
press [1] repeatedly to get to each screen, and eventually back to the
title display.  Press [2] to get to the high score screen.

If you press [L] or [K] to change the level, and you are viewing a help
screen, the title display will reappear.

If you press [Space] to begin a game, and you are viewing a help screen,
the game will begin.


THE GAME SCREEN
---------------
The game screen looks similar to this text representation:

   _________________________________________ 
  | Score: 00000    Level: 01     Lives: 03 |  <-- Game status
  |                                         |
  |                   X     X               |
  |                                         |
  |          %     %     %     %     %      |
  |                                         |  <-- Evil GalaXan aliens
  |          &     &     &     &     &      |
  |                                         |
  |                                         |
  |                                         |
  |                                         |
  |                                         |
  |                                         |
  |                                         |
  |                      A                  |  <-- Your fighter
  |_________________________________________|


PLAYING THE GAME
----------------
Each level begins with you warping forward in space.

After you've dropped out of hyperspace, the aliens begin coming onto the
screen and taking their place at the top.

Note: Some aliens are only escorts, and will abruptly turn towards the
bottom of the screen and attack!  After they've left the screen,
they will not come back.  Try to shoot them for extra points, and
definitely watch out not to get killed!

You control your ship by moving it left and right and firing bullets
up towards the aliens.

The aliens move side to side (or in other directions) at the top of the
screen and occasionally fly down to attack you.  They fire bullets down
towards you when they're attacking.


LIVES AND GAME OVER
-------------------
You start the game with 3 ships (lives).

If you are hit by an alien's bullet or by an actual alien, you loose
a ship.

When the number of lives reaches 0, the game is over.

Note: During game over, you can see your "Hit-Ratio."  This is the
percentage of hits to shots.  (For example, if you fired 1000 bullets
during the game, but only 500 of them hit, your hit-ratio would be 50.00%.)

Press [Q] to quit from the "Game Over" screen.  If you beat one of the
10 high scores and/or high levels, or you beat the high hit-ratio, you
will be prompted for your initials (for each).

When the game returns to the title-screen mode, the high score screen
will appear first, with your high scores highlighted.


KEYBOARD CONTROLS
-----------------
THe keyboard controls in the game are simple:

[Left Arrow]  - Slide ship left.  (Release to stop sliding.)
[Right Arrow] - Slide ship right. (Release to stop sliding.)
[Space]       - Fire a bullet.
[P]           - Pause/unpause.
[Q]           - Quit.  Return to the title screen.


MEET THE ALIENS
---------------
There are three categories of aliens.  (See the game's help screens to
see what they look like.)

  MASTERS
    * There are always two, at the very top of the screen.
    * They look like flies.
    * When they attack, they are often escorted by the alien just below
      them.
    * When they reach the bottom, they sometimes fire a "tractor beam."
      If you hit this beam, your ship will begin spinning up towards
      the alien, and will be captured by it!  See below for more info.
    * Masters require TWO shots to be killed!  (They change color
      when shot the first time.)
    * Masters are worth 250 points.

  GUARDS
    * There are always five, making a row just below the Masters.
    * They look like beetles.  (There are two styles of Guards.)
    * They often escort Masters down during attacks.
    * Guards are worth 100 points.

  DRONES
    * There are five or ten, making up one or two rows just below the
      Guards.
    * Sometimes they are bee-like, sometimes they are ant-like.
    * Drones are worth 50 points.

  SUPER-MASTERS
    * These are gigantic Masters which appear on every 10th level.
    * They require many many hits to be destroyed!  Watch out!
    * Like regular Masters, they can capture your ship.  (See below.)
    * Super-Masters are worth lots of points!


GETTING CAPTURED
----------------
If you allow your ship to be captured by a Master or Super-Master,
your ship will be in their control!  (It will appear red.)

Note: You loose a life when this happens, so definitely avoid getting
captured if you only have one life left!

When the Master attacks, the captured ship will follow.  If you can,
try shooting the Master (but NOT the ship) while it's attacking.
If you do so, the captured ship will be freed (it will change from
red to white) and will fly down towards your current ship.

When both ships touch, they will dock and you will control both ships
at once.  This provides both double firepower (you shoot two shots at
once) AND extra protection (if one ship is destroyed, the other remains
in action)!

Note: If you destroy the Master while it is NOT attacking (sitting in it's
"home" postion at the top of the screen), the captured ship will NOT
be freed.  It will instead take the place of the Master and fly down to
attack you itself!  It can even capture your ship, like a Master can.
Be careful!


FUTURE RELEASES
---------------
This is the first beta release of GalaXa.  It's been released simply
to find out what people think of the game.

A future release will have:

  Challenge Stages
  More sound effects
  ...anything else you'd like!  E-mail me!


CREDITS
-------
Original Concept   - NAMCO, 1981
X-Window Game Code - Bill Kendrick, New Breed Software, 1998
Graphics           - Bill Kendrick, with some graphics stolen off of
                     numerous websites
Sounds             - Bill Kendrick, and many sounds from the original
                     "Galaga" arcade game by NAMCO, 1981


MAKE CONTACT
------------
Please send your questions, comments, suggestions and dontations to:

Go Postal: Bill Kendrick
           7673 Melody Drive
           Rohnert Park
           California 94928, USA

Phone:     1-707-795-1234 ext. 2 voicemail
           1-707-795-5678 fax

E-mail:    kendrick@zippy.sonoma.edu

Website:   http://zippy.sonoma.edu/kendrick/
