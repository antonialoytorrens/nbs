/* mpgfx.c
   bill kendrick
   bill@newbreedsoftware.com

   2003.Mar.16 - 2003.Apr.5
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include "SDL.h"
#include "SDL_image.h"
#include "smpeg.h"

#define min(a,b) ((a < b) ? a : b)
#define max(a,b) ((a > b) ? a : b)
#define sign(a) ((a < 0) ? -1 : (a == 0) ? 0 : 1)

void myabort(char * str);
void getpixel(SDL_Surface * surf, int x, int y, Uint8 * r, Uint8 * g, Uint8 * b);
void putpixel(SDL_Surface * surf, int x, int y, Uint8 r, Uint8 g, Uint8 b);
void rgbtohsv(Uint8 r8, Uint8 g8, Uint8 b8, float *h, float *s, float *v);
void hsvtorgb(float h, float s, float v, Uint8 *r8, Uint8 *g8, Uint8 *b8);


enum {
  MODE_NORMAL,
  MODE_THRESHOLD,
  MODE_COLORTHRESHOLD,
  MODE_WIGGLE,
  MODE_ZOOMY,
  MODE_VIDEO,
  MODE_WIND,
  MODE_MOTIONTRAIL,
  MODE_PANSCAN,
  MODE_SPHERE,
  MODE_MATRIX,
  MODE_CONTRAST,
  MODE_REFLECT,
  MODE_BLEND,
  MODE_FIRE,
  MODE_CARTOON,
  MODE_BW,
  MODE_BRIGHTINVERT,
  MODE_SEPIA,
  NUM_MODES
};

char * mode_names[NUM_MODES] = {
  "Normal",
  "Threshold",
  "Colorthreshold",
  "Wiggle",
  "Zoomy",
  "Video",
  "Wind",
  "Motiontrail",
  "Pan/scan",
  "Sphere",
  "Matrix",
  "Contrast",
  "Reflect",
  "Blend",
  "Fire",
  "Cartoon",
  "B/W",
  "Brightinvert",
  "Sepia"
};

#define MAX_PAN_M 4
#define THR_PAN 16 

typedef struct point_type {
  int x, y;
} point_type;


int main(int argc, char * argv[])
{
  SDL_Surface * screen, * backsurf, * tmpsurf;
  SMPEG * mpeg;
  SMPEG_Info info;
  SDL_Rect dest, src;
  int done, mode, x, y, dith, cnt, zoom, i, push, override, xx, yy;
  float h, s, v;
  Uint8 r, g, b, grey, r2, g2, b2, r3, g3, b3, grey2;
  Uint32 big_grey;
  SDL_Event event;
  Uint32 last_time, now_time;
  double cur_time;
  Uint32 cur_frame;
  int rr, gg, bb;
  int pan_x, pan_y, pan_xm, pan_ym, pan_want_x, pan_want_y, pan_want_count;
  point_type * * map;
  float org_x, org_y, zo_x, zo_y, W2, H2;
  int matrix[24][80];
  int matrix_row_falling[80], matrix_row_timer[80], matrix_fall_height[80];
  SDL_Surface * img_matrix[8];
  char fname[128];


  if (argc != 2)
  {
    printf("Usage: %s mpgfile.mpg\n", argv[0]);
    exit(1);
  }

 
  /* Init SDL video: */

  if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0)
    myabort("SDL_Init");
 

  /* Load MPEG: */
  
  mpeg = SMPEG_new(argv[1], &info, 1);
  if (SMPEG_error(mpeg))
    myabort("SMPEG_new");


  /* Create window: */
  
  screen = SDL_SetVideoMode(info.width, info.height, 16, SDL_SWSURFACE);
  if (screen == NULL)
    myabort("SDL_SetVideoMode");

 
  /* Set MPEG options: */
  
  SMPEG_enablevideo(mpeg, 1);
  SMPEG_enableaudio(mpeg, 1);
  SMPEG_setvolume(mpeg, 100);
  SMPEG_loop(mpeg, 1);


  /* Have MPEG write into a back surface: */

  backsurf = SDL_AllocSurface(screen->flags,
		              info.width, info.height,
			      screen->format->BitsPerPixel,
			      screen->format->Rmask,
			      screen->format->Gmask,
			      screen->format->Bmask,
			      0);
  if (backsurf == NULL)
    myabort("SDL_AllocSurface");
  
  tmpsurf = SDL_AllocSurface(screen->flags,
		             info.width, info.height,
			     screen->format->BitsPerPixel,
			     screen->format->Rmask,
			     screen->format->Gmask,
			     screen->format->Bmask,
			     0);
  if (tmpsurf == NULL)
    myabort("SDL_AllocSurface");

  SMPEG_setdisplay(mpeg, backsurf, NULL, NULL);


  /* Calculate sphere map: */

  W2 = (float)info.width / 2.0;
  H2 = (float)info.height / 2.0;
  
  map = (point_type * *) malloc(info.height * sizeof(point_type *));
  for (y = 0; y < info.height; y++)
    map[y] = (point_type *) malloc(info.width * sizeof(point_type));

  for (y = 0; y < info.height; y++)
  {
    for (x = 0; x < info.width; x++)
    {
      org_x = (float)x - W2;
      org_y = (float)y - H2;

      zo_x = sqrt(abs(org_x) * W2) * sign(org_x) / 2;
      zo_y = sqrt(abs(org_y) * H2) * sign(org_y) / 2;

      map[y][x].x = zo_x + W2;
      map[y][x].y = zo_y + H2;
    }
  }


  /* Clear matrix: */

  for (x = 0; x < 80; x++)
  {
    matrix_row_timer[x] = (rand() % 40) + 20;
    matrix_row_falling[x] = rand() % 2;
    matrix_fall_height[x] = (rand() % 20);

    for (y = 0; y < 24; y++)
    {
      matrix[y][x] = 0;
    }
  }


  /* Load matrix font: */

  for (i = 0; i < 8; i++)
  {
    snprintf(fname, sizeof(fname), "matrix%d.png", i);

    img_matrix[i] = IMG_Load(fname);
    if (img_matrix[i] == NULL)
      myabort("IMG_Load");
  }


  /* Begin! */

  done = 0;
  mode = 0;
  mode = MODE_CARTOON;
  override = 0;
  cnt = 0;
  
  pan_x = 0;
  pan_y = 0;
  pan_want_x = pan_x;
  pan_want_y = pan_y;
  pan_xm = 0;
  pan_ym = 0;
  
  SMPEG_play(mpeg);

  do
  {
    last_time = SDL_GetTicks();

    while (SDL_PollEvent(&event))
    {
      if (event.type == SDL_QUIT)
	done = 1;
      else if (event.type == SDL_KEYDOWN)
      {
	if (event.key.keysym.sym == SDLK_ESCAPE)
	  done = 1;
	else if (event.key.keysym.sym == SDLK_SPACE)
	{
	  override = !override;
	  SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));
	}
	else if (event.key.keysym.sym == SDLK_RIGHT)
	{
	  SMPEG_skip(mpeg, 5.0);
	}
	else if (event.key.keysym.sym == SDLK_LEFT)
	{
	  // SMPEG_getinfo(mpeg, &info);

	  // cur_time = info.current_time; // - 5.0;
	  //if (cur_time < 0.0)
	  //  cur_time = 0.0;
	  // printf("Going back to: %f\n", cur_time);

	  SMPEG_rewind(mpeg);
          SMPEG_play(mpeg);
	  // SMPEG_skip(mpeg, cur_time);
	}
      }
      else if (event.type == SDL_MOUSEBUTTONDOWN)
      {
	if (event.button.button == 1)
	  mode = (mode + 1) % NUM_MODES;
	else
	{
	  if (mode > 0)
	    mode--;
	  else
	    mode = NUM_MODES - 1;
	}
	printf("%s\n", mode_names[mode]);
	SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));
      }
    }


    if (mode == MODE_NORMAL || override)
    {
      SDL_BlitSurface(backsurf, NULL, screen, NULL);
    }
    else if (mode == MODE_THRESHOLD)
    {
      dith = (cnt % 2);
      
      for (y = 0; y < info.height; y++)
      {
	dith = !dith;
	
	for (x = 0; x < info.width; x++)
	{
	  dith = !dith;

	  getpixel(backsurf, x, y, &r, &g, &b);

	  grey = (r + g + b) / 3;

	  if (grey < 85)
	    grey = 0;
	  else if (grey < 170)
	    grey = 255 * dith;
	  else
	    grey = 255;

	  putpixel(screen, x, y, grey, grey, grey);
	}
      }
    }
    else if (mode == MODE_COLORTHRESHOLD)
    {
      for (y = 0; y < info.height; y++)
      {
	for (x = 0; x < info.width; x++)
	{
	  getpixel(backsurf, x, y, &r, &g, &b);

	  r = (r / 85) * 85;
	  g = (g / 85) * 85;
	  b = (b / 85) * 85;
	  
	  putpixel(screen, x, y, r, g, b);
	}
      }
    }
    else if (mode == MODE_WIGGLE)
    {
      for (y = 0; y < info.height; y++)
      {
	src.x = 0;
	src.y = y;
	src.w = info.width;
	src.h = 1;

	dest.x = cos(((y + (cnt * 4)) * 2) / 180.0 * M_PI) * 20;
	dest.y = y;
	
	SDL_BlitSurface(backsurf, &src, screen, &dest);
      }
    }
    else if (mode == MODE_ZOOMY)
    {
      i = cnt / 4;
      
      if ((i % 20) < 10)
      {
        zoom = (i % 10) + 1;
      }
      else
      {
        zoom = 11 - (i % 10);
      }
     
      if (zoom > 1)
      {
        for (y = 0; y < info.height; y = y + zoom)
        {
	  for (x = 0; x < info.width; x = x + zoom)
	  {
	    getpixel(backsurf, x, y, &r, &g, &b);

	    dest.x = x;
	    dest.y = y;
	    dest.w = zoom;
	    dest.h = zoom;

	    SDL_FillRect(screen, &dest,
		         SDL_MapRGB(screen->format, r, g, b));
	  }
	}
      }
      else
      {
	SDL_BlitSurface(backsurf, NULL, screen, NULL);
      }
    }
    else if (mode == MODE_VIDEO)
    {
      for (y = 0; y < info.height; y++)
      {
	for (x = 0; x < info.width; x++)
	{
	  getpixel(backsurf, x, y, &r, &g, &b);

	  i = ((y + x) % 3);
	  
	  if (i == 0)
	  {
	    g = g / 2;
	    b = b / 2;
	  }
	  else if (i == 1)
	  {
	    r = r / 2;
	    b = b / 2;
	  }
	  else
	  {
	    r = r / 2;
	    g = g / 2;
	  }

	  putpixel(screen, x, y, r, g, b);
	}
      }
    }
    else if (mode == MODE_WIND)
    {
      for (y = 0; y < info.height; y++)
      {
	push = (rand() % 4);

	for (x = 3; x < info.width; x++)
	{
	  rr = 0;
	  gg = 0;
	  bb = 0;

	  for (i = -3; i <= 0; i++)
	  {
	    getpixel(backsurf, x + i, y, &r, &g, &b);

	    rr = rr + r;
	    gg = gg + g;
	    bb = bb + b;
	  }
	  
	  r = rr >> 2;
	  g = gg >> 2;
	  b = bb >> 2;
	  
	  putpixel(screen, x + push, y, r, g, b);
	}
      }
    }
    else if (mode == MODE_MOTIONTRAIL)
    {
      for (y = 0; y < info.height; y++)
      {
	for (x = 0; x < info.width; x++)
	{
	  getpixel(backsurf, x, y, &r, &g, &b);
	  getpixel(tmpsurf, x, y, &r2, &g2, &b2);


	  /* Chop lowest bits to remove some MPEG artifacts (noise): */

	  i = 6;
	  grey = (((r + g + b) / 3) >> i) << i;
	  grey2 = (((r2 + g2 + b2) / 3) >> i) << i;

	  rgbtohsv(r, g, b, &h, &s, &v);
          hsvtorgb(h, s, ((float)((grey2 - grey) / 2 + 128)) / 255.0,
		   &r, &g, &b);

	  putpixel(screen, x, y, r, g, b);
	}
      }

      SDL_BlitSurface(backsurf, NULL, tmpsurf, NULL);
    }
    else if (mode == MODE_PANSCAN)
    {
      pan_want_count = 0;
      
      for (y = 0; y < info.height; y++)
      {
	for (x = 0; x < info.width; x++)
	{
	  getpixel(backsurf, x, y, &r, &g, &b);
	  getpixel(tmpsurf, x, y, &r2, &g2, &b2);


	  /* Chop lowest bits to remove some MPEG artifacts (noise): */

	  r = (r >> 4) << 4;
	  g = (g >> 4) << 4;
	  b = (b >> 4) << 4;

	  grey = abs(((r2 - r) / 2) + ((g2 - g) / 2) + ((b2 - b) / 2) / 3);

	  if (grey > 64)
	  {
	    pan_want_x = pan_want_x + (x - info.width / 2);
	    pan_want_y = pan_want_y + (y - info.height / 2);
	    pan_want_count++;
	  }
	}
      }

      if (pan_want_count > 0)
      {
        pan_want_x = (pan_want_x / pan_want_count);
        pan_want_y = (pan_want_y / pan_want_count);
      }

      if (pan_x > pan_want_x - THR_PAN)
      {
	if (pan_xm > -MAX_PAN_M)
	  pan_xm--;
      }
      else if (pan_x < pan_want_x + THR_PAN)
      {
	if (pan_xm < MAX_PAN_M)
	  pan_xm++;
      }
      else
	pan_xm = 0;

      if (pan_y > pan_want_y - THR_PAN)
      {
	if (pan_ym > -MAX_PAN_M)
	  pan_ym--;
      }
      else if (pan_y < pan_want_y + THR_PAN)
      {
	if (pan_ym < MAX_PAN_M)
	  pan_ym++;
      }
      else
	pan_ym = 0;

      pan_x = pan_x + pan_xm;
      pan_y = pan_y + pan_ym;

      src.x = 0;
      src.y = 0;
      src.w = info.width;
      src.h = info.height;
      
      dest.x = - pan_x;
      dest.y = - pan_y;
    
#ifdef SHOWREST
      SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));
      
      SDL_BlitSurface(backsurf, &src, screen, &dest);

      for (y = 0; y < info.height; y = y + 4)
      {
	dest.x = 0;
	dest.y = y;
	dest.w = info.width;
	dest.h = 3;
	
        SDL_FillRect(screen, &dest, SDL_MapRGB(screen->format, 0, 0, 0));
      }
#endif
     
      src.x = pan_x - 64 + info.width / 2;
      src.y = pan_y - 64 + info.height / 2;
      src.w = 128;
      src.h = 128;

      dest.x = info.width / 2 - 64;
      dest.y = info.height / 2 - 64;

      SDL_BlitSurface(backsurf, &src, screen, &dest);

      SDL_BlitSurface(backsurf, NULL, tmpsurf, NULL);
    }
    else if (mode == MODE_SPHERE)
    {
      for (y = 0; y < info.height; y++)
      {
	for (x = 0; x < info.width; x++)
	{
	  getpixel(backsurf, x, y, &r, &g, &b);
	  putpixel(screen, map[y][x].x, map[y][x].y, r, g, b);
	}
      }
    }
    else if (mode == MODE_MATRIX)
    {
      for (y = 0; y < 24; y++)
      {
	for (x = 0; x < 80; x++)
	{
          big_grey = 0;
	  i = 0;

	  for (yy = 0; yy <= info.height / 24; yy = yy + 3)
	  {
	    for (xx = 0; xx <= info.width / 80; xx = xx + 3)
	    {
	      getpixel(backsurf,
		       x * (info.width / 80) + xx,
		       y * (info.height / 24) + yy,
		       &r, &g, &b);
	    
	      big_grey = big_grey + ((r + g + b) / 3);
              i++;
	    }
	  }

	  grey = big_grey / i;

	  if (abs(matrix[y][x] - grey) > 32)
	    matrix[y][x] = grey;
	}
      }
      
     
      for (y = 23; y >= 1; y--)
      {
	for (x = 0; x < 80; x++)
	{
	  if (matrix_row_falling[x])
	  {
	    if (y > matrix_fall_height[x])
	      matrix[y][x] = matrix[y - 1][x];
	    
	    matrix[y - 1][x] /= 2;
	  }
	}
      }


      for (y = 0; y < 24; y++)
      {
	for (x = 0; x < 80; x++)
	{
	  dest.x = x * ((info.width / 80) + 1);
	  dest.y = y * ((info.height / 24) - 1);

	  src.x = 0;
	  src.y = (rand() % 4) * 10;
	  src.w = 4;
	  src.h = 10;
	  
	  SDL_BlitSurface(img_matrix[matrix[y][x] / 32], &src, screen, &dest);
	}
      }

      for (x = 0; x < 80; x++)
      {
	matrix_row_timer[x]--;

	if (matrix_row_timer[x] <= 0)
	{
	  matrix_row_falling[x] = rand() % 2;
	  matrix_row_timer[x] = (rand() % 40) + 20;
	  matrix_fall_height[x] = (rand() % 20);
	}
      }
    }
    else if (mode == MODE_CONTRAST)
    {
      for (y = 0; y < info.height; y++)
      {
	for (x = 0; x < info.width; x++)
	{
	  getpixel(backsurf, x, y, &r, &g, &b);

	  if (r < 128)
	    r = (Uint8) ((float) r * 0.9);
	  else
	    r = max((Uint8) ((float) (r - 128) * 1.1) + 128, 255);
	  
	  if (g < 128)
	    g = (Uint8) ((float) g * 0.9);
	  else
	    g = max((Uint8) ((float) (g - 128) * 1.1) + 128, 255);
	  
	  if (b < 128)
	    b = (Uint8) ((float) b * 0.9);
	  else
	    b = max((Uint8) ((float) (b - 128) * 1.1) + 128, 255);

	  putpixel(screen, x, y, r, g, b);
	}
      }
    }
    else if (mode == MODE_REFLECT)
    {
      src.x = 0;
      src.y = 0;
      src.w = info.width;
      src.h = info.height * 0.75;

      dest.x = 0;
      dest.y = 0;

      SDL_BlitSurface(backsurf, &src, screen, &dest);

      for (y = (info.height) * 0.75; y < info.height; y++)
      {
	src.x = 0;
	src.y = info.height - (y - (info.height * 0.75)) - (info.height * 0.25);
	src.w = info.width;
	src.h = 10;

	dest.x = 0;
	dest.y = pow(2, (y - (info.height * 0.75)) / 10) + (info.height * 0.75);
	
	SDL_BlitSurface(backsurf, &src, screen, &dest);
      }
    }
    else if (mode == MODE_BLEND)
    {
      for (y = 0; y < info.height; y++)
      {
	for (x = 0; x < info.width; x++)
	{
	  getpixel(backsurf, x, y, &r, &g, &b);

	  getpixel(screen, x, y, &r2, &g2, &b2);

	  putpixel(screen, x, y,
	           (r + r2) / 2,
	           (g + g2) / 2,
	           (b + b2) / 2);
	}
      }
    }
    else if (mode == MODE_FIRE)
    {
      for (y = 0; y < info.height - 4; y = y + 4)
      {
	for (x = 0; x < info.width - 4; x = x + 4)
	{
	  getpixel(backsurf, x, y, &r, &g, &b);
	  getpixel(screen, x, y, &r2, &g2, &b2);

	  if ((r + g + b) / 3 > 128 && (r2 + g2 + b2) / 3 < 192)
	  {
	    dest.x = x;
	    dest.y = y;
	    dest.w = 4;
	    dest.h = 4;

	    SDL_FillRect(screen, &dest,
			 SDL_MapRGB(screen->format, r, g, b));
	  }

	  getpixel(screen, x, y, &r, &g, &b);
	  getpixel(screen, x - 4, y + 4, &r2, &g2, &b2);
	  getpixel(screen, x + 4, y + 4, &r3, &g3, &b3);
	 
	  r = (r + r2 + r3) / 3;
	  g = (g + g2 + g3) / 5;
	  b = (b + b2 + b3) / 6;

	  dest.x = x;
	  dest.y = y;
	  dest.w = 4;
	  dest.h = 4;
	
	  SDL_FillRect(screen, &dest,
		       SDL_MapRGB(screen->format, r, g, b));
	}
      }
    }
    else if (mode == MODE_CARTOON)
    {
      for (y = 0; y < info.height - 2; y = y + 2)
      {
	for (x = 0; x < info.width - 2; x = x + 2)
	{
	  getpixel(backsurf, x, y, &r, &g, &b);
	  getpixel(backsurf, x + 1, y, &r2, &g2, &b2);
	  getpixel(backsurf, x, y + 1, &r3, &g3, &b3);
	  
	  if ((abs(r - r2) > 16 || abs (r - r3) > 16) &&
              (abs(g - g2) > 16 || abs (g - g3) > 16) &&
	      (abs(b - b2) > 16 || abs (b - b3) > 16))
	  {
	    r = g = b = 0;
	  }
	  else
	  {
	    r = (r / 32) * 32;
	    g = (g / 32) * 32;
	    b = (b / 32) * 32;

	    if (abs(r - g) < 64 && abs(g - b) < 64 && abs(r - b) < 64)
	    {
	      r = g = b = r;
	    }
	    else if (r > 200 && g > 200 && g > 200)
	    {
	      r = g = b = 255;
	    }
	    else if (r < 32 && g < 32 && b < 32)
	    {
	      r = g = b = 0;
	    }
	    else
	    {
	      rgbtohsv(r, g, b, &h, &s, &v);

	      h = floorf(h / 90.0) * 90.0;
	      v = floorf(v * 20) / 20;
	    
              hsvtorgb(h, s * 0.75, v, &r, &g, &b);
	    }
	  }
	  
          dest.x = x;
	  dest.y = y;
	  dest.w = 2;
	  dest.h = 2;

	  putpixel(screen, x, y, r, g, b);
	  
	  SDL_FillRect(screen, &dest,
		       SDL_MapRGB(screen->format, r, g, b));
	}
      }
    }
    else if (mode == MODE_BW)
    {
      for (y = 0; y < info.height; y++)
      {
	for (x = 0; x < info.width; x++)
	{
	  getpixel(backsurf, x, y, &r, &g, &b);
	  
	  if ((r + g + b) / 3 < 128)
            r = g = b = 0;
	  else
	    r = g = b = 255;

	  putpixel(screen, x, y, r, g, b);
	}
      }
    }
    else if (mode == MODE_BRIGHTINVERT)
    {
      for (y = 0; y < info.height - 1; y = y + 2)
      {
	for (x = 0; x < info.width - 1; x = x + 2)
	{
	  getpixel(backsurf, x, y, &r, &g, &b);

	  rgbtohsv(r, g, b, &h, &s, &v);
	  hsvtorgb(h, s, 1.0 - v, &r, &g, &b);
	  
	  putpixel(screen, x, y, r, g, b);
	  putpixel(screen, x + 1, y, r, g, b);
	  putpixel(screen, x, y + 1, r, g, b);
	  putpixel(screen, x + 1, y + 1, r, g, b);
	}
      }
    }
    else if (mode == MODE_SEPIA)
    {
      for (y = 0; y < info.height - 1; y = y + 2)
      {
	for (x = 0; x < info.width - 1; x = x + 2)
	{
	  getpixel(backsurf, x, y, &r, &g, &b);

	  rgbtohsv(r, g, b, &h, &s, &v);
	  hsvtorgb(40, s / 2 + 0.5, 0.25 + v / 2, &r, &g, &b);
	  
	  putpixel(screen, x, y, r, g, b);
	  putpixel(screen, x + 1, y, r, g, b);
	  putpixel(screen, x, y + 1, r, g, b);
	  putpixel(screen, x + 1, y + 1, r, g, b);
	}
      }
    }
    
    


    cnt++;

    SDL_Flip(screen);
   
    now_time = SDL_GetTicks();
    if (now_time < last_time + 20)
    {
      SDL_Delay(now_time - last_time + 20);
    }
  }
  while (!done);

  return (0);
}


void myabort(char * str)
{
  fprintf(stderr, "Error: %s: %s\n", str, SDL_GetError());
  exit(1);
}


void getpixel(SDL_Surface * surf, int x, int y, Uint8 * r, Uint8 * g, Uint8 * b)
{
  int bpp;
  Uint8 * p;
  Uint32 pixel;

  if (x >= 0 && y >= 0 && x < surf->w && y < surf->h)
  {
    pixel = 0;

    bpp = surf->format->BytesPerPixel;

    p = (Uint8 *) (((Uint8 *)surf->pixels) +
		    (y * surf->pitch) +
		    (x * bpp));

    if (bpp == 1)
      pixel = *p;
    else if (bpp == 2)
      pixel = *(Uint16 *)p;
    else if (bpp == 3)
    {
      /* FIXME! */
    }
    else if (bpp == 4)
      pixel = *(Uint32 *)p;

    SDL_GetRGB(pixel, surf->format, r, g, b);
  }
}


void putpixel(SDL_Surface * surf, int x, int y, Uint8 r, Uint8 g, Uint8 b)
{
  int bpp;
  Uint8 * p;
  Uint32 pixel;
 
  if (x >= 0 && y >= 0 && x < surf->w && y < surf->h)
  {
    pixel = SDL_MapRGB(surf->format, r, g, b);

    bpp = surf->format->BytesPerPixel;

    p = (Uint8 *) (((Uint8 *)surf->pixels) +
		    (y * surf->pitch) +
		    (x * bpp));

    if (bpp == 1)
      *p = pixel;
    else if (bpp == 2)
      *(Uint16 *)p = pixel;
    else if (bpp == 3)
    {
      /* FIXME! */
    }
    else if (bpp == 4)
      *(Uint32 *)p = pixel;
  }
}

void rgbtohsv(Uint8 r8, Uint8 g8, Uint8 b8, float *h, float *s, float *v)
{
  float rgb_min, rgb_max, delta, r, g, b;

  r = (r8 / 255.0);
  g = (g8 / 255.0);
  b = (b8 / 255.0);

  rgb_min = min(r, min(g, b));
  rgb_max = max(r, max(g, b));
  *v = rgb_max;

  delta = rgb_max - rgb_min;

  if (rgb_max == 0)
    {
      /* Black */

      *s = 0;
      *h = -1;
    }
  else
    {
      *s = delta / rgb_max;

      if (r == rgb_max)
        *h = (g - b) / delta;
      else if (g == rgb_max)
        *h = 2 + (b - r) / delta;     /* between cyan & yellow */
      else
        *h = 4 + (r - g) / delta;     /* between magenta & cyan */

      *h = (*h * 60);                 /* degrees */

      if (*h < 0)
        *h = (*h + 360);
    }
}


void hsvtorgb(float h, float s, float v, Uint8 *r8, Uint8 *g8, Uint8 *b8)
{
  int i;
  float f, p, q, t, r, g, b;

  if (s == 0)
    {
      /* Achromatic (grey) */

      r = v;
      g = v;
      b = v;
    }
  else
    {
      h = h / 60;
      i = floor(h);
      f = h - i;
      p = v * (1 - s);
      q = v * (1 - s * f);
      t = v * (1 - s * (1 - f));

      if (i == 0)
        {
          r = v;
          g = t;
          b = p;
        }
      else if (i == 1)
        {
          r = q;
          g = v;
          b = p;
        }
      else if (i == 2)
        {
          r = p;
          g = v;
          b = t;
        }
      else if (i == 3)
        {
          r = p;
          g = q;
          b = v;
        }
      else if (i == 4)
        {
          r = t;
          g = p;
          b = v;
        }
      else
        {
          r = v;
          g = p;
          b = q;
        }
    }


  *r8 = (Uint8) (r * 255);
  *g8 = (Uint8) (g * 255);
  *b8 = (Uint8) (b * 255);
}
