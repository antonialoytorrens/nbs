README.txt for mpgfx

Bill Kendrick
bill@newbreedsoftware.com
http://www.newbreedsoftware.com/

March 16, 2003 - December 13, 2003


About
-----
  In March 2003, shortly after being laid off from my full-time job,
  I had a lot of free time, and very little code I had to write.
  So, to keep myself entertained, I created a number of 'toy' applications,
  including this one, "mpgfx."

  All "mpgfx" does is play an MPEG video in a window, and allow you to
  apply visual effects, which are done to each frame, as the animation plays.


Requirements
------------
  "mpgfx" uses SDL for the graphics display, and keyboard and mouse input.

    http://www.libsdl.org/

  It uses the SDL-based "SMPEG" library to load and play MPEG animations.

    http://www.icculus.org/smpeg/

  And it uses the SDL helper library, "SDL_image", to load a set of PNG
  images used for one of the effects.

    http://www.libsdl.org/projects/SDL_image/


Compiling
---------
  Once the necessary libraries are installed (including any developmental
  headers needed; e.g., from the "SDL-devel" Linux RPM package, etc.),
  you can just type:

    make

  to compile "mpgfx."


Usage
-----
  Run the "mpgfx" command, and give it an MPEG video file to play.
  For example:

    ./mpgfx SomeRandomVideo.mpg


Controls
--------
  Left Mouse Click - Switch to next visual effect.
  Right Mouse Click - Switch to previous visual effect.
  [Space] key - Toggle visual effects on and off.
  [Left] arrow key - Restart the video from the beginning.
  [Right] arrow key - Skip ahead a few seconds.

  When clicking to change the visual effect, the effect's name is displayed
  to 'stdout' (e.g., on the terminal where you ran the "mpgfx" command).
  

Effects
-------
  Cartoon - [Cel Shading]
    An attempt to both reduce the number of colors, as well as emphasize
    shapes by outlining them in black.
    
  B/W - [Black and white]
    A simple threshold algorithm.  Pixels are either black, or white.
    Reminiscient of Atari 800 high resolution graphics mode.
    
  Brightinvert - 
    Brightness is inverted, but colors are left alone.

  Sepia - 
    Display the video in a 'sepia tone,' a la antique photographs.

  Normal -
    No effect.
  
  Threshold - 
    Similar to black and white mode.  Checkerboard dithering is used to
    give the illusion of a shade of grey.
    
  Colorthreshold - [Posterize]
    Dark, medium and bright values are used, but with some color saturation.
    
  Wiggle - [Sinus]
    The frame is 'wiggled' using a sine wave.
    
  Zoomy - [Pixelate]
    The image is pixelated to varying degrees.
    
  Video - 
    The image is composed of small red, green and blue pixels.
    
  Wind - 
    A random motion blur is applied to each scanline of the image, to give
    a windy effect.
    
  Motionaltrail - [Difference / Emboss]
    The value difference between two frames are shown.  Lack of movement
    appears as grey.  Lots of motion between two frames appears as black or
    white, depending on the difference.
    
  Pan/scan - 
    A smaller segment of the video is shown, and an attempt is made to
    follow the parts of the video containing the most motion.  A virtual
    'camera' points at the screen, and moves around as the video plays.
    Large changes in the frame draw the camera's attention.
    It ALMOST works well. ;^)  I'm sure the folks at MIT and Stanford would
    laugh their asses off at me.

  Sphere - 
    A failed attempt at trying to quickly (without any true 3D or heavy
    floating point operations) map a flat image to a spherical shape.
    
  Matrix - 
    The scene is composed of small, ever-changing little green characters
    of varying degrees of brightness; and sometimes falling.  A poor attempt
    at the "Matrix" movie effect, and the screensavers that followed.
    
  Contrast - 
    The contrast of the pixels' values are increased (similar to B/W and
    Threshold effects), but the color and saturation remain the same.
    All it really ends up doing is showing just how loss MPEG video encoding
    can be for some images.
    
  Reflect - 
    A nice reflection of the video is displayed at the bottom of the window.
    Less like water, more like tiled glass.
    
  Blend - [Motion blur]
    The display is composed of the previous frames, averaged together.
    Creates a stop-motion/go-motion style effect.
    
  Fire - 
    The pixels of the image are used to seet a simple 'fire' effect.


The end
-------
  That's it!  This was just a toy I wrote to satisfy my need to code neat
  little snippets.  I haven't looked at the code in over 6 months, but when
  I ran it again, it seemed interesting enough to release to the web.

  Enjoy!


-bill!
bill@newbreedsoftware.com

