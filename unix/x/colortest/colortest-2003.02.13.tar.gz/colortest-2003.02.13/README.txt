colortest
bill kendrick <bill@newbreedsoftware.com>
2003.02.13

What is it?
  A simple application that fills the screen with a particular color.
  Useful for finding dead pixels, for example.

Requirements
  SDL libraries and headers - http://www.libsdl.org/
  (If you don't have "sdl-config" installed, and installed SDL from
  RPM or Debian packages, be sure to install the "libsdl-devel" package, too!)

Compiling
  Type "make" and it should compile.

Running
  colortest runs from its own directory (it expects to find the included BMP
  image files there):

    ./colortest

  The screen will fill with black, and Red, Green and Blue values will appear
  at the top left of the screen.

Keyboard controls
  Changing colors:
    [R], [G] and [B] alter the red, green and blue values, respectively.

    Alone, the keys increase the value by 16.
    With [CTRL], the keys increase the value by 1.
    With [SHIFT], the keys drecrease the value by 16.
    With [SHIFT] and [CTRL] both, the keys decrease the value by 1.

    In other words, [SHIFT] decreases, [CTRL] makes the step smaller.

  Value display
    Press [?] to make the RGB value display on the screen disappear and
    reappear.

    Press [P] to change the position of the display; top left corner, or
    bottom left corner.

  Quitting
    [ESCAPE] or [Q] quit

Command-line options:
  --window
    Run colortest in a window, rather than (trying to) open in fullscreen mode.
  
  --width W  (-w W)
    Set the screen (or window) width to W.  e.g., 640, 800, 1024, 1280

  --height H  (-h H)
    Set the screen (or window) height to H.  e.g., 480, 600, 768, 1024

  --depth D  (-d D)
    Set the screen to a depth of D bits per pixel, if possible.   e.g., 16, 24

  --hidevals
    Initially hide the value display.  ([?] will make it visible again)

  --bottom
    Initially display the values at the bottom.  ([P] will toggle to top)

  --red R, --green G, --blue B    (-r R, -g G, -b B)
    Set the initial value for red, green and/or blue.  (Default is 0 for each.)
    ([R], [G] and [B] keys still alter the values, of course.)

  --usage, --help (-h)
    Display program usage: command-line arguments and summary of key controls.


The end!

-bill!

