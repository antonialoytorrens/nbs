/* colortest.c */
/* bill kendrick <bill@newbreedsoftware.com> */
/* 2003.02.13 */

#include <stdio.h>
#include <stdlib.h>
#include <SDL.h>


/* Globals: */

SDL_Surface * screen;
SDL_Surface * img_numbers;
int value_corner;


/* Local function prototypes: */

SDL_Surface * loadbmp(char * fname);
void showvalue(int y, SDL_Surface * label, int value);
void alter(int * val, SDLMod mod);
int nextarg(int argc, char * argv[], int * i);
void usage(FILE * fs);


/* --- MAIN --- */

int main(int argc, char * argv[])
{
  int width, height, depth, fullscreen;
  int red, green, blue;
  int show_values;
  int i, do_update, done;
  SDL_Surface * img_red, * img_green, * img_blue;
  SDL_Event event;
  SDLKey key;
  SDLMod mod;
  

  /* Default settings: */
  
  width = 800;
  height = 600;
  depth = 16;
  fullscreen = 1;
  
  red = 0;
  green = 0;
  blue = 0;

  show_values = 1;
  value_corner = 0;

  
  /* Get command-line args: */

  for (i = 1; i < argc; i++)
  {
    if (strcmp(argv[i], "--width") == 0 || strcmp(argv[i], "-w") == 0)
    {
      width = nextarg(argc, argv, &i);
    }
    else if (strcmp(argv[i], "--height") == 0 || strcmp(argv[i], "-h") == 0)
    {
      height = nextarg(argc, argv, &i);
    }
    else if (strcmp(argv[i], "--depth") == 0 || strcmp(argv[i], "--bpp") == 0 ||
	     strcmp(argv[i], "-d") == 0)
    {
      depth = nextarg(argc, argv, &i);
    }
    else if (strcmp(argv[i], "--usage") == 0 ||
	     strcmp(argv[i], "--help") == 0 || strcmp(argv[i], "--help") == 0)
    {
      usage(stdout);
      exit(0);
    }
    else if (strcmp(argv[i], "--window") == 0)
    {
      fullscreen = 0;
    }
    else if (strcmp(argv[i], "--hidevals") == 0)
    {
      show_values = 0;;
    }
    else if (strcmp(argv[i], "--bottom") == 0)
    {
      value_corner = 1;
    }
    else if (strcmp(argv[i], "--red") == 0 || strcmp(argv[i], "-r") == 0)
    {
      red = nextarg(argc, argv, &i);
    }
    else if (strcmp(argv[i], "--green") == 0 || strcmp(argv[i], "-g") == 0)
    {
      green = nextarg(argc, argv, &i);
    }
    else if (strcmp(argv[i], "--blue") == 0 || strcmp(argv[i], "-b") == 0)
    {
      blue = nextarg(argc, argv, &i);
    }
    else
    {
      fprintf(stderr, "\nUnknown option: %s\n", argv[i]);
      usage(stderr);
      exit(1);
    }
  }
  
  
  /* Init SDL and open screen: */
  
  if (SDL_Init(SDL_INIT_VIDEO) < 0)
  {
    fprintf(stderr, "SDL_Init() failed:\n%s\n", SDL_GetError());
    exit(1);
  }

  screen = SDL_SetVideoMode(width, height, depth, fullscreen?SDL_FULLSCREEN:0);

  if (screen == NULL)
  {
    fprintf(stderr, "SDL_SetVideoMode() (%d x %d, %d bpp) failed:\n%s\n",
		    width, height, depth, SDL_GetError());
    SDL_Quit();
    exit(1);
  }

  
  /* Enable key repeat: */

  SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY, SDL_DEFAULT_REPEAT_INTERVAL);
  

  /* Load bitmaps: */

  img_red = loadbmp("red.bmp");
  img_green = loadbmp("green.bmp");
  img_blue = loadbmp("blue.bmp");
  
  img_numbers = loadbmp("numbers.bmp");



  /* Main loop! */

  done = 0;
  do_update = 1;
  
  do
  {
    if (do_update)
    {
      /* Fill the screen with a color: */
	  
      SDL_FillRect(screen, NULL,
	           SDL_MapRGB(screen->format, red, green, blue));


      /* Show values: */

      if (show_values)
      {
        showvalue(0, img_red, red);
        showvalue(50, img_green, green);
        showvalue(100, img_blue, blue);
      }

      SDL_Flip(screen);
    }

    do_update = 0;


    /* Wait for an event: */

    SDL_WaitEvent(&event);

    if (event.type == SDL_QUIT)
    {
      /* Window close; kill signal; whatever... */

      done = 1;
    }
    else if (event.type == SDL_KEYDOWN)
    {
      /* Key pressed! */

      key = event.key.keysym.sym;
      mod = event.key.keysym.mod;


      if (key == SDLK_ESCAPE || key == SDLK_q)
      {
	done = 1;
      }
      else if (key == SDLK_r)
      {
	alter(&red, mod);
	do_update = 1;
      }
      else if (key == SDLK_g)
      {
	alter(&green, mod);
	do_update = 1;
      }
      else if (key == SDLK_b)
      {
	alter(&blue, mod);
	do_update = 1;
      }
      else if (key == SDLK_SLASH)
      {
	show_values = !show_values;
	do_update = 1;
      }
      else if (key == SDLK_p)
      {
	value_corner = !value_corner;
	do_update = 1;
      }
    }
  }
  while (!done);
  


  /* All done! */

  SDL_Quit();

  return 0;
}


/* Load a BMP file and set its color key (transparent pixel): */

SDL_Surface * loadbmp(char * fname)
{
  SDL_Surface * tmp, * ret;


  /* Load the image: */

  tmp = SDL_LoadBMP(fname);
  if (tmp == NULL)
  {
    fprintf(stderr, "SDL_LoadBMP(\"%s\") failed\n%s\n", fname, SDL_GetError());

    SDL_Quit();
    exit(1);
  }


  /* Set the color key: */

  if (SDL_SetColorKey(tmp, (SDL_SRCCOLORKEY | SDL_RLEACCEL),
		      SDL_MapRGB(tmp->format, 0xFF, 0x00, 0xFF)) == -1)
  {
    fprintf(stderr, "SDL_SetColorKey() failed (%s)\n%s\n",
		    fname, SDL_GetError());
    SDL_Quit();
    exit(1);
  }


  /* Convert to display format for quicker blitting: */
  
  ret = SDL_DisplayFormat(tmp);
  if (ret == NULL)
  {
    fprintf(stderr, "SDL_DisplayFormat() failed (%s)\n%s\n",
		    fname, SDL_GetError());
    SDL_Quit();
    exit(1);
  }

  SDL_FreeSurface(tmp);
  
  
  return ret;
}


/* Show one of the RGB values by blitting bitmaps: */

void showvalue(int y, SDL_Surface * label, int value)
{
  SDL_Rect src, dest;


  if (value_corner == 1)
  {
    /* Bottom left corner! */

    y = screen->h - 150 + y;
  }


  /* Blit label: */
  
  dest.x = 0;
  dest.y = y;

  SDL_BlitSurface(label, NULL, screen, &dest);


  /* Blit value: */

  /* 1st digit... */

  dest.x = 200;
  dest.y = y;

  src.x = ((img_numbers->w) / 10) * (value / 100);
  src.y = 0;
  src.w = (img_numbers->w) / 10;
  src.h = img_numbers->h;
  
  SDL_BlitSurface(img_numbers, &src, screen, &dest);
  
  
  /* 2nd digit... */

  dest.x = 200 + ((img_numbers->w) / 10);
  dest.y = y;

  src.x = ((img_numbers->w) / 10) * ((value % 100) / 10);
  src.y = 0;
  src.w = (img_numbers->w) / 10;
  src.h = img_numbers->h;
  
  SDL_BlitSurface(img_numbers, &src, screen, &dest);
 
  
  /* 3rd digit... */
  
  dest.x = 200 + ((img_numbers->w) / 10) * 2;
  dest.y = y;

  src.x = ((img_numbers->w) / 10) * (value % 10);
  src.y = 0;
  src.w = (img_numbers->w) / 10;
  src.h = img_numbers->h;
  
  SDL_BlitSurface(img_numbers, &src, screen, &dest);
}


/* Change one of the RGB values; how its changed depends on modifier keys: */
/* (NONE = +16, SHIFT = -16, CTRL = +1, SHIFT+CTRL = -1) */

void alter(int * val, SDLMod mod)
{
  int rate;
  

  /* Determine rate and direction (based on modifier keys): */
  
  rate = 16;
  
  if (mod & KMOD_CTRL)
    rate = 1;

  if (mod & KMOD_SHIFT)
    rate = -rate;


  /* Change the value: */
  
  *val = *val + rate;


  /* Keep the value in bounds (0-255): */

  if (*val < 0)
    *val = 0;
  else if (*val > 255)
    *val = 255;
}


/* Get the integer value of the next argument on the command line: */

int nextarg(int argc, char * argv[], int * i)
{
  int val;
  
  
  /* Is there another arg? */
	
  if (*i + 1 >= argc)
  {
    fprintf(stderr, "Missing argument to %s!\n", argv[*i]);
    usage(stderr);
    exit(1);
  }


  /* Get the arg's value, increment the arg counter: */
  
  val = atoi(argv[(*i) + 1]);
  *i = *i + 1;

  return(val);
}


/* Display usage message/error: */

void usage(FILE * fs)
{
  fprintf(fs, "\n"
	      "Usage: colortest [options] | --usage | --help (-h)\n"
              "Options:\n"
	      "  --width  W (-w)          - Set window or screen width\n"
	      "  --height H (-h)          - Set window or screen height\n"
	      "  --depth  D (-d, --bpp)   - Set screen depth (e.g., 16 bpp)\n"
	      "  --window                 - Open a window, not fullscreen\n"
	      "\n"
	      "  --hidevals               - Hide RGB by default ([?] toggles)\n"
	      "  --bottom                 - RGB at bottom ([P] toggles)\n"
	      "\n"
	      "  --red    R (-r)          - Initial red value (0-255)\n"
	      "  --green  G (-g)          - Initial blue value (0-255)\n"
	      "  --blue   B (-b)          - Initial green value (0-255)\n"
	      "\n"
	      "Keyboard controls:\n"
	      "  [R]                      - Increase red by 16\n"
	      "  [SHIFT]-[R]              - Decrease red by 16\n"
	      "  [CTRL]-[R]               - Increase red by 1\n"
	      "  [SHIFT]-[CTRL]-[R]       - Decrease red by 1\n"
	      "\n"
	      "  [G]                      - Increase green by 16\n"
	      "  [SHIFT]-[G]              - Decrease green by 16\n"
	      "  [CTRL]-[G]               - Increase green by 1\n"
	      "  [SHIFT]-[CTRL]-[G]       - Decrease green by 1\n"
	      "\n"
	      "  [B]                      - Increase blue by 16\n"
	      "  [SHIFT]-[B]              - Decrease blue by 16\n"
	      "  [CTRL]-[B]               - Increase blue by 1\n"
	      "  [SHIFT]-[CTRL]-[B]       - Decrease blue by 1\n"
	      "\n"
	      "  [?]                      - Toggle display of RGB values\n"
	      "  [P]                      - Toggle RGB display's position\n"
	      "\n"
	      "  [ESCAPE]                 - Quit\n"
	      "  [Q]                      - Quit\n"
	      );
}

