/*
  explosions.c

  A simplified 3D world with alpha-blended objects that look kind of like
  fireworks or sparks.  Also has fun screen effects.

  Run with "--help" for runtime keyboard and mouse controls.
  See COPYING.txt for license!

			      
  by Bill Kendrick
  bill@newbreedsoftware.com
  http://www.newbreedsoftware.com/bill/

  July 30, 2001 - October 29, 2001
*/


#include <stdio.h>     /* For fprintf()'ing errors & sprintf()'ing filenames */
#include <stdlib.h>    /* For exit(), rand()/srand() and qsort() functions */
#include <math.h>      /* For cos() and sin() trig. functions */
#include <SDL.h>       /* For graphics init., blitting and event functions */
#include <SDL_image.h> /* For loading PNG-format image files */


#define VERSION "2001.10.29"


#ifndef M_PI
#define M_PI 3.14159
#endif


/* Constants: */

#define FPS 30              /* Max frames-per-second to display */
#define NUM_EXPLOSIONS 500  /* Max number of mouse-based explosions to track */
#define MAX_BITS 1000       /* Max number of bits we can cue/render */


#define F_WIDTH 160         /* Window width */
#define F_HEIGHT 160        /* Window height */

#define H_WIDTH (F_WIDTH / 2)    /* Horizontal center of window */
#define H_HEIGHT (F_HEIGHT / 2)  /* Vertical center of window */

#define BURST_PER_FRAME 20  /* How many to shoot out of mouse */
#define BURST_SPEED 5       /* How far to shoot out of mouse */
#define GRAVITY 0.50        /* Affects of gravity (per frame) */

#define DISTANCE 500.0      /* Distance (Z) to the 3D space's origin */
#define ASPECT 400.0        /* When doing "screen_x = (x / z) + (width / 2)"
			       and "screen_y = (y / z) + (height / 2)"
			       calculations, this scales down the effect of
			       the "Z" value.  Changing it can cause a nifty
			       'fish-eye'-lens effect! :) */


/* Effect toggles' possible values: */

enum { FALSE, TRUE };
enum { NOZOOM, ZOOMIN, ZOOMOUT, NUM_ZOOM_MODES };


/* Effect toggles: */

int fade = FALSE;           /* Toggle with [F] key */
int zoom = NOZOOM;          /* Change with [Z] key */
int rotate = FALSE;         /* Toggle with [R] key */
int blur = FALSE;           /* Toggle with [B] key */
int dissolve = FALSE;       /* Toggle with [D] key */
int heat = FALSE;           /* Toggle with [H] key */


/* Number of "spark#.png" files available, and human-readable names: */

enum { YELLOW, GREEN, CYAN, BLUE, RAINBOW, NUMS, PEPPERS, NUM_BITMAPS };


/* Where in the PNGs each of the sprites begin, and their sizes: */
/* Probably almost easier to calculate, but we're drawing so many per frame! */

int src_start[9] = {0, 3, 8, 15, 24, 35, 48, 63, 80};
int src_width[9] = {3, 5, 7, 9, 11, 13, 15, 17, 19};


/* Types: */

/* Explosions that come out of the mouse, and which we must track, move,
 * and, in the end, destroy: */

typedef struct explosion_type {
  int alive, time, c;   /* Is the explosion alive?  How old?  Color? */
  float x, y, z;        /* X,Y,Z coordinates in 3D space */
  float xm, ym, zm;     /* Speed/direction (eg, x < 0 == moving left) */
} explosion_type;


/* Each bit (which will be queued, sorted, and then rendered each frame) */

typedef struct bit_type {
  int x, y, z, c;       /* Screen X and Y coordinates.
			   Z corresponds to size (which sprite to draw)
			   and also is used when sorting (closer objects
			   are drawn last, so that they overlap the
			   farther ones */
} bit_type;


/* Globals */

SDL_Surface * screen;   /* Window we're drawing into */
SDL_Surface * spark[NUM_BITMAPS];   /* Sprites (loaded from the PNG files) */
explosion_type explosions[NUM_EXPLOSIONS];   /* Explosions to track */
bit_type bits[MAX_BITS];  /* Queue for bits (sorted, then rendered) */
int num_bits;  /* How many bits in the queue */
float anglex, angley;  /* Angle to rotate world (controlled w/ arrow keys) */
float cos_anglex, sin_anglex,  /* When world-rotation angles change, these */
      cos_angley, sin_angley;  /* are recalculated, so that trig functions
				  are called only a few times per frame,
				  rather than once for EVERY object drawn! */


/* Local function prototypes: */

void event_loop(void);                           /* Main event loop */
void setup_sdl(void);                            /* Open window, load PNG */
void init(void);                                 /* Init variables */
void add_explosion(float x, float y, float z,    /* Add expl-bit to array */
		   float xm, float ym, float zm,
		   int time, int color);
void calc3d(float x, float y, float z,           /* Convert 2D to 3D */
	    int * sx, int * sy, int * ss);
void recalctrig(void);                           /* Re-COS/SIN after rotate */
void queuebit(float x, float y, float z, int c); /* Convert object for queue */
void addbit(int x, int y, int z, int c);         /* Add object to queue */
void sortbits(void);                             /* Sort queue */
int compare_bits(const void * b1, const void * b2);  /* (For sorting) */
void drawbits(void);                             /* Draw queue */
void fadeout(void);                              /* Fade effect */
void zoomout(int zoom_x, int zoom_y);            /* Zoom-out effect */
void zoomin(int zoom_x, int zoom_y);             /* Zoom-in effect */
void rotatescreen(int angle);                    /* Rotation effect */
void blurscreen();                               /* Blur effect */
void dissolvescreen();                           /* Dissolve effect */
void heatscreen();                               /* Heat (flame) effect */
Uint32 getpixel(SDL_Surface * surface,           /* (For effects) */
		int x, int y);
void putpixel(SDL_Surface * surface,             /* (For effects) */
	      int x, int y, Uint32 pixel);


/* --- MAIN --- */

int main(int argc, char * argv[])
{
  int i;
  

  /* Deal with any command-line options: */

  for (i = 1; i < argc; i++)
    {
      if (strcmp(argv[i], "--version") ==0 ||
	  strcmp(argv[i], "-v") == 0)
	{
	  /* Show version: */
	  
	  printf("\n\"explosions\" demo version " VERSION "\n");
	  printf("By Bill Kendrick (bill@newbreedsoftware.com) 2001\n\n");
	  
	  
	  /* Quit happily: */
	  
	  exit(0);
	}
      else if (strcmp(argv[i], "--help") ==0 ||
	       strcmp(argv[i], "-h") == 0)
	{
	  /* Show help (runtime controls): */
	  
	  printf("\n\"explosions\" demo help\n"
		 "Keyboard:\n"
		 "  ARROWS  - Rotate screen\n"
		 "  F       - Toggle 'fade' effect\n"
		 "  Z       - Switch to next 'zoom' effect\n"
		 "  R       - Toggle 'rotation' effect\n"
		 "  B       - Toggle 'blur' effect\n"
		 "  D       - Toggle 'dissolve' effect\n"
		 "  H       - Toggle 'heat' (fire) effect\n"
		 "  KEYPAD  - Move zoom center\n"
		 "  PGUP/DN - Change rotation angle\n"
		 "  ESCAPE  - Quit\n\n");
	  
	  
	  /* Quit happily: */

	  exit(0);
	}
      else
	{
	  /* Print usage: */
	  
	  fprintf(stderr, "\n\"explosions\" demo Usage:\n");
	  fprintf(stderr, "%s [--version | --help]\n\n", argv[0]);
	  
	  
	  /* And quit with an error: */
	  
	  exit(1);
	}
    }
  
  
  /* Open window, create surface, load PNG images: */

  setup_sdl();


  /* Clear tracked explosions array and other globals: */
  
  init();


  /* MAIN EVENT LOOP! */
  
  event_loop();
  

  /* All done... */

  SDL_Quit();
  
  return(0);
}


/* Event loop: */

void event_loop(void)
{
  int i, done, count;
  int mouse_down, mouse_x, mouse_y;
  int left_down, right_down, up_down, down_down;
  int kpleft_down, kpright_down, kpup_down, kpdown_down;
  int pgdn_down, pgup_down;
  int zoom_x, zoom_y, rotation_angle;
  int color;
  Uint32 now, then;
  SDL_Event event;
  SDLKey key;
  

  /* No keys or mouse buttons have been pressed yet... */
  
  mouse_down = 0;
  mouse_x = 0;
  mouse_y = 0;
  
  left_down = 0;
  right_down = 0;
  up_down = 0;
  down_down = 0;
  
  pgdn_down = 0;
  pgup_down = 0;

  kpleft_down = 0;
  kpright_down = 0;
  kpup_down = 0;
  kpdown_down = 0;


  /* Reset effect variables: */
  
  zoom_x = H_WIDTH;
  zoom_y = H_HEIGHT;
  rotation_angle = 5;


  /* Reset global counter */
  
  count = 0;
  
  
  /* Current 'drawing' color (changed with BUTTON-3 clicks) */
  
  color = 0;
  

  /* MAIN EVENT LOOP IS HERE! */
  
  done = 0;  /* (We haven't decided to quit yet) */
  
  do
    {
      /* Get the current time (used at the end of the loop, just before
       * the while, to make sure framerate doesn't exceed chosen FPS! */

      then = SDL_GetTicks();


      /* Increase global counter */
      
      count += 2;
      
      
      /* Handle events: */
      
      while (SDL_PollEvent(&event))
	{
          if (event.type == SDL_QUIT)
            {
              /* Quit request! (eg, the window's "close" button was clicked) */

              done = 1;
            }
	  else if (event.type == SDL_KEYDOWN)
	    {
              /* A keypress! */
		    
              key = event.key.keysym.sym;
	      
	      if (key == SDLK_ESCAPE)
		done = 1;         /* ESCAPE - quit! */
	      else if (key == SDLK_LEFT)
		left_down = 1;    /* LEFT - record that left is pressed */
	      else if (key == SDLK_RIGHT)
		right_down = 1;   /* (ditto for RIGHT) */
	      else if (key == SDLK_UP)
		up_down = 1;      /* (ditto for UP) */
	      else if (key == SDLK_DOWN)
		down_down = 1;    /* (ditto for DOWN) */
	      else if (key == SDLK_PAGEDOWN)
		pgdn_down = 1;    /* (ditto for PAGEDOWN) */
	      else if (key == SDLK_PAGEUP)
		pgup_down = 1;    /* (ditto for PAGEUP) */
	      else if (key == SDLK_KP4)
		kpleft_down = 1;  /* (ditto for KPLEFT) */
	      else if (key == SDLK_KP6)
		kpright_down = 1; /* (ditto for KPRIGHT) */
	      else if (key == SDLK_KP8)
		kpup_down = 1;    /* (ditto for KPUP) */
	      else if (key == SDLK_KP2)
		kpdown_down = 1;  /* (ditto for KPDOWN) */
	      else if (key == SDLK_f)
		fade = !fade;     /* F - Toggle 'fade' effect */
	      else if (key == SDLK_z)
	        {
		  /* Z - Switch 'zoom' mode */
			
	          zoom = (zoom + 1) % NUM_ZOOM_MODES;
		}
	      else if (key == SDLK_r)
		rotate = !rotate; /* R - Toggle 'rotation' effect */
	      else if (key == SDLK_b)
		blur = !blur;     /* B - Toggle 'blur' effect */
	      else if (key == SDLK_d)
		dissolve = !dissolve; /* D - Toggle 'dissolve' effect */
              else if (key == SDLK_h)
                heat = !heat;     /* H - Toggle 'heat' (fire) effect */
	    }
	  else if (event.type == SDL_KEYUP)
	    {
	      /* A key-release! */
		    
	      key = event.key.keysym.sym;
	      
	      if (key == SDLK_LEFT)
		left_down = 0;  /* LEFT - record that left was released */
	      else if (key == SDLK_RIGHT)
		right_down = 0; /* (ditto for RIGHT) */
	      else if (key == SDLK_UP)
		up_down = 0;    /* (ditto for UP) */
	      else if (key == SDLK_DOWN)
		down_down = 0;  /* (ditto for DOWN) */
              else if (key == SDLK_PAGEDOWN)
                pgdn_down = 0;  /* (ditto for PAGEDOWN) */
	      else if (key == SDLK_PAGEUP)
		pgup_down = 0;  /* (ditto for PAGEUP) */
	      else if (key == SDLK_KP4)
		kpleft_down = 0;  /* (ditto for KPLEFT) */
	      else if (key == SDLK_KP6)
		kpright_down = 0; /* (ditto for KPRIGHT) */
	      else if (key == SDLK_KP8)
		kpup_down = 0;    /* (ditto for KPUP) */
	      else if (key == SDLK_KP2)
		kpdown_down = 0;  /* (ditto for KPDOWN) */
	    }
	  else if (event.type == SDL_MOUSEBUTTONDOWN)
	    {
	      /* A mouse button was pressed, make note! */
	      
	      mouse_down = 1;


	      /* If it's button-3, change the 'drawing color' */
	      
	      if (event.button.button == 3)
		color = ((color + 1) % NUM_BITMAPS);
	      

	      /* Notice where the mouse was when user clicked: */
	      
	      mouse_x = event.button.x;
	      mouse_y = event.button.y;
	    }
	  else if (event.type == SDL_MOUSEBUTTONUP)
	    {
	      /* A mouse button was released, make note! */
		    
	      mouse_down = 0;
	    }
	  else if (event.type == SDL_MOUSEMOTION)
	    {
	      /* Mouse was moved! */

	      /* Notice where the mouse is now: (for all we know, the
	       * mouse button is still being held, so we should draw
	       * at the new location!) */

              mouse_x = event.motion.x;
	      mouse_y = event.motion.y;
	    }
	}

      
      /* Handle rotation keys: */
      
      if (left_down)
	{
	  /* LEFT key is (still) depressed.  Rotate screen accordingly. */
          
	  anglex = anglex + 5;


	  /* Recalculate trig. values ("cos_angelx", etc.) */
	  
	  recalctrig();
	}
      
      if (right_down)
	{
          /* (ditto for RIGHT) */
		
	  anglex = anglex - 5;
	  recalctrig();
	}
      
      if (up_down)
	{
	  /* (ditto for UP) */
		
	  angley = angley + 5;
	  recalctrig();
	}
      
      if (down_down)
	{
          /* (ditto for DOWN) */
		
	  angley = angley - 5;
	  recalctrig();
	}

      /* NOTE: The above is _not_ an "if / else if / else if ..." block!
       * Since two keys can be pressed at once (say, LEFT and UP), we want
       * to be able to rotate both ways at the same time (eg, diagonal!) :) */


      /* Handle interactive effects controls keys: */

      /* (Rotation effect) */
      
      if (pgup_down)
        {
	  /* PAGEUP key is (still) depressed.  Change rotation effect angle. */
	
	  rotation_angle = (rotation_angle - 2) % 360;
        }
      
      if (pgdn_down)
        {
	  /* (ditto for PAGEDOWN) */

	  rotation_angle = (rotation_angle + 2) % 360;
	}


      /* (Zoom effect) */

      if (kpleft_down)
        {
	  /* KEYPAD_LEFT key is (still) depressed.  Move zoom effect. */

	  zoom_x--;
        }

      if (kpright_down)
        {
	  /* (ditto for KEYPAD_RIGHT) */

	  zoom_x++;
        }

      if (kpup_down)
        {
	  /* (ditto for KEYPAD_UP) */

	  zoom_y--;
        }

      if (kpdown_down)
        {
	  /* (ditto for KEYPAD_DOWN) */

	  zoom_y++;
        }

      
      /* Add explosion bits: */
      
      if (mouse_down)
	{
	  /* Mouse is (still being) clicked, add a few explosion bits: */
		
	  for (i = 0; i < BURST_PER_FRAME; i++)
	    {
	      add_explosion(mouse_x - H_WIDTH,   /* Starting X */
			    mouse_y - H_HEIGHT,  /* Starting Y */
			    0,                   /* Starting Z */
			   
			    /* Starting XM (random left/right) */
			    
			    ((rand() % (BURST_SPEED * 10)) -
			     (BURST_SPEED * 5)) / 10.0,
			    -(rand() % (BURST_SPEED * 10) / 5.0),
			   
			    /* Starting YM (random, mostly up) */
			    
			    ((rand() % (BURST_SPEED * 10)) -
			     (BURST_SPEED * 5)) / 10.0,
			   
			    /* Starting ZM (random in/out) */ 
			    (rand() % 10) + 20,
			    
			    /* Current 'drawing color' */
			    color);
	    }
	}

      
      /* Move explosions: */
      
      for (i = 0; i < NUM_EXPLOSIONS; i++)
	{
	  /* For each explosion that we track that is 'alive'... */
		
	  if (explosions[i].alive)
	    {
	      /* Move its X,Y,Z coords based on the XM,YM,ZM values: */
		    
	      explosions[i].x += explosions[i].xm;
	      explosions[i].y += explosions[i].ym;
	      explosions[i].z += explosions[i].zm;
	      

	      /* Subtly increase the YM value to simulate gravity */
	      
	      explosions[i].ym = explosions[i].ym + GRAVITY;
	      

	      /* Count-down the explosion's lifespan */
	      
	      explosions[i].time--;
	      

	      /* When it hits 0, kill it! */
	      
	      if (explosions[i].time <= 0)
		explosions[i].alive = 0;
	    }
	}


      /* Clear bits queue: */
      
      num_bits = 0;
      
      
      /* "Draw" explosions: */
      /* (eg, add them to the queue) */
      
      for (i = 0; i < NUM_EXPLOSIONS; i++)
	{
	  /* For each explosion that we track that is 'alive'... */
		
	  if (explosions[i].alive)
	    {
              /* If it's not half-dead yet, always draw it...
	       * otherwise, draw it randomly half the time */
		    
	      if (explosions[i].time > 10 ||
		  (rand() % 10) < 5)
		{
		  /* Add this bit to the queue! */
			
		  queuebit(explosions[i].x,
			   explosions[i].y,
			   explosions[i].z,
			   explosions[i].c);
		}
	    }
	}


      /* Draw green borders seen on the screen: */
      
      for (i = -H_WIDTH; i <= H_WIDTH - 40; i = i + 40)
	{
	  /* Top and bottom far lines: */
		
	  queuebit(i + (count % 40), H_HEIGHT, 40, GREEN);
	  queuebit(i - (count % 40) + 40, -H_HEIGHT, 40, GREEN);
	  

	  /* Top and bottom near lines: */

	  queuebit(i + (count % 40), -H_HEIGHT, -40, GREEN);
	  queuebit(i - (count % 40) + 40, H_HEIGHT, -40, GREEN);
	}
      
      for (i = -H_HEIGHT; i <= H_HEIGHT - 40; i = i + 40)
	{
	  /* Left and right far lines: */
		
	  queuebit(-H_WIDTH, i + (count % 40), 40, GREEN);
	  queuebit(H_WIDTH, i - (count % 40) + 40, 40, GREEN);


	  /* Left and right near lines: */
	  
	  queuebit(-H_WIDTH, i - (count % 40) + 40, -40, GREEN);
	  queuebit(H_WIDTH, i + (count % 40), -40, GREEN);
	}

      /* NOTE: The "i +/- (count % 40)" stuff uses the global counter
       * value to position the bits in such a way that as time goes on,
       * the bits appear to be crawling around the edges. */
      
     
      /* Draw the strange multicolored "Y" shape in the center: */
      
      for (i = -20; i <= 0; i = i + 5)
	{
	  queuebit(0, i, 0, GREEN);
	  queuebit(i, -i, 0, CYAN);
	  queuebit(-i, -i, 0, YELLOW);
	}
      
      
      /* Draw everything! */

      if (fade == FALSE && zoom == NOZOOM && rotate == FALSE &&
	  blur == FALSE && dissolve == FALSE && heat == FALSE)
        {
	  /* (Not one effect is enabled, clear the screen) */
		
      	  SDL_FillRect(screen, /* In the window... */
		     NULL,   /* The entire window (dest rect NULL for short) */
		     SDL_MapRGB(screen->format,
		     0x00, 0x00, 0x00));  /* R=0, G=0, B=0 .. black */
	}
      else
        {
	  /* (One or more effect enabled, do them (instead of clearing) */

	  
	  /* (Since we're accessing raw pixel data, lock the surface
	     if we need to) */
	  
	  if (SDL_MUSTLOCK(screen))
	    SDL_LockSurface(screen);
	  
	  
          if (heat == TRUE)
            {
              /* (Heat (burn) the screen) */

              heatscreen();
            }


	  if (fade == TRUE)
            {
	      /* (Fade the screen some) */
	      
	      fadeout();
	    }
	  
	  
	  if (zoom == ZOOMOUT)
	    {
	      /* (Zoom the screen away) */
	      
	      zoomout(zoom_x - H_WIDTH, zoom_y - H_HEIGHT);
	    }
	  else if (zoom == ZOOMIN)
	    {
	      /* (Zoom the screen in) */
	      
	      zoomin(zoom_x - H_WIDTH, zoom_y - H_HEIGHT);
	    }
	  

	  if (rotate == TRUE)
	    {
	      /* (Rotate the screen) */
	      
	      rotatescreen(rotation_angle);
	    }
	  
	  
	  if (blur == TRUE)
	    {
	      /* (Blur the screen) */
	      
	      blurscreen();
	    }


	  if (dissolve == TRUE)
	    {
	      /* (Dissolve the screen) */
	      
	      dissolvescreen();
	    }
	  
	  
	  /* NOTE: The above is _not_ an "if / else if / else if ..." block!
	   * Multiple effects can be enabled at once, so we need to do
	   * all of them! */


	  /* (Unlock the surface if it needed locking) */
	  
	  if (SDL_MUSTLOCK(screen))
	    SDL_UnlockSurface(screen);
	}
      

      /* (Sort all of the bits in the queue according to distance) */
      
      sortbits();


      /* (Draw all of the (now sorted) bits) */
      
      drawbits();


      /* (Swap the window's "backbuffer" onto the screen... eg, make the
       * switch from the previous frame, to the one we just drew, an
       * 'atomic' (all-at-once) event) */
      
      SDL_Flip(screen);
      
      
      /* Pause for even frame rate: */
      
      /* (What time is it now?) */
      
      now = SDL_GetTicks();


      /* (Has enough (or more than enough) time been eaten to make this
       * frame appear at the appropriate time (based on the chosen FPS)?) */
      
      if (now < then + (1000 / FPS))
	{
	  /* (If not... idle until the time has passed) */
	
          SDL_Delay(then + (1000 / FPS) - now);
	}
    }
  while (done == 0);
}


/* Set up: */

void setup_sdl(void)
{
  int i;
  char filename[512];
  

  /* Init SDL's video stuff */
  
  if (SDL_Init(SDL_INIT_VIDEO) < 0)
    {
      fprintf(stderr, "Error: %s\n", SDL_GetError());
      exit(1);
    }


  /* Open a window with 16bpp depth */
  
  screen = SDL_SetVideoMode(F_WIDTH, F_HEIGHT, 16, SDL_HWSURFACE);
  if (screen == NULL)
    {
      fprintf(stderr, "Error: %s\n", SDL_GetError());
      exit(1);
    }
  
  
  /* Set window's title: */
  
  SDL_WM_SetCaption("Explosions", "Explosions");
  
  
  /* Load all of the PNG image files: */
  
  for (i = 0; i < NUM_BITMAPS; i++)
    {
      /* Construct filename ("spark#.png") */
	    
      sprintf(filename, "spark%d.png", i + 1);
      

      /* Load image file:  (SDL_image library call; handles PNG & alpha!) */
      
      spark[i] = IMG_Load(filename);
      if (spark[i] == NULL)
	{
	  fprintf(stderr, "Error: %s - %s\n", filename, SDL_GetError());
	  exit(1);
	}
    }
  

  /* Seed random-number generator (so that it's pretty much random each
   * time we start this program) */
  
  srand(SDL_GetTicks());
}


/* Init: */

void init(void)
{
  int i;
  

  /* Initialize all tracked explosions (make them dead) */
  
  for (i = 0; i < NUM_EXPLOSIONS; i++)
    explosions[i].alive = 0;


  /* Set angle to 'straight-on': */
  
  anglex = 0;
  angley = 0;
  
  /* (and calculate the trig values) */
  
  recalctrig();
}


/* Add an explosion: */

void add_explosion(float x, float y, float z,
		   float xm, float ym, float zm,
		   int time, int color)
{
  int found, i;
  

  /* Look for an empty slot in the "explosions[]" array: */
  
  found = -1;
  
  for (i = 0; i < NUM_EXPLOSIONS && found == -1; i++)
    {
      if (explosions[i].alive == 0)
	found = i;
    }
  

  /* If we found one, fill it! */
  
  if (found != -1)
    {
      explosions[found].alive = 1;    /* Alive is true */
      explosions[found].time = time;  /* Starting age */

      explosions[found].x = x;        /* X, Y, Z coords... */
      explosions[found].y = y;
      explosions[found].z = z;

      explosions[found].xm = xm;      /* XM, YM, ZM values... */
      explosions[found].ym = ym;
      explosions[found].zm = zm;

      explosions[found].c = color;    /* Color */
    }
}


/* Convert 3D to 2D: */

void calc3d(float x, float y, float z,
	    int * sx, int * sy, int * sz)
{
  float xx, yy, zz;
  
  
  /* Taking the "x", "y" and "z" values, rotate them based on the
   * trig. values which should have been recalculated after the
   * "anglex" and "angley" angles-of-rotation were changed... */
  
  xx = (x * cos_anglex) - (z * sin_anglex);
  zz = (x * sin_anglex) + (z * cos_anglex);
  
  yy = (y * cos_angley) - (zz * sin_angley);
  zz = (y * sin_angley) + (zz * cos_angley);
  

  /* Based on the new (rotated) "xx", "yy" and "zz" values,
   * convert them to screen coordinates ("sx" and "sy"), with
   * the 3D world's (0,0,0) origin centered around the center of the window */
  
  *sx = (xx / ((zz + DISTANCE) / ASPECT)) + H_WIDTH;
  *sy = (yy / ((zz + DISTANCE) / ASPECT)) + H_HEIGHT;
  

  /* Keep track of the rotated "Z" value, since we use it to determine
   * which sprite to use (smaller ones for more distant objects, and
   * larger sprites for closer objects), as well as use it to sort the
   * queue of bits-to-draw based on distance (so they overlap each other
   * realistically) */
  
  *sz = ((zz + (DISTANCE / 4)) * 100) / (ASPECT / 10);
}


/* Recalc. trig.: */

void recalctrig(void)
{
  /* Calculate some COS and SIN values based on the "anglex" and "angley"
   * angle-of-rotation values.  They are only calculated when the
   * angles change (rather than calculating them for EACH object!  Eek!) */
	
  cos_anglex = cos(M_PI * anglex / 180.0);
  sin_anglex = sin(M_PI * anglex / 180.0);
  
  cos_angley = cos(M_PI * angley / 180.0);
  sin_angley = sin(M_PI * angley / 180.0);
}


/* "Draw" one explosion bit: */
/* (Add it to the queue of things which will need to be sorted and drawn) */

void queuebit(float x, float y, float z, int c)
{
  int tmp_x, tmp_y, tmp_z;
  

  /* Convert the X,Y,Z coordinates to screen coordinates and
   * that "Z" distance value */
  
  calc3d(x, y, z, &tmp_x, &tmp_y, &tmp_z);
  

  /* If it's TOO close to the viewer, we won't have a large enough
   * sprite to draw for it, so use the largest one. */
  /* NOT THE BEST WAY OF DOING THIS, REALLY */
  
  if (tmp_z < 0)
    tmp_z = 0;
  

  /* Add this bit to the queue of things to sort-and-draw... */
  
  addbit(tmp_x, tmp_y, tmp_z, c);
}


/* Add a bit to the bit queue: */

void addbit(int x, int y, int z, int c)
{
  /* As long as we haven't already filled the queue... */
	
  if (num_bits < MAX_BITS)
    {
      /* Add a bit to the queue: */

      bits[num_bits].x = x;  /* Screen X */
      bits[num_bits].y = y;  /* Screen Y */
      bits[num_bits].z = z;  /* Distance value (for sprite size & sorting) */
      bits[num_bits].c = c;  /* "Drawing color" */
     
      
      /* Increase the size of the queue */
      
      num_bits++;
    }
}


/* Sort the bits by Z: */

void sortbits(void)
{
  qsort(bits,        /* Thing to sort; the queue (an array of "bit_type"'s) */
	num_bits,    /* How many there are; size of the queue */
	sizeof(bit_type), /* Size of data structures being sorted */
	compare_bits);    /* Function to call to do the actual comparisons */
}


/* Comparison function for sortbits()'s qsort() call: */

int compare_bits(const void * b1, const void * b2)
{
  /* Return a positive, negative, or zero value to qsort() depending
     on which of the two bits (b1 and b2) sent had a higher Z value: */
  
  return (((bit_type *) b2) -> z) - (((bit_type *) b1) -> z);
}


/* Draw all bits in the queue: */

void drawbits(void)
{
  int i;
  SDL_Rect src, dest;
  

  /* For each bit in the (by now, sorted) queue... */
  
  for (i = 0; i < num_bits; i++)
    {
      /* If the distance is something we can convert into one of the
       * sprite images: */
	    
      if (bits[i].z >= 0 && bits[i].z < 900)
	{
	  /* Draw the bit at it's X,Y coordinates (taking into account
	   * the size and shape of the sprite itself... we want the
	   * center of the sprite to appear at the calculated screen
	   * coordinates (x,y) */
	  
	  dest.x = bits[i].x - (src_width[8 - (bits[i].z / 100)] / 2);
	  dest.y = bits[i].y - (src_width[8 - (bits[i].z / 100)] / 2);
	  

	  /* Within the surface (the loaded PNG image file), use the
	   * appropriate shape: */
	  
	  src.x = src_start[8 - (bits[i].z / 100)];
	  src.y = 0;
	  
	  src.w = src_width[8 - (bits[i].z / 100)];
	  src.h = src_width[8 - (bits[i].z / 100)];
	 
	 
	  /* (The width and heights of the destination (in 'screen' surface)
	   * should match those of the source (from the loaded PNG)) */
	  
	  dest.w = src.w;
	  dest.h = src.h;
	 

	  /* Actually copy the sprite onto the window's surface!  WHEW!!! */
	  
	  SDL_BlitSurface(spark[bits[i].c],  /* Copy from appropriately-colored
						image... */
			  &src,   /* .. the appropriate sprite. */
			  screen, /* Draw it into the window... */
			  &dest); /* .. at the appropriate place! */
	}
    }
}


/* Fade every pixel in the window (in the "screen" surface) */
/* This func. is called instead of the screen-clearing SDL_FillRect */
/* if "zoom" is set to 'TRUE'... */

void fadeout(void)
{
  int x, y;
  Uint8 r, g, b;
  Uint32 nr, ng, nb;

  
  /* Traverse the entire window: */
  
  for (y = 0; y < F_HEIGHT; y++)
    {
      for (x = 0; x < F_WIDTH; x++)
	{
	  /* Get the RGB values of the pixel: */
	  
	  SDL_GetRGB(getpixel(screen, x, y), screen->format, &r, &g, &b);
	  
	  
	  /* Darken it some */
	  
	  nr = (r * 3) >> 2;  /* == (r * 3) / 4 == r * 0.75 */
	  ng = (g * 3) >> 2;
	  nb = (b * 3) >> 2;
	  
	  
	  /* Draw the new pixel: */
	  
	  putpixel(screen, x, y,
	           SDL_MapRGB(screen->format,
		              (Uint8) nr,
			      (Uint8) ng,
			      (Uint8) nb));
	}
    }
}


/* Zoom the entire image in the window ("screen surface") out some */
/* This func. is called instead of the screen-clearing SDL_FillRect */
/* if "zoom" is set to 'ZOOMOUT'... */

void zoomout(int zoom_x, int zoom_y)
{
  int x, y;
  SDL_Surface * tmp;
  
  
  /* Create a temp. surface to draw onto: */
  
  tmp = SDL_CreateRGBSurface(SDL_HWSURFACE, F_WIDTH, F_HEIGHT, 16,
			     0, 0, 0, 0);
  
  if (tmp == NULL)
    {
      /* Couldn't create it!? */
      
      printf("%s\n", SDL_GetError());
      exit(1);
    }
  
  
  /* Lock temp. surface if we need to (accessing raw pixels) */
  
  if (SDL_MUSTLOCK(tmp))
    SDL_LockSurface(tmp);
  

  /* For every pixel in the window... */
  
  for (y = 0; y < F_HEIGHT; y++)
    {
      for (x = 0; x < F_WIDTH; x++)
	{
	  /* Draw a smaller version of the existing image (screen) into
	     the temp. surface: */
	  
	  putpixel(tmp,          /* Drawing into temp. surface */
		   ((((x - H_WIDTH) * 3) / 4) + /* X scaled by .75*/
		    H_WIDTH +                   /* (re-centered) */
		    zoom_x),                    /* and moved (zoom_x offset) */
		   ((((y - H_HEIGHT) * 3) / 4) +
		    H_HEIGHT +                  /* (ditto for Y) */
		    zoom_y),
		   getpixel(screen, x, y));  /* A pixel from "screen" */
	}
    }
  
  
  /* Unlock temp. surface: */
  
  if (SDL_MUSTLOCK(tmp))
    SDL_UnlockSurface(tmp);
  
  
  /* Copy entire temp. surface into window: */
  
  SDL_BlitSurface(tmp, NULL, screen, NULL);
  
  
  /* Free the temp. surface from memory, now that we're done with it: */
  
  SDL_FreeSurface(tmp);
}


/* Zoom the entire image in the window ("screen surface") in some */
/* This func. is called instead of the screen-clearing SDL_FillRect */
/* if "zoom" has been set to 'ZOOMIN'... */

void zoomin(int zoom_x, int zoom_y)
{
  int x, y;
  Uint32 pix;
  SDL_Surface * tmp;
  int nx, ny;
  
  
  /* Create a temp. surface to draw onto: */
  
  tmp = SDL_CreateRGBSurface(SDL_HWSURFACE, F_WIDTH, F_HEIGHT, 16,
			     0, 0, 0, 0);
  
  if (tmp == NULL)
    {
      /* Couldn't create it!? */
      
      printf("%s\n", SDL_GetError());
      exit(1);
    }
  
  
  /* Lock temp. surface if we need to (accessing raw pixels) */
  
  if (SDL_MUSTLOCK(tmp))
    SDL_LockSurface(tmp);
  

  /* For every pixel in the window... */
  
  for (y = 0; y < F_HEIGHT; y++)
    {
      for (x = 0; x < F_WIDTH; x++)
	{
	  /* Get the pixel's color: */
	  
	  pix = getpixel(screen, x, y);
	  
	  
	  /* Calculate new X/Y location: */
	  
	  nx = ((((x - H_WIDTH) * 4) / 3) +  /* X scaled up by 125% */
		H_WIDTH +                    /* (re-centered) */
		zoom_x);                     /* and moved (zoom_x offset) */
	  
	  ny = ((((y - H_HEIGHT) * 4) / 3) +
		H_HEIGHT +                   /* (Ditto for Y) */
		zoom_y);
	  
	  
	  /* Draw the pixel (2x2 to fill in gaps) into temp. surface */
	  
	  putpixel(tmp, nx + 0, ny + 0, pix);
	  putpixel(tmp, nx + 1, ny + 0, pix);
	  putpixel(tmp, nx + 0, ny + 1, pix);
	  putpixel(tmp, nx + 1, ny + 1, pix);
	}
    }
  
  
  /* Unlock temp. surface: */
  
  if (SDL_MUSTLOCK(tmp))
    SDL_UnlockSurface(tmp);
  
  
  /* Copy entire temp. surface into window: */
  
  SDL_BlitSurface(tmp, NULL, screen, NULL);
  
  
  /* Free the temp. surface from memory, now that we're done with it: */
  
  SDL_FreeSurface(tmp);
}


/* Rotate the entire image in the window ("screen surface") some angle */
/* This func. is called instead of the screen-clearing SDL_FillRect */
/* if "rotate" has been set to 'TRUE'... */

void rotatescreen(int angle)
{
  int x, y;
  Uint32 pix;
  SDL_Surface * tmp;
  int nx, ny;
  float rad, cos_r, sin_r;
 

  /* Create a temp. surface to draw onto: */
  
  tmp = SDL_CreateRGBSurface(SDL_HWSURFACE, F_WIDTH, F_HEIGHT, 16,
			     0, 0, 0, 0);
  
  if (tmp == NULL)
    {
      /* Couldn't create it!? */
      
      printf("%s\n", SDL_GetError());
      exit(1);
    }
  
  
  /* Lock temp. surface if we need to (accessing raw pixels) */
  
  if (SDL_MUSTLOCK(tmp))
    SDL_LockSurface(tmp);
  

  /* Convert rotation angle into radians: */
  
  rad = - (3.14159 * angle) / 180;
  

  /* Get COSINE and SINE of the angle, for use later
     (rather than calculating the same value over and over!) */
  
  cos_r = cos(rad);
  sin_r = sin(rad);

  
  /* For every pixel on the screen: */

  for (y = 0; y < F_HEIGHT; y++)
    {
      for (x = 0; x < F_WIDTH; x++)
        {
	  /* Get the pixel's color: */
	  
	  pix = getpixel(screen, x, y);
	  
	  
	  /* Calculate new X/Y location: */
	  
	  nx = (((x - H_WIDTH) * cos_r) -   /* Rotated around... */
		((y - H_HEIGHT) * sin_r) +  /* ...old pixel's position */
		H_WIDTH);                   /* (Re-centered) */
	  
	  ny = (((x - H_WIDTH) * sin_r) +
		((y - H_HEIGHT) * cos_r) +  /* (Similar for Y) */
		H_HEIGHT);


	  /* Draw the pixel (2x2 to fill in gaps) into temp. surface */
	  
	  putpixel(tmp, nx + 0, ny + 0, pix);
	  putpixel(tmp, nx + 1, ny + 0, pix);
	  putpixel(tmp, nx + 0, ny + 1, pix);
	  putpixel(tmp, nx + 1, ny + 1, pix);
	}
    }


  /* Unlock temp. surface: */
  
  if (SDL_MUSTLOCK(tmp))
    SDL_UnlockSurface(tmp);
  
  
  /* Copy entire temp. surface into window: */
  
  SDL_BlitSurface(tmp, NULL, screen, NULL);
  
  
  /* Free the temp. surface from memory, now that we're done with it: */
  
  SDL_FreeSurface(tmp);
}


/* Blur the entire image in the window ("screen surface") some angle */
/* This func. is called instead of the screen-clearing SDL_FillRect */
/* if "blur" has been set to 'TRUE'... */

void blurscreen(int angle)
{
  int x, y;
  int xx, yy;
  Uint8 r, g, b;
  Uint32 nr, ng, nb;   /* Bigger (Uint32) because we total many RGBs */
  SDL_Surface * tmp;
 

  /* Create a temp. surface to draw onto: */
  
  tmp = SDL_CreateRGBSurface(SDL_HWSURFACE, F_WIDTH, F_HEIGHT, 16,
			     0, 0, 0, 0);
  
  if (tmp == NULL)
    {
      /* Couldn't create it!? */
      
      printf("%s\n", SDL_GetError());
      exit(1);
    }
  
  
  /* Lock temp. surface if we need to (accessing raw pixels) */
  
  if (SDL_MUSTLOCK(tmp))
    SDL_LockSurface(tmp);
  

  /* For every pixel (excluding outer edges)... */
  
  for (y = 1; y < F_HEIGHT - 1; y++)
    {
      for (x = 1; x < F_WIDTH - 1; x++)
        {
	  /* Clear RGB color totals: */
	  
	  nr = 0;
	  ng = 0;
	  nb = 0;
	  
	  
	  /* For the 9 pixels surrounding this location... */

	  for (yy = -1; yy <= 1; yy++)
	    {
	      for (xx = -1; xx <= 1; xx++)
		{
		  /* Get the RGB values for the pixel: */
		  
		  SDL_GetRGB(getpixel(screen, x + xx, y + yy),
			     screen->format, &r, &g, &b);
		  
		  
		  /* Increase the RGB color totals: */
		  
		  nr = nr + r;
		  ng = ng + g;
		  nb = nb + b;
		}
	    }
	  
	  
	  /* Calculate the average (total divided by how many) */
	  
	  nr = nr / 9;
	  ng = ng / 9;
	  nb = nb / 9;
	  
	  
	  /* Draw the averaged pixel onto the temp. surface: */
	  
	  putpixel(tmp, x, y,
	           SDL_MapRGB(screen->format,
		              (Uint8) nr,
			      (Uint8) ng,
			      (Uint8) nb));
	}
    }


  /* Unlock temp. surface: */
  
  if (SDL_MUSTLOCK(tmp))
    SDL_UnlockSurface(tmp);
  
  
  /* Copy entire temp. surface into window: */
  
  SDL_BlitSurface(tmp, NULL, screen, NULL);
  
  
  /* Free the temp. surface from memory, now that we're done with it: */
  
  SDL_FreeSurface(tmp);
}


/* Dissolve the entire image in the window ("screen surface") some angle */
/* This func. is called instead of the screen-clearing SDL_FillRect */
/* if "dissolve" has been set to 'TRUE'... */

void dissolvescreen(int angle)
{
  int x, y;
  
  
  /* For every pixel... */
  
  for (y = 0; y < F_HEIGHT; y++)
    {
      for (x = 0; x < F_WIDTH; x++)
        {
	  /* Based on random chance (pick a number between 0 and 7...
	     is it less than 3?...) */
	  
	  if ((rand() % 8) < 3)
	    {
	      /* (...if so) Set the pixel to black: */
	      
	      putpixel(screen, x, y,
		       SDL_MapRGB(screen->format, 0x00, 0x00, 0x00));
	    }
	}
    }
}


/* Heat (blur with fire) the entire image in the window */
/* ("screen surface") some angle */
/* This func. is called instead of the screen-clearing SDL_FillRect */
/* if "heat" has been set to 'TRUE'... */

void heatscreen(int angle)
{
  int x, y;
  int xx, yy, xoff;
  Uint8 r, g, b;
  Uint32 nr, ng, nb;
  SDL_Surface * tmp;
 

  /* Create a temp. surface to draw onto: */
  
  tmp = SDL_CreateRGBSurface(SDL_HWSURFACE, F_WIDTH, F_HEIGHT, 16,
			     0, 0, 0, 0);
  
  if (tmp == NULL)
    {
      /* Couldn't create it!? */
      
      printf("%s\n", SDL_GetError());
      exit(1);
    }
  
  
  /* Lock temp. surface if we need to (accessing raw pixels) */
  
  if (SDL_MUSTLOCK(tmp))
    SDL_LockSurface(tmp);
  

  /* For every pixel except the outer edges: */
  
  for (y = 1; y < F_HEIGHT - 1; y++)
    {
      /* Pick a random offset for this row (for 'wavering' effect of heat) */
      
      xoff = (rand() % 3) - 1;
      
      for (x = 1; x < F_WIDTH - 1; x++)
        {
	  /* Clear RGB totals: */
	  
	  nr = 0;
	  ng = 0;
	  nb = 0;
	  
	  
	  /* For the lower-surrounding locations of this pixel: */
	  
	  for (yy = 0; yy <= 1; yy++)
	    {
	      for (xx = xoff - 1; xx <= xoff + 1; xx++)
		{
		  /* Get the RGB values for the pixel: */
		  
		  SDL_GetRGB(getpixel(screen, x + xx, y + yy),
			     screen->format, &r, &g, &b);
		  
		  
		  /* Set the new colors: */
		  
		  nr += (r +              /* Red gets increased a little */
			 ((g + b) / 4));  /* more by the current B & G */
		  ng += g;
		  nb += b;
		}
	    }
	  
	  
	  /* "Average" the totals: */
	  
	  nr = nr / 6;    /* Red is true average of total */
	  ng = ng / 7;    /* Green is slightly smaller */
	  nb = nb >> 3;   /* Blue is even smaller */
	  
	  /* NOTE: The above causes the color to have much more red,
	     and slightly more green (therefore orange/yellow) than
	     if all values were simply truly averaged (divided by 6 each) */
	  
	  
	  /* If the red is greater than max possible value,
	     cut it off (so it doesn't wrap around, causing weird
	     effects... brighter-than-bright would become dark!!!) */
	  
	  if (nr >= 0xFF)
	    nr = 0xFF;
	  
	  
	  /* Draw the new, more red pixel onto the temp. surface: */
	  
	  putpixel(tmp, x, y,
	           SDL_MapRGB(screen->format,
		              (Uint8) nr,
			      (Uint8) ng,
			      (Uint8) nb));
	}
    }


  /* Unlock temp. surface: */
  
  if (SDL_MUSTLOCK(tmp))
    SDL_UnlockSurface(tmp);
  
  
  /* Copy entire temp. surface into window: */
  
  SDL_BlitSurface(tmp, NULL, screen, NULL);
  
  
  /* Free the temp. surface from memory, now that we're done with it: */
  
  SDL_FreeSurface(tmp);
}


/* Get a single pixel from a surface (to convert to R, G, B) */

Uint32 getpixel(SDL_Surface * surface, int x, int y)
{
  int bpp;
  Uint8 * p;
  
  
  /* Determine bytes-per-pixel for the surface in question: */
  
  bpp = surface->format->BytesPerPixel;
  
  
  /* Set a pointer to the exact location in memory of the pixel
     in question: */
  
  p = (Uint8 *) (surface->pixels +       /* Start at beginning of RAM */
		 (y * surface->pitch) +  /* Go down Y lines */
		 (x * bpp));             /* Go in X pixels */
  
  
  /* Assuming the X/Y values are within the bounds of this surface... */
  
  if (x >= 0 && y >= 0 && x < surface -> w && y < surface -> h)
    {
      /* Return the correctly-sized piece of data containing the
	 pixel's value (an 8-bit palette value, or a 16-, 24- or 32-bit
	 RGB value) */
      
      if (bpp == 1)         /* 8-bit display */
	return *p;
      else if (bpp == 2)    /* 16-bit display */
	return *(Uint16 *)p;
      else if (bpp == 3)    /* 24-bit display */
	{
	  /* Depending on the byte-order, it could be stored RGB or BGR! */
	  
	  if (SDL_BYTEORDER == SDL_BIG_ENDIAN)
	    return p[0] << 16 | p[1] << 8 | p[2];
	  else
	    return p[0] | p[1] << 8 | p[2] << 16;
	}
      else if (bpp == 4)    /* 32-bit display */
	return *(Uint32 *)p;
      else
	return 0;           /* (Should never occur) */
    }
  else
    return 0;               /* (Out of bounds?  Just return zero) */
}


/* Draw a single pixel into the surface: */

void putpixel(SDL_Surface * surface, int x, int y, Uint32 pixel)
{
  int bpp;
  Uint8 * p;
  
  /* Determine bytes-per-pixel for the surface in question: */
  
  bpp = surface->format->BytesPerPixel;
  
  
  /* Set a pointer to the exact location in memory of the pixel
     in question: */
  
  p = (Uint8 *) (surface->pixels +       /* Start at beginning of RAM */
		 (y * surface->pitch) +  /* Go down Y lines */
		 (x * bpp));             /* Go in X pixels */
  
  
  /* Assuming the X/Y values are within the bounds of this surface... */
  
  if (x >= 0 && y >= 0 && x < surface -> w && y < surface -> h)
    {
      /* Set the (correctly-sized) piece of data in the surface's RAM
	 to the pixel value sent in: */
      
      if (bpp == 1)
	*p = pixel;
      else if (bpp == 2)
	*(Uint16 *)p = pixel;
      else if (bpp == 3)
	{
	  if (SDL_BYTEORDER == SDL_BIG_ENDIAN)
	    {
	      p[0] = (pixel >> 16) & 0xff;
	      p[1] = (pixel >> 8) & 0xff;
	      p[2] = pixel & 0xff;
	    }
	  else
	    {
	      p[0] = pixel & 0xff;
	      p[1] = (pixel >> 8) & 0xff;
	      p[2] = (pixel >> 16) & 0xff;
	    }
	}
      else if (bpp == 4)
	{
	  *(Uint32 *)p = pixel;
	}
    }
}
