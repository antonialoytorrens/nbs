#!/bin/bash

export FRAMEBUFFER=/dev/fb0
./atari800zaurus -pal -run dc.com
