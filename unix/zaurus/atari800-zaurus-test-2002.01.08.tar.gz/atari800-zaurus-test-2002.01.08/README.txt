atari800 for Zaurus - test!

atari800 emulator by many people - see http://atari800.atari.org/
crosscompiled for Zaurus by Jiri Svoboda <jiri.svoboda@ds-holding.cz>
tar'd and README.txt by Bill Kendrick <bill@newbreedsoftware.com>

2002.Jan.08

Files:
------
  ATARIBAS.ROM   - Atari BASIC ROM  - From PC XFormer 2.5
  ATARIOSB.ROM   - Atari OS B ROM   - "
  ATARIXL.ROM    - Atari XL OS ROM  - "
  atari800.cfg   - Tell atari800 where everything is (ROMs, etc)
  atari800.sh    - Shell script to run atari800 and load Drunk Chessboard demo
                   (also sets up "FRAMEBUFFER" env. variable)
  atari800zaurus - 'atari800', cross-compiled for Zaurus (ARM, framebuf, etc.)
  dc.com         - Drunk Chessboard (Atari 8-bit executable file)
                   by 'Infinity' (Fox, QBA, X-RAY), 1996

How to run it:
--------------
  SSH into your Zaurus and run "./atari800.sh".

  Hit ^C and then type "quit" to exit the emulator.
  (It currently doesn't notice stylus/key events!!!)
