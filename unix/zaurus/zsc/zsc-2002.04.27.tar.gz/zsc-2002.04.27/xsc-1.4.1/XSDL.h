#include "global.h"

#ifndef XSC_XSDL_H
#define XSC_XSDL_H

typedef struct {
  short x, y;
} XPoint;

typedef Uint32 GC;

typedef SDLKey KeySym;

typedef SDL_Surface * Window;

typedef int Display;

void XBell(Display * d, int v);

void XFillArc(Display * disp, Window d, GC gc, int x, int y,
		              unsigned int width, unsigned int height,
			                    int angle1, int angle2);

extern void XDrawLine(void * display, SDL_Surface * window, Uint32 thisgc,
		                      int nx0, int ny0, int nx1, int ny1);


#endif
