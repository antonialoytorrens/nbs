#ifndef PLAYSOUND_H
#define PLAYSOUND_H

#include <SDL_mixer.h>

enum {
  SND_THRUST,
  SND_BULLET,
  SND_BUZZER,
  SND_MINEFIELD,
  SND_NEWSHIELDS,
  SND_PLAYERDIE,
  SND_CASTLEDIE,
  SND_FIREBALL,
  NUM_SOUNDS
};


extern char * soundfiles[NUM_SOUNDS];
extern Mix_Chunk * sounds[NUM_SOUNDS];

void playsound(int snd);

#endif /* PLAYSOUND_H */

