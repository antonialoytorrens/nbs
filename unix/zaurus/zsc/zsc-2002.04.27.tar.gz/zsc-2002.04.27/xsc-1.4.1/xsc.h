// xsc: Copyright (c) 1993-2001 by Mark B. Hanson (mbh@panix.com).

// @(#)$Id: xsc.h,v 3.1 2001/04/27 05:32:43 mark Exp $

#ifndef	XSC_XSC_H
#define	XSC_XSC_H

#include "args.h"
#include "timing.h"

#ifdef USE_SDL
#include "XSDL.h"
#endif


extern char *program;
extern Display *display;
extern Window game_window;
extern Window stats_window;
extern int wwidth;
extern int wwidth2;
extern int mwheight;
extern int gwheight;
extern int gwheight2;
extern struct Args::info args;
extern Stamp time_now;

const float DEFAULT_FPS	= 30.0;

#endif	// XSC_XSC_H
