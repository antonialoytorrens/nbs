// xsc: Copyright (c) 1993-2001 by Mark B. Hanson (mbh@panix.com).

// @(#)$Id: ething.h,v 3.0 2001/01/01 20:17:53 mark Exp $

#ifdef	XSC_ETHING_H

class Ething;

#else	// XSC_ETHING_H
#define	XSC_ETHING_H

#include "tthing.h"
#include "xything.h"

class Ething : public Xything, public Tthing {
public:
    Ething(void);
    ~Ething(void);
};

#endif	// XSC_ETHING_H
