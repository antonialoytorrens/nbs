#include "playsound.h"


Mix_Chunk * sounds[NUM_SOUNDS];


char * soundfiles[NUM_SOUNDS] = {
	  "sounds/thrust.wav",
	  "sounds/bullet.wav",
	  "sounds/buzzer.wav",
	  "sounds/minefield.wav",
	  "sounds/newshields.wav",
	  "sounds/playerdie.wav",
	  "sounds/castledie.wav",
	  "sounds/fireball.wav"
};


void playsound(int snd)
{
  Mix_PlayChannel(-1, sounds[snd], 0);
}

