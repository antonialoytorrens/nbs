// xsc: Copyright (c) 1993-2001 by Mark B. Hanson (mbh@panix.com).

// @(#)$Id: starfield.h,v 3.0 2001/01/01 20:18:27 mark Exp $

#ifdef	XSC_STARFIELD_H

class Stats;

#else	// XSC_STARFIELD_H
#define	XSC_STARFIELD_H

#include "ething.h"

class Starfield : public Ething {
private:
    float starsize;
    struct coords *pts;
    int wander;

public:
    Starfield(const int, const bool);
    ~Starfield(void);

    void render(const bool);

    void move(void);
    void resize(const int, const int);
};

#endif	// XSC_STARFIELD_H
