// xsc: Copyright (c) 1993-2001 by Mark B. Hanson (mbh@panix.com).

static const char *const file_id =
	"@(#)$Id: ething.C,v 3.0 2001/01/01 20:17:52 mark Exp $";

#include "global.h"

#include "ething.h"


Ething::Ething(void)
{
    //fprintf(stderr, "Ething::Ething()\n");
} // Ething::Ething


Ething::~Ething(void)
{
    //fprintf(stderr, "Ething::~Ething()\n");
} // Ething::~Ething
