#!/bin/sh

# mkipk.sh
# generates an ipkg for ZSC (embedded XSC for Zaurus)

# Bill Kendrick
# bill@newbreedsoftware.com

# 2002.Apr.27 - 2002.Apr.27


VER=1.4.1

PACKAGE=zsc
TMPDIR=tmp
CONTROL=$TMPDIR/CONTROL/control
ARCH=arm
RM=rm



echo "SETTING UP"
mkdir -p $TMPDIR/CONTROL/


echo
echo "BUILDING EMBEDDED VERSION"
(cd xsc-$VER ; make embedded)


echo
echo "CREATING CONTROL FILE ($CONTROL)"
echo "Package: $PACKAGE" > $CONTROL
echo "Priority: optional" >> $CONTROL
echo "Version: $VER" >> $CONTROL
echo "Section: games" >> $CONTROL
echo "Architecture: $ARCH" >> $CONTROL
echo "Maintainer: Bill Kendrick (bill@newbreedsoftware.com)" >> $CONTROL
echo "Description: A clone of Star Castle based on XSC" >> $CONTROL


echo
echo "CREATING BINARIES"

mkdir -p $TMPDIR/opt/QtPalmtop/bin/
echo "zsc" > $TMPDIR/opt/QtPalmtop/bin/zsc.sh
chmod 755 $TMPDIR/opt/QtPalmtop/bin/zsc.sh
cp xsc-$VER/xsc $TMPDIR/opt/QtPalmtop/bin/zsc

echo
echo "COPYING SOUNDS"
mkdir -p $TMPDIR/opt/QtPalmtop/share/zsc/
cp -R xsc-$VER/data/* $TMPDIR/opt/QtPalmtop/share/zsc/

echo
echo "CREATING ICON AND DESKTOP FILE"

mkdir -p $TMPDIR/opt/QtPalmtop/pics/
cp zsc.png $TMPDIR/opt/QtPalmtop/pics/

mkdir -p $TMPDIR/opt/QtPalmtop/apps/Games/
DESKTOP=$TMPDIR/opt/QtPalmtop/apps/Games/zsc.desktop

echo "[Desktop Entry]" > $DESKTOP
echo "Comment=Zaurus Star Castle" >> $DESKTOP
echo "Exec=zsc.sh" >> $DESKTOP
echo "Icon=zsc" >> $DESKTOP
echo "Type=Application" >> $DESKTOP
echo "Name=ZSC" >> $DESKTOP


echo
echo "CREATING IPK..."

ipkg-build $TMPDIR

echo
echo "CLEANING UP"

$RM -r $TMPDIR

echo

