#include <SDL.h>
#include "XSDL.h"


void drawvertline(Window w, int x, int y1, int y2, GC c);
void putpixel(SDL_Surface * surface, int x, int y, Uint32 pixel);


void XBell(Display * d, int v)
{
	  /* Do nothing */
}

void XFillArc(Display * disp, Window d, GC gc, int x, int y,
		              unsigned int width, unsigned int height,
			                    int angle1, int angle2)
{
  XDrawLine(disp, d, gc, x - width, y - height, x + width, y + height);
  XDrawLine(disp, d, gc, x - width, y + height, x + width, y - height);
}



/* SDL replacement for XDrawLine(): */

void XDrawLine(void * display, SDL_Surface * window, GC thisgc,
		               int nx0, int ny0, int nx1, int ny1)
{
  int dx, dy;
  float m, b;


#ifdef EMBEDDED
  /* Rotate sideways for embedded: */

  int tmp;

  tmp = nx0;
  nx0 = 239 - ny0;
  ny0 = tmp;
  
  tmp = nx1;
  nx1 = 239 - ny1;
  ny1 = tmp;
#endif


  if (nx0 >= 0 && nx0 < window->w &&
      nx1 >= 0 && nx1 < window->w &&
      ny0 >= 0 && ny0 < window->h &&
      ny1 >= 0 && ny1 < window->h)
  {
    dx = nx1 - nx0;
    dy = ny1 - ny0;

    if (dx != 0)
    {
      m = ((float) dy) / ((float) dx);
      b = ny0 - m * nx0;

      if (nx1 >= nx0)
	dx = 1;
      else
	dx = -1;

      while (nx0 != nx1)
      {
	ny0 = (int) (m * nx0 + b);
	ny1 = (int) (m * (nx0 + dx) + b);

	drawvertline(window, nx0, ny0, ny1, thisgc);

	nx0 = nx0 + dx;
      }
    }
    else
    {
      drawvertline(window, nx0, ny0, ny1, thisgc);
    }
  }
}

void drawvertline(Window w, int x, int y1, int y2, GC c)
{
  int tmp, dy;

  if (y1 > y2)
  {
    tmp = y1;
    y1 = y2;
    y2 = tmp;
  }

  for (dy = y1; dy <= y2; dy++)
  {
    putpixel(w, x, dy, c);
  }
}


/* Draw a single pixel into the surface: */

void putpixel(SDL_Surface * surface, int x, int y, Uint32 pixel)
{
  int bpp;
  Uint8 * p;


  /* Assuming the X/Y values are within the bounds of this surface... */

  if (x >= 0 && y >= 0 && x < surface->w && y < surface->h)
    {
      /* Determine bytes-per-pixel for the surface in question: */

      bpp = surface->format->BytesPerPixel;


      /* Set a pointer to the exact location in memory of the pixel
         in question: */

      p = (((Uint8 *) surface->pixels) +       /* Start at beginning of RAM */
           (y * surface->pitch) +  /* Go down Y lines */
           (x * bpp));             /* Go in X pixels */


      /* Set the (correctly-sized) piece of data in the surface's RAM
         to the pixel value sent in: */

      if (bpp == 1)
        *p = pixel;
      else if (bpp == 2)
        *(Uint16 *)p = pixel;
      else if (bpp == 3)
        {
          if (SDL_BYTEORDER == SDL_BIG_ENDIAN)
            {
              p[0] = (pixel >> 16) & 0xff;
              p[1] = (pixel >> 8) & 0xff;
              p[2] = pixel & 0xff;
            }
          else
            {
              p[0] = pixel & 0xff;
              p[1] = (pixel >> 8) & 0xff;
              p[2] = (pixel >> 16) & 0xff;
            }
        }
      else if (bpp == 4)
        {
          *(Uint32 *)p = pixel;
        }
    }
}
