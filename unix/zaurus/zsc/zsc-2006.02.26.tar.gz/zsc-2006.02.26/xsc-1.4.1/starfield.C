// xsc: Copyright (c) 1993-2001 by Mark B. Hanson (mbh@panix.com).

static const char *const file_id =
	"@(#)$Id: starfield.C,v 3.4 2001/04/29 04:36:21 mark Exp $";

#include "global.h"

#include "random.h"
#include "util.h"
#include "xsc.h"

#include "starfield.h"


Starfield::Starfield(const int number, const bool bright)
{
    //fprintf(stderr, "Starfield::Starfield()\n");
    int dim = (int)hypot(wwidth, gwheight);

    wander = dim / 2;
    dim += wander;

    x = wwidth2;
    y = gwheight2;

    num_points = number;
    pts = new coords[num_points];

    for (int i = 0; i < num_points; i++) {
    	pts[i].x = (Random::get() % dim) - (dim / 2.0);
    	pts[i].y = (Random::get() % dim) - (dim / 2.0);
    }
    points = pts;

    xpoints = new XPoint[num_points];

    starsize = wwidth / 200.0;
    set_size(1.0);

    set_gc(fetch_gc(bright ? GC_BRIGHT_GREY : GC_DULL_GREY));

    dx = 30 / args.fps;
    dy = -15 / args.fps;
    set_dtheta(50 / args.fps);
} // Starfield::Starfield


Starfield::~Starfield(void)
{
    //fprintf(stderr, "Starfield::~Starfield()\n");
    delete[] pts;
} // Starfield::~Starfield


void
Starfield::move(void)
{
    if ((x + dx) > wwidth2 + (wander / 2.0) ||
	    (x + dx) < wwidth2 - (wander / 2.0)) {
	dx = -dx;
    }
    if ((y + dy) > gwheight2 + (wander / 2.0) ||
	    (y + dy) < gwheight2 - (wander / 2.0)) {
	dy = -dy;
    }
    Xything::move();
} // Starfield::move


void
Starfield::render(const bool ink)
{
    GC thisgc;

    if (ink) {
	thisgc = gc;
	Tthing::set_xpoints();
    } else {
    	thisgc = fetch_gc(GC_BLACK);
    }

    for (int i = 0; i < num_points; i++) {
	XFillArc(display, window, thisgc,
		(int)(xpoints[i].x - (starsize / 2.0)),
		(int)(xpoints[i].y - (starsize / 2.0)),
		(int)starsize, (int)starsize,
		0, 360*64);
    }
} // Starfield::render


void
Starfield::resize(const int nwidth, const int nheight)
{
    starsize *= (float)nwidth / wwidth;
    wander = (wander * nwidth) / wwidth;
    Xything::resize(nwidth, nheight);
} // Starfield::resize
