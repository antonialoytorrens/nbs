/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define as the return type of signal handlers (int or void).  */
#define RETSIGTYPE void

/* Define if you can safely include both <sys/time.h> and <time.h>.  */
#define TIME_WITH_SYS_TIME 1

/* Define if the X Window System is missing or not being used.  */
/* #undef X_DISPLAY_MISSING */

/* Define if you have the gettimeofday function.  */
#define HAVE_GETTIMEOFDAY 1

/* Define if you have the rand function.  */
/* #undef HAVE_RAND */

/* Define if you have the random function.  */
#define HAVE_RANDOM 1

/* Define if you have the srand function.  */
/* #undef HAVE_SRAND */

/* Define if you have the srandom function.  */
#define HAVE_SRANDOM 1

/* Define if you have the usleep function.  */
#define HAVE_USLEEP 1

/* Define if you have the <sys/time.h> header file.  */
#define HAVE_SYS_TIME_H 1

/* Define if you have the <time.h> header file.  */
#define HAVE_TIME_H 1

/* Define if you have the X11 library (-lX11).  */
#define HAVE_LIBX11 1

/* Define if you have the m library (-lm).  */
#define HAVE_LIBM 1

/* Name of package */
#define PACKAGE "xsc"

/* Version number of package */
#define VERSION "1.4"

