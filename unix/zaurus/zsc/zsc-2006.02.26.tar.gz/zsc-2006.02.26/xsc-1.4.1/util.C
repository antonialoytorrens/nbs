// xsc: Copyright (c) 1993-2001 by Mark B. Hanson (mbh@panix.com).

static const char *const file_id =
	"@(#)$Id: util.C,v 3.2 2001/04/29 04:36:27 mark Exp $";

#include "global.h"

#include "util.h"
#include "xsc.h"

#ifdef USE_SDL
#include "XSDL.h"
#endif

namespace {

GC gc_list[GC_TOKEN_COUNT];


#ifndef USE_SDL

void
alloc_color(const char *const name, XColor *color)
{
    const int screen_number = DefaultScreen(display);
    XColor dummy;
    Colormap colormap = DefaultColormap(display, screen_number);

    if (XAllocNamedColor(display, colormap, name, color, &dummy) == 0) {
	fprintf(stderr, "%s: failed to allocate color `%s'.  ", program, name);
	fprintf(stderr, "substituting `white'.\n");
	if (XAllocNamedColor(display, colormap, "white", color,
		    &dummy) == 0) {
	    fprintf(stderr, "%s: failed to allocate color `white'.\n", program);
	}
    }
} // ::alloc_color


GC
alloc_gc(const char *const colorname, const int width)
{
    const int screen_number = DefaultScreen(display);
    XColor color;
    XGCValues gc_values;

    gc_values.line_width = width;
    gc_values.background = BlackPixel(display, screen_number);

    alloc_color(colorname, &color);
    gc_values.foreground = color.pixel;

    return XCreateGC(display, RootWindow(display, screen_number),
	(GCForeground | GCBackground | GCLineWidth), &gc_values);
} // ::alloc_gc

#else

GC
alloc_gc(Uint8 r, Uint8 g, Uint8 b)
{
  return SDL_MapRGB(game_window->format, r, g, b);
}
#endif

} // namespace


void
init_gc(void)
{
#ifndef USE_SDL
    gc_list[GC_BLACK] = alloc_gc("black", 2);

    gc_list[GC_BRIGHT_RED] = alloc_gc("red", 2);
    gc_list[GC_DULL_RED] = alloc_gc("red3", 2);

    gc_list[GC_BRIGHT_ORANGE] = alloc_gc("orange", 2);
    gc_list[GC_DULL_ORANGE] = alloc_gc("orange3", 2);

    gc_list[GC_BRIGHT_YELLOW] = alloc_gc("yellow", 2);
    gc_list[GC_DULL_YELLOW] = alloc_gc("yellow3", 2);

    gc_list[GC_BRIGHT_GREY] = alloc_gc("grey80", 2);
    gc_list[GC_DULL_GREY] = alloc_gc("grey40", 2);

    gc_list[GC_GREEN] = alloc_gc("green", 2);

    gc_list[GC_BLUE] = alloc_gc("dodgerblue", 2);
#else
    gc_list[GC_BLACK] = alloc_gc(0, 0, 0);

    gc_list[GC_BRIGHT_RED] = alloc_gc(255, 0, 0);
    gc_list[GC_DULL_RED] = alloc_gc(192, 0, 0);

    gc_list[GC_BRIGHT_ORANGE] = alloc_gc(255, 128, 0);
    gc_list[GC_DULL_ORANGE] = alloc_gc(255, 192, 64);
    
    gc_list[GC_BRIGHT_YELLOW] = alloc_gc(255, 255, 0);
    gc_list[GC_DULL_YELLOW] = alloc_gc(255, 255, 64);

    gc_list[GC_BRIGHT_GREY] = alloc_gc(192, 192, 192);
    gc_list[GC_DULL_GREY] = alloc_gc(112, 112, 112);

    gc_list[GC_GREEN] = alloc_gc(0, 255, 0);

    gc_list[GC_BLUE] = alloc_gc(0, 0, 255);
#endif
    
} // ::init_gc


void
free_all_gcs(void)
{
#ifndef USE_SDL
    XFreeGC(display, gc_list[GC_BLACK]);

    XFreeGC(display, gc_list[GC_BRIGHT_RED]);
    XFreeGC(display, gc_list[GC_DULL_RED]);

    XFreeGC(display, gc_list[GC_BRIGHT_ORANGE]);
    XFreeGC(display, gc_list[GC_DULL_ORANGE]);

    XFreeGC(display, gc_list[GC_BRIGHT_YELLOW]);
    XFreeGC(display, gc_list[GC_DULL_YELLOW]);

    XFreeGC(display, gc_list[GC_BRIGHT_GREY]);
    XFreeGC(display, gc_list[GC_DULL_GREY]);

    XFreeGC(display, gc_list[GC_BLUE]);

    XFreeGC(display, gc_list[GC_GREEN]);
#endif
} // ::free_all_gcs


GC
fetch_gc(const gc_token t)
{
    return gc_list[t];
} // ::fetch_gc

