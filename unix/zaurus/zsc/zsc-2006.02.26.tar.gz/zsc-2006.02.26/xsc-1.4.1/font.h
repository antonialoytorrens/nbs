// xsc: Copyright (c) 1993-2001 by Mark B. Hanson (mbh@panix.com).

// @(#)$Id: font.h,v 3.0 2001/01/01 20:17:57 mark Exp $

#ifndef	XSC_FONT_H
#define	XSC_FONT_H

#include "global.h"

const int font_digit_offset = 0;
const int font_comma_offset = 10;
const int font_upper_offset = 11;
const int font_lower_offset = 37;

extern const struct coords *const cyrilc_points[];
extern const int cyrilc_count[];

extern const struct coords *const gothgbt_points[];
extern const int gothgbt_count[];

extern const struct coords *const romans_points[];
extern const int romans_count[];

extern const struct coords *const romant_points[];
extern const int romant_count[];

#endif	// XSC_FONT_H
