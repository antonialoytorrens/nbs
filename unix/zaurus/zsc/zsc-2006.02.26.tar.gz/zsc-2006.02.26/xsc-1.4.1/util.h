// xsc: Copyright (c) 1993-2001 by Mark B. Hanson (mbh@panix.com).

// @(#)$Id: util.h,v 3.2 2001/04/29 04:36:28 mark Exp $

#ifndef	XSC_UTIL_H
#define	XSC_UTIL_H


typedef enum _gc_token {
    GC_BLACK,

    GC_BRIGHT_RED,
    GC_DULL_RED,

    GC_BRIGHT_ORANGE,
    GC_DULL_ORANGE,

    GC_BRIGHT_YELLOW,
    GC_DULL_YELLOW,

    GC_BRIGHT_GREY,
    GC_DULL_GREY,

    GC_GREEN,

    GC_BLUE,

    GC_TOKEN_COUNT
} gc_token;

extern void init_gc(void);
extern void free_all_gcs(void);

extern GC fetch_gc(const gc_token);


#endif	// XSC_UTIL_H
