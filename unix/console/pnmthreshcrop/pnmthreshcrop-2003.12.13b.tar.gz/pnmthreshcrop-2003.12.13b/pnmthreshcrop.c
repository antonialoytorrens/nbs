/*
  pnmthreshcrop.c

  Crops a NetPBM image file (PBM bitmap, PGM greyscale, or PPM color pixmap)
  based on the contents, using a threshold.

  Remove the black border around a photo of a small planet, for example.
  Use the threshold value to decide how "black" a pixel must be for it to
  be ignored.  (So that, for example, faint starts don't get confused as
  the useful part of the image.)

  Based on a request on 'comp.graphics.apps.gimp' by Frank Stefani

  By Bill Kendrick
  bill@newbreedsoftware.com
  http://www.newbreedsoftware.com/

  December 13, 2003 - December 13, 2003
*/


#include <stdio.h>
#include <stdlib.h>
#include <pam.h>


#define VERSION "2003.12.13b"


/* Define "DEBUG" if you want interesting output sent to STDERR: */
/* #define DEBUG */


/* Local function prototypes: */

int my_atoi(int argc, char * * argv, int w);
void usage(FILE * out);
void debug(char * msg, char * val);


/* --- MAIN! --- */

int main(int argc, char * argv[])
{
  struct pam inpam, outpam;
  int x, y, sample, val;
  int top, bottom, left, right;
  int threshold, top_padding, bottom_padding, left_padding, right_padding;
  int i, done;
  FILE * infile, * outfile;
  tuple * * tuplerows;
  tuple * * out_tuplerows;
  

  /* Pass our arguments off to libnetpbm, so it can deal with any options
     it understands (e.g., "--quiet") */

  pnm_init(&argc, argv);


  /* Assume default options: */

  threshold = 0;

  top_padding = 0;
  left_padding = 0;
  bottom_padding = 0;
  right_padding = 0;

  infile = stdin;
  outfile = stdout;


  /* Handle our command-line arguments: */

  for (i = 1; i < argc; i++)
  {
    if (strcmp(argv[i], "-T") == 0 ||
	strcmp(argv[i], "--threshold") == 0)
    {
      /* Threshold for pixel values we can ignore: */
	    
      threshold = my_atoi(argc, argv, i);
      i++;
    }
    else if (strcmp(argv[i], "-t") == 0 ||
	     strcmp(argv[i], "--toppadding") == 0)
    {
      /* Padding above the object we're cropping: */

      top_padding = my_atoi(argc, argv, i);
      i++;
    }
    else if (strcmp(argv[i], "-b") == 0 ||
	     strcmp(argv[i], "--bottompadding") == 0)
    {
      /* Padding below the object we're cropping: */

      bottom_padding = my_atoi(argc, argv, i);
      i++;
    }
    else if (strcmp(argv[i], "-l") == 0 ||
	     strcmp(argv[i], "--leftpadding") == 0)
    {
      /* Padding to the left of the object we're cropping: */

      left_padding = my_atoi(argc, argv, i);
      i++;
    }
    else if (strcmp(argv[i], "-r") == 0 ||
	     strcmp(argv[i], "--rightpadding") == 0)
    {
      /* Padding to the right of the object we're cropping: */
      
      right_padding = my_atoi(argc, argv, i);
      i++;
    }
    else if (strcmp(argv[i], "-p") == 0 ||
	     strcmp(argv[i], "--padding") == 0)
    {
      /* Set ALL paddings: */
      
      top_padding = my_atoi(argc, argv, i);
      bottom_padding = top_padding;
      left_padding = top_padding;
      right_padding = top_padding;

      i++;
    }
    else if (strcmp(argv[i], "-o") == 0 ||
	     strcmp(argv[i], "--outfile") == 0)
    {
      /* An output file! (Instead of stdout) */

      if (i + 1 >= argc)
      {
        fprintf(stderr, "%s requires a filename", argv[i]);
        usage(stderr);
        exit(1);
      }
      else
      {
        if (outfile != stdout)
        {
	  /* Was a file already open?  Close it, and show a warning! */
	      
	  fprintf(stderr, "Warning: pnmthreshcrop can only write to one file\n"
	                  "Using %s\n");
	  fclose(outfile);
        }


	/* Open the file for write: */

        debug("Opening for write: ", argv[i]);
	
        outfile = fopen(argv[i + 1], "w");
        if (outfile == NULL)
        {
	  perror(argv[i + 1]);
	  exit(1);
        }
	
        i++;
      }
    }
    else if (strcmp(argv[i], "-h") == 0 ||
	     strcmp(argv[i], "--help") == 0 ||
	     strcmp(argv[i], "-u") == 0 ||
	     strcmp(argv[i], "--usage") == 0)
    {
      /* Display usage info: */

      usage(stdout);
      exit(0);
    }
    else if (strcmp(argv[i], "-v") == 0 ||
	     strcmp(argv[i], "--pnmthreshcrop-version") == 0)
    {
      /* Display version info: */

      printf("pnmthreshcrop version " VERSION "\n");
      exit(0);
    }
    else
    {
      /* Assume anything else is a filename for input */

      if (infile != stdin)
      {
	/* Was a file already open?  Close it, and show a warning! */
	      
	fprintf(stderr, "Warning: pnmthreshcrop can only read one input file\n"
	                "Using %s\n");
	fclose(infile);
      }
      

      /* Open a file for input: */
      
      debug("Opening for read: ", argv[i]);
      
      infile = fopen(argv[i], "r");
      if (infile == NULL)
      {
	perror(argv[i]);
	exit(1);
      }
    }
  }


  /* All set to read! */

  if (infile == stdin)
    debug("Reading from STDIN", "");

  if (outfile == stdout)
    debug("Writing to STDOUT", "");


  /* Read image: */

  pnm_readpaminit(infile, &inpam, sizeof(inpam));


  /* Set extreme values for borders: */

  top = 0;
  left = 0;
  bottom = inpam.height - 1;
  right = inpam.width - 1;

#ifdef DEBUG
  fprintf(stderr, "Input image is a %s that's %d x %d in size\n",
	  inpam.tuple_type, inpam.width, inpam.height);
#endif
 
  
  /* Create an array of tuples to load the image into: */
  
  tuplerows = (tuple * *) malloc(sizeof(tuple *) * inpam.height);
  if (tuplerows == NULL)
  {
    fprintf(stderr, "Couldn't allocate tuple rows!");
    exit(1);
  }

  
  /* Read the data into the array of tuple rows: */

  for (y = 0; y < inpam.height; y++)
  {
    /* Allocate space for that one row: */
	  
    tuplerows[y] = pnm_allocpamrow(&inpam);
    if (tuplerows[y] == NULL)
    {
      fprintf(stderr, "Couldn't allocate tuple row %d!", y);
      exit(1);
    }

    
    /* Read it in: */
    
    pnm_readpamrow(&inpam, tuplerows[y]);
  }


  /* FIXME: Right now, it only cares about black!  This needs to be fixed! */


  /* Determine top of image: */
  
  done = 0;

  for (y = top; y <= bottom && !done; y++)
  {
    for (x = left; x <= right && !done; x++)
    {
      for (sample = 0; sample < inpam.depth && !done; sample++)
      {
	val = tuplerows[y][x][sample];

	if (val > threshold)
	{
	  top = y - top_padding;

	  if (top < 0)
	    top = 0;

#ifdef DEBUG
	  fprintf(stderr, "Top found at %d,%d (%d sample is %d)\n",
			  x, y, sample, val);
#endif

	  done = 1;
	}
      }
    }
  }


  /* Determine bottom of image: */

  done = 0;
  
  for (y = bottom; y > top && !done; y--)
  {
    for (x = left; x <= right && !done; x++)
    {
      for (sample = 0; sample < inpam.depth && !done; sample++)
      {
	val = tuplerows[y][x][sample];

	if (val > threshold)
	{
	  bottom = y + bottom_padding;

	  if (bottom >= inpam.height)
	    bottom = inpam.height - 1;

#ifdef DEBUG
	  fprintf(stderr, "Bottom found at %d,%d (%d sample is %d)\n",
			  x, y, sample, val);
#endif

	  done = 1;
	}
      }
    }
  }


  /* Determine left of image: */

  done = 0;
  
  for (x = left; x <= right && !done; x++)
  {
    for (y = top; y <= bottom && !done; y++)
    {
      for (sample = 0; sample < inpam.depth && !done; sample++)
      {
	val = tuplerows[y][x][sample];

	if (val > threshold)
	{
	  left = x - left_padding;

	  if (left < 0)
	    left = 0;

#ifdef DEBUG
	  fprintf(stderr, "Left found at %d,%d (%d sample is %d)\n",
			  x, y, sample, val);
#endif

	  done = 1;
	}
      }
    }
  }


  /* Determine right of image: */

  done = 0;
  
  for (x = right; x > left && !done; x--)
  {
    for (y = top; y <= bottom && !done; y++)
    {
      for (sample = 0; sample < inpam.depth && !done; sample++)
      {
	val = tuplerows[y][x][sample];

	if (val > threshold)
	{
	  right = x + right_padding;

	  if (right >= inpam.width)
	    right = inpam.width - 1;

#ifdef DEBUG
	  fprintf(stderr, "Right found at %d,%d (%d sample is %d)\n",
			  x, y, sample, val);
#endif

	  done = 1;
	}
      }
    }
  }

#ifdef DEBUG
  fprintf(stderr, "Important part of image is between (%d,%d) and (%d,%d)\n",
	  left, top, right, bottom);
#endif


  /* Create the new image: */

  outpam.file = outfile;

  outpam.depth = inpam.depth;
  outpam.maxval = inpam.maxval;
  strcpy(outpam.tuple_type, inpam.tuple_type);
  outpam.format = inpam.format;
  
  outpam.height = bottom - top + 1;
  outpam.width = right - left + 1;
  outpam.size = outpam.height * outpam.width * outpam.depth;
  outpam.len = outpam.size;

  
  /* Create an array of tuples to store the new image: */
  
  out_tuplerows = (tuple * *) malloc(sizeof(tuple *) * outpam.height);
  if (out_tuplerows == NULL)
  {
    fprintf(stderr, "Couldn't allocate output tuple rows!");
    exit(1);
  }
  
  
  /* Allocate the space for the new tuple rows: */

  for (y = 0; y < outpam.height; y++)
  {
    /* Allocate space for that one row: */
 
    out_tuplerows[y] = pnm_allocpamrow(&outpam);
    if (out_tuplerows[y] == NULL)
    {
      fprintf(stderr, "Couldn't allocate output tuple row %d!", y);
      exit(1);
    }
  }


  /* Spit out the output file's header: */
  
  pnm_writepaminit(&outpam);

  
  /* Copy the relevant parts from the original image into the new one: */

  for (y = top; y <= bottom; y++)
  {
    for (x = left; x <= right; x++)
    {
      for (sample = 0; sample < inpam.depth; sample++)
        out_tuplerows[y - top][x - left][sample] = tuplerows[y][x][sample];
    }
  
    
    /* Spit out this row! */

    pnm_writepamrow(&outpam, out_tuplerows[y - top]);
  }
  

  /* Free the tuple rows: */
  
  for (y = 0; y < inpam.height; y++)
    pnm_freepamrow(tuplerows[y]);
  
  for (y = 0; y < outpam.height; y++)
    pnm_freepamrow(out_tuplerows[y]);


  /* Free the tuple arrays: */

  free(tuplerows);
  free(out_tuplerows);


  /* All done! */

  return(0);
}


/* Gather the next command-line arg as an integer; or complain and die
   if there are no more args! */

int my_atoi(int argc, char * * argv, int w)
{
  if (w + 1 >= argc)
  {
    fprintf(stderr, "%s requires a value\n\n", argv[w]);
    usage(stderr);
    exit(1);
  }
  else
  {
    return(atoi(argv[w + 1]));
  }

  return -1;
}


/* Usage display: */

void usage(FILE * out)
{
  fprintf(out,
  "Usage: pnmthreshcrop [--threshold N]\n"
  "                     [--padding N | [--toppadding N] [--bottompadding N]\n"
  "                                    [--leftpadding N] [--rightpadding N]]\n"
  "                     [--outfile OUTFILE] [INFILE]\n"
  "\n"
  "       pnmthreshcrop [--usage | --help] [--pnmthreshcrop-version]\n"
  "\n"
  "       (Other libpnm command line arguments are parsed before these)\n"
  "\n");
}


/* A function to show some debugging info: */

void debug(char * msg, char * val)
{
#ifdef DEBUG
  fprintf(stderr, "%s %s\n", msg, val);
#endif
}

