#!/bin/sh

# pnmcentercrop.sh

# Specify the width and height you want for your new image,
# and the input image will be cropped so that the center remains.

# Usage:
#   pnmcentercrop.sh INPUT.PPM WIDTH HEIGHT > OUTPUT.PPM

# By Bill Kendrick
# bill@newbreedsoftware.com
# http://www.newbreedsoftware.com/

# December 13, 2003 - December 13, 2003


# Determine width and height of input image:

WIDTH=`pnmfile $1 | cut -d , -f 2 | cut -d " " -f 2`
HEIGHT=`pnmfile $1 | cut -d , -f 2 | cut -d " " -f 4`


# Determine where to cut from to get the center

LEFT=`expr $WIDTH - $2`
LEFT=`expr $LEFT / 2`

TOP=`expr $HEIGHT - $3`
TOP=`expr $TOP / 2`


# Cut it!

pnmcut -top $TOP -left $LEFT -width $2 -height $3 $1
