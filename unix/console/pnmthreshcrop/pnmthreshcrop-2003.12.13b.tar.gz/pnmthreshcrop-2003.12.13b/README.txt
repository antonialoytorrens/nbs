README.txt for pnmthreshcrop

"pnmthreshcrop" crops a NetPBM image file (PBM bitmap, PGM greyscale,
or PPM color pixmap) based on the contents, using a threshold.

The script "pnmcentercrop.sh" crops a NetPBM based on width and height
requirements, and uses the center of the input image for the results.

Based on a request on 'comp.graphics.apps.gimp' by Frank Stefani

By Bill Kendrick
bill@newbreedsoftware.com
http://www.newbreedsoftware.com/

December 13, 2003 - December 13, 2003


About
-----
  "pnmthreshcrop" removes a solid-colored border (or one that's made of
  pixels CLOSE to the same color) from around an image.
  
  For example, remove the black border around a photo of a small planet.
  Use the threshold value to decide how "black" a pixel must be for it to
  be ignored.  For example, faint starts could be confused for the useful
  part of the image; set the threshold higher to avoid that.

  "pnmcentercrop.sh" allows you to crop an image around the center,
  similar to "pnmcrop" and "pnmcut", except that all you need supply is
  the width and height that you wish the output file to be.  It then
  crops around the center of the input image.

  Used together, these tools allow you to crop a small object (say, a planet)
  from a set of large photos, and then re-crop them so that they're all the
  same size, regardless of exactly how large the content was which was
  originally cropped out.


Requirements
------------
  Requires the NetPBM tools and NetPBM libraries.
  (e.g., under Debian, install the package "libnetpbm9-dev")


Compiling
---------
  Simply compile with "make".

  You can install it to "/usr/local/bin" using "make install",
  and delete it from there using "make uninstall".

  (This process should be cleaned up.)


Usage - pnmthreshcrop
---------------------
  You can send a NetPBM image (PBM bitmap, PGM greyscale, or PPM color pixmap)
  via STDIN, and allow 'pnmthreshcrop' to dump the resulting image out to
  STDOUT.  For example:

    djpeg somepicture.jpg | pnmthreshcrop | cjpeg > cropped.jpg


  Or, you can specify the input file and output files on the command line:

    pnmthreshcrop myimage.ppm --outfile cropped.ppm


  Or a combination:

    giftoppm original.gif | pnmthreshcrop -o newpict.ppm

    pnmthreshcrop something.ppm > newthing.ppm


  Command-line options include:

    --threshold VALUE
    -T VALUE

      Sets the threshold value to VALUE.  Default value is "0."  Only
      solid black will be cropped.  Any slight divergance from that
      color will be considered "valuable information," and not cropped out.

    --toppadding PIXELS
    -t PIXELS

      After deciding what part of the image is important, and shouldn't
      be cropped, you can alter the size and shape by adding a few pixels
      to the top, bottom, left or right.

      This option adds pixels to the top.  (It will not go above the top of
      the original image, of course.)

    --bottompadding PIXELS
    -b PIXELS

      This option adds pixels to the top.  (It will not go below the bottom
      of the original image, of course.)
    
    --leftpadding PIXELS
    -l PIXELS

      This option adds pixels to the left.  (It will not go beyond the
      left edge of the original image, of course.)
    
    --rightpadding PIXELS
    -r PIXELS

      This option adds pixels to the right.  (It will not go beyond the
      right edge of the original image, of course.)

    --padding PIXELS
    -p PIXELS

      This option sets all of the padding values at once.
      In other words, "--padding 5" is the same as
      "--toppadding 5 --bottompadding 5 --leftpadding 5 --rightpadding 5".


  Other command-line options:

    --usage
    -u
    --help
    -h

    Display the program's usage to STDOUT and exit.


    --pnmthreshcrop-version
    -v

    Display the program version number.


Usage - pnmcentercrop.sh
------------------------
  Call this script, providing a PPM filename, and a width and height for
  the resulting image, and it will dump the results to STDOUT.

    pnmcentercrop.sh input.ppm 100 150 > output.ppm

  Note that the input image should be AT LEAST as large as the output
  file you want.

  For example, say you want a collection of 150x150 images, which are
  first cropped using 'pnmthreshcrop.'  You could do this:

    pnmthreshcrop -p 150 original.ppm > temp.ppm
    pnmcentercrop.sh temp.ppm 150 150 > results.ppm
    rm temp.ppm
  

To Do
-----
  Right now, 'pnmthreshcrop' only crops black, and colors in that threshold.

  You should be able to set a particular color which you consider
  "unimportant, background/border."  Specify as RGB values, and
  perhaps allow specification using words ("white", "red", "black").

  You should be able to set different thresholds for the different
  color channels.  e.g., "--redthreshold", "--greenthreshold", etc.

  Create a 'man page'.

  Clean up install/uninstall process.

  Document libpnm command-line arguments, maybe?


The end
-------
  Enjoy!

