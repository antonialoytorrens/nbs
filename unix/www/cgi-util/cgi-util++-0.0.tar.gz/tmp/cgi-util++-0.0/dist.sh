#!/bin/sh

VERSION="0.0"
PACKAGE="cgi-util++"

TMP=/tmp/$PACKAGE-$VERSION
DST=./$PACKAGE-$VERSION

[ -e $DST.tar.gz ] && { echo Manually remove existing $DST.tar.gz! ; \
	exit 1 ; }

[ -d $TMP ] && { echo Removing old temporary directory \"$TMP\"... ; \
	rm -Rf $TMP ; }

[ -d $TMP ] && { echo Existing directory $TMP could not be removed! ; \
	exit 2 ; }

echo Creating temporary directory...
mkdir $TMP

echo Cleaning distribution...
make clean >/dev/null

echo Copying files to temporary directory...
cp -Ra ./* $TMP/

echo Removing useless files from temporary directory...
find $TMP -name "obsolete" -exec rm -Rf {} \;
find $TMP -name "other" -exec rm -Rf {} \;

echo Creating tar-archive...
tar -cf $DST.tar $TMP/*

echo Compressing tar-archive with gzip...
gzip $DST.tar

echo Removing temporary directory...
rm -Rf $TMP

echo $0 done.
