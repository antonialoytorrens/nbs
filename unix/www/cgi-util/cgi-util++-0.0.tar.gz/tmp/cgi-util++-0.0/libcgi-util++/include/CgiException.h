/**
	CgiException is a base class of all exceptions thrown by methods
	of the cgi-util++ library.

	@author Tobias Jahn <tjahn@sourceforge.net>
*/

#ifndef CGI_EXCEPTION_H
#define CGI_EXCEPTION_H


#include <stdexcept>
#include <string>


class CgiException : public exception
{
	public:

		CgiException(const string& location_ = 0, const string& message_ = 0) ;
		CgiException(const string& location_, const int errorcode) ;

		virtual ~CgiException() ;

		virtual const char* where() const ;
		virtual const char* what() const ;

	protected:

		string location ;
		string message ;
} ;

#endif
