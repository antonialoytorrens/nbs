/**
	CgiUtil allows object oriented common gateway interface applications.

	It is based on cgi-util from Bill Kendrick <bill@newbreedsoftware.com>
	and Mike Simons <msimons@fsimons01.erols.com>. It can be downloaded from
	http://www.newbreedsoftware.com/cgi-util/.

	Therefore you may create multiple instances of CgiUtil but all will
	give you access to same name/value pairs and other items.

	@author Tobias Jahn <tjahn@sourceforge.net>
*/

#ifndef CGI_UTIL_H
#define CGI_UTIL_H


#include <iostream.h>
#include <string>


class CgiUtil
{
	public:

		CgiUtil() ;
		virtual ~CgiUtil() ;


		///	Returns the request method.
		int getRequestMethod() const ;


		/**	Returns the number of name/value pairs received, or
			0 if none or an error occured.
		*/
		int getEntryCount() const ;


		///	Returns the error code of the last method.
		int getErrorCode() const ;

		string* getEntryString(const string& name) const ;

		int getEntryInteger(const string& name) const ;

		double getEntryDouble(const string& name) const ;

		bool getEntryBool(const string& name, const bool def = false) const ;


		void dumpNoAbort(const string& filename) const ;
		void dump(const string& filename) const ;

		void displayError(const string& message) const ;

		static bool isGoodEmailAddress(const string& address) ;

		static string* getErrorString(const int errorcode) ;

	protected:

	private:

		///	Destination of output.
		ostream& out ;

		///	Destination of error messages and debug information.
		ostream& err ;
} ;

#endif
