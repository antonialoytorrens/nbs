
#include <CgiException.h>
#include <cgi-util++.h>


CgiException::CgiException(const string& location_, const string& message_)
	: location(location_), message(message_)
{
	#ifdef DEBUG_CGI
		cerr << "CgiException::CgiException(" << location_ << ", \""
			<< message_ << "\")" << endl ;
	#endif
}

CgiException::CgiException(const string& location_, const int errorcode)
	: location(location_)
{
	#ifdef DEBUG_CGI
		cerr << "CgiException::CgiException(" << location_ << ", "
			<< errorcode << ")" << endl ;
	#endif

	message = *(CgiUtil::getErrorString(errorcode)) ;
}

CgiException::~CgiException()
{
	#ifdef DEBUG_CGI
		cerr << "CgiException::~CgiException()" << endl ;
	#endif
}

const char* CgiException::where() const
{
	return location.c_str() ;
}

const char* CgiException::what() const
{
	return message.c_str() ;
}

