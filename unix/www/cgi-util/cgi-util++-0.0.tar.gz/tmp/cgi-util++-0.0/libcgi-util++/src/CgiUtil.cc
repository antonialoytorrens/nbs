

// for sprintf()
#include <stdio.h>

#include <CgiUtil.h>
#include <cgi-util++.h>

CgiUtil::CgiUtil()
	: out(cout), err(cerr)
{
	#ifdef DEBUG_CGI
		err << "CgiUtil::CgiUtil()" << endl ;
	#endif

	if (int res = cgi_init())
	{
		throw CgiException("CgiUtil::CgiUtil", res) ;
	}
}


CgiUtil::~CgiUtil()
{
	cgi_quit() ;

	#ifdef DEBUG_CGI
		err << "CgiUtil::~CgiUtil()" << endl ;
	#endif
}


int CgiUtil::getRequestMethod() const
{
	return cgi_request_method ;
}


int CgiUtil::getEntryCount() const
{
	return cgi_num_entries ;
}


int CgiUtil::getErrorCode() const
{
	return cgi_errno ;
}


string* CgiUtil::getEntryString(const string& name) const
{
	const char *res = cgi_getentrystr(name.c_str()) ;

	if (!res)
	{
		char buf[128] ;
		sprintf(buf, "unknown entry: %s", name.c_str()) ;

		throw CgiException("CgiUtil::getEntryString", buf) ;
	}
	else if (getErrorCode() != CGIERR_NONE)
		throw CgiException("CgiUtil::getEntryString", getErrorCode()) ;

	return new string(res) ;
}


int CgiUtil::getEntryInteger(const string& name) const
{
	const int res = cgi_getentryint(name.c_str()) ;

	if (getErrorCode() != CGIERR_NONE)
		throw CgiException("CgiUtil::getEntryInteger", getErrorCode()) ;

	return res ;
}


double CgiUtil::getEntryDouble(const string& name) const
{
	const double res = cgi_getentrydouble(name.c_str()) ;

	if (getErrorCode() != CGIERR_NONE)
		throw CgiException("CgiUtil::getEntryDouble", getErrorCode()) ;

	return res ;
}


bool CgiUtil::getEntryBool(const string& name, const bool def) const
{
	const int res = cgi_getentrybool(name.c_str(), (def ? 1 : 0)) ;

	return (res == 1) ? true : false ;
}


void CgiUtil::dumpNoAbort(const string& filename) const
{
	cgi_dump_no_abort(filename.c_str()) ;

	if (getErrorCode() != CGIERR_NONE)
		throw CgiException("CgiUtil::dumpNoAbort", getErrorCode()) ;
}


void CgiUtil::dump(const string& filename) const
{
	cgi_dump(filename.c_str()) ;
}


void CgiUtil::displayError(const string& message) const
{
	cgi_error(message.c_str()) ;
}


bool CgiUtil::isGoodEmailAddress(const string& address)
{
	const int res = cgi_goodemailaddress(address.c_str()) ;

	return (res == 1) ? true : false ;
}


string* CgiUtil::getErrorString(const int errorcode)
{
	return new string(cgi_strerror(errorcode)) ;
}



