#!/bin/sh

. config-4sh

echo Installing libraries...
install -d $LIBPATH
install -s $LOCLIB/libcgi-util++.a $LIBPATH
install -s $LOCLIB/libcgi-util++.so $LIBPATH

echo Installing include files...
install -d $INCPATH
install $LOCINC/CgiUtil.h $INCPATH
install $LOCINC/CgiException.h $INCPATH
install $LOCINC/cgi-util++.h $INCPATH

echo "Determine run-time link bindings (calling ldconfig)..."
ldconfig

echo $0 done.
