/**
	This class is a simple test application for the cgi-util++ library.

	@author Tobias Jahn <tjahn@sourceforge.net>
*/


#include <iostream.h>
#include <string>
#include <cgi-util++.h>


int main(void)
{
	cout << "Content-type: text/html\n\n" ;

	CgiUtil* cgi = new CgiUtil() ;

	string name = "hello" ;
	string* value = cgi->getEntryString(name) ;

	cout << "<H1>Test</H1>" << endl
		<< "<UL>" << endl
		<< "<LI>name  = " << name << endl << "<LI>value = " << *value << endl
		<< "</UL>" << endl ;

	delete cgi ;

	return 0 ;
}

