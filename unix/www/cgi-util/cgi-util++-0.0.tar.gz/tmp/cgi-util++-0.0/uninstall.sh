#!/bin/sh

. config-4sh

echo Removing libraries from $LIBPATH...
cd $LIBPATH ; \
	rm -f libcgi-util++.a ; \
	rm -f libcgi-util++.so

echo Removing include files from $INCPATH...
cd $INCPATH ; \
	rm -f CgiUtil.h CgiException.h cgi-util++.h

echo $0 done.
