/*
  background.cxx

  Allows user to choose a background image (XPM) and set the background
  (by calling "xpmroot")

  by Bill Kendrick
  bill@newbreedsoftware.com
  http://www.newbreedsoftware.com/

  April 18, 2001 - April 18, 2001
*/


#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <Fl/Fl.H>
#include <Fl/Fl_Window.H>
#include <Fl/Fl_Button.H>
#include <Fl/Fl_Select_Browser.H>
#include <Fl/Fl_Input.H>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>

#include <stdio.h>


/* Typedef: */

typedef struct file_type {
  char name[512];
  int isdir;
} file_type;


/* Globals: */

char cur_dir[512];
char last_dir[10][512];
int num_last_dirs;
Fl_Select_Browser *browser;
Fl_Input *location;
Fl_Window *window;
Fl_Button *btn_back, *btn_fwd, *btn_done, *btn_dots;
int num_files, selected, show_dots;
file_type files[256];
char tmp_str[512];


/* Callback prototypes: */

static void cb_refresh(Fl_Button *button, void *);
static void cb_back(Fl_Button *button, void *);
static void cb_fwd(Fl_Button *button, void *);
static void cb_home(Fl_Button *button, void *);
static void cb_pix(Fl_Button *button, void *);
static void cb_done(Fl_Button *button, void *);
static void cb_cancel(Fl_Button *button, void *);
static void cb_browser(Fl_Select_Browser *browser, void *);
static void cb_location(Fl_Input *input, void *);
static void cb_dots(Fl_Button *button, void *);


/* Function prototypes: */

void fill_browser(void);
void add_to_browser(char * str, int italic, int highlight);
void get_directory(char * dir);


/* --- Main --- */

int main(int argc, char **argv)
{
  Fl_Button *btn_refresh, *btn_home, *btn_pix, *btn_cancel;


  // Create Window:

  window = new Fl_Window(160, 240, "Browser");
  {
    // Add buttons at the top:

    btn_back = new Fl_Button(0, 0, 20, 15, "@<");
    btn_back->labeltype(FL_SYMBOL_LABEL);
    btn_back->labelsize(10);
    btn_back->align(FL_ALIGN_BOTTOM|FL_ALIGN_INSIDE);
    btn_back->callback((Fl_Callback*) cb_back);
    btn_back->shortcut(FL_ALT + 'b');

    btn_fwd = new Fl_Button(20, 0, 20, 15, "@>");
    btn_fwd->labeltype(FL_SYMBOL_LABEL);
    btn_fwd->labelsize(10);
    btn_fwd->align(FL_ALIGN_BOTTOM|FL_ALIGN_INSIDE);
    btn_fwd->callback((Fl_Callback*) cb_fwd);
    btn_fwd->shortcut(FL_ALT + 'f');
    btn_fwd->deactivate();

    btn_refresh = new Fl_Button(40, 0, 40, 15, "Refresh");
    btn_refresh->labelsize(10);
    btn_refresh->align(FL_ALIGN_BOTTOM|FL_ALIGN_INSIDE);
    btn_refresh->callback((Fl_Callback*) cb_refresh);
    btn_refresh->shortcut(FL_ALT + 'r');

    btn_home = new Fl_Button(80, 0, 35, 15, "Home");
    btn_home->labelsize(10);
    btn_home->align(FL_ALIGN_BOTTOM|FL_ALIGN_INSIDE);
    btn_home->callback((Fl_Callback*) cb_home);
    btn_home->shortcut(FL_ALT + 'h');

    btn_pix = new Fl_Button(120, 0, 40, 15, "Pixmaps");
    btn_pix->labelsize(10);
    btn_pix->align(FL_ALIGN_BOTTOM|FL_ALIGN_INSIDE);
    btn_pix->callback((Fl_Callback*) cb_pix);
    btn_pix->shortcut(FL_ALT + 'p');


    // Add buttons at the bottom:

    btn_done = new Fl_Button(0, 225, 35, 15, "Done");
    btn_done->labelsize(10);
    btn_done->align(FL_ALIGN_BOTTOM|FL_ALIGN_INSIDE);
    btn_done->callback((Fl_Callback*) cb_done);

    btn_cancel = new Fl_Button(35, 225, 35, 15, "Cancel");
    btn_cancel->labelsize(10);
    btn_cancel->align(FL_ALIGN_BOTTOM|FL_ALIGN_INSIDE);
    btn_cancel->callback((Fl_Callback*) cb_cancel);

    btn_dots = new Fl_Button(100, 225, 60, 15, "Show Dots");
    btn_dots->labelsize(10);
    btn_dots->align(FL_ALIGN_BOTTOM|FL_ALIGN_INSIDE);
    btn_dots->callback((Fl_Callback*) cb_dots);


    // Add the file browser:

    browser = new Fl_Select_Browser(0, 30, 160, 195);
    browser->callback((Fl_Callback*) cb_browser);
    // browser->textfont(FL_SCREEN);
    browser->textsize(10);


    // Add the type-in field:

    location = new Fl_Input(0, 15, 160, 15);
    location->callback((Fl_Callback*) cb_location);
    location->when(FL_WHEN_ENTER_KEY|FL_WHEN_NOT_CHANGED);
    location->textfont(FL_SCREEN);
    location->textsize(10);
  }
  window->end();
 

  // Display the window

  window->show(argc, argv);


  // Set current directory:
 
  strcpy(cur_dir, getenv("PWD"));
  strcat(cur_dir, "/");

  strcpy(last_dir[0], "");
  num_last_dirs = 0;


  // Set options:

  show_dots = 0;


  // Fill the browser with the default directory:

  get_directory(cur_dir);
  fill_browser();


  // Start the main loop
  return Fl::run();
}


/* Callback: Refresh browser with current directory */

static void cb_refresh(Fl_Button *button, void *)
{
  fill_browser();
}


/* Callback: Toggle Show/Hide Dots */

static void cb_dots(Fl_Button *button, void *)
{
  // Toggle status:

  show_dots = !show_dots;


  // Reload directroy:

  get_directory(cur_dir);
  fill_browser();


  // Change button label

  if (show_dots)
    btn_dots->label("Hide Dots");
  else
    btn_dots->label("Show Dots");
}


/* Callback: Go to user's home directory, then refresh */

static void cb_home(Fl_Button *button, void *)
{
  sprintf(tmp_str, "%s/", getenv("HOME"));
  num_last_dirs = 0;
  get_directory(tmp_str);
  fill_browser();
}


/* Callback: Go to pixmap directory, then refresh */

static void cb_pix(Fl_Button *button, void *)
{
  num_last_dirs = 0;
  get_directory(PIXMAP_DIR);
  fill_browser();
}


/* Callback: Set background, and quit!: */

static void cb_done(Fl_Button *button, void *)
{
  char cmd[1024];

  if (selected < 0 || selected >= num_files)
  {
    fprintf(stderr, "How did this happen? \"selected\"=%d\n", selected);
  }
  else
  {
    sprintf(cmd, "xpmroot %s%s", cur_dir, files[selected].name);
    system(cmd);

    window->hide();
  }
}


/* Callback: Back (go back a dir) */

static void cb_back(Fl_Button *button, void *)
{
  int i, done;

  done = 0;

  printf("last_dir[%d] = %s\n", num_last_dirs, last_dir[num_last_dirs]);

  strcpy(last_dir[++num_last_dirs], cur_dir);

  printf("         added %s\n", cur_dir);


  for (i = strlen(cur_dir) - 2; i >= 0 && !done; i--)
  {
    if (cur_dir[i] == '/')
    {
      cur_dir[i + 1] = '\0';
      done = 1;
    }
  }

  get_directory(cur_dir);
  fill_browser();
}


/* Callback: Forward (go forward to selected dir) */

static void cb_fwd(Fl_Button *button, void *)
{
  get_directory(last_dir[num_last_dirs]);
  num_last_dirs--;

  fill_browser();
}




/* Callback: Quit (cancel; no change!) */

static void cb_cancel(Fl_Button *button, void *)
{
  window->hide();
}


/* Callback: Browser click: */

static void cb_browser(Fl_Select_Browser *browser, void *)
{
  int which;


  which = browser->value() - 1;

  if (which != -1)
  {
    if (files[which].isdir)
    {
      /* If they clicked a directory, try to go to that dir: */

      sprintf(tmp_str, "%s%s/", cur_dir, files[which].name);

      if (strcmp(tmp_str, last_dir[num_last_dirs]) != 0)
        num_last_dirs = 0;
      else
        num_last_dirs--;

      get_directory(tmp_str);
      fill_browser();
    }
    else
    {
      /* If it's a file, activate the "Done" button! */

      selected = which;
      btn_done->activate();
    }
  }
  else
  {
    selected = -1;
  }
}


/* Callback: Browser click: */

static void cb_location(Fl_Input *input, void *)
{
  // Load the directory the user typed in to the location field:

  strcpy(tmp_str, (char *) location->value());

  if (strlen(tmp_str) != 0)
  {
    // If they typed something...

    if (tmp_str[strlen(tmp_str) - 1] != '/')
    {
      // Add a trailing slash, if it's missing!

      strcat(tmp_str, "/");
    }

    // Go to that directory!

    if (strcmp(tmp_str, last_dir[num_last_dirs]) != 0)
      num_last_dirs = 0;
    else
      num_last_dirs--;

    get_directory(tmp_str);
  }
  fill_browser();
}


/* Fill the browser with the current directory's contents: */

void fill_browser(void)
{
  int i;


  // Set location field to contain this directory:

  location->value(cur_dir);
  location->position(strlen(cur_dir), strlen(cur_dir));


  // If the current directory is root ("/"), deactivate the "<<" back button

  if (strcmp(cur_dir, "/") == 0)
    btn_back->deactivate();
  else
    btn_back->activate();


  if (num_last_dirs == 0)
    btn_fwd->deactivate();
  else
    btn_fwd->activate();


  // Add each file to the list:

  browser->clear();
  for (i = 0; i < num_files; i++)
  {
    if (files[i].isdir)
      sprintf(tmp_str, "%s%s/", cur_dir, files[i].name);
    else
      strcpy(tmp_str, "..");


    add_to_browser(files[i].name, files[i].isdir,
                   !(strcmp(tmp_str, last_dir[num_last_dirs])));

    if (strcmp(tmp_str, last_dir[num_last_dirs]) == 0)
    {
      browser->topline(i + 1);
    }
  }


  // Make sure no item selected; disable Done button:

  browser->select(0);
  btn_done->deactivate();
  selected = -1;
}


/* Add one line to the end of the browser: */

void add_to_browser(char * str, int italic, int highlight)
{
  char tmp[1024];
  
  if (tmp != NULL)
  {
    /* (Directories show up bolded) */

    tmp[0] = '\0';

    if (italic)
      strcat(tmp, "@i");
    if (highlight)
      strcat(tmp, "@b");

    strcat(tmp, str);

    browser->add(tmp);
  }
}


/* Try to open and read a directory: */

void get_directory(char * dir)
{
  DIR * d;
  int i, tmpint, changed;
  dirent * item;
  struct stat s;
  char str[1024];


  // Open directory:

  d = opendir(dir);
  if (d != NULL)
  {
    strcpy(cur_dir, dir);

    num_files = 0;
    selected = -1;


    // Read in each file:

    do
    {
      item = readdir(d);

      if (item != NULL)
      {
        // Create the file's full path

        sprintf(str, "%s%s", cur_dir, item->d_name);
        stat(str, &s);


        // If it's a dir (but not "." or "..") or an ".xpm", add it to list:

        if (((S_ISDIR(s.st_mode) &&
              strcmp(item->d_name, ".") != 0 &&
              strcmp(item->d_name, "..") != 0) ||
             strstr(item->d_name, ".xpm") != NULL) &&
            (show_dots || item->d_name[0] != '.'))
        {
          strcpy(files[num_files].name, item->d_name);
          files[num_files].isdir = S_ISDIR(s.st_mode);

          num_files++;
        }
      }
    }
    while (item != NULL);

    closedir(d);


    // Sort the list!   [ ACK! Bubblesort!  Hehehe! ]

    do
    {
      changed = 0;

      for (i = 0; i < num_files - 1; i++)
      {
        if ((files[i].isdir == files[i + 1].isdir &&
             strcmp(files[i].name, files[i + 1].name) > 0) ||
            (files[i].isdir < files[i + 1].isdir))
        {
          strcpy(str, files[i].name);
          strcpy(files[i].name, files[i + 1].name);
          strcpy(files[i + 1].name, str);

          tmpint = files[i].isdir;
          files[i].isdir = files[i + 1].isdir;
          files[i + 1].isdir = tmpint;

          changed = 1;
        }
      }
    }
    while (changed);
  }
}


