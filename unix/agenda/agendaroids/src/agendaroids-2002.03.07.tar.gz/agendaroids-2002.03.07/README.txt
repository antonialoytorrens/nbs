README.txt for "Agendaroids"

by Bill Kendrick
bill@newbreedsoftware.com
http://www.newbreedsoftware.com/gendaroids/

May 18, 2001 - March 7, 2002


About:
------
  "Agendaroids" is a vector-based rock-shooting game similar to the
  arcade classic "Asteroids," and written specifically with the
  Agenda VR3 Linux-based PDA in mind.  (It runs on any X-Window system,
  though, including that of Compaq iPAQ PDAs running Linux and X-Window,
  and Sharp Zaurus Linux-based PDAs, with X-Window installed.)


Features:
---------
  Vector graphics, but no floating-point math is used.  Trigonometric
  functions are replaced with fast fixed-point (bit-shiftable, even!)
  look-up tables.  This means it's fast!

  Uses Xlib for graphics, sound (PC speaker) and input (keyboard/buttons),
  and has a small window (160x240), so it fits perfectly on an Agenda.

  Executable size is under 25KB!  Program loads and starts up almost
  instantaneously on an Agenda PDA.

  Asteroid shapes are all random.  Asteroids rotate in different speeds
  and directions, too.

  Cool "photon"-like bullets.


Title Screen:
-------------
  The title screen displays the title and credits.

  The high score is displayed at the top of the screen.
  If a game has been played since loading Agendaroids, the last score
  is displayed just below.  (If it is the same as the high score, it will
  be blinking.)

  Three control buttons are displayed along the bottom of the screen.
  See the "On-Screen Controls" section, below.

    * To begin a game, tap or click the word "START".

    * To continue a paused game, tap or click "CONTINUE".

    * To quit, tap the "X" button at the lower left (see the
      "On-Screen Controls" section, below).  Any currently paused game
      will be saved, so when you run Agendaroids again, you can CONTINUE
      where you left off...


Keyboard Controls:
------------------
  There are two keyboard modes.  You can toggle the mode at any time
  (see below).


  Default Mode:  (Better on an Agenda PDA - default for "mips-*" targets))

    * Page-Up / Page-Down
      Rotate the ship clockwise and counter-clockwise, respectively.

    * Left
      Thrusts the ship in the direction it is currently facing.

    * Right
      Fires a bullet in the direction the ship is facing.


  Alternative Mode:  (For PC Keyboards - default for "host" and "arm" targets)

    * Left / Right
      Rotate ship counter-clockwise and clockwise, respectively.

    * Up / Page-Up
      Thrusts the ship in the direction it is currently facing.

    * Space / Page-Down
      Fires a bullet in the direction the ship is facing.


  Either mode:

    * Shift
      Respawns your ship after you die, even if the game thinks there
      are still too many asteroids near the center of the screen.


On-Screen Controls:
-------------------

  * X Button

    From within the game, the "X" button at the bottom left corner will
    pause the game and return you to the title screen.  From there, you
    can continue, start a new game, or quit Agendaroids completely.

    If you're already on the title screen, the "X" button will quit the
    program entirely.


  * D / A Button

    The button in the center of the screen at the bottom allows you to
    toggle which button mode the game is in, Default or Alternative.
    (See "Keyboard Controls," above)


  * Speaker Button

    The button at the bottom right corner of the screen which has a little
    speaker icon in it lets you toggle sound effects on and off.

    If effects are off, this icon has a "/" (slash) through it.


Status Display:
---------------
  The following is displayed at the top of the screen during the game,
  from left to right:

  * Score

    Your current score.


  * Level

    The level of the game you are currently playing.


  * Lives

    Miniature spaceships which represent how many extra lives you have left.


Scoring:
--------
  Each rock you shoot (or crash into) gains you points.  The smaller the
  rock, the more points you gain.

  Every 10,000 points, you also receive an extra ship.

