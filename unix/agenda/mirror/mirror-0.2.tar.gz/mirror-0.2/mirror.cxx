/*
 * mirror.cxx
 *
 * An FLTK-based program that displays a completely black fullscreen window.
 * Useful for turning a greyscale LCD-based system (eg, the Agenda VR3 PDA)
 * into a reflective mirror, when you don't have a real one handy.
 *
 * by Bill Kendrick
 * bill@newbreedsoftware.com
 *
 * Code based on hello_fltk.c, by Andrej Cedilnik
 * and Stopwatch by Mike Hall
 *
 * Concept based on "Mirror" for PalmOS by Utilware (Bill Westerman)
 */

#include <Fl/Fl.H>
#include <Fl/Fl_Window.H>
#include <Fl/Fl_Box.H>
#include <Fl/Fl_Button.H>
#include <Fl/Fl_Output.H>
#include <Fl/Fl_Pixmap.H>
#include <Fl/Fl_Image.H>
#include "mirror.xpm"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


/* Project began 2001.Mar.22 */

#define VERSION "0.2"
#define DATE "2001.Mar.23"


/* Local prototypes: */

static void cb_main_done(Fl_Button *button, void *);
static void cb_main_about(Fl_Button *button, void *);
static void cb_about_done(Fl_Button *button, void *);


/* About Window Class: */

class abouticonbox : public Fl_Box
{
  public:
    abouticonbox(Fl_Boxtype, int, int, int, int, char *);
    void draw();
    Fl_Pixmap *icon;
};


/* Globals: */

Fl_Window *wnd_main, *wnd_about;
abouticonbox *box_about;
Fl_Button *btn_about_done;
Fl_Output *out_about;


abouticonbox::abouticonbox(Fl_Boxtype type, int x, int y, int w, int h,
                           char * title) : Fl_Box(type, x, y, w, h, title)
{
}

void abouticonbox::draw()
{
  icon->draw(0, 0);
}


/* --- MAIN --- */

int main(int argc, char **argv)
{
  Fl_Box *box;
  Fl_Button *btn_main_done, *btn_main_about;
  int i;


  /* Create Main Window */

  wnd_main = new Fl_Window(160, 240, "Mirror");
  wnd_main -> fullscreen();
  {
    /* Create Frame */

    box = new Fl_Box(FL_FLAT_BOX, 0, 0, wnd_main->w(), wnd_main->h(), "");
    box->color(0);


    /* Create "Done" button */

    btn_main_done = new Fl_Button(0, wnd_main->h() - 15, 32, 15, "Done");
    btn_main_done->labelsize(10);
    btn_main_done->callback((Fl_Callback*) cb_main_done);
    btn_main_done->align(FL_ALIGN_BOTTOM|FL_ALIGN_INSIDE);


    /* Create "About" button */

    btn_main_about = new Fl_Button(32, wnd_main->h() - 15, 32, 15, "About");
    btn_main_about->labelsize(10);
    btn_main_about->callback((Fl_Callback*) cb_main_about);
    btn_main_about->align(FL_ALIGN_BOTTOM|FL_ALIGN_INSIDE);
  }
  wnd_main->end();


  /* Create the About Window */

  wnd_about = new Fl_Window(0, 0, 160, 184, "About Mirror");
  {
    /* Create Icon */

    box_about = new abouticonbox(FL_UP_BOX, 0, 0, 24, 24, "");
    box_about->icon = new Fl_Pixmap(mirror_xpm);


    /* Create About text */

    out_about = new Fl_Output(2, 26, 156, 141);
    out_about->type(4);
    out_about->labelsize(10);
    out_about->textsize(10);
    out_about->value("Mirror\n"
                     "\n"
                     "Version " VERSION "\n"
                     DATE "\n"
                     "\n"
                     "Bill Kendrick\n"
                     "bill@newbreedsoftware.com\n"
                     "http://newbreedsoftware.com/\n"
                     "\n"
                     "Based on \"mirror\" for PalmOS\n"
                     "by utilware (Bill Westerman)");


    /* Create "Done" button */

    btn_about_done = new Fl_Button(0, wnd_about->h() - 15, 32, 15, "Done");
    btn_about_done->labelsize(10);
    btn_about_done->callback((Fl_Callback*) cb_about_done);
    btn_about_done->align(FL_ALIGN_BOTTOM|FL_ALIGN_INSIDE);
  }
  wnd_about->end();


  /* Check for command-line options: */

  for (i = 1; i < argc; i++)
  {
    if (strcmp(argv[i], "--version") == 0 ||
        strcmp(argv[i], "-v") == 0)
      {
        printf("Mirror (in FLTK) - Version " VERSION ", " DATE "\n");
        exit(0);
      }
    else if (strcmp(argv[i], "--help") == 0 || strcmp(argv[i], "-h") == 0 ||
             strcmp(argv[i], "--usage") == 0 || strcmp(argv[i], "-u") == 0)
      {
        printf("Usage: %s [--version | --help/usage ]\n", argv[0]);
        exit(0);
      }
    else
      {
        fprintf(stderr, "Unknown option: %s\n", argv[i]);
        fprintf(stderr, "Usage: %s [--version | --help/usage ]\n", argv[0]);
        exit(1);
      }
  }


  /* Display the main window */

  wnd_main->show();


  /* Start the main loop */

  return Fl::run();
}


/* Main window's "Done" button's callback: */

static void cb_main_done(Fl_Button *button, void *)
{
  wnd_main->hide();
}


/* Main window's "About" button's callback: */

static void cb_main_about(Fl_Button *button, void *)
{
  wnd_about->show();
}


/* About window's "Done" button's callback: */

static void cb_about_done(Fl_Button *button, void *)
{
  wnd_about->hide();
}
