/*
  a800launcher.cxx

  Launch Atari800 emulator

  by Bill Kendrick
  bill@newbreedsoftware.com
  http://www.newbreedsoftware.com/

  April 5, 2001 - April 5, 2001
*/


#include <Fl/Fl.H>
#include <Fl/Fl_Window.H>
#include <Fl/Fl_Button.H>
#include <Fl/Fl_Choice.H>
#include <Fl/Fl_Menu_Item.H>
#include <stdlib.h>


/* Globals: */

Fl_Window *window;
Fl_Button *btn_done, *btn_launch;
Fl_Button *btn_disk, *btn_bin, *btn_cart;
Fl_Choice *choice_main;
Fl_Menu_Item *item_disk, *item_binary, *item_cart;


void cb_launch(Fl_Widget *, void *);
void cb_done(Fl_Widget *, void *);


int main(int argc, char **argv)
{
  /* Set up main window: */

  window = new Fl_Window(160, 240);
  {
    /* Done button: */

    btn_done = new Fl_Button(0, 225, 32, 15, "Done");
    btn_done->labelsize(10);
    btn_done->callback((Fl_Callback*) cb_done);
    btn_done->align(FL_ALIGN_BOTTOM|FL_ALIGN_INSIDE);


    /* Launch button: */

    btn_launch = new Fl_Button(32, 225, 32, 15, "Launch");
    btn_launch->labelsize(10);
    btn_launch->callback((Fl_Callback*) cb_launch);
    btn_launch->align(FL_ALIGN_BOTTOM|FL_ALIGN_INSIDE);


    /* Menu: */

    /* choice_main = new Fl_Choice(64, 225, 48, 15, "Menu");
    choice_main->labelsize(10);
    choice_main->align(FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    {
      /* Menu items: */

      /* item_disk = new Fl_Menu_Item(&crap);
    } */


    /* Mode buttons: */

    btn_disk = new Fl_Button(0, 0, 53, 15, "Disks");
    btn_disk->labelsize(10);
    btn_disk->callback((Fl_Callback*) cb_launch);
    btn_disk->align(FL_ALIGN_BOTTOM|FL_ALIGN_INSIDE);

    btn_bin = new Fl_Button(53, 0, 54, 15, "Run Binary");
    btn_bin->labelsize(10);
    btn_bin->callback((Fl_Callback*) cb_launch);
    btn_bin->align(FL_ALIGN_BOTTOM|FL_ALIGN_INSIDE);

    btn_cart = new Fl_Button(107, 0, 53, 15, "Carts / OS");
    btn_cart->labelsize(10);
    btn_cart->callback((Fl_Callback*) cb_launch);
    btn_cart->align(FL_ALIGN_BOTTOM|FL_ALIGN_INSIDE);
  }
  window->show(argc, argv);

  return Fl::run();
}


void cb_done(Fl_Widget *, void *)
{
  window -> hide();
}


void cb_launch(Fl_Widget *, void *)
{
  btn_done -> deactivate();
  window -> redraw();
  system("/flash/local/bin/atari800 -tiny -basic -refresh 100");
  btn_done -> activate();
}

