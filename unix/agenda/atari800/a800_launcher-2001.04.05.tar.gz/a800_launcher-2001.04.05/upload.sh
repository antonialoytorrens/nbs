rsync a800_launcher.mips agenda::vr3/local/bin/a800_launcher
