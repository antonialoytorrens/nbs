README for Thumbpad

by Bill Kendrick
bill@newbreedsoftware.com
http://www.newbreedsoftware.com/

October 6, 2001 - October 8, 2001


What Is It?
-----------
  "Thumbpad" is an FLTK-based "scratchpad" where you can temporarily enter
  information.  With one hand, you can enter letters or numbers using large
  on-screen keys.


How to Use It:
--------------
  The window contains a text-entry field and a backspace button at the top,
  a 4x4 series of alphabetic keys in the center, below that are
  control buttons, a Shift button, and a space button, and at the very bottom
  are menu buttons:

    * Input area
      ----------
      Text that you type with Thumbpad's large on-screen keys appear here.
      You can also enter text here using the normal keyboard application or
      handwriting recognition.

      You can use the stylus or your finger to position the cursor,
      scroll around the text entry field, or highlight text, too.


    * Backspace  ("<")
      ---------
      This on-screen button acts just like a regular backspace key:
      it deletes the character to the left of the cursor.  (Or, if some
      text is highlighted, erases it.)


    * Alphabetic keys
      ---------------
      The main part of the screen has alphabetic keys (or numeric, depending
      on the current mode).

      The default key layout contains the 16 most commonly-used letters
      (at least in English).  You can switch between layouts using the
      layout buttons below...


    * Layout buttons
      --------------
      The left layout button, labelled "A/Q" or "Q/A", switches between the
      two alphabetic modes:

        * "A", the default mode, contains the 16 most commonly-used letters:
          A, C, D, E, G, H, I, L, M, N, O, P, R, S, T, and U

        * "Q" contains the remaining letters and some punctuation:
          B, F, J, K, Q, V, W, X, Y, Z, ., ,, ", -, &, Enter

          Note: When you switch to this mode and type a letter, the layout
          automatically switches back to the default ("A") layout.


      The right layout button, labelled "A/1" or "1/A", switches between the
      main alphanetic mode and the numeric mode:

        * "1" mode contains numbers and some useful punctuation:
          0, 1, 2, 3, 4, 5, 6, 7, 8, 9, (, ), -, +, /, .


    * Shift button  ("^")
      ------------
      The Shift button allows you to type uppercase letters.
      Tapping it once switches it to Shift mode (the button changes to
      an arrow and a line).  Tapping it a second time switches it to CapsLock
      mode (the button switches to a double-arrow).

      When you type a key in Shift mode, the Shift button returns to normal
      (unshifted).  When you type in CapsLock mode, the Shift buton remains
      in CapsLock mode, of course.


    * Space button  (" ")
      ------------
      This button simply inserts a space (" ") into the text.


    * Menu buttons
      ------------
      Four menu buttons appear at the very bottom of the window:

        * Done:     Quits Thumbpad.  (Data is saved.  See "Sessions," below.)

        * About:    Displays an 'About' dialog window.

        * Clear:    Erases the contents of the text input field.

        * CopyAll:  Highlights the entire contents of the text input field,
                    and places it in the clipboard.  You can now switch to
                    another application (do not quit "Thumbpad" yet!) and
                    paste the text.


Shortcut Keys:
--------------
  You can use the PageUp and PageDown keys on your keyboard to switch
  between layout modes:

    * PageUp:    Toggles between "A/Q" and "Q/A"  (the two alpha modes)
    * PageDown:  Toggles between "A/1" and "1/A"  (alpha and numeric)
      

Sessions:
---------
  When you quit Thumbpad, the current text, as well as the cursor position
  and information about any highlighted text, is recorded.
  (It is saved into a file called ".thumbpad" in your home directory.)

  When you start Thumbpad up again later on, the file will be read, and
  you should be back where you had left off.

  When you're done with any text that's in the buffer, be sure to use
  the "Clear" button to erase it.


WARNING!
--------
  Please do not use Thumbpad while driving or in other potentially dangerous
  situations!


Installation
------------
  Please see the file "INSTALL" for details on compiling and installing
  Thumbpad.


Credits
-------
  Based directly on "Dot Note" (".Note"), (c) 1999 by William Westerman,
  utilware.

  http://www.utilware.com/


  "Thumbpad" (c) 2001 by Bill Kendrick, New Breed Software.

  http://www.newbreedsoftware.com/


  Thanks to:
    Kent Dahl, Stefan Szomraky, Alberto ("matmota"), Carl ("Luke"),
    Jeff Costlow, James Palmer, and Adrian Ulrich.

