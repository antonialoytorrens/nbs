/*
 * thumbpad.cxx
 *
 * An FLTK-based program that displays very large keys, allowing one to
 * write out a short note using only one hand.
 *
 * by Bill Kendrick
 * bill@newbreedsoftware.com
 *
 * Concept based on "DotNote" for PalmOS, (c) 1999 Utilware (Bill Westerman)
 *
 * Thumbpad is Open Source software released under the
 * GNU General Public License.  See "COPYING.txt".
 */

#include <Fl/Fl.H>
#include <Fl/Fl_Window.H>
#include <flpda/Widget_Factory.h>
#include <Fl/Fl_Box.H>
#include <Fl/Fl_Button.H>
#include <Fl/Fl_Output.H>
#include <Fl/Fl_Multiline_Input.H>
#include <Fl/Fl_Pixmap.H>
#include <Fl/Fl_Image.H>
#include <Fl/x.H>
#include "thumbpad.xpm"
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>


/* Project began 2001.Oct.06 */

#define VERSION "0.1"
#define DATE "2001.Oct.08"


/* Available keymodes: */

enum {
  KEYMODE_DEFAULTS,
  KEYMODE_OTHERS,
  KEYMODE_NUMBERS
};


/* Shift button modes, and their labels: */

enum {
  SHIFT_NONE,
  SHIFT_SHIFT,
  SHIFT_CAPS
};

char * shift_label[3] = {
  "@#2<", "@#2|<", "@#2<<"
};


/* The various keysets: */

char * keys_defaults[4][4] = {
  {"A", "C", "D", "E"},
  {"G", "H", "I", "L"},
  {"M", "N", "O", "P"},
  {"R", "S", "T", "U"}
};

char * keys_others[4][4] = {
  {"B", "F", "J", "K"},
  {"Q", "V", "W", "X"},
  {"Y", "Z", ".", ","},
  {"\"", "-", "&", "\n"}
};

char * keys_numbers[4][4] = {
  {"7", "8", "9", "("},
  {"4", "5", "6", ")"},
  {"1", "2", "3", "-"},
  {"0", ".", "+", "/"}
};


/* Local prototypes: */

static void cb_key(Fl_Button *button, void *which);
static void cb_main_space(Fl_Button *button, void *);
static void cb_main_shift(Fl_Button *button, void *);
static void cb_main_del(Fl_Button *button, void *);
static void cb_main_done(Fl_Button *button, void *);
static void cb_main_about(Fl_Button *button, void *);
static void cb_main_clear(Fl_Button *button, void *);
static void cb_main_copyall(Fl_Button *button, void *);
static void cb_main_alphamode(Fl_Button *button, void *);
static void cb_main_nummode(Fl_Button *button, void *);
static void cb_about_done(Fl_Button *button, void *);
void set_keys(void);
static int my_handler(int event);
void click(void);


/* About Window Class: */

class abouticonbox : public Fl_Box
{
  public:
    abouticonbox(Fl_Boxtype, int, int, int, int, char *);
    void draw();
    Fl_Pixmap *icon;
};


/* Globals: */

Fl_Window *wnd_about;
Fl_App_Window * wnd_main;
// Fl_Window *wnd_main;
abouticonbox *box_about;
Fl_Button *btn_about_done;
Fl_Output *out_about;
Fl_Multiline_Input *text_buf;
Fl_Button *btn_key[5][4];
Fl_Button *btn_main_space, *btn_main_del, *btn_main_shift;
Fl_Button *btn_main_alphamode, *btn_main_nummode;
int key_mode, shift_pressed;
char fname[512];


abouticonbox::abouticonbox(Fl_Boxtype type, int x, int y, int w, int h,
                           char * title) : Fl_Box(type, x, y, w, h, title)
{
}

void abouticonbox::draw()
{
  icon->draw(0, 0);
}


/* --- MAIN --- */

int main(int argc, char **argv)
{
  int file, l, pos, mark;
  char buf[256];
  // Fl_Box *box;
  Fl_Group *box;
  Fl_Dockable_Window *toolbar;
  Fl_Button *btn_main_done, *btn_main_about, *btn_main_copyall,
    *btn_main_clear;
  int i, x, y;


  /* Check for command-line options: */

  for (i = 1; i < argc; i++)
  {
    if (strcmp(argv[i], "--version") == 0 ||
        strcmp(argv[i], "-v") == 0)
      {
        printf("Thumbpad - Version " VERSION ", " DATE "\n");
        exit(0);
      }
    else if (strcmp(argv[i], "--help") == 0 || strcmp(argv[i], "-h") == 0 ||
             strcmp(argv[i], "--usage") == 0 || strcmp(argv[i], "-u") == 0)
      {
        printf("Usage: %s [--version | --help/usage ]\n", argv[0]);
        exit(0);
      }
    else
      {
        fprintf(stderr, "Unknown option: %s\n", argv[i]);
        fprintf(stderr, "Usage: %s [--version | --help/usage ]\n", argv[0]);
        exit(1);
      }
  }
  
  
  /* Determine filename for us: */
  
  snprintf(fname, 512, "%s/.thumbpad", getenv("HOME"));
  
  
  /* Create Main Window */
  
  wnd_main = WidgetFactory::new_window("Thumbpad");
  {
    /* Create Frame */

    // box = new Fl_Box(FL_FLAT_BOX, 0, 0, wnd_main->w(), wnd_main->h(), "");
    box = new Fl_Group(0, 0, wnd_main->w(), wnd_main->h(), "");
    {
      wnd_main->contents()->resizable(box);
      wnd_main->resizable(box);
      wnd_main->resizable();
   
 
      /* Create keypad */
    
      for (y = 0; y < 4; y++)
        {
          for (x = 0; x < 4; x++)
	    {
	      btn_key[y][x] = new Fl_Button(x * 40, y * 35 + 40,
					    40, 35, keys_defaults[y][x]);
	      btn_key[y][x]->labelsize(16);
              btn_key[y][x]->labelfont(FL_HELVETICA_BOLD);
	      btn_key[y][x]->callback((Fl_Callback*) cb_key,
				      (void*) (y * 4 + x));
	      btn_key[y][x]->align(FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
	      (wnd_main->contents())->resizable(btn_key[y][x]);
	      wnd_main->resizable(btn_key[y][x]);
	    }
        }
    
    
      /* Alpha mode toggle: */
    
      btn_main_alphamode = new Fl_Button(0, 185,
				         40, 35, "A/Q");
      btn_main_alphamode->labelsize(14);
      btn_main_alphamode->callback((Fl_Callback*) cb_main_alphamode);
      btn_main_alphamode->align(FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
      (wnd_main->contents())->resizable(btn_main_alphamode);
      btn_main_alphamode->box(FL_ROUND_UP_BOX);
    
    
      /* Numeric mode toggle: */
    
      btn_main_nummode = new Fl_Button(40, 185,
				       40, 35, "A/1");
      btn_main_nummode->labelsize(14);
      btn_main_nummode->callback((Fl_Callback*) cb_main_nummode);
      btn_main_nummode->align(FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
      (wnd_main->contents())->resizable(btn_main_nummode);
      btn_main_nummode->box(FL_ROUND_UP_BOX);
 
    
      /* Space key: */
    
      btn_main_space = new Fl_Button(120, 185,
				     40, 35, " ");
      btn_main_space->labelsize(14);
      btn_main_space->callback((Fl_Callback*) cb_main_space);
      btn_main_space->align(FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
      (wnd_main->contents())->resizable(btn_main_space);
    
    
      /* Delete key: */
    
      btn_main_del = new Fl_Button(120, 0,
				   40, 35, "@#<");
      btn_main_del->labelsize(14);
      btn_main_del->labeltype(FL_SYMBOL_LABEL);
      btn_main_del->callback((Fl_Callback*) cb_main_del);
      btn_main_del->align(FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
      (wnd_main->contents())->resizable(btn_main_del);
    
    
      /* Shift key: */
    
      btn_main_shift = new Fl_Button(80, 185,
				     40, 35, shift_label[SHIFT_NONE]);
      btn_main_shift->labelsize(14);
      btn_main_shift->labeltype(FL_SYMBOL_LABEL);
      btn_main_shift->callback((Fl_Callback*) cb_main_shift);
      btn_main_shift->align(FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
      (wnd_main->contents())->resizable(btn_main_shift);
      btn_main_shift->box(FL_ROUND_UP_BOX);
 
    
      /* Create text input buffer: */
    
      text_buf = new Fl_Multiline_Input(2, 2, 116, 36);
#ifdef FL_WORDWRAP_INPUT
      text_buf->type(FL_WORDWRAP_INPUT);
#else
      text_buf->type(FL_MULTILINE_INPUT);
#endif
      text_buf->labelsize(10);
      text_buf->textsize(14);
      (wnd_main->contents())->resizable(text_buf);
    }
    box->end();

    
    /* Create toolbar at the bottom: */
    
    toolbar = WidgetFactory::new_toolbar();
    {
      /* Create "Done" button */

      btn_main_done = WidgetFactory::new_button("Done",
                        (Fl_Callback*) cb_main_done, NULL);


      /* Create "About" button */

      btn_main_about = WidgetFactory::new_button("About",
                         (Fl_Callback*) cb_main_about, NULL);
    
    
      /* Create "Clear" button */

      btn_main_clear = WidgetFactory::new_button("Clear",
                         (Fl_Callback*) cb_main_clear, NULL);


      /* Create "Copy All" button */

      btn_main_copyall = WidgetFactory::new_button("Copy All",
                           (Fl_Callback*) cb_main_copyall, NULL);
      btn_main_copyall->labelfont(FL_HELVETICA_BOLD);
      btn_main_copyall->size(64, 15);
    }
    toolbar->end();
    ((Fl_App_Window *)wnd_main)->add_dockable(toolbar, 1);
  }
  wnd_main->end();
  
  
  /* Set key mode: */
  
  key_mode = KEYMODE_DEFAULTS;
  shift_pressed = SHIFT_NONE;


  /* Create handler for hardware buttons: */

  Fl::add_handler(my_handler);


  /* Create the About Window */

  wnd_about = new Fl_Window(0, 0, 160, 184, "About Thumbpad");
  {
    /* Create Icon */

    box_about = new abouticonbox(FL_UP_BOX, 0, 0, 30, 30, "");
    box_about->icon = new Fl_Pixmap(thumbpad_xpm);
    
    
    /* Create About text */
    
    out_about = new Fl_Output(2, 32, 156, 137);
    out_about->type(4);
    out_about->labelsize(10);
    out_about->textsize(10);
    out_about->value("Thumbpad - v" VERSION "-" DATE "\n"
                     "\n"
                     "Bill Kendrick\n"
                     "bill@newbreedsoftware.com\n"
                     "http://newbreedsoftware.com/\n"
                     "\n"
                     "Based on: PalmOS \"dotNote\"\n"
                     "by utilware (Bill Westerman)\n"
		     "\n"
		     "Please do not use while driving\n"
		     "or other dangerous situations.");


    /* Create "Done" button */

    btn_about_done = new Fl_Button(0, wnd_about->h() - 15, 32, 15, "Done");
    btn_about_done->labelsize(10);
    btn_about_done->callback((Fl_Callback*) cb_about_done);
    btn_about_done->align(FL_ALIGN_BOTTOM|FL_ALIGN_INSIDE);
  }
  wnd_about->end();
  
  
  /* Display the main window */

  wnd_main->show();


  /* Try to load existing data: */
  
  file = open(fname, O_RDONLY);
  if (file != -1)
    {
      read(file, &pos, sizeof(int));
      read(file, &mark, sizeof(int));
      
      while ((l = read(file, buf, sizeof(buf) - 1)) > 0)
	{
	  buf[l] = '\0';
	  text_buf->insert(buf);
	}
      
      close(file);
      
      text_buf->position(pos);
      text_buf->mark(mark);
    }
  
  
  /* Start the main loop */

  return Fl::run();
}


/* Main window's "Done" button's callback: */

static void cb_main_done(Fl_Button *button, void *)
{
  int file, pos, mark;
  
  /* Try to save existing data: */
  
  mark = text_buf->mark();
  pos = text_buf->position();
  
  file = creat(fname, S_IREAD | S_IWRITE);
  if (file != -1)
    {
      write(file, &pos, sizeof(int));
      write(file, &mark, sizeof(int));
      
      write(file, text_buf->value(), text_buf->size());
      
      close(file);
    }
  else
    {
      fprintf(stderr, "\nError writing to file: %s\n", fname);
    }


  wnd_main->hide();
}


/* Main window's "About" button's callback: */

static void cb_main_about(Fl_Button *button, void *)
{
  wnd_about->show();
}


/* Main window's "Copy All" button's callback: */

static void cb_main_copyall(Fl_Button *button, void *)
{
  text_buf->position(0);
  text_buf->mark(text_buf->size());
  text_buf->copy();
}


/* Main window's "Clear" button's callback: */

static void cb_main_clear(Fl_Button *button, void *)
{
  text_buf->cut(0, text_buf->size());
}


/* A key button's callback: */

static void cb_key(Fl_Button *button, void *which)
{
  int x, y;
  char c;
  char str[2];
  
  
  /* Which button was it? */
  
  y = ((int) (which)) / 4;
  x = ((int) (which)) % 4;
  
  
  /* Based on keymode, which key was it? */
  
  if (key_mode == KEYMODE_DEFAULTS)
    c = keys_defaults[y][x][0];
  else if (key_mode == KEYMODE_OTHERS)
    c = keys_others[y][x][0];
  else if (key_mode == KEYMODE_NUMBERS)
    c = keys_numbers[y][x][0];
  else
    c = ' ';
  
  
  /* If SHIFT isn't down, we want lowercase: */
  
  if (shift_pressed == SHIFT_NONE)
    c = tolower(c);
  
  
  /* Insert the character at the cursor! */
  
  str[0] = c;
  str[1] = '\0';
  
  text_buf->insert(str);
  
  
  if (key_mode == KEYMODE_OTHERS)
    {
      /* If in "Others" mode, go back to normal now: */
      
      key_mode = KEYMODE_DEFAULTS;
      set_keys();
    }
  
  
  if (shift_pressed == SHIFT_SHIFT)
    {
      /* If shift was held (not caps), reset to off: */
      
      shift_pressed = SHIFT_NONE;
      
      btn_main_shift->label(shift_label[shift_pressed]);
      btn_main_shift->redraw();
      btn_main_shift->show();
    }

  click();
}


/* Space button callback: */

static void cb_main_space(Fl_Button *button, void *)
{
  /* Insert a space: */
  
  text_buf->insert(" ");
  click();
}


/* Delete button callback: */

static void cb_main_del(Fl_Button *button, void *)
{
  int mark, pos, tmp;
  
  mark = text_buf->mark();
  pos = text_buf->position();
  
  
  /* Arrange what we see as mark and position so that we delete in the
     right direction (and so that mark has a better chance of being > 0 :) ) */
  
  if (mark < pos)
    {
      tmp = mark;
      mark = pos;
      pos = tmp;
    }
  
  
  /* If we're not at the left already, delete! */
  
  if (mark > 0)
    {
      /* If there's no highlighted selection, delete the char behind us: */
      
      if (mark == pos)
	pos--;

      text_buf->cut(mark, pos);
    }

  click();
}


/* Shift button callback: */

static void cb_main_shift(Fl_Button *button, void *)
{
  /* Switch between no shift, shift, and caps: */
  
  if (shift_pressed == SHIFT_NONE)
    shift_pressed = SHIFT_SHIFT;
  else if (shift_pressed == SHIFT_SHIFT)
    shift_pressed = SHIFT_CAPS;
  else
    shift_pressed = SHIFT_NONE;
  
  
  /* Change the label: */
  
  btn_main_shift->label(shift_label[shift_pressed]);
  btn_main_shift->redraw();
  btn_main_shift->show();

  click();
}


/* Alpha mode toggle callback: */

static void cb_main_alphamode(Fl_Button *button, void *)
{
  /* Switch between the alpha modes: */
  
  if (key_mode == KEYMODE_DEFAULTS)
    key_mode = KEYMODE_OTHERS;
  else
    key_mode = KEYMODE_DEFAULTS;
  
  
  /* Show the keys for that mode: */
  
  set_keys();

  click();
}


/* Number mode toggle callback: */

static void cb_main_nummode(Fl_Button *button, void *)
{
  /* Toggle numbers mode: */
  
  if (key_mode == KEYMODE_NUMBERS)
    key_mode = KEYMODE_DEFAULTS;
  else
    key_mode = KEYMODE_NUMBERS;

  
  /* Show the keys for the current mode: */
  
  set_keys();

  click();
}


/* About window's "Done" button's callback: */

static void cb_about_done(Fl_Button *button, void *)
{
  /* Close the 'about' window: */
  
  wnd_about->hide();
}


/* Set keys: */

void set_keys(void)
{
  int x, y;
  char * keyset[4][4];
  
  
  /* Determine which keyset to use.  Redraw keymode buttons: */
  
  if (key_mode == KEYMODE_DEFAULTS)
    {
      keyset = keys_defaults;
      
      btn_main_alphamode->label("A/Q");
      btn_main_alphamode->redraw();
      btn_main_alphamode->show();

      btn_main_nummode->label("A/1");
      btn_main_nummode->redraw();
    }
  else if (key_mode == KEYMODE_OTHERS)
    {
      keyset = keys_others;
      
      btn_main_alphamode->label("Q/A");
      btn_main_alphamode->redraw();
      btn_main_alphamode->show();

      btn_main_nummode->label("A/1");
      btn_main_nummode->redraw();
    }
  else if (key_mode == KEYMODE_NUMBERS)
    {
      keyset = keys_numbers;
      
      btn_main_alphamode->hide();

      btn_main_nummode->label("1/A");
      btn_main_nummode->redraw();
    }
  
  
  /* Redraw the keys for this keyset: */
  
  for (y = 0; y < 4; y++)
    {
      for (x = 0; x < 4; x++)
	{
	  if (keyset[y][x][0] != '\n')
	    {
	      btn_key[y][x]->label(keyset[y][x]);
	      btn_key[y][x]->labeltype(FL_NORMAL_LABEL);
	    }
	  else
	    {
	      btn_key[y][x]->label("@returnarrow");
	      btn_key[y][x]->labeltype(FL_SYMBOL_LABEL);
	    }
	  btn_key[y][x]->redraw();
	}
    }
}


/* Handle pageup and pagedown keys: */
/* (Note: I'm not sure if I'm doing this absolutely correctly!) */

static int my_handler(int event)
{
  if (event == FL_SHORTCUT)
  {
    if (Fl::event_key() == FL_Page_Up)
    {
      cb_main_alphamode(NULL, NULL);      
      return 1;
    }
    else if (Fl::event_key() == FL_Page_Down)
    {
      cb_main_nummode(NULL, NULL);
      return 1;
    }
  }

  return 0;
}


/* Make a click sound: */

void click(void)
{
  XKeyboardControl vals;

  vals.bell_pitch = 440;
  vals.bell_duration = 5;
  XChangeKeyboardControl(fl_display, KBBellPitch | KBBellDuration, &vals);
  XBell(fl_display, 100);
}

