/*
  goweather.c

  GoWeather, a small graphical program which can display current weather
  conditions and ~5-day forecast, by using METAR and Zone Forecast (ZFP)
  information available freely from the US National Weather Service.

  by Bill Kendrick
  bill@newbreedsoftware.com
  http://www.newbreedsoftware.com/goweather/

  October 16, 2001 - October 24, 2001
*/

#define VERSION "2001.Oct.24-beta"
#define DATE "2001.Oct.24"


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <limits.h>
#include <math.h>
#include <sys/types.h>
#include <dirent.h>
#include <Fl/Fl.H>
#include <Fl/Fl_Window.H>
#include <flpda/Widget_Factory.h>
#include <flpda/gettext.h>
#include <flpda/Fl_Paged_Scroll.H>
#include <Fl/Fl_Box.H>
#include <Fl/Fl_Button.H>
#include <Fl/Fl_Menu_Button.H>
#include <Fl/Fl_Pixmap.H>
#include <Fl/Fl_Image.H>
#include <Fl/Fl_Tabs.H>
#include <Fl/Fl_Output.H>

extern "C" {
#include <metar.h>
};


/* Images: */

#include "images/na.xpm"
#include "images/fair.xpm"
#include "images/sunny.xpm"
#include "images/sunnyn.xpm"
#include "images/pcloudy.xpm"
#include "images/pcloudyn.xpm"
#include "images/mcloudy.xpm"
#include "images/mcloudyn.xpm"
#include "images/cloudy.xpm"
#include "images/drizzle.xpm"
#include "images/fdrizzle.xpm"
#include "images/showers.xpm"
#include "images/tstorm.xpm"
#include "images/rain.xpm"
#include "images/frain.xpm"
#include "images/rainandsnow.xpm"
#include "images/snow.xpm"
#include "images/snowshowers.xpm"
#include "images/flurries.xpm"
#include "images/blowingsnow.xpm"
#include "images/blizzard.xpm"
#include "images/wswatch.xpm"
#include "images/wind.xpm"
#include "images/hazy.xpm"
#include "images/fog.xpm"
#include "images/smoke.xpm"

enum {
  NA,          /* CF - Screens it's used on so far: C=conditions, F=forecast */
  FAIR,        /* C  */
  SUNNY,       /*  F */
  SUNNYN,      /*  F */
  PCLOUDY,     /* CF */
  PCLOUDYN,    /*  F */
  MCLOUDY,     /* C  */
  MCLOUDYN,    /* C  */
  CLOUDY,      /* CF */
  DRIZZLE,     /*    */
  FDRIZZLE,    /*    */
  SHOWERS,     /*    */
  TSTORM,      /*    */
  RAIN,        /*    */
  FRAIN,       /*    */
  RAINANDSNOW, /*    */
  SNOW,        /*    */
  SNOWSHOWERS, /*    */
  FLURRIES,    /*    */
  BLOWINGSNOW, /*    */
  BLIZZARD,    /*    */
  WSWATCH,     /*    */
  WIND,        /*  F */
  HAZY,        /*    */
  FOG,         /*  F */
  SMOKE,       /*    */
  NUM_FORECASTS
};

char ** forecast_xpm_ptrs[NUM_FORECASTS] = {
  na_xpm,
  fair_xpm,
  sunny_xpm,
  sunnyn_xpm,
  pcloudy_xpm,
  pcloudyn_xpm,
  mcloudy_xpm,
  mcloudyn_xpm,
  cloudy_xpm,
  drizzle_xpm,
  fdrizzle_xpm,
  showers_xpm,
  tstorm_xpm,
  rain_xpm,
  frain_xpm,
  rainandsnow_xpm,
  snow_xpm,
  snowshowers_xpm,
  flurries_xpm,
  blowingsnow_xpm,
  blizzard_xpm,
  wswatch_xpm,
  wind_xpm,
  hazy_xpm,
  fog_xpm,
  smoke_xpm
};

char * forecast_strings[NUM_FORECASTS] = {
  "N/A",
  "Fair",
  "Sunny",
  "Clear",
  "Partly Cloudy",
  "Partly Cloudy",
  "Mostly Cloudy",
  "Mostly Cloudy",
  "Cloudy",
  "Drizzle",
  "Freezing Drizzle",
  "Showers",
  "Thunderstorms",
  "Rain",
  "Freezing Rain",
  "Rain and Snow",
  "Snow",
  "Snow Showers",
  "Flurries",
  "Blowing Snow",
  "Blizzard",
  "Winter Storm Watch",
  "Wind",
  "Hazy",
  "Fog",
  "Smoke"
};

/* Strings for directions: */

char * wind_dir_strings[16] = {
  "N", "NNE", "NE", "ENE",
  "E", "ESE", "SE", "SSE",
  "S", "SSW", "SW", "WSW",
  "W", "WNW", "NW", "NNW"
};


enum {
  UNITS_METRIC,
  UNITS_ENGLISH,
  UNITS_BOTH
};

#define UNITS_DEFAULT UNITS_ENGLISH

char * location_dir;


/* Forecast box class: */

class forecast_box : public Fl_Box
{
public:
  forecast_box(Fl_Boxtype, int, int, int, int, char *);
  void draw();
  Fl_Pixmap * icon;
};


forecast_box::forecast_box(Fl_Boxtype type,
			   int x, int y, int w, int h, char * title) :
  Fl_Box(type, x, y, w, h, title)
{
}

void forecast_box::draw()
{
  icon->draw(this->x(), this->y());
}


/* --- Enums, typedefs, #defines: --- */

#define MAX_FORECASTS 7

#define DEBUG
// #define DEBUG_ZFP

enum {
  FALSE,
  TRUE
};

typedef struct zfp_type {
  char * date;      /* eg, "TODAY" or "WEDNESDAY" or... <sigh> */
  int cond_icon;    /* See enum at top */
  char * cond_str;  /* eg, "PARTLY CLOUDY AND COOLER", etc. */
  float temp;       /* Temp in F */
} zfp_type;


/* --- Globals: --- */

/* FIXME: Needs a more rational place (~/.goweather/...)
   Needs to be over-ridable via command-line, and possibly
   at runtime!!! */

char * metar_fname = "metar.dat";
char * zfp_fname = "zfp.dat";


Decoded_METAR metar;  /* Needs to be outside of main() due to a bug(?)
                         in MDSP Lib (libmetar) */

Fl_Window *wnd_about;
Fl_App_Window *wnd_main, *wnd_raw;
Fl_Button *btn_main_done, *btn_main_toggle, *btn_about_done;
Fl_Button *btn_raw_done;
Fl_Menu_Button *btn_main_menu;
Fl_Dockable_Window *toolbar, *raw_toolbar;
Fl_Group *box_conditions, *box_forecast, *tab_forecast;
Fl_Paged_Scroll *scroll;
Fl_Box *invisible_box;
Fl_Page_UpDown_Button* page_button;
forecast_box *forecasts[MAX_FORECASTS];
forecast_box *condition_box;
zfp_type zfp[MAX_FORECASTS];
Fl_Box *forecast_date[MAX_FORECASTS],
  *forecast_cond[MAX_FORECASTS],
  *forecast_temp[MAX_FORECASTS];
int showing_forecast, units;
Fl_Box * cond_label, * temp_label, * dewp_val, * vis_val;
Fl_Output *out_about;
Fl_Output *out_raw_metar, *out_raw_zfp;


/* Local function prototypes: */

static void cb_main_done(Fl_Button *button, void *);
static void cb_about_done(Fl_Button *button, void *);
static void cb_menu_about(Fl_Button *button, void *);
static void cb_raw_done(Fl_Button *button, void *);
static void cb_menu_raw(Fl_Button *button, void *);
static void cb_menu_units(Fl_Button *button, void *what);
static void cb_menu_location(Fl_Button *button, void *where);
static void cb_main_toggle(Fl_Button *button, void *);
void redraw_all(void);
float farenheit(float c);
float celsius(float f);
float kilometers(float m);
char * temperature_string(float t);
char * distance_string(float d);
int calc_humidity(float temp, float dewp);
char * wind_dir_string(WindStruct w);
void draw_conditions(void);
void draw_forecast(void);
FILE * dat_fopen(char * file);
void load_metar(void);
void load_zfp(void);


/* --- MAIN --- */

int main(int argc, char * argv[])
{
  int i;
  char str[128], dirname[128];
  DIR * dir;
  struct dirent * locdirent;
  Fl_Box *tmp;


  /* FIXME: Handle command-line args: */
  
  units = UNITS_DEFAULT;


  location_dir = strdup("Default");  


  /* Create the "About" window: */

  wnd_about = new Fl_Window(0, 0, 160, 160, "About GoWeather");
  {
    out_about = new Fl_Output(2, 2, 156, 141);
    out_about->type(4);
    out_about->labelsize(10);
    out_about->textsize(10);
    out_about->value(
      "GoWeater\n"
      "\n"
      "Version " VERSION "\n"
      DATE "\n"
      "\n"
      "Bill Kendrick\n"
      "bill@newbreedsoftware.com\n"
      "newbreedsoftware.com/goweather");

    btn_about_done = new Fl_Button(0, wnd_about->h() - 15, 32, 15, "Done");
    btn_about_done->labelsize(10);
    btn_about_done->callback((Fl_Callback*) cb_about_done);
    btn_about_done->align(FL_ALIGN_BOTTOM | FL_ALIGN_INSIDE);
  }
  wnd_about->end();


  /* Raw output window: */

  wnd_raw = WidgetFactory::new_window("GoWeather - Raw data");
  {
    Fl_Group * raw_group = new Fl_Group(0, 0, 160, 240 - 15);
    {
      Fl_Box * metar_label = new Fl_Box(2, 2, 156, 15, "METAR:");
      metar_label->align(FL_ALIGN_CENTER | FL_ALIGN_INSIDE);
      metar_label->labelsize(15);
      metar_label->labelfont(FL_HELVETICA_BOLD);

      out_raw_metar = new Fl_Output(2, 17, 156, 3 * 15);
      out_raw_metar->type(4);
      out_raw_metar->labelsize(10);
      out_raw_metar->textsize(10);
      out_raw_metar->value("No METAR data loaded\n");
      out_raw_metar->labelfont(FL_SCREEN);

      Fl_Box * zfp_label = new Fl_Box(2, 4 * 15 + 2, 156, 15, "Zone Forecast:");
      zfp_label->align(FL_ALIGN_CENTER | FL_ALIGN_INSIDE);
      zfp_label->labelsize(15);
      zfp_label->labelfont(FL_HELVETICA_BOLD);

      out_raw_zfp = new Fl_Output(2, 5 * 15 + 2, 156, 240 - (6 * 16) - 2);
      out_raw_zfp->type(4);
      out_raw_zfp->labelsize(10);
      out_raw_zfp->textsize(10);
      out_raw_zfp->value("No ZFP data loaded\n");
      out_raw_zfp->labelfont(FL_SCREEN);
    }

    wnd_raw->contents()->resizable(raw_group);
    wnd_raw->resizable(raw_group);


    raw_toolbar = WidgetFactory::new_toolbar();
    {
      /* Add the "Done" button: */

      btn_raw_done = WidgetFactory::new_button(_("Done"),
                                               (Fl_Callback*) cb_raw_done,
                                               NULL);
      btn_raw_done->size(32, 15);
    }
    raw_toolbar->end();
    ((Fl_App_Window *)wnd_raw)->add_dockable(raw_toolbar, 1);
  }
  wnd_raw->end();


  /* Load the data files: */

  load_metar();
  load_zfp();


  /* Open the app. window: */
  
  wnd_main = WidgetFactory::new_window("GoWeather");
  {
    /* Create forecast frame: */
    
    box_forecast = new Fl_Group(0, 0, wnd_main->w(), 40 * MAX_FORECASTS + 20,
				"");
    {
      scroll = new Fl_Paged_Scroll(0, 0, 160, 240 - 15, "GoWeather");
      {
	scroll->box(FL_FLAT_BOX);
	scroll->color(FL_WHITE);
	scroll->selection_color(FL_BLACK);
	scroll->labelsize(WidgetFactory::labelsize());
	

	for (i = 0; i < MAX_FORECASTS; i++)
	  {
#ifdef DEBUG
	    printf("Building spot for forecast #%d\n", i);
	    fflush(stdout);
#endif
  
	    /* Forecast icon: */
	    
	    forecasts[i] = new forecast_box(FL_UP_BOX, 0, i * 42, 40, 40, "");
	    forecasts[i]->icon = new Fl_Pixmap(forecast_xpm_ptrs[NA]);
	    
	    
	    /* Forecast date: */
	    
	    forecast_date[i] = new Fl_Box(42, i * 42 + 2, 118, 8, "");
	    forecast_date[i]->align(FL_ALIGN_LEFT | FL_ALIGN_INSIDE);
	    forecast_date[i]->labelsize(8);
	    forecast_date[i]->labelfont(FL_HELVETICA_BOLD);
	
	    
	    /* Forecast conditions: */
	    
	    forecast_cond[i] = new Fl_Box(42, i * 42 + 10,
					  118, 8, "");
	    forecast_cond[i]->align(FL_ALIGN_LEFT | FL_ALIGN_INSIDE);
	    forecast_cond[i]->labelsize(8);
	    
	    
	    /* Forecast temp: */
	    
	    forecast_temp[i] = new Fl_Box(42, i * 42 + 18,
					  118, 8, "");
            forecast_temp[i]->align(FL_ALIGN_LEFT | FL_ALIGN_INSIDE);
	    forecast_temp[i]->labelsize(8);
	  }
	
	tmp = new Fl_Box(0, i * 42, 160, 20);
      }
      scroll->end();
    }
    box_forecast->end();
    box_forecast->hide();
    
    showing_forecast = 0;
    
    
    /* Create conditions frame: */
    
    box_conditions = new Fl_Group(0, 0, wnd_main->w(), wnd_main->h(), "");
    {
      /* Display location: */
      
      Fl_Box * loc_label = new Fl_Box(0, 2, 160, 15, metar.stnid);
      loc_label->align(FL_ALIGN_CENTER | FL_ALIGN_INSIDE);
      loc_label->labelsize(15);
      loc_label->labelfont(FL_HELVETICA_BOLD);
      
      
      /* Icon: */
      
      condition_box = new forecast_box(FL_UP_BOX, 60, 17, 40, 40, "");
      condition_box->icon = new Fl_Pixmap(forecast_xpm_ptrs[NA]);
      

      /* Conditions: */
      
      cond_label = new Fl_Box(0, 60, 160, 15, "");
      cond_label->align(FL_ALIGN_CENTER | FL_ALIGN_INSIDE);
      cond_label->labelsize(15);
      
      
      /* Temp: */
      
      temp_label = new Fl_Box(0, 75, 160, 15,
			      temperature_string(metar.Temp_2_tenths));
      temp_label->align(FL_ALIGN_CENTER | FL_ALIGN_INSIDE);
      
      
      
      Fl_Box * details_box = new Fl_Box(FL_FLAT_BOX, 2, 92, 156, 100, "");
      {
	details_box->color(FL_DARK1);
	
	/* Humidity: */
	
	Fl_Box * humid_label = new Fl_Box(0, 95, 80, 10, _("Humidity:"));
	humid_label->align(FL_ALIGN_RIGHT | FL_ALIGN_INSIDE);
	humid_label->labelfont(FL_HELVETICA_BOLD);
	humid_label->labelsize(10);
	
	snprintf(str, sizeof(str), "%d%%",
		 calc_humidity(metar.Temp_2_tenths, metar.DP_Temp_2_tenths));
	Fl_Box * humid_val = new Fl_Box(80, 95, 80, 10, strdup(str));
	humid_val->align(FL_ALIGN_LEFT | FL_ALIGN_INSIDE);
	humid_val->labelsize(10);
	
	
	/* Wind speed: */
	
	Fl_Box * windspd_label = new Fl_Box(0, 110, 80, 10, _("Wind Speed:"));
	windspd_label->align(FL_ALIGN_RIGHT | FL_ALIGN_INSIDE);
	windspd_label->labelfont(FL_HELVETICA_BOLD);
	windspd_label->labelsize(10);
	
	snprintf(str, sizeof(str), "%s @ %d %s",
		 wind_dir_string(metar.winData),
		 metar.winData.windSpeed,
		 metar.winData.windUnits);
	Fl_Box * windspd_val = new Fl_Box(80, 110, 80, 10, strdup(str));
	windspd_val->align(FL_ALIGN_LEFT | FL_ALIGN_INSIDE);
	windspd_val->labelsize(10);
	
	
	/* Dew Point: */
	
	Fl_Box * dewp_label = new Fl_Box(0, 125, 80, 10, _("Dew Point:"));
	dewp_label->align(FL_ALIGN_RIGHT | FL_ALIGN_INSIDE);
	dewp_label->labelfont(FL_HELVETICA_BOLD);
	dewp_label->labelsize(10);
	
	dewp_val = new Fl_Box(80, 125, 80, 10,
			      temperature_string(metar.DP_Temp_2_tenths));
	dewp_val->align(FL_ALIGN_LEFT | FL_ALIGN_INSIDE);
	dewp_val->labelsize(10);
	
	
	/* Visibility: */
	
	Fl_Box * vis_label = new Fl_Box(0, 140, 80, 10, _("Visibility:"));
	vis_label->align(FL_ALIGN_RIGHT | FL_ALIGN_INSIDE);
	vis_label->labelfont(FL_HELVETICA_BOLD);
	vis_label->labelsize(10);
	
	/* FIXME: Which ".prevail_vsby*" var. should I /expect/? */
	
	vis_val = new Fl_Box(80, 140, 80, 10,
			     distance_string(metar.prevail_vsbySM));
	vis_val->align(FL_ALIGN_LEFT | FL_ALIGN_INSIDE);
	vis_val->labelsize(10);
      }
      
      
      /* Update fields with current data: */
      
      draw_conditions();
      draw_forecast();
    }
    box_conditions->end();
    
    
    /* Create toolbar at the bottom: */
    
    toolbar = WidgetFactory::new_toolbar();
    {
      /* Add the "Done" button: */
      
      btn_main_done = WidgetFactory::new_button(_("Done"),
						(Fl_Callback*) cb_main_done,
						NULL);
      btn_main_done->size(32, 15);

      
      /* Add the "Menu" button: */
      
      btn_main_menu = WidgetFactory::new_menu_button(_("Menu"));
      
      Fl_Menu_Item mi[] = {
	{_("About"), 0, (Fl_Callback*) cb_menu_about, 0, 0},
	{_("Units"), 0, 0, 0, FL_SUBMENU },
	{_("Metric"), 0, (Fl_Callback*) cb_menu_units, (void*) UNITS_METRIC,
	 FL_MENU_RADIO },
	{_("English"), 0, (Fl_Callback*) cb_menu_units, (void*) UNITS_ENGLISH,
	 FL_MENU_RADIO },
	{_("Both"), 0, (Fl_Callback*) cb_menu_units, (void*) UNITS_BOTH,
	 FL_MENU_RADIO },
	{0},
	{_("Raw Data"), 0, (Fl_Callback*) cb_menu_raw, 0, FL_MENU_DIVIDER},
	{0}
      };
      
      
      /* Read the "~/.goweather/" directory for locations to add to the
	 "Location" submenu: */
      
      snprintf(dirname, sizeof(dirname), "%s/.goweather", getenv("HOME"));

      dir = opendir(dirname);
      if (dir != NULL)
	{
	  do
	    {
	      locdirent = readdir(dir);
	      
	      if (locdirent != NULL)
		{
		  if (locdirent->d_name[0] != '.')
		    {
		      mi->add(locdirent->d_name, 0,
			      (Fl_Callback*) cb_menu_location,
			      (void*) strdup(locdirent->d_name), FL_MENU_RADIO);
		    }
		}
	    }
	  while (locdirent != NULL);
	  
	  closedir(dir);
	}
    
      
      
      /* Set default units checkbox: */
      
      mi[UNITS_DEFAULT + 2].setonly();
      
      
      /* Set default location checkbox: */
      
      mi[8].setonly();
      
      
      /* Build the menu! */
      
      btn_main_menu->clear();
      btn_main_menu->copy(mi);

      
      /* Add the toggle ("Forecast"/"Conditions") button: */

      btn_main_toggle = WidgetFactory::new_button(_("Forecast"),
						  (Fl_Callback*)
						  cb_main_toggle,
						  NULL);
      btn_main_toggle->size(64, 15);
      
      
      
      /* Add some space (so the pgup/pgdown buttons will be flush to right) */

      invisible_box = new Fl_Box(0, 0, wnd_main->w() - 32 - 32 - 64 - 10, 15);
      invisible_box->box(FL_FLAT_BOX);
      
      
      /* Add the pgup/pgdown buttons to this Fl_Paged_Scroll: */
      
      page_button = WidgetFactory::new_pagekey();
      scroll->page_updown_button(page_button);
      page_button->deactivate_up();
      page_button->deactivate_down();
      page_button->align(FL_ALIGN_RIGHT);
    }
    toolbar->end();
    ((Fl_App_Window *)wnd_main)->add_dockable(toolbar, 1);
  }
  wnd_main->end();
  
  
  /* Make it all resizable: */
 
  wnd_main->contents()->resizable(scroll);
  wnd_main->resizable(scroll);
  
  
  /* Display the main window: */

  wnd_main->show();

  return Fl::run();
}


/* Main window's toggle ('Forecast'/'Conditions') button callback: */

static void cb_main_toggle(Fl_Button *button, void *)
{
  showing_forecast = !showing_forecast;
  
  if (showing_forecast)
    {
      box_conditions->hide();
      box_forecast->show();
      btn_main_toggle->label(_("Conditions"));
      page_button->show();
    }
  else
    {
      box_forecast->hide();
      box_conditions->show();
      btn_main_toggle->label(_("Forecast"));
      page_button->hide();
    }
}


/* Convert temp. C to F: */

float farenheit(float c)
{
  return (c * 9.0 / 5.0) + 32.0;
}


/* Convert temp. F to C: */

float celsius(float f)
{
  return (f - 32.0) / 5.0 * 9.0;
}


/* Convert distance MI to KM: */

float kilometers(float m)
{
  return (m * 1.609344);
}


/* Return string version of temperature (converted as needed) */

char * temperature_string(float t)
{
  char str[128];
  
  if (t < 1000.0)  /* Shouldn't this be INT_MAX or, better, LONG_MAX !? */
    {
      if (units == UNITS_BOTH)
	{
	  snprintf(str, sizeof(str), "%.0fF (%.0fC)",
		   rint(farenheit(t)), rint(t));
	}
      else if (units == UNITS_ENGLISH)
	{
	  snprintf(str, sizeof(str), "%.0fF", rint(farenheit(t)));
	}
      else
	{
	  snprintf(str, sizeof(str), "%.0fC", rint(t));
	}
    }
  else
    {
      strcpy(str, "???");
    }
  
  return(strdup(str));
}


/* Return string version of distance (converted as needed) */

char * distance_string(float d)
{
  char str[128];
  
  if (d != INT_MAX)
    {
      /* FIXME: Show F or C or both based on user prefs! */
      
      if (units == UNITS_BOTH)
	{
	  snprintf(str, sizeof(str), "%.2fmi (%.2fkm)", d, kilometers(d));
	}
      else if (units == UNITS_ENGLISH)
	{
	  snprintf(str, sizeof(str), "%.2fmi", d);
	}
      else
	{
	  snprintf(str, sizeof(str), "%.2fkm", kilometers(d));
	}
    }
  else
    {
      strcpy(str, "???");
    }
  
  return(strdup(str));
}


/* Relative humidity computation, taken from GnomeWeather applet.
   Credited to Olof.Oberg@modopaper.modogroup.com */

int calc_humidity(float temp, float dewp)
{
  float esat, esurf;
  
  esat = 6.11 * pow(10.0, (7.5 * temp) / (237.7 + temp));
  esurf = 6.11 * pow(10.0, (7.5 * dewp) / (237.7 + dewp));
  
  return (int)((esurf/esat) * 100.0);
}


/* Return string for wind direction (eg, "Variable", "North", etc.): */

char * wind_dir_string(WindStruct w)
{
  if (w.windVRB)
    return(_("Variable"));
  else
    return wind_dir_strings[((w.windDir + 11) % 360) / 22];
}


/* Main window's 'Done' button callback: */

static void cb_main_done(Fl_Button *button, void *)
{
  wnd_main->hide();
}


/* About window's 'Done' button callback: */

static void cb_about_done(Fl_Button *button, void *)
{
  wnd_about->hide();
}


/* Menu's 'About' button callback: */

static void cb_menu_about(Fl_Button *button, void *)
{
  wnd_about->show();
}


/* Raw window's 'Done' button callback: */

static void cb_raw_done(Fl_Button *button, void *)
{
  wnd_raw->hide();
}


/* Menu's 'Raw' button callback: */

static void cb_menu_raw(Fl_Button *button, void *)
{
  wnd_raw->show();
}


/* Menu's 'Metric' button callback: */

static void cb_menu_units(Fl_Button *button, void *what)
{
  /* Set units: */
  
  units = (int) ((int*) what);
  redraw_all();
}


void redraw_all(void)
{
  /* Redraw everything! */
  
  draw_conditions();
  box_conditions->redraw();
  
  draw_forecast();
  box_forecast->redraw();
  

  if (showing_forecast)
    {
      box_forecast->hide();
      box_forecast->show();
    }
  else
    {
      box_conditions->hide();
      box_conditions->show();
    }
}


/* Menu's 'Location' button callback: */

static void cb_menu_location(Fl_Button *button, void *where)
{
  free(location_dir);
  location_dir = strdup((char*) where);

#ifdef DEBUG
  printf("%s chosen\n", (char*) where);
#endif

  load_metar();
  load_zfp();

  redraw_all();
}


/* Set values of fields on conditions screen: */

void draw_conditions(void)
{
  int f;
  
  
  /* Determine conditions to display: */
  
  f = NA;
  
  
  /* (First, test for phenomenon (rain, snow, ice, hail, mist, fog, etc) */
  
  /* (Last resort, check cloud types) */
  
  if (strcmp(metar.cldTypHgt[0].cloud_type, "CLR") == 0)
    f = FAIR;
  else if (strcmp(metar.cldTypHgt[0].cloud_type, "BKN") == 0)
    f = CLOUDY;
  else if (strcmp(metar.cldTypHgt[0].cloud_type, "SCT") == 0)
    f = PCLOUDY;
  else if (strcmp(metar.cldTypHgt[0].cloud_type, "OVC") == 0 ||
	   strcmp(metar.cldTypHgt[0].cloud_type, "FEW") == 0)
    f = MCLOUDY;
  
  
  /* Set icon: */
  
  delete condition_box->icon;
  condition_box->icon = new Fl_Pixmap(forecast_xpm_ptrs[f]);
  
  
  /* Set condition and temp. text: */
  
  cond_label->label(_(forecast_strings[f]));
  temp_label->label(temperature_string(metar.Temp_2_tenths));

  
  /* Set dew point temp. text: */
  
  dewp_val->label(temperature_string(metar.DP_Temp_2_tenths));

  
  /* Set the visibility distance text: */
  
  vis_val->label(distance_string(metar.prevail_vsbySM));
}


/* Set values of fields on forecast screen: */

void draw_forecast(void)
{
  int i;
  
  
  /* Determine conditions to display: */

#ifdef DEBUG  
  printf("Redrawing forecasts\n");
#endif

  for (i = 0; i < MAX_FORECASTS; i++)
    {
      delete forecasts[i]->icon;
      forecasts[i]->icon = new Fl_Pixmap(forecast_xpm_ptrs[zfp[i].cond_icon]);
      
      if (zfp[i].date != NULL)
	forecast_date[i]->label(_(zfp[i].date));
      else
	forecast_date[i]->label("...");
      
      if (zfp[i].cond_str != NULL)
	forecast_cond[i]->label(zfp[i].cond_str);
      else
	forecast_cond[i]->label("...");
      
      forecast_temp[i]->label(temperature_string(celsius(zfp[i].temp)));
    }
}


/* Open a data file for the current location */

FILE * dat_fopen(char * file)
{
  char fname[512];
  FILE * fi;
  
  snprintf(fname, sizeof(fname), "%s/.goweather/%s/%s",
	   getenv("HOME"), location_dir, file);
#ifdef DEBUG
  printf("Attempting to open: %s\n", fname);
  fflush(stdout);
#endif
  
  fi = fopen(fname, "r");
  
  return(fi);
}


void load_metar(void)
{
  FILE * fi;
  char str[128];
  int c, len, maxlen;
  unsigned int i;
  char * observation, * observation_no_crlf;


  /* Open the METAR file: */

  fi = dat_fopen(metar_fname);

  observation = "";
  observation_no_crlf = "";


  /* Skip header line: */

  fgets(str, sizeof(str), fi);
#ifdef DEBUG
  printf("Line one of %s: %s\n", metar_fname, str);
  fflush(stdout);
#endif


  /* Read file into memory: */

  if (fi != NULL)
    {
      maxlen = 256;
      observation = (char*) malloc(sizeof(char) * maxlen);
      len = 0;
      
      
      /* File-read loop: */
      
      while (!feof(fi))
	{
	  c = fgetc(fi);
	  
	  if (c != EOF)
	    {
	      /* Add char to string: */

	      observation[len] = c;
	      len++;
	      
	      
	      /* Make string bigger if we need to! */
	      
	      if (len > maxlen)
		{
		  maxlen = maxlen + 256;
		  observation = (char*) realloc(observation,
						sizeof(char) * maxlen);
		}
	    }
	  
	  
	  /* End the string: */
	  
	  observation[len] = '\0';
	}
      
      fclose(fi);
      
      
      /* Convert CRs and LFs to spaces: */
	      
      observation_no_crlf = strdup(observation);

      for (i = 0; i <= strlen(observation_no_crlf); i++)
        {
          if (observation_no_crlf[i] == '\n' ||
              observation_no_crlf[i] == '\r')
            observation_no_crlf[i] = ' ';
        }
 
 
      /* Try to decode the METAR data: */

      if (DcdMETAR(observation_no_crlf, &metar) != 0)
	{
	  fprintf(stderr, "Error decoding %s\n", metar_fname);
	}

      free(observation_no_crlf);
    }
  else
    {
      /* Was unable to open METAR file... */
      
      perror(metar_fname);
    }
  
  
#ifdef DEBUG
  printf("%s contains observation from %d day, %d:%d UTC\n",
         metar_fname, metar.ob_date, metar.ob_hour, metar.ob_minute);
  fflush(stdout);
      
  prtDMETR(&metar);
  fflush(stdout);
#endif


  /* Change text of 'Raw' window's METAR section: */

  out_raw_metar->value(strdup(observation));

  free(observation);
}


void load_zfp(void)
{
  int i, cur_zfp, pos_in_str, f;
  unsigned int maxlen;
  char str[256], date_str[128], cond_str[128];
  char * forecast_text;
  FILE * fi;


  /* Clear ZFP array */
  /* (in case it doesn't get filled (or completely, at least)) */
  
  for (i = 0; i < MAX_FORECASTS; i++)
    {
      zfp[i].date = NULL;
      zfp[i].cond_icon = NA;
      zfp[i].cond_str= NULL;
      zfp[i].temp = INT_MAX;
    }

  forecast_text = "";
  
  
  /* Load current forecast (from ZFP data): */
  
  fi = dat_fopen(zfp_fname);

  if (fi != NULL)
    {
      /* File-read loop: */
      
      cur_zfp = 0;

      maxlen = 256;
      forecast_text = (char*) malloc(sizeof(char) * maxlen);
      forecast_text[0] = '\0';
      
      do
	{
	  fgets(str, sizeof(str), fi);
	  
#ifdef DEBUG_ZFP
	  printf("ZFP: %s\n", str);
	  fflush(stdout);
#endif
	  
	  if (!feof(fi))
	    {
              if (strlen(forecast_text) + strlen(str) >= maxlen)
                {
                  maxlen = maxlen + 256;
                  forecast_text = (char*) realloc(forecast_text,
                                                  sizeof(char) * maxlen);
                }

              strcat(forecast_text, str);



	      if (str[0] == '.')
		{
		  /* Slurp date (eg, "TODAY", "TONIGHT", etc.) */
		  
		  for (i = 1; i < (int) strlen(str) && str[i] != '.'; i++)
		    date_str[i - 1] = str[i];
		  
		  date_str[i - 1] = '\0';

#ifdef DEBUG
		  printf("date_str = %s\n", date_str);
		  fflush(stdout);
#endif
		  
		  
		  pos_in_str = i + 3;  /* Ugh.. assuming "..." after day */
		  
		  
		  /* Slurp the expected conditions (eg, "PARTLY CLOUDY") */
		  
		  for (i = pos_in_str; i < (int) strlen(str) && str[i] != '.';
		       i++)
		    cond_str[i - pos_in_str] = str[i];
		  
		  cond_str[i - pos_in_str] = '\0';

#ifdef DEBUG
		  printf("cond_str = %s\n", cond_str);
		  fflush(stdout);
#endif
		  
		  
		  /* Determine which condition value to use for this: */
		  
		  f = NA;
		  
		  if (strstr(cond_str, "PARTLY CLOUDY") == cond_str ||
		      strstr(cond_str, "PARTLY SUNNY") == cond_str)
		    {
		      f = PCLOUDY;
		      
		      if (strstr(date_str, "NIGHT") != NULL ||
			  strstr(date_str, "EVENING") != NULL)
			{
			  f = PCLOUDYN;
			}
		    }
		  else if (strstr(cond_str, "MOSTLY CLEAR") == cond_str ||
			   strstr(cond_str, "MOSTLY SUNNY") == cond_str)
		    {
		      f = FAIR;
		    }
		  else if (strstr(cond_str, "SUNNY") == cond_str ||
			   strstr(cond_str, "CLEAR") == cond_str ||
			   strstr(cond_str, "DRY") == cond_str)
		    {
		      f = SUNNY;
		      
		      if (strstr(date_str, "NIGHT") != NULL ||
			  strstr(date_str, "EVENING") != NULL)
			{
			  f = SUNNYN;
			}
		    }
                  else if (strstr(cond_str, "WINDY") != NULL)
                    {
                      f = WIND;
                    }
                  else if (strstr(cond_str, "FOG") != NULL)
                    {
                      f = FOG;
                    }
		  
		  
		  /* Add the ZFP entry to the array: */
		  
#ifdef DEBUG
		  printf("Adding ZFP %d!!\n", cur_zfp);
#endif

		  zfp[cur_zfp].date = strdup(date_str);
		  zfp[cur_zfp].cond_icon = f;
		  zfp[cur_zfp].cond_str = strdup(cond_str);
		  zfp[cur_zfp].temp = 50;
		  
		  cur_zfp++;
		}
	    }
	}
      while (!feof(fi) && cur_zfp < MAX_FORECASTS - 1);
      
      fclose(fi);


      /* Set 'Raw' window's ZFP data text: */

      out_raw_zfp->value(strdup(forecast_text));
      free(forecast_text);
    }
  else
    {
      /* Was unable to open ZFP file... */
      
      perror(zfp_fname);
    }
}
