#!/bin/sh

# grabweather.sh
# Download's a station's weather information via FTP
# for GoWeather

# Usage:  grabweather.sh loc_name loc_id zone_path
#   loc_name  = name for directory under ~/.gnomeweather/ (eg, "San Francisco")
#   loc_id    = location ID for METAR/TAF data fetching   (eg, "KSFO")
#   zone_path = location ID (path on site) for ZFP data   (eg, "ca/caz017")

# by Bill Kendrick
# bill@newbreedsoftware.com
# http://www.newbreedsoftware.com/

# (originally written in April 2001 for first attempt at GoWeather)

# October 16, 2001 - October 20, 2001


# Station Requested (ICAO Location Indicator)
# -------------------------------------------
# See: http://www.nws.noaa.gov/oso/siteloc.shtml
# and: http://www.nws.noaa.gov/pub/stninfo/nsd_cccc.txt


if [ $# -eq 0 ]; then
  LOC_NAME=Sacramento
  STATIONID=KSAC
  ZONEID=ca/caz017
else
  LOC_NAME=$1
  STATIONID=$2
  ZONEID=$3
fi


CLIENT=lynx


# Constants (hopefully)
# ---------------------

GOWEATHER_PATH=$HOME/.goweather/

TAF_FTPDOMAIN=weather.noaa.gov
TAF_FTPPATH=data/forecasts/taf/stations
TAF_OUTFILE=taf.dat

METAR_FTPDOMAIN=weather.noaa.gov
METAR_FTPPATH=data/observations/metar/stations
METAR_OUTFILE=metar.dat

ZFP_FTPDOMAIN=weather.noaa.gov
ZFP_FTPPATH=data/forecasts/zone/
ZFP_OUTFILE=zfp.dat




# Check settings:

if [ x$STATIONID == "x" ]; then
  echo "Set your STATION ID!"
  echo "Visit: http://www.nws.noaa.gov/oso/siteloc.shtml"
  exit 1
fi

if [ x$ZONEID == "x" ]; then
  echo "Set your ZONE ID!"
  exit 1
fi


# Download data file
# ------------------

echo "Downloading METAR/TAF/ZFP $STATIONID ($ZONEID)"


# Uncomment ONLY ONE of the following, depending on which
# client you have installed, or prefer to use:
# ---------------------------------------------------------

if [ $CLIENT == "wget" ]; then
  wget ftp://$METAR_FTPDOMAIN/$METAR_FTPPATH/$STATIONID.TXT -O $METAR_OUTFILE
  wget ftp://$TAF_FTPDOMAIN/$TAF_FTPPATH/$STATIONID.TXT -O $TAF_OUTFILE
  wget ftp://$ZFP_FTPDOMAIN/$ZFP_FTPPATH/$ZONEID.txt -O $ZFP_OUTFILE
elif [ $CLIENT == "lynx" ]; then
  lynx -dump ftp://$METAR_FTPDOMAIN/$METAR_FTPPATH/$STATIONID.TXT > \
	$METAR_OUTFILE
  lynx -dump ftp://$TAF_FTPDOMAIN/$TAF_FTPPATH/$STATIONID.TXT > $TAF_OUTFILE
  lynx -dump ftp://$ZFP_FTPDOMAIN/$ZFP_FTPPATH/$ZONEID.txt > $ZFP_OUTFILE
elif [ $CLIENT == "links" ]; then
  links -dump ftp://anonymous@$METAR_FTPDOMAIN/$METAR_FTPPATH/$STATIONID.TXT > \
	$METAR_OUTFILE
  links -dump ftp://anonymous@$TAF_FTPDOMAIN/$TAF_FTPPATH/$STATIONID.TXT > \
	$TAF_OUTFILE
  links -dump ftp://anonymous@$ZFP_FTPDOMAIN/$ZFP_FTPPATH/$ZONEID.txt > \
	$ZFP_OUTFILE
elif [ $CLIENT == "ncftp" ]; then
  ncftpget ftp://$METAR_FTPDOMAIN/$METAR_FTPPATH/$STATIONID.TXT
  mv $STATIONID.TXT $METAR_OUTFILE

  ncftpget ftp://$TAF_FTPDOMAIN/$TAF_FTPPATH/$STATIONID.TXT
  mv $STATIONID.TXT $TAF_OUTFILE

  ncftpget ftp://$ZFP_FTPDOMAIN/$ZFP_FTPPATH/$ZONEID.txt
  mv $ZONEID.txt $ZFP_OUTFILE
else
  echo "Set your CLIENT!"
  exit 1
fi

# ---------------------------------------------------------


# Spit out file's header
# ----------------------

echo -n "$STATIONID METAR last updated: UTC "
head -1 $METAR_OUTFILE
echo
echo -n "$STATIONID TAF last updated: UTC "
head -1 $TAF_OUTFILE
echo


# Move to appropriate place
# -------------------------

echo "Moving files to '$GOWEATHER_PATH/$LOC_NAME'"
/bin/mkdir -p --verbose "$GOWEATHER_PATH/$LOC_NAME"
/bin/mv metar.dat taf.dat zfp.dat "$GOWEATHER_PATH/$LOC_NAME"


# Upload data file to PDA
# -----------------------

echo Uploading to PDA

# Agenda VR3:
#rsync $METAR_OUTFILE agenda::root/flash/home/default/.goweather/metar.dat


echo All done

