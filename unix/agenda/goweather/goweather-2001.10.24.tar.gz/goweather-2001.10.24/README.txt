README.txt for GoWeather

by Bill Kendrick
bill@newbreedsoftware.com
http://www.newbreedsoftware.com/gowether/

October 16, 2001 - October 24, 2001


-- This document is under construction --


PURPOSE:
  GoWeather is a small graphical program which can display current weather
  conditions and ~5-day forecast, by using METAR and Zone Forecast (ZFP)
  information available freely from the US National Weather Service.


USAGE:
  Run the "grabweather.sh" shell script to download data for a particular
  location.  Three files will be fetched from the National Weather Service
  FTP servers, and will be stored in a subdirectory of "~/.goweather/"
  on your account.

  For example, Sacramento, California data might be fetched and then
  stored in "~/.goweather/Sacramento/".

  The files are named "metar.dat", "taf.dat" and "zfp.dat".

  Default values for the location name (which directory it will be stored
  in under "~/.goweather/", eg, "Sacramento"), the location's NWS station
  identification (for downloading TAF and METAR reports, eg, "KSAC") and
  the location's zone identification (for downloading ZFP reports,
  eg, "ca/ca017") can be set either on the command-line, or within the
  shell script itself.

  The method for fetching the documents (what client to use, eg,
  wget, Lynx, Links or NCFTP) can be set in the shell script.  The
  default is wget.  NOTE: Right now, Links fetching is broken.


  Once downloaded, you can upload (eg, rsync) the ".dat" files to your PDA,
  storing them in "/home/default/.goweather/[location]/", just like on
  the desktop.

  (In fact, if your PDA has Internet connectivity and one of the supported
  clients (eg, "lynx" or "wget"), you can run the "grabweather.sh" script
  right on the PDA!)


  NOTE!!!  Currently, GoWeather looks in a "Default/" directory under
  "~/.goweather/" when it first loads.  You should make "Default" a
  symbolic link to your favorite location, like so:

    ln -s Sunnytown/ Default

  It will then show whatever conditions/forecasts you've placed in
  the "Sunnytown/" directory when it first loads.

  (BUG: Not having a "Default" location currently has undefined effects.)



REFERENCES:
  Finding a locations' Station ID:
    http://www.nws.noaa.gov/oso/siteloc.shtml
    http://www.nws.noaa.gov/pub/stninfo/nsd_cccc.txt

  Finding a location's Zone ID:
    ???

  Zone Forecasts:
    ftp://weather.noaa.gov/data/forecasts/zone/
    (eg ftp://weather.noaa.gov/data/forecasts/zone/ca/caz017.txt)

  TAF forecasts:
    ftp://weather.noaa.gov/data/forecasts/taf/stations/
    (eg ftp://weather.noaa.gov/data/forecasts/taf/stations/KSAC.TXT)

  METAR conditions:
    ftp://weather.noaa.gov/data/observations/metar/stations/
    (eg ftp://weather.noaa.gov/data/observations/metar/stations/KSAC.TXT)

  Specifications:
    http://wsom.nws.noaa.gov/wsom/manual/CHAPTERC/C_11_PDF/c11_main.pdf

  GoWeather links:
    Home page:         http://www.newbreedsoftware.com/goweather/
    Development page:  http://www.sourceforge.net/projects/goweather/
    IRC channel:       irc.openprojects.net - #goweather


CREDITS:
  Thanks to WeatherUnderground.com, National Weather Service,
  Weathernut.net, GnomeWeather, Agenda Computing,
  National Oceanic & Atmospheric Administration (NOAA)
  and others for inspiration, data sources, and documentation.

  Software and graphics by Bill Kendrick (bill@newbreedsoftware.com)

