/*
 * Copyright (C) 2002 Robert Ernst <robert.ernst@maxxio.com>
 *
 * This file may be distributed and/or modified under the terms of the
 * GNU General Public License version 2 as published by the Free Software
 * Foundation and appearing in the file LICENSE.GPL included in the
 * packaging of this file.
 *
 * This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 * WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See COPYING for GPL licensing information.
 *
 */

#include <qpe/qpemenubar.h>
#include <qpe/config.h>
#include <qapplication.h>
#include <qmainwindow.h>
#include <qpopupmenu.h>
#include "PlayField.h"
#include "Pdamaze.h"
#include <stdlib.h>
#include <time.h>

Pdamaze::Pdamaze(QWidget *parent, const char *name, WFlags f) :
    QMainWindow(parent, name, f)
{
    /* initialize random number generator */
    srand(::time(0));

    /* set windows style and caption */
    setCaption(tr("PDA-Maze"));

    /* create the play field as the central widget */
    m_field = new PlayField(this);
    setCentralWidget(m_field);
    m_field->show();

    /* create the game/timer_mode submenu */
    m_timerModeMenu = new QPopupMenu(0, "timer_mode_menu");
    connect(m_timerModeMenu, SIGNAL(activated(int)), this, SLOT(updateTimerMode(int)));
    connect(m_timerModeMenu, SIGNAL(activated(int)), m_field, SLOT(updateTimerMode(int)));
    m_timerModeMenu->setCheckable(true);
    m_timerModeMenu->insertItem(tr("Up"), PlayField::TimerUp);
    m_timerModeMenu->insertItem(tr("Down"), PlayField::TimerDown);

    /* create the game/map_mode submenu */
    m_mapModeMenu = new QPopupMenu(0, "map_mode_menu");
    connect(m_mapModeMenu, SIGNAL(activated(int)), this, SLOT(updateMapMode(int)));
    connect(m_mapModeMenu, SIGNAL(activated(int)), m_field, SLOT(updateMapMode(int)));
    m_mapModeMenu->setCheckable(true);
    m_mapModeMenu->insertItem(tr("All"), PlayField::MapAll);
    m_mapModeMenu->insertItem(tr("Build"), PlayField::MapBuild);
    m_mapModeMenu->insertItem(tr("None"), PlayField::MapNone);

    /* create the game/size submenu */
    m_sizeMenu = new QPopupMenu(0, "size_menu");
    connect(m_sizeMenu, SIGNAL(activated(int)), this, SLOT(updateSize(int)));
    connect(m_sizeMenu, SIGNAL(activated(int)), m_field, SLOT(updateSize(int)));
    m_sizeMenu->setCheckable(true);
    m_sizeMenu->insertItem(tr("9x9"), 9);
    m_sizeMenu->insertItem(tr("19x19"), 19);
    m_sizeMenu->insertItem(tr("29x29"), 29);
    m_sizeMenu->insertItem(tr("39x39"), 39);
    m_sizeMenu->insertItem(tr("49x49"), 49);

    /* create the game submenu */
    QPopupMenu *gameMenu = new QPopupMenu(0, "game_menu");
    gameMenu->insertItem(tr("New"), m_field, SLOT(start()));
    gameMenu->insertItem(tr("Timer"), m_timerModeMenu);
    gameMenu->insertItem(tr("Map"), m_mapModeMenu);
    gameMenu->insertItem(tr("Size"), m_sizeMenu);
    gameMenu->insertSeparator();
    gameMenu->insertItem(tr("Close"), this, SLOT(close()));

    /* create the menu */
    QPEMenuBar *menu = new QPEMenuBar(this);
    menu->insertItem(tr("Game"), gameMenu);

    /* read the configuration file */
    readConfig();

    /* check the menu entries of game submenus */
    m_timerModeMenu->setItemChecked(m_timer_mode, true);
    m_mapModeMenu->setItemChecked(m_map_mode, true);
    m_sizeMenu->setItemChecked(m_size, true);
}

Pdamaze::~Pdamaze()
{
    writeConfig();
}

void Pdamaze::readConfig(void)
{
    Config cfg("Pdamaze");

    cfg.setGroup("Settings");

    int timer_mode = cfg.readNumEntry("TimerMode", PlayField::TimerUp);
    switch (timer_mode) {
    case PlayField::TimerDown:
	m_timer_mode = PlayField::TimerDown;
	break;
    default:
	m_timer_mode = PlayField::TimerUp;
	break;
    }
    m_field->updateTimerMode(m_timer_mode);

    int map_mode = cfg.readNumEntry("MapMode", PlayField::MapBuild);
    switch (map_mode) {
    case PlayField::MapAll:
	m_map_mode = PlayField::MapAll;
	break;
    case PlayField::MapNone:
	m_map_mode = PlayField::MapNone;
	break;
    default:
	m_map_mode = PlayField::MapBuild;
	break;
    }
    m_field->updateMapMode(m_map_mode);

    int size = cfg.readNumEntry("Size", 9);
    if (size <= 9) {
	m_size = 9;
    } else if (size <= 19) {
	m_size = 19;
    } else if (size <= 29) {
	m_size = 29;
    } else if (size <= 39) {
	m_size = 39;
    } else {
	m_size = 49;
    }
    m_field->updateSize(m_size);
}

void Pdamaze::writeConfig(void)
{
    Config cfg("Pdamaze");

    cfg.setGroup("Settings");
    cfg.writeEntry("TimerMode", m_timer_mode);
    cfg.writeEntry("MapMode", m_map_mode);
    cfg.writeEntry("Size", m_size);
}

void Pdamaze::updateTimerMode(int timer_mode)
{
    m_timerModeMenu->setItemChecked(m_timer_mode, false);
    switch (timer_mode) {
    case PlayField::TimerDown:
	m_timer_mode = PlayField::TimerDown;
	break;
    default:
	m_timer_mode = PlayField::TimerUp;
	break;
    }
    m_timerModeMenu->setItemChecked(m_timer_mode, true);
    writeConfig();
}

void Pdamaze::updateMapMode(int map_mode)
{
    m_mapModeMenu->setItemChecked(m_map_mode, false);
    switch (map_mode) {
    case PlayField::MapAll:
	m_map_mode = PlayField::MapAll;
	break;
    case PlayField::MapNone:
	m_map_mode = PlayField::MapNone;
	break;
    default:
	m_map_mode = PlayField::MapBuild;
	break;
    }
    m_mapModeMenu->setItemChecked(m_map_mode, true);
    writeConfig();
}

void Pdamaze::updateSize(int size)
{
    m_sizeMenu->setItemChecked(m_size, false);
    m_size = size;
    m_sizeMenu->setItemChecked(m_size, true);
    writeConfig();
}

