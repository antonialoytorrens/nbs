/*
 * Copyright (C) 2002 Robert Ernst <robert.ernst@maxxio.com>
 *
 * This file may be distributed and/or modified under the terms of the
 * GNU General Public License version 2 as published by the Free Software
 * Foundation and appearing in the file LICENSE.GPL included in the
 * packaging of this file.
 *
 * This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 * WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See COPYING for GPL licensing information.
 *
 */

#ifndef __PDAMAZE_HEADER__
#define __PDAMAZE_HEADER__

#include <qpe/qpemenubar.h>
#include <qmainwindow.h>
#include <qpopupmenu.h>
#include "PlayField.h"

class Pdamaze : public QMainWindow
{
    Q_OBJECT

public:
    Pdamaze(QWidget *parent = 0, const char *name = 0, WFlags f = 0);
    ~Pdamaze();

private:
    void readConfig(void);
    void writeConfig(void);

private:
    PlayField *m_field;
    QPopupMenu *m_timerModeMenu;
    QPopupMenu *m_mapModeMenu;
    QPopupMenu *m_sizeMenu;
    enum PlayField::TimerModes m_timer_mode;
    enum PlayField::MapModes m_map_mode;
    int m_size;

protected slots:
    void updateTimerMode(int timer_mode);
    void updateMapMode(int map_mode);
    void updateSize(int size);
};

#endif // __PDAMAZE_HEADER__

