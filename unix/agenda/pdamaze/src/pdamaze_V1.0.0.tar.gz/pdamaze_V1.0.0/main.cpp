/*
 * Copyright (C) 2002 Robert Ernst <robert.ernst@maxxio.com>
 *
 * This file may be distributed and/or modified under the terms of the
 * GNU General Public License version 2 as published by the Free Software
 * Foundation and appearing in the file LICENSE.GPL included in the
 * packaging of this file.
 *
 * This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 * WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See COPYING for GPL licensing information.
 *
 */

#include <qpe/qpeapplication.h>
#include "Pdamaze.h"

int
main(int argc, char *argv[])
{
    QPEApplication app(argc, argv);
    Pdamaze pdamaze;

    app.setMainWidget(&pdamaze);
    QPEApplication::setInputMethodHint(&pdamaze, QPEApplication::AlwaysOff);
    pdamaze.showMaximized();
    return app.exec();
}

