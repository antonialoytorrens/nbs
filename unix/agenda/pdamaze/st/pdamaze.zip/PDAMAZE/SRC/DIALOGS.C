/*  dialogs.c	(c) 1997 Dan Ackerman		baldrick@netset.com
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   Electronic contact can be made via the following web address
 *  	http://www.netset.com/~baldrick/stik2.html
 *
 * These are all the routines that handle what happens when
 * the user attempts to use one of the pretty windowed dialogs
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>


#include <ext.h>

#include "global.h"

int new_size = 19;


/*
 * Routines for program window creation
 */

extern char prg_title[];

int
do_about(void)
{
	int wh;

	wh = new_window(about,prg_title,0,ABOUT_WIN);

	if (wh >= 0)
	{
		win[ABOUT_WIN].handle = wh;
		win[ABOUT_WIN].window_obj = about;
		win[ABOUT_WIN].title = prg_title;
		win[ABOUT_WIN].cur_item = -1;
		win[ABOUT_WIN].text_block = NULL;
		win[ABOUT_WIN].buf_size = 0;
		win[ABOUT_WIN].status = 0;
		win[ABOUT_WIN].edit = 0;
		win[ABOUT_WIN].type = 0;
		
		win[ABOUT_WIN].icon_obj = icon_about;

		wind_get(wh, WF_CURRXYWH, ELTR(win[ABOUT_WIN].curr));

		wind_get(wh, WF_WORKXYWH, ELTR(win[ABOUT_WIN].work));
	}

	return(wh);
}


int
do_options(void)
{
	int wh;

	wh = new_window(options,prg_title,0,OPTIONS_WIN);

	if (wh >= 0)
	{
		win[OPTIONS_WIN].handle = wh;
		win[OPTIONS_WIN].window_obj = options;
		win[OPTIONS_WIN].title = prg_title;
		win[OPTIONS_WIN].cur_item = -1;
		win[OPTIONS_WIN].text_block = NULL;
		win[OPTIONS_WIN].buf_size = 0;
		win[OPTIONS_WIN].status = 0;
		win[OPTIONS_WIN].edit = 0;
		win[OPTIONS_WIN].type = 0;
		
		win[OPTIONS_WIN].icon_obj = icon_opt;

		wind_get(wh, WF_CURRXYWH, ELTR(win[OPTIONS_WIN].curr));

		wind_get(wh, WF_WORKXYWH, ELTR(win[OPTIONS_WIN].work));
	}

	return(wh);
}


/*
 * Routines for window handling
 */

/*
 * actual final window event drivers
 */
 
int
about_drive(int which_obj)
{
	GRECT p;

	wind_get(win[ABOUT_WIN].handle,WF_WORKXYWH,ELTR(p));

/*
	if(which_obj == ABOUT_OK)
	{
		objc_change(about,which_obj,0,ELTS(p),0x0001,1);
		objc_change(about,which_obj,0,ELTS(p),0x0000,0);

		wind_close(win[ABOUT_WIN].handle);
		wind_delete(win[ABOUT_WIN].handle);
		win[ABOUT_WIN].handle = NO_WINDOW;

		proc_window(MAIN_WIN,do_main_win);

	}
*/
	return(1);
}


int
options_drive(int which_obj)
{
	GRECT p;
	int old_object;
	
	switch (maze_size)
	{
		case 19:
			old_object = R_SMALL;
			break;
		case 29:
			old_object = R_MEDIUM;
			break;
		case 39:
			old_object = R_LARGE;
	}	

	wind_get(win[OPTIONS_WIN].handle,WF_WORKXYWH,ELTR(p));

	if(which_obj == R_SMALL)
	{
		objc_change(options,which_obj,0,ELTS(p),0x0001,1);
		objc_change(options,R_MEDIUM,0,ELTS(p),0x0000,1);
		objc_change(options,R_LARGE,0,ELTS(p),0x0000,1);

		new_size = 19;
	}
	else if(which_obj == R_MEDIUM)
	{
		objc_change(options,which_obj,0,ELTS(p),0x0001,1);
		objc_change(options,R_SMALL,0,ELTS(p),0x0000,1);
		objc_change(options,R_LARGE,0,ELTS(p),0x0000,1);
		
		new_size = 29;
	}
	else if(which_obj == R_LARGE)
	{
		objc_change(options,which_obj,0,ELTS(p),0x0001,1);
		objc_change(options,R_MEDIUM,0,ELTS(p),0x0000,1);
		objc_change(options,R_SMALL,0,ELTS(p),0x0000,1);

		new_size = 39;
	}
	else if (which_obj == R_OPT_RESET)
	{
		objc_change(options,which_obj,0,ELTS(p),0x0001,1);
	
		objc_change(options,R_SMALL,0,ELTS(p),0x0000,1);
		objc_change(options,R_MEDIUM,0,ELTS(p),0x0000,1);
		objc_change(options,R_LARGE,0,ELTS(p),0x0000,1);

		objc_change(options,old_object,0,ELTS(p),0x0001,1);

		objc_change(options,which_obj,0,ELTS(p),0x0000,1);
	}
	else if (which_obj == R_OPT_APPLY)
	{
		objc_change(options,which_obj,0,ELTS(p),0x0001,1);
	
		maze_size = new_size;
		
		objc_change(options,which_obj,0,ELTS(p),0x0000,0);

		wind_close(win[OPTIONS_WIN].handle);
		wind_delete(win[OPTIONS_WIN].handle);
		win[OPTIONS_WIN].handle = NO_WINDOW;

		done = 1;
		restart = 1;
	}	

	return(1);
}
