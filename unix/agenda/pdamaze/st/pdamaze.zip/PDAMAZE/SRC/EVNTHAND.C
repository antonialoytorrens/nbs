/*  EVNTHAND.C   (c) Dan Ackerman 2000         baldrick@netset.com
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   Electronic contact can be made via the following web address
 *  	http://www.netset.com/~baldrick/stik2.html
 *
 *  Handles gem, button and mouse events
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <aes.h>
#include <vdi.h>
#include <tos.h>

#include "global.h"

/* handle Key evnts - handles all key events in the program
	returns 0 if no special case exists, 
	if special case exists it will return the key passed to it.
	This will be dependent on the routine that calls them.
	
	It might be necessary to expand the returns later, for now
	this should do the trick as it's only going to be the timers 
	that care */

int
handle_key_evnts(short key,short mousex,short mousey)
{
	short junk, top_window = 0;
	char scrap[128];
	char scrap_name[128];
	int cont, next;
	FILE *fp;
	char line[500];
	GRECT p;
	int which_window;
	int w_info;
	GRECT clip;

	which_window = wind_find(mousex,mousey);

	wind_get(which_window,WF_TOP,&top_window,&junk,&junk,&junk);

	w_info = get_wininfo_from_handle(top_window);

	/* These hot keys don't care about windows*/
	
	if (key == 4113) /* Control Q */
	{
		done = 1;
		return(0);
	}
		
	if (win[w_info].status == 0)
	{
		if (key == 12054)
		{
			/* Control V - PASTE */

			if (win[w_info].edit == 1)
			{
				wind_get(win[w_info].handle,WF_WORKXYWH,ELTR(p));

				if(scrp_read((char *)scrap) == 0)
					return (0);

				if (win[w_info].cur_item != -1)
				{
					construct_path(scrap_name,scrap,"SCRAP.TXT");
					
					if ((fp = fopen(scrap_name, "r")) > 0)
					{
						fgets(line,500,fp);
						fclose(fp);

						strcat(line,"\0");
								
						objc_edit(win[w_info].window_obj, win[w_info].cur_item, 0, &win[w_info].edit_pos, ED_END);
	
						set_edits(win[w_info].window_obj,win[w_info].cur_item,line);
	
						objc_draw(win[w_info].window_obj,win[w_info].cur_item,7,clip.g_x,clip.g_y,clip.g_w,clip.g_h);
						objc_edit(win[w_info].window_obj, win[w_info].cur_item, 0, &win[w_info].edit_pos, ED_INIT);
					}
				}
			return(0);
			}
		}
	
#if 0
		if (w_info == ABOUT_WIN)
		{
			/* These are all standard windows, no edit object's etc */

			cont = form_keybd(win[w_info].window_obj, win[w_info].cur_item, 0, key, &next, &key);

			if ((cont != 1) || (next!=0 && next != win[w_info].cur_item))
			{	
;
/*				if ((w_info == ABOUT_WIN)&&(next == ABOUT_OK))
					about_drive(ABOUT_OK);
*/
			}
		}
		else if (w_info == FONTSEL_WIN)
		{
			cont = form_keybd(win[w_info].window_obj, win[w_info].cur_item, 0, key, &next, &key);

			if (key)
			{
				/* if not special the edit the form */
						
				objc_edit(win[w_info].window_obj, win[w_info].cur_item, key, (int *)&win[w_info].edit_pos, ED_CHAR);
			}

			if ((cont != 1) || (next!=0 && next != win[w_info].cur_item))
			{	
				objc_edit(win[w_info].window_obj, win[w_info].cur_item, 0, &win[w_info].edit_pos, ED_END);

				if ((next == R_FNTOK) || (next == 5))
					fontsel_drive(R_FNTOK);
				else if (next == R_FNTCANCEL)
					fontsel_drive(R_FNTCANCEL);
				else
				{
					win[w_info].cur_item = next;

					objc_edit(win[w_info].window_obj,win[w_info].cur_item,0, &win[w_info].edit_pos,ED_INIT);
				}
			}
		}				
		else 
#endif

		if (w_info == GAME_WIN)
		{
/*		printf("%d\r\n",key);
*/
			if (key == 19712) /* Right */
			{
				turn = 1;
			}
			else if (key == 19200) /* Left */
			{
				turn = -1;
			}
			else if (key == 18432) /* Forward / Up */
			{
				move_forward = 1;
			}
			else if (key == 20480) /* Back / Down */
			{
				move_forward = -1;
			}
#if 0

			if (key == 3592) /* Backspace */
			{
				win[GAME_WIN].inp[(strlen(win[GAME_WIN].inp)-1)] = '\0';
				
				/* Now clear the space */
				
				p.g_x = win[GAME_WIN].work.g_x;
				p.g_y = win[GAME_WIN].work.g_y+win[GAME_WIN].work.g_h - inptexth*2;
				p.g_w = win[GAME_WIN].work.g_w;
				p.g_h = inptexth*2;
				
				clearwin((GRECT *)&p,objcolors[BACKG]);
			}
			else if ((key == 7181)||(key == 29197))
			{
				sprintf(line,">%s",win[GAME_WIN].inp);
				output(GAME_WIN,line);

				strcat(win[GAME_WIN].inp,"\n");
				strcpy(game_buf,win[GAME_WIN].inp);
				
				/* Now clear the space */
			
				p.g_x = win[GAME_WIN].work.g_x;
				p.g_y = win[GAME_WIN].work.g_y+win[GAME_WIN].work.g_h - inptexth*2;
				p.g_w = win[GAME_WIN].work.g_w;
				p.g_h = inptexth*2;
				
				clearwin((GRECT *)&p,objcolors[BACKG]);
		
				/* and clear the input */
				strcpy(win[GAME_WIN].inp,"\0");

				writeinpinfo(w_info);

/*				do_redraw(win[w_info].handle,(GRECT *)&win[w_info].work);
*/
				return(1);
			}
			else
			{
				sprintf(line,"%c",key);
				strcat(win[GAME_WIN].inp,line);
			}
			
			dispinput(GAME_WIN);
#endif

		}

	}
		
	return (0);
}


/****************************************/
/*			Handle button events		*/
/****************************************/

void
handle_button_events(short button,short mousex,short mousey)
{
	int which_obj = 0;
	int which_window = 0;
	short top_window = 0;
	short junk;
	int w_info;

	GRECT p;

	which_window = wind_find(mousex,mousey);

	w_info = get_wininfo_from_handle(which_window);

	wind_get(which_window,WF_TOP,&top_window,&junk,&junk,&junk);

	if ( button == 1 )
	{
		if (which_window == top_window)
		{
			which_obj = objc_find(win[w_info].window_obj,0,MAX_DEPTH,mousex,mousey);

			wind_get(which_window,WF_WORKXYWH,ELTR(p));

			if (win[w_info].status == 0)
			{
				if (w_info == ABOUT_WIN)
					about_drive(which_obj);
				else if (w_info == OPTIONS_WIN)
					options_drive(which_obj);
#if 0

				else if (w_info == COLOR_WIN)
					objcolors_drive(which_obj);
				else if (w_info == OPTION_WIN)
					game_opt_drive(which_obj);


				else if (w_info == IP_WIN)
					ip_drive(which_obj);
				else if (w_info == MEM_WIN)
					mem_drive(which_obj);
				else if (w_info == INF_WIN)
					inf_drive(which_obj);
				else if (w_info == CON_WIN)
					status_drive(which_obj);
				else if (w_info == TOOLS_WIN)
					tools_drive(which_obj);
#endif
			}
		} /* end of which_window == top_window test */
	}
	else if (button == 2)
	{
#if 0
		if (which_window == top_window)
		{
			which_obj = objc_find(win[w_info].window_obj,0,MAX_DEPTH,mousex,mousey);

			if(w_info == MAIN_WIN)
			{
				if (which_obj == MAIN_INFO)
					bubblegem_show(mousex, mousey, BUB_ABOUT_TOOL);
				else if (which_obj == MAIN_MEMORY)
					bubblegem_show(mousex, mousey, BUB_MEM_TOOL);
				else if (which_obj == MAIN_IP)
					bubblegem_show(mousex, mousey, BUB_IP_TOOL);
				else if (which_obj == MAIN_PORTINFO)
					bubblegem_show(mousex, mousey, BUB_PORT_TOOL);
				else if (which_obj == MAIN_TOOLS)
					bubblegem_show(mousex, mousey, BUB_TOOLS_TOOL);
				else if (which_obj == PORT_NAME)
					bubblegem_show(mousex, mousey, BUB_CURR_PORT);
				else if (which_obj == PORT_STATUS)
					bubblegem_show(mousex, mousey, BUB_CONN_STATUS);
				else if (which_obj == PORT_SCRIPT)
					bubblegem_show(mousex, mousey, BUB_CURR_SCRIPT);
				else if (which_obj == CONNECT)
					bubblegem_show(mousex, mousey, BUB_CONNECT);
			}
			else if(w_info == IP_WIN)
			{
				if (which_obj == I_IP)
					bubblegem_show(mousex, mousey, BUB_IP_ADD);
				else if (which_obj == I_SETIP)
					bubblegem_show(mousex, mousey, BUB_IP_SET);
				else if (which_obj == I_OK)
					bubblegem_show(mousex, mousey, BUB_IP_CANCEL);
			}
			else if (w_info == MEM_WIN)
			{
				if (which_obj == MEM_FREE)
					bubblegem_show(mousex, mousey, BUB_MEM_SFREE);
				else if (which_obj == MEM_LARGEST)
					bubblegem_show(mousex, mousey, BUB_MEM_SLARGE);
				else if (which_obj == MEM_SYSTEM)
					bubblegem_show(mousex, mousey, BUB_MEM_SYST);
				else if (which_obj == MEM_OK)
					bubblegem_show(mousex, mousey, BUB_TOOL_OK);
			}
			else if (w_info == INF_WIN)
			{
				if (which_obj == INF_PORT)
					bubblegem_show(mousex, mousey, BUB_PI_PORT);
				else if (which_obj == INF_TIME)
					bubblegem_show(mousex, mousey, BUB_PI_ONLINE);
				else if (which_obj == INF_TOTAL)
					bubblegem_show(mousex, mousey, BUB_PI_TOTAL);
				else if (which_obj == INF_BAUD)
					bubblegem_show(mousex, mousey, BUB_PI_DTE);
				else if (which_obj == INF_DSENT)
					bubblegem_show(mousex, mousey, BUB_PI_SENT);
				else if (which_obj == INF_DRECV)
					bubblegem_show(mousex, mousey, BUB_PI_RECV);
			}						
			else if (w_info == TOOLS_WIN)
			{
				if (which_obj == T_CANCEL)
					bubblegem_show(mousex, mousey, BUB_IP_CANCEL);
				else if (which_obj == T_OK)
					bubblegem_show(mousex, mousey, BUB_TOOL_OK);
				else if (which_obj == R_SAVEPREF)
					bubblegem_show(mousex, mousey, BUB_T_SAVE);
				else if (which_obj == T_MLOG)
					bubblegem_show(mousex, mousey, BUB_TB_LOGOPT);
				else if (which_obj == T_MDISPLAY)
					bubblegem_show(mousex, mousey, BUB_TB_DISPOPT);
				else if (which_obj == T_MCONFIG)
					bubblegem_show(mousex, mousey, BUB_TB_CFGOPT);
				else if (which_obj == T_MLAUNCH)
					bubblegem_show(mousex, mousey, BUB_TB_LAUNCHOPT);

				
				if (win[TOOLS_WIN].window_obj == dilog)
				{
					if (which_obj == T_DIAL_LOG)
						bubblegem_show(mousex, mousey, BUB_TOOL_LOG);
					else if (which_obj == T_LOG_TIMES)
						bubblegem_show(mousex, mousey, BUB_TB_LOGTIME);
					else if (which_obj == T_ELOG)
						bubblegem_show(mousex, mousey, BUB_TOOL_ELOG);
				}
				else if (win[TOOLS_WIN].window_obj == dilaunch)
				{
					if (which_obj == T_LUSESCR)
						bubblegem_show(mousex, mousey, BUB_TB_USESCR);
					else if (which_obj == T_LSCRIPT)
						bubblegem_show(mousex, mousey, BUB_TB_SCRIPT);
				}
				else if (win[TOOLS_WIN].window_obj == didisp)
				{
					if (which_obj == T_CONINT)
						bubblegem_show(mousex, mousey, BUB_TOOL_DIALOG);
				}
			}
		}

#endif
	}	
}


/****************************************/
/*		Handle GEM Message events		*/
/****************************************/

void
handle_gem_evnts(int *msg)
{
	GRECT p;
	int junk;
	int w_info;
	char temp[90];

	switch(msg[0])
   	{
		case 80:
		case 90: /* CH_EXIT */
			break;

		case 0xBABC: /* BubbleGem ack message */
/*			bubblegem_ack(msg);*/
			break;
			
		case AP_TERM:
			if (_app != 0)
				done = 1;
			break;

		case WM_FULLED:
			w_info = get_wininfo_from_handle(msg[3]);

			/* This just rolls it up in my version */
			if(win[w_info].status == 1)
			{
				unroll_window(win[w_info].handle);

				win[w_info].status = 0;
			}
			else
			{
				win[w_info].status = 1;

				if (win[w_info].type == 0)
					wind_calc(WC_BORDER, W_TYPE,
					    win[w_info].curr.g_x,
						win[w_info].curr.g_y,
						(win[w_info].curr.g_w/3), 
						0,
						ELTR(p));			

				wind_set(msg[3], WF_NAME, win[w_info].title);
				wind_set(msg[3], WF_CURRXYWH, PTRS((GRECT *)&p));
			}
			break;

		case WM_VSLID:
			w_info = get_wininfo_from_handle(msg[3]);
		
			wind_set(win[w_info].handle,WF_VSLIDE,msg[4],0,0,0);

			win[w_info].top=((msg[4]/10) * win[w_info].cur_item)/100;

			win[w_info].top -= win[w_info].cl_cnt;

			if (win[w_info].top < 0)
				win[w_info].top = 0;

							
/*			if (win[w_info].top > (win[w_info].cur_item - win[w_info].cl_cnt))
				win[w_info].top = win[w_info].cur_item - win[w_info].cl_cnt;
*/				
			do_redraw(win[w_info].handle,(GRECT *)&win[w_info].work);

			break;

		case WM_ARROWED:
			w_info = get_wininfo_from_handle(msg[3]);
			
			switch(msg[4])
			{
				case WA_UPLINE:
					if (win[w_info].top > 0)
						win[w_info].top--;
					
					break;
					
				case WA_DNLINE:
					if (win[w_info].top < (win[w_info].cur_item - win[w_info].cl_cnt))
						win[w_info].top++;
						
					break;
				
				case WA_UPPAGE:
					win[w_info].top -= win[w_info].cl_cnt;
					
					if (win[w_info].top < 0)
						win[w_info].top = 0;
				
					break;
					
				case WA_DNPAGE:
					win[w_info].top += win[w_info].cl_cnt;
					
					if (win[w_info].top > (win[w_info].cur_item - win[w_info].cl_cnt))
						win[w_info].top = (win[w_info].cur_item - win[w_info].cl_cnt);
				
					break;
			}

			do_redraw(win[w_info].handle,(GRECT *)&win[w_info].work);
		
			set_vslide_pos(w_info);

			break;
			
		case WM_SIZED:
			w_info = get_wininfo_from_handle(msg[3]);

			resizewindow(w_info,(GRECT *)&msg[4],1);

			break;
			
		case WM_TOPPED:
			w_info = get_wininfo_from_handle(msg[3]);

			wind_set(msg[3], WF_TOP, msg[3]);

			do_redraw(msg[3], (GRECT *)&msg[4]);

			break;

	    case WM_BOTTOM :	      /* Bottom the window */			wind_set(msg[3],WF_BOTTOM,PTRS((GRECT *)&msg[4]));			break;
		case WM_CLOSED:
			w_info = get_wininfo_from_handle(msg[3]);

			close_window(w_info);

			if (win[w_info].cur_item != -1)
				objc_change(win[w_info].window_obj,win[w_info].cur_item,0,ELTS(p),0x0000,0);

			if (w_info == GAME_WIN)
				done = 1;
				
			break;
				
		case WM_REDRAW:
			do_redraw(msg[3], (GRECT *)&msg[4]);
			break;

		case WM_ICONIFY:
			w_info = get_wininfo_from_handle(msg[3]);
			
			if (w_info != -1)			
				iconify(w_info,((GRECT *)&msg[4]));
					break;		case WM_UNICONIFY:
			w_info = get_wininfo_from_handle(msg[3]);

			if (w_info != -1)
			{
				un_iconify(w_info,((GRECT *)&msg[4]));
				send_message(WM_TOPPED, 0, msg[3], 0, 0, 0, 0);
			}

			break;
		case WM_SHADED:
			w_info = get_wininfo_from_handle(msg[3]);

			if (w_info != -1)
				win[w_info].status = 4;
				
			break;
			
		case WM_UNSHADED:
			w_info = get_wininfo_from_handle(msg[3]);

			if (w_info != -1)
				win[w_info].status = 0;

			do_redraw(msg[3], (GRECT *)&msg[4]);

			break;
						
		case WM_M_BDROPPED:
			printf("back dropped\r\n");
			break;

		case MN_SELECTED:
 	      	menu_tnormal(menu_ptr,msg[3],1);

			switch(msg[4])
			{

				case M_ABOUT:
					proc_window(ABOUT_WIN,do_about);
					break;

#if 0

				case R_NEW:
					/* use file selector to get a new game
					 * if none selected break out of loop
					 */
					if(!get_newgame())
						break;
						
#endif

				case M_RESTART:
					done = 1;
					restart = 1;
					break;
					
				case M_QUIT:
					done = 1;
					restart = -1;
					break;

				case M_MAZE_OPTIONS:
					proc_window(OPTIONS_WIN,do_options);
					break;
					
#if 0
				case R_FONT:
					proc_window(FONTSEL_WIN,do_fontsel);
					break;
				
				case R_COLORS:
					proc_window(COLOR_WIN,do_colors);
					break;
					
				case R_SAVE_SET:
					write_cfg_file(config_file);
					break;
#endif

			}
			break;


		case WM_MOVED:
			wind_set(msg[3], WF_CURRXYWH, PTRS((GRECT *)&msg[4]));

			w_info = get_wininfo_from_handle(msg[3]);

			switch(win[w_info].status)
			{
				case 0:
					/* Normal */
						
					if (win[w_info].type == 0)
					{
						wind_calc(WC_BORDER, W_TYPE, PTRS((GRECT *)&msg[4]), ELTR(win[w_info].curr));
						wind_calc(WC_WORK, W_TYPE, PTRS((GRECT *)&msg[4]), ELTR(win[w_info].work));
					}
					else if (win[w_info].type == 1)
					{
						wind_calc(WC_BORDER, W_T2, PTRS((GRECT *)&msg[4]), ELTR(win[w_info].curr));
						wind_calc(WC_WORK, W_T2, PTRS((GRECT *)&msg[4]), ELTR(win[w_info].work));
					}
					else
					{
						wind_calc(WC_BORDER, W_T3, PTRS((GRECT *)&msg[4]), ELTR(win[w_info].curr));
						wind_calc(WC_WORK, W_T3, PTRS((GRECT *)&msg[4]), ELTR(win[w_info].work));
					}
					
					if (win[w_info].window_obj != (OBJECT *)NULL)
					{
						win[w_info].window_obj[ROOT].ob_x = win[w_info].work.g_x;
						win[w_info].window_obj[ROOT].ob_y = win[w_info].work.g_y;
						win[w_info].window_obj[ROOT].ob_width = win[w_info].work.g_w;
						win[w_info].window_obj[ROOT].ob_height = win[w_info].work.g_h;
					}
					
					break;
							
				case 1:		/* Rolled up */						
				case 4:		/* Shaded */						

					wind_calc(WC_WORK, W_TYPE, PTRS((GRECT *)&msg[4]),
					  &win[w_info].work.g_x,
					  &win[w_info].work.g_y,
					  &junk,
					  &junk);
					
					break;

				case 3:
					/* Iconified */

					wind_calc(WC_WORK, W_TYPE, PTRS((GRECT *)&msg[4]),
					  ELTR(win[w_info].icon));

					win[w_info].icon_obj[ROOT].ob_x = win[w_info].icon.g_x;
					win[w_info].icon_obj[ROOT].ob_y = win[w_info].icon.g_y;
					win[w_info].icon_obj[ROOT].ob_width = win[w_info].icon.g_w;
					win[w_info].icon_obj[ROOT].ob_height = win[w_info].icon.g_h;
					break;
			}
	
		break;
	}
}        
