/*
 *  BLIT.C
 * May 1, 2000
 * Routines for manipulation of blitting in any screen depth
 * 
 * Dan Ackerman baldrick@netset.com
 * http://www.netset.com/~baldrick/
 */

#include <tos.h>
#include <aes.h>
#include <vdi.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "global.h"

int colors[2];    

/* does a test on number of screen planes
 * if > 8 does NOTS_AND_D
 * else S_OR_D.  Just a common test for truecolor resolutions
 */
void
vro_notcpy(int *pxy, MFDB *source, MFDB *dest)
{
	if (planes > 8)
		vro_cpyfm(vdi_handle,S_AND_D,pxy,source,dest);
	else
		vro_cpyfm(vdi_handle,S_OR_D,pxy,source,dest);
}

void
clear_back(int *pxy)
{
	int array[8];

	array[0] = array[4] = pxy[4];
	array[1] = array[5] = pxy[5];
	array[2] = array[6] = pxy[6];
	array[3] = array[7] = pxy[7];

    /* clear out back */
	vro_cpyfm(vdi_handle,S_ONLY,array,&backbuffer,&scrollbuf);
}

/* whole window */
void
cpy_2_back(int *pxy, MFDB *source, MFDB *mask)
{
    colors[0] = 0;
    colors[1] = 1; 

	/* blit our mask into place */
	vrt_cpyfm(vdi_handle, MD_TRANS, pxy, mask, &backbuffer, colors);	
	
	/* copy our object into the hole */
	vro_notcpy(pxy, source, &backbuffer);
}

/* game area */
void
cpy_2_scroll(int *pxy, MFDB *source, MFDB *mask)
{
    colors[0] = 0;
    colors[1] = 1;
    
	/* blit our mask into place */
	vrt_cpyfm(vdi_handle, MD_TRANS, pxy, mask, &scrollbuf, colors);	
	
	/* copy our object into the hole */
	vro_notcpy(pxy, source, &scrollbuf);
	
	/* now put it on whole back buffer */
	cpy_2_back(pxy, source, mask);
}
