/*
  pdamaze.c
 
  A 3D maze game for the Agenda VR3 Linux-based PDA.
  
  by Bill Kendrick
  bill@newbreedsoftware.com
  http://www.newbreedsoftware.com/brickout/

  May 23, 2001 - May 24, 2001

  Atari GEM version
  by Dan Ackerman
  baldrick@netset.com
  http://www.netset.com/~baldrick/
  
  

*/

/* Atari conversion notes

I've equated the following for anyone interested
   
   Pixmap -> MFDB
   display -> vdi_handle
   
   xcopy parameters x,y,width,height, dest x, dest y
   
Other conversion notes
   
   I converted all of the XPM files to xIMG files
*/


#include <stdio.h>
#include <stdlib.h>

#include <string.h>
#include <time.h>

#include "global.h"



char title[] = "\\images\\title.img";
char generate[] = "\\images\\generate.img";
char donename[] = "\\images\\done.img";
char numbers[] = "\\images\\numbers.img";

char cmp_east[] = "\\images\\cmp_east.img";
char cmp_nort[] = "\\images\\cmp_nort.img";
char cmp_sout[] = "\\images\\cmp_sout.img";
char cmp_west[] = "\\images\\cmp_west.img";

char bkg_east[] = "\\images\\bkg_east.img";
char bkg_nort[] = "\\images\\bkg_nort.img";
char bkg_sout[] = "\\images\\bkg_sout.img";
char bkg_west[] = "\\images\\bkg_west.img";
char ground[] = "\\images\\ground.img";

char clo_cent[] = "\\images\\clo_cent.img";
char clo_cbri[] = "\\images\\clo_cbri.img";
char clo_left[] = "\\images\\clo_left.img";
char clo_lbri[] = "\\images\\clo_lbri.img";
char clo_righ[] = "\\images\\clo_righ.img";
char clo_rbri[] = "\\images\\clo_rbri.img";

char mid_cent[] = "\\images\\mid_cent.img";
char mid_cbri[] = "\\images\\mid_cbri.img";
char mid_left[] = "\\images\\mid_left.img";
char mid_lbri[] = "\\images\\mid_lbri.img";
char mid_righ[] = "\\images\\mid_righ.img";
char mid_rbri[] = "\\images\\mid_rbri.img";

char far_cent[] = "\\images\\far_cent.img";
char far_cbri[] = "\\images\\far_cbri.img";
char far_left[] = "\\images\\far_left.img";
char far_lbri[] = "\\images\\far_lbri.img";
char far_righ[] = "\\images\\far_righ.img";
char far_rbri[] = "\\images\\far_rbri.img";


/* Definitions: */

enum {
  DIR_NORTH,
  DIR_EAST,
  DIR_SOUTH,
  DIR_WEST
};

enum {
  FAR,
  MID,
  CLOSE
};

enum {
  TIMER_MODE_UP,
  TIMER_MODE_DOWN,
  NUM_TIMER_MODES
};

enum {
  MAP_MODE_ALL,
  MAP_MODE_BUILD,
  MAP_MODE_NONE,
  NUM_MAP_MODES
};


int xm[4] = {0, 1, 0, -1};
int ym[4] = {-1, 0, 1, 0};

#define MAX_SIZE 39


/* Globals: */

char prg_title[] = " PDAMaze ";

int vdi_handle;
int planes;
int aes_id,menu_id;

int	AES_type; /* We might want this to be global */
short aes_version;
unsigned int tos_ver;
int mch_type;	/* Value of the _MCH cookie		*/

int gl_wchar,gl_hchar,gl_wbox,gl_hbox;

RGB1000 screen_colortab[256]; /* used to save colors */
int screen_colors;

struct win_info win[MAX_WINDOWS]; /* 1 win_info struct for each window */

OBJECT *about,*menu_ptr,*options,*icons,*icon_about,*icon_opt;

#if 0

GC whitegc, blackgc, pastegc;

#endif

MFDB screen;

/* ok a slight change I use backbuffer for whole window
    and scroll buffer for only the game window
    / Dan Ackerman May 28 2001
*/

MFDB backbuffer, scrollbuf;
MFDB pix_generating, pix_done, pix_numbers, pix_title;
MFDB pix_cmp_east, pix_cmp_north, pix_cmp_south, pix_cmp_west;
MFDB pix_bkg_east, pix_bkg_north, pix_bkg_south, pix_bkg_west, pix_ground;
MFDB pix_close_left, pix_close_center, pix_close_right,
       pix_close_left_bright, pix_close_center_bright, pix_close_right_bright,
       pix_mid_left, pix_mid_center, pix_mid_right,
       pix_mid_left_bright, pix_mid_center_bright, pix_mid_right_bright,
       pix_far_left, pix_far_center, pix_far_right,
       pix_far_left_bright, pix_far_center_bright, pix_far_right_bright;
MFDB mask_generating, mask_done, mask_numbers;
MFDB mask_cmp_east, mask_cmp_north, mask_cmp_south, mask_cmp_west;
MFDB mask_bkg_east, mask_bkg_north, mask_bkg_south, mask_bkg_west, mask_ground;
MFDB mask_close_left, mask_close_center, mask_close_right,
       mask_close_left_bright, mask_close_center_bright, mask_close_right_bright,
       mask_mid_left, mask_mid_center, mask_mid_right,
       mask_mid_left_bright, mask_mid_center_bright, mask_mid_right_bright,
       mask_far_left, mask_far_center, mask_far_right,
       mask_far_left_bright, mask_far_center_bright, mask_far_right_bright;


int sound_toggle;
int maze_size;
int done, restart, turn, move_forward;

int timer_mode, map_mode;
int xpos, ypos, dir;
int timer, old_timer, start_timer;
int redraw_screen;

int oxpos, oypos, odir;

int maze[MAX_SIZE][MAX_SIZE];
int seenmaze[MAX_SIZE][MAX_SIZE];

char path[PATH_MAX];
char tempname[FILENAME_MAX];

/* Local function prototypes: */

void drawscreen(int scroll);
void drawwall(int block, int dist, int xoffset);
void draw_farcenter(int xx);
void draw_farleft(int xx);
void draw_farright(int xx);
void draw_midcenter(int xx);
void draw_midleft(int xx);
void draw_midright(int xx);
void draw_closecenter(void);
void draw_closeleft(void);
void draw_closeright(void);
void drawbkg(MFDB *pix, int yy);
void setup(void);

void drawcompass(void);
void drawdone(void);

void LoadImage(char * imgfile, MFDB * pix, MFDB *mask,int mask_color);

int mazechunk(int xx, int yy);
void swapbuffer(void);
void create_maze(int size);
void drawtimer(void);

void open_vwork(void);
int new_game_window(void);
void save_colors(void);
void do_loop(void);

/* --- MAIN! --- */

int
main(int argc, char * argv[])
{
	int footstep;
	int alert_return;

	setup();

game_restart:

	done = 0;
	restart = 0;
	turn = 0;
	move_forward = 0;

	create_maze(maze_size);
	xpos = (maze_size / 2) + 1;
	ypos = (maze_size / 2) + 1;

  
	if (maze[2][3] == 255)
		dir = DIR_SOUTH;
	else
		dir = DIR_EAST;

	odir = dir;

	start_timer = (int)(clock()/CLK_TCK);
  
	timer = 0;
	old_timer = 0;
  
	footstep = 0;
  
	drawscreen(0);

	while(!done)
	{
/*
		if (timer_mode == TIMER_MODE_UP)
			timer++;
		else
		{
			timer--;
			
			if (timer < 0)
				timer = 0;
		}
*/

		redraw_screen = 0;
		move_forward = 0;
		turn = 0;

		oxpos = xpos;
		oypos = ypos;
		odir = dir;
		
		/* Keep track of where we've seen: */
		
		seenmaze[ypos - 1][xpos - 1] = 1;
		seenmaze[ypos - 1][xpos + 0] = 1;
		seenmaze[ypos - 1][xpos + 1] = 1;
		
		seenmaze[ypos + 0][xpos - 1] = 1;
		seenmaze[ypos + 0][xpos + 0] = 1;
		seenmaze[ypos + 0][xpos + 1] = 1;
		
		seenmaze[ypos + 1][xpos - 1] = 1;
		seenmaze[ypos + 1][xpos + 0] = 1;
		seenmaze[ypos + 1][xpos + 1] = 1;

		/* Handle all events */
		
		do_loop();

		/* Turn or move: */
      
		if (turn != 0)
		{
			dir = dir + turn;
			
			if (dir < 0)
				dir = 3;
			else if (dir > 3)
				dir = 0;
			
			redraw_screen = 1;
		}
		else if (move_forward != 0)
		{
			xpos = xpos + (move_forward * xm[dir]);
			ypos = ypos + (move_forward * ym[dir]);
			
			/* Bump into walls: */
			
			if (mazechunk(xpos, ypos) == 255)
			{
				xpos = oxpos;
				ypos = oypos;

				sound_play(S_SIDE);
			}
			else
			{
				redraw_screen = 1;
				
				footstep = !footstep;

				sound_play(S_TOP);
			}
		}

		/* Draw timer (always!) */

		if ((win[GAME_WIN].handle != NO_WINDOW)&&
			(win[GAME_WIN].status == 0))
			drawtimer();
		
		/* Redraw screen: */
      
		if (redraw_screen)
		{
			if (odir == dir)
				drawscreen(0);
			else if (((odir + 1) % 4) == dir)
				drawscreen(1);
			else
				drawscreen(-1);
		}

		/* End of game?! */
      
		if (timer < 0)
		{
			/* Time up - you lose! */
	  
			/*
			XCopyArea(display, pix_timeup, window, whitegc,
		    0, 0, 80, 24, 40, 68);

			XFlush(display);*/
      
			/*playsound(1000, 200);*/
	  
			done = 1;
		}
      
		if (xpos == 2 && ypos == 2)
		{
			/* You win! */
	  
			/*XCopyArea(display, pix_youwin, window, whitegc,
		    0, 0, 80, 24, 40, 68);

			XFlush(display);*/
      
			/*playsound(200, 200);*/

			sound_play(S_BONUS);
	  
			done = 1;
		}
	}

	if (restart == 1)
		goto game_restart;
	else if (restart == 0)
	{
		alert_return = form_alert(2,"[1][Congratulations!][ Restart | Quit ]");
	
		if (alert_return == 1)
			goto game_restart;
	}
	
	bye();

	return(0);
}
	
void
bye(void)
{		
	/* free graphics */
	
	if (backbuffer.fd_addr != NULL)
		free(backbuffer.fd_addr);

	if (scrollbuf.fd_addr != NULL)
		free(scrollbuf.fd_addr);

	if (pix_generating.fd_addr != NULL)
		free(pix_generating.fd_addr);
	if (pix_done.fd_addr != NULL)
		free(pix_done.fd_addr);
	if (pix_numbers.fd_addr != NULL)
		free(pix_numbers.fd_addr);
	if (pix_title.fd_addr != NULL)
		free(pix_title.fd_addr);

	if (pix_cmp_east.fd_addr != NULL)
		free(pix_cmp_east.fd_addr);
	if (pix_cmp_north.fd_addr != NULL)
		free(pix_cmp_north.fd_addr);
	if (pix_cmp_south.fd_addr != NULL)
		free(pix_cmp_south.fd_addr);
	if (pix_cmp_west.fd_addr != NULL)
		free(pix_cmp_west.fd_addr);
	if (pix_bkg_east.fd_addr != NULL)
		free(pix_bkg_east.fd_addr);
	if (pix_bkg_north.fd_addr != NULL)
		free(pix_bkg_north.fd_addr);
	if (pix_bkg_south.fd_addr != NULL)
		free(pix_bkg_south.fd_addr);
	if (pix_bkg_west.fd_addr != NULL)
		free(pix_bkg_west.fd_addr);
	if (pix_ground.fd_addr != NULL)
		free(pix_ground.fd_addr);
	
	if (pix_close_left.fd_addr != NULL)
		free(pix_close_left.fd_addr);
	if (pix_close_center.fd_addr != NULL)
		free(pix_close_center.fd_addr);
	if (pix_close_right.fd_addr != NULL)
		free(pix_close_right.fd_addr);
	if (pix_close_left_bright.fd_addr != NULL)
		free(pix_close_left_bright.fd_addr);
	if (pix_close_center_bright.fd_addr != NULL)
		free(pix_close_center_bright.fd_addr);
	if (pix_close_right_bright.fd_addr != NULL)
		free(pix_close_right_bright.fd_addr);

	if (pix_mid_left.fd_addr != NULL)
		free(pix_mid_left.fd_addr);
	if (pix_mid_center.fd_addr != NULL)
		free(pix_mid_center.fd_addr);
	if (pix_mid_right.fd_addr != NULL)
		free(pix_mid_right.fd_addr);
	if (pix_mid_left_bright.fd_addr != NULL)
		free(pix_mid_left_bright.fd_addr);
	if (pix_mid_center_bright.fd_addr != NULL)
		free(pix_mid_center_bright.fd_addr);
	if (pix_mid_right_bright.fd_addr != NULL)
		free(pix_mid_right_bright.fd_addr);

	if (pix_far_left.fd_addr != NULL)
		free(pix_far_left.fd_addr);
	if (pix_far_center.fd_addr != NULL)
		free(pix_far_center.fd_addr);
	if (pix_far_right.fd_addr != NULL)
		free(pix_far_right.fd_addr);
	if (pix_far_left_bright.fd_addr != NULL)
		free(pix_far_left_bright.fd_addr);
	if (pix_far_center_bright.fd_addr != NULL)
		free(pix_far_center_bright.fd_addr);
	if (pix_far_right_bright.fd_addr != NULL)
		free(pix_far_right_bright.fd_addr);
	
	if (mask_generating.fd_addr != NULL)
		free(mask_generating.fd_addr);
	if (mask_done.fd_addr != NULL)
		free(mask_done.fd_addr);
	if (mask_numbers.fd_addr != NULL)
		free(mask_numbers.fd_addr);

	if (mask_cmp_east.fd_addr != NULL)
		free(mask_cmp_east.fd_addr);
	if (mask_cmp_north.fd_addr != NULL)
		free(mask_cmp_north.fd_addr);
	if (mask_cmp_south.fd_addr != NULL)
		free(mask_cmp_south.fd_addr);
	if (mask_cmp_west.fd_addr != NULL)
		free(mask_cmp_west.fd_addr);
	if (mask_bkg_east.fd_addr != NULL)
		free(mask_bkg_east.fd_addr);
	if (mask_bkg_north.fd_addr != NULL)
		free(mask_bkg_north.fd_addr);
	if (mask_bkg_south.fd_addr != NULL)
		free(mask_bkg_south.fd_addr);
	if (mask_bkg_west.fd_addr != NULL)
		free(mask_bkg_west.fd_addr);
	if (mask_ground.fd_addr != NULL)
		free(mask_ground.fd_addr);
	
	if (mask_close_left.fd_addr != NULL)
		free(mask_close_left.fd_addr);
	if (mask_close_center.fd_addr != NULL)
		free(mask_close_center.fd_addr);
	if (mask_close_right.fd_addr != NULL)
		free(mask_close_right.fd_addr);
	if (mask_close_left_bright.fd_addr != NULL)
		free(mask_close_left_bright.fd_addr);
	if (mask_close_center_bright.fd_addr != NULL)
		free(mask_close_center_bright.fd_addr);
	if (mask_close_right_bright.fd_addr != NULL)
		free(mask_close_right_bright.fd_addr);

	if (mask_mid_left.fd_addr != NULL)
		free(mask_mid_left.fd_addr);
	if (mask_mid_center.fd_addr != NULL)
		free(mask_mid_center.fd_addr);
	if (mask_mid_right.fd_addr != NULL)
		free(mask_mid_right.fd_addr);
	if (mask_mid_left_bright.fd_addr != NULL)
		free(mask_mid_left_bright.fd_addr);
	if (mask_mid_center_bright.fd_addr != NULL)
		free(mask_mid_center_bright.fd_addr);
	if (mask_mid_right_bright.fd_addr != NULL)
		free(mask_mid_right_bright.fd_addr);

	if (mask_far_left.fd_addr != NULL)
		free(mask_far_left.fd_addr);
	if (mask_far_center.fd_addr != NULL)
		free(mask_far_center.fd_addr);
	if (mask_far_right.fd_addr != NULL)
		free(mask_far_right.fd_addr);
	if (mask_far_left_bright.fd_addr != NULL)
		free(mask_far_left_bright.fd_addr);
	if (mask_far_center_bright.fd_addr != NULL)
		free(mask_far_center_bright.fd_addr);
	if (mask_far_right_bright.fd_addr != NULL)
		free(mask_far_right_bright.fd_addr);

	/* close menu bar */
	menu_bar(menu_ptr, 0);	/* close the menu */
	
	/* close sound system */
	
	sound_exit();

	/* close the vdi handle */
	
	v_clsvwk(vdi_handle);
}


/* Draw the screen: */

void drawscreen(int scroll)
{
	int x, y;
	GRECT p;

	/* Draw the background: */

	/* (Skyline) */

	if (dir == DIR_NORTH)
		drawbkg(&pix_bkg_north, 0);
	else if (dir == DIR_EAST) 
		drawbkg(&pix_bkg_east, 0);
	else if (dir == DIR_SOUTH) 
		drawbkg(&pix_bkg_south, 0);
	else if (dir == DIR_WEST)
		drawbkg(&pix_bkg_west, 0);

	/* (Ground) */

	drawbkg(&pix_ground, 80);

	/* Draw the farthest walls: */

	if (dir == DIR_NORTH)
	{
		/* Far... */

		drawwall(mazechunk(xpos - 1, ypos - 3), FAR, -1);
		drawwall(mazechunk(xpos + 1, ypos - 3), FAR, 1);
		drawwall(mazechunk(xpos + 0, ypos - 3), FAR, 0);

		/* Med... */

		drawwall(mazechunk(xpos - 1, ypos - 2), MID, -1);
		drawwall(mazechunk(xpos + 1, ypos - 2), MID, 1);
		drawwall(mazechunk(xpos + 0, ypos - 2), MID, 0);

		/* Close... */

		drawwall(mazechunk(xpos - 1, ypos - 1), CLOSE, -1);
		drawwall(mazechunk(xpos + 1, ypos - 1), CLOSE, 1);
		drawwall(mazechunk(xpos + 0, ypos - 1), CLOSE, 0);
	}
	else if (dir == DIR_EAST)
	{
		/* Far... */

		drawwall(mazechunk(xpos + 3, ypos - 1), FAR, -1);
		drawwall(mazechunk(xpos + 3, ypos + 1), FAR, 1);
		drawwall(mazechunk(xpos + 3, ypos + 0), FAR, 0);

		/* Med... */

		drawwall(mazechunk(xpos + 2, ypos - 1), MID, -1);
		drawwall(mazechunk(xpos + 2, ypos + 1), MID, 1);
		drawwall(mazechunk(xpos + 2, ypos + 0), MID, 0);

		/* Close... */

		drawwall(mazechunk(xpos + 1, ypos - 1), CLOSE, -1);
		drawwall(mazechunk(xpos + 1, ypos + 1), CLOSE, 1);
		drawwall(mazechunk(xpos + 1, ypos + 0), CLOSE, 0);
	}
	else if (dir == DIR_SOUTH)
	{
		/* Far... */

		drawwall(mazechunk(xpos + 1, ypos + 3), FAR, -1);
		drawwall(mazechunk(xpos - 1, ypos + 3), FAR, 1);
		drawwall(mazechunk(xpos + 0, ypos + 3), FAR, 0);

		/* Med... */

		drawwall(mazechunk(xpos + 1, ypos + 2), MID, -1);
		drawwall(mazechunk(xpos - 1, ypos + 2), MID, 1);
		drawwall(mazechunk(xpos + 0, ypos + 2), MID, 0);

		/* Close... */

		drawwall(mazechunk(xpos + 1, ypos + 1), CLOSE, -1);
		drawwall(mazechunk(xpos - 1, ypos + 1), CLOSE, 1);
		drawwall(mazechunk(xpos + 0, ypos + 1), CLOSE, 0);
	}
	else if (dir == DIR_WEST)
	{
		/* Far... */

		drawwall(mazechunk(xpos - 3, ypos + 1), FAR, -1);
		drawwall(mazechunk(xpos - 3, ypos - 1), FAR, 1);
		drawwall(mazechunk(xpos - 3, ypos + 0), FAR, 0);

		/* Med... */
	
		drawwall(mazechunk(xpos - 2, ypos + 1), MID, -1);
		drawwall(mazechunk(xpos - 2, ypos - 1), MID, 1);
		drawwall(mazechunk(xpos - 2, ypos + 0), MID, 0);

		/* Close... */

		drawwall(mazechunk(xpos - 1, ypos + 1), CLOSE, -1);
		drawwall(mazechunk(xpos - 1, ypos - 1), CLOSE, 1);
		drawwall(mazechunk(xpos - 1, ypos + 0), CLOSE, 0);
	}

	/* Draw the compass: */

	drawcompass();

	/* Draw the "Done" button: */

/*	drawdone();
*/	
	swapbuffer();

	/* Draw the thumbnail map of the maze: */

	p.g_x =  win[GAME_WIN].work.g_x + (80 - maze_size);
	p.g_y =  win[GAME_WIN].work.g_y + 160;
	p.g_w =  (maze_size * 2);
	p.g_h =  (maze_size * 2);

	clearwin(&p,0);

	for (y = 0; y < maze_size; y++)
	{
		for (x = 0; x < maze_size; x++)
		{
			if (maze[y][x] == 255)/* &&
			(map_mode == MAP_MODE_ALL ||
			(map_mode == MAP_MODE_BUILD && seenmaze[y][x])))*/
			{
				p.g_x =  win[GAME_WIN].work.g_x + 80 - maze_size + x * 2;
				p.g_y =  win[GAME_WIN].work.g_y + 160 + y * 2;
				p.g_w =  2;
				p.g_h =  2;
	
				clearwin(&p,1);
			}
		}
	}
		
	/* Draw your location on the thumbnail: */

	p.g_x =  win[GAME_WIN].work.g_x + (80 - maze_size) + xpos * 2 - 1;
	p.g_y =  win[GAME_WIN].work.g_y + 160 + ypos * 2 - 1;
	p.g_w =  4;
	p.g_h =  4;
	
	clearwin(&p,0);

	p.g_x =  win[GAME_WIN].work.g_x + (80 - maze_size) + xpos * 2;
	p.g_y =  win[GAME_WIN].work.g_y + 160 + ypos * 2;
	p.g_w =  2;
	p.g_h =  2;
	
	clearwin(&p,1);
		
#if 0
  /* Swap backbuffer: */

  if (scroll == 0)
    {
      swapbuffer();
    }
  else
    {
      XCopyArea(vdi_handle, window, scrollbuf, whitegc, 0, 0, 160, 240, 0, 0);
      
      if (scroll == 1)
	{
	  for (x = 0; x <= 160; x = x + 20)
	    {
	      XCopyArea(vdi_handle, scrollbuf, window, whitegc,
			x, 0,
			160 - x, 160,
			0, 0);
	      
	      XCopyArea(vdi_handle, backbuffer, window, whitegc,
			0, 0,
			x, 160,
			160 - x, 0);
	      
	      XSync(vdi_handle, 0);

	      usleep(100);
	    }
	}
      else if (scroll == -1)
	{
	  for (x = 0; x <= 160; x = x + 20)
	    { 
	      XCopyArea(vdi_handle, scrollbuf, window, whitegc,
			0, 0,
			160 - x, 160,
			x, 0);
	      
	      XCopyArea(vdi_handle, backbuffer, window, whitegc,
			160 - x, 0,
			x, 160,
			0, 0);
	      
	      XSync(vdi_handle, 0);

	      usleep(100);
	    }
	}
    }
    
#endif
}


/* Draw a wall piece: */

void drawwall(int block, int dist, int xoffset)
{
  if (block == 255)
  {
    if (dist == FAR)
    {
      if (xoffset < 0)
      {
        draw_farcenter(80 - 12 + (xoffset * 24));
        draw_farleft(80 - 12 + (xoffset * 24) + 24);
      }
      else if (xoffset == 0)
      {
        draw_farcenter(80 - 12);
      }
      else if (xoffset > 0)
      {
        draw_farcenter(80 - 12 + (xoffset * 24));
        draw_farright(80 - 12 + (xoffset * 24) - 10);
      }
    }
    else if (dist == MID)
    {
      if (xoffset < 0)
      {
        draw_midcenter(80 - 33 - (66 - 24) + (xoffset * 24));
        draw_midleft(80 - 33 - (66 - 24) + (xoffset * 24) + 66);
      }
      else if (xoffset == 0)
      {
        draw_midcenter(80 - 33);
      }
      else if (xoffset > 0)
      {
        draw_midcenter(80 - 33 + (66 - 24) + (xoffset * 24));
        draw_midright(80 - 33 + (66 - 24) + (xoffset * 24) - 21);
      }
    }
    else if (dist == CLOSE)
    {
      if (xoffset < 0)
      {
        draw_closeleft();
      }
      else if (xoffset == 0)
      {
        draw_closecenter();
      }
      else if (xoffset > 0)
      {
        draw_closeright();
      }
    }
  }
}


void
draw_farcenter(int xx)
{
	MFDB pix;
	MFDB msk;
	int pxy[8];
  
	if (dir == DIR_NORTH || dir == DIR_WEST)
	{
		pix = pix_far_center_bright;
		msk = mask_far_center_bright;
	}
	else
	{
		pix = pix_far_center;
		msk = mask_far_center;
	}
	
	pxy[0] = 0;
	pxy[1] = 0;
	pxy[2] = pix.fd_w - 1;
	pxy[3] = pix.fd_h - 1;
	pxy[4] = xx;
	pxy[5] = 80 - 12;
	pxy[6] = pxy[4] + pix.fd_w - 1;
	pxy[7] = pxy[5] + pix.fd_h - 1;

	cpy_2_scroll(pxy, &pix, &msk);
}

void
draw_farleft(int xx)
{
	MFDB pix;
	MFDB msk;
	int pxy[8];
  
	if (dir == DIR_NORTH || dir == DIR_EAST)
	{
		pix = pix_far_left_bright;
		msk = mask_far_left_bright;
	}
	else
	{
		pix = pix_far_left;
		msk = mask_far_left;
	}
	
	pxy[0] = 0;
	pxy[1] = 0;
	pxy[2] = pix.fd_w - 1;
	pxy[3] = pix.fd_h - 1;
	pxy[4] = xx;
	pxy[5] = 80 - pix.fd_w;
	pxy[6] = pxy[4] + pix.fd_w - 1;
	pxy[7] = pxy[5] + pix.fd_h - 1;

	cpy_2_scroll(pxy, &pix, &msk);
}

void draw_farright(int xx)
{
  MFDB pix;
  MFDB msk;
  int pxy[8];
  
	if (dir == DIR_SOUTH || dir == DIR_WEST)
	{
		pix = pix_far_right_bright;
		msk = mask_far_right_bright;
	}
	else
	{
		pix = pix_far_right;
		msk = mask_far_right;
	}
	
	pxy[0] = 0;
	pxy[1] = 0;
	pxy[2] = pix.fd_w - 1;
	pxy[3] = pix.fd_h - 1;
	pxy[4] = xx;
	pxy[5] = 80 - 12;
	pxy[6] = pxy[4] + pix.fd_w - 1;
	pxy[7] = pxy[5] + pix.fd_h - 1;

	cpy_2_scroll(pxy, &pix, &msk);
}


void
draw_midcenter(int xx)
{
	MFDB pix;
	MFDB msk;
	int pxy[8];
	
	if (dir == DIR_NORTH || dir == DIR_WEST)
	{
		pix = pix_mid_center_bright;
		msk = mask_mid_center_bright;
	}
	else
	{
		pix = pix_mid_center;
		msk = mask_mid_center;
	}

	/* make certain the block is even on view port */
	
	if (xx < (0 - pix.fd_w))
		return;
		
	if (xx > 160)
		return;

	if (xx < 0)
	{
		pxy[0] = 0;
		pxy[2] = pix.fd_w + xx;
		pxy[4] = 0;
	}
	else if ((xx + pix.fd_w) > 160)
	{
		pxy[0] = 0;
		pxy[2] = pix.fd_w - ((xx + pix.fd_w) - 160) - 1;
		pxy[4] = xx;
	}
	else
	{
		pxy[0] = 0;
		pxy[2] = pix.fd_w - 1;
		pxy[4] = xx;
	}


	pxy[1] = 0;
	pxy[3] = pix.fd_h - 1;
	pxy[5] = (scrollbuf.fd_h/2) - (pix.fd_h/2);
	pxy[6] = pxy[4] + pxy[2];
	pxy[7] = pxy[5] + pxy[3];
	
	cpy_2_scroll(pxy, &pix, &msk);
}

void
draw_midleft(int xx)
{
	MFDB pix;
	MFDB msk;
	int pxy[8];

	if (dir == DIR_NORTH || dir == DIR_EAST)
	{
		pix = pix_mid_left_bright;
		msk = mask_mid_left_bright;
	}
	else
	{
		pix = pix_mid_left;
		msk = mask_mid_left;
	}

	pxy[0] = 0;
	pxy[1] = 0;
	pxy[2] = pix.fd_w - 1;
	pxy[3] = pix.fd_h - 1;
	pxy[4] = xx;
	pxy[5] = 80 - 33;
	pxy[6] = pxy[4] + pix.fd_w - 1;
	pxy[7] = pxy[5] + pix.fd_h - 1;

	cpy_2_scroll(pxy, &pix, &msk);
}

void
draw_midright(int xx)
{
	MFDB pix;
	MFDB msk;
	int pxy[8];

	if (dir == DIR_SOUTH || dir == DIR_WEST)
	{
		pix = pix_mid_right_bright;
		msk = mask_mid_right_bright;
	}
	else
	{
		pix = pix_mid_right;
		msk = mask_mid_right;
	}
	
	pxy[0] = 0;
	pxy[1] = 0;
	pxy[2] = pix.fd_w - 1;
	pxy[3] = pix.fd_h - 1;
	pxy[4] = xx;
	pxy[5] = 80 - 33;
	pxy[6] = pxy[4] + pix.fd_w - 1;
	pxy[7] = pxy[5] + pix.fd_h - 1;

	cpy_2_scroll(pxy, &pix, &msk);
}


void
draw_closecenter(void)
{
	MFDB pix;
	MFDB msk;
	int pxy[8];

	if (dir == DIR_NORTH || dir == DIR_WEST)
	{
		pix = pix_close_center_bright;
		msk = mask_close_center_bright;
	}
	else
	{
		pix = pix_close_center;
		msk = mask_close_center;
	}

	pxy[0] = 0;
	pxy[1] = 0;
	pxy[2] = pix.fd_w - 1;
	pxy[3] = pix.fd_h - 1;
	pxy[4] = 0;
	pxy[5] = 0;
	pxy[6] = pix.fd_w - 1;
	pxy[7] = pix.fd_h - 1;


	cpy_2_scroll(pxy, &pix, &msk);
}

void
draw_closeleft(void)
{
	MFDB pix;
	MFDB msk;
	int pxy[8];
  
	if (dir == DIR_NORTH || dir == DIR_EAST)
	{
		pix = pix_close_left_bright;
		msk = mask_close_left_bright;
	}
	else
	{
		pix = pix_close_left;
		msk = mask_close_left;
	}

	pxy[0] = 0;
	pxy[1] = 0;
	pxy[2] = pix.fd_w - 1;
	pxy[3] = pix.fd_h - 1;
	pxy[4] = 0;
	pxy[5] = 0;
	pxy[6] = pix.fd_w - 1;
	pxy[7] = pix.fd_h - 1;

	cpy_2_scroll(pxy, &pix, &msk);
}

void
draw_closeright(void)
{
	MFDB pix;
  	MFDB msk;
	int pxy[8];

	if (dir == DIR_SOUTH || dir == DIR_WEST)
	{
		pix = pix_close_right_bright;
		msk = mask_close_right_bright;
	}
	else
	{
		pix = pix_close_right;
		msk = mask_close_right;
	}
  
	pxy[0] = 0;
	pxy[1] = 0;
	pxy[2] = pix.fd_w - 1;
	pxy[3] = pix.fd_h - 1;
	pxy[4] = scrollbuf.fd_w - pix.fd_w;
	pxy[5] = 0;
	pxy[6] = pxy[4] + pix.fd_w - 1;
	pxy[7] = pxy[5] + pix.fd_h - 1;

	cpy_2_scroll(pxy, &pix, &msk);
}


/* Draw the background: */

void
drawbkg(MFDB *pix, int yy)
{
	int pxy[8];
	MFDB msk;

	if (dir == DIR_NORTH)
		msk = mask_bkg_north;
	else if (dir == DIR_EAST) 
		msk = mask_bkg_east;
	else if (dir == DIR_SOUTH) 
		msk = mask_bkg_south;
	else if (dir == DIR_WEST)
		msk = mask_bkg_west;
	else /* (Ground) */
		msk = mask_ground;

	pxy[0] = 0;
	pxy[1] = 0;
	pxy[2] = pix->fd_w - 1;
	pxy[3] = pix->fd_h - 1;
	pxy[4] = 0;
	pxy[5] = yy;
	pxy[6] = pix->fd_w - 1;
	pxy[7] = yy + pix->fd_h - 1; /* + yy */

	cpy_2_scroll(pxy, pix, &msk);
}

/* Draw the compass: */

void
drawcompass(void)
{
	int pxy[8];
	MFDB msk;
	MFDB pix;
	
	if (dir == DIR_NORTH)
	{
		pix = pix_cmp_north;
		msk = mask_cmp_north;
	}
	else if (dir == DIR_SOUTH)
	{
		pix = pix_cmp_south;
		msk = mask_cmp_south;
	}
	else if (dir == DIR_EAST)
	{
		pix = pix_cmp_east;
		msk = mask_cmp_east;
	}
	else if (dir == DIR_WEST)
	{
		pix = pix_cmp_west;
		msk = mask_cmp_west;
	}

	pxy[0] = 0;
	pxy[1] = 0;
	pxy[2] = pix.fd_w - 1;
	pxy[3] = pix.fd_h - 1;
	pxy[4] = 0;
	pxy[5] = 172;
	pxy[6] = pix.fd_w - 1;
	pxy[7] = pxy[5] + pix.fd_h - 1; /* + yy */

	cpy_2_back(pxy, &pix, &msk);
}

/* Draw the Done: */

void
drawdone(void)
{
	int pxy[8];
	MFDB msk;
	MFDB pix;
	
	pix = pix_done;
	msk = mask_done;

	pxy[0] = 0;
	pxy[1] = 0;
	pxy[2] = pix.fd_w - 1;
	pxy[3] = pix.fd_h - 1;
	pxy[4] = 0;
	pxy[5] = 224;
	pxy[6] = pix.fd_w - 1;
	pxy[7] = pxy[5] + pix.fd_h - 1; /* + yy */

	cpy_2_back(pxy, &pix, &msk);
}

/* Set up GEM and handle images! */

void
setup(void)
{
	int i;
	long size;
	GRECT p,clip;
	int pxy[8];
	char rpath[128];

	void rsrc_init(void);

	/* Default settings: */
  
	timer_mode = TIMER_MODE_UP;
	map_mode = MAP_MODE_BUILD;
	maze_size = 29; /*19;*/
	sound_toggle = 1;

	/* Seed random number generator: */

	srand(time(NULL)); /* Initialize the random number generator ( for rand() )*/

	aes_id = appl_init(); /* aes_id wasn't being set?  - DAN */

	AES_type = identify_AES();

	if (_app != 0)
	{
		if( AES_type != AES_single ) 
		{
			shel_write(9,1,1,"","");
				
			if ( (AES_type == AES_MTOS)||(AES_type == AES_nAES))
	    		menu_register(aes_id, "  PDAMaze  ");
		}
	}
	else
	    menu_id = menu_register(aes_id, "  PDAMaze  ");
	    
	vdi_handle = graf_handle(&gl_wchar,&gl_hchar,&gl_wbox,&gl_hbox);

	open_vwork();

	rpath[0] = Dgetdrv() + 'A';
	rpath[1] = ':';
	Dgetpath(rpath+2, 0);

	if(rpath[strlen(rpath)-1]=='\\')
		rpath[strlen(rpath)-1]=0;

	strcat(rpath, "\\pdamaze.rsc");

	if (rsrc_load(rpath) <= 0) 
	{		/* Load ST RSC */
		form_alert(1, "[1][ Can't load RSC file ][ Damn! ]");
		return(FALSE);
	}
	else 
	{
		rsrc_init();

		menu_bar(menu_ptr, 1);	/* display the menu */
	}

	/* clear out window array */
	
	for(i=0;i<MAX_WINDOWS;i++)
	{
		win[i].handle = -1;

		win[i].curr.g_x = 0;
		win[i].curr.g_y = 0;
	}

	/* fix options windows buttons */
	
	switch (maze_size)
	{
		case 19:
			objc_change(options,R_SMALL,0,ELTS(p),0x0001,0);
			break;
		case 29:
			objc_change(options,R_MEDIUM,0,ELTS(p),0x0001,0);
			break;
		case 39:
			objc_change(options,R_LARGE,0,ELTS(p),0x0001,0);
	}	
	
	/* Now fix the Game Win */

	clip.g_x = 30;
	clip.g_y = 40;
	clip.g_w = 160;
	clip.g_h = 260;
	
	wind_calc(WC_BORDER, W_TYPE, PTRS((GRECT *)&clip), ELTR(p));

	win[GAME_WIN].curr.g_x = p.g_x;
	win[GAME_WIN].curr.g_y = p.g_y;
	win[GAME_WIN].curr.g_w = p.g_w;
	win[GAME_WIN].curr.g_h = p.g_h;

/*	Set up the path for the background picture*/
#if OS_TOS
	path[0] = Dgetdrv() + 'A';
	path[1] = ':';
	Dgetpath(path+2, 0);
#endif
#if OS_DOS
	path[0] = dos_gdrv() + 'A';
	path[1] = ':';
	path[2] = '\\';
	dos_gdir(0, path+3);
#endif
#if OS_UNIX
	getcwd(path, PATH_MAX); /* Will most probably not work */
#endif
	if(path[strlen(path)-1]=='\\')  path[strlen(path)-1]=0;

	strcpy(tempname,path);
	
	/* Get screen colors: */

	save_colors();
  
	/* Open the Game window */
	new_game_window();

	/* Bring window up! */

	clearwin((GRECT *)&win[GAME_WIN].work,0);
  
	wind_set(win[GAME_WIN].handle, WF_TOP, win[GAME_WIN].handle);

	/* Create backbuffer: */

	scrollbuf.fd_w = backbuffer.fd_w = 160;                /* width        */
	scrollbuf.fd_wdwidth = backbuffer.fd_wdwidth = (160 + 15) >> 4;    /* (words)      */
	scrollbuf.fd_h = 160;                /* height       */
	backbuffer.fd_h = 260;                /* height       */
	scrollbuf.fd_stand = backbuffer.fd_stand = 0;                  /* raster format = device */
	scrollbuf.fd_nplanes = backbuffer.fd_nplanes = planes;               /* bitplanes    */

	size = (long)(scrollbuf.fd_wdwidth * scrollbuf.fd_h);
	
	/* convert size from words to bytes */
	size <<= 1;

	/* memory for the device raster */
	if( (scrollbuf.fd_addr = (char *) malloc( size * planes )) == NULL )
		return;

	size = (long)(backbuffer.fd_wdwidth * backbuffer.fd_h);
	
	/* convert size from words to bytes */
	size <<= 1;

	/* memory for the device raster */
	if( (backbuffer.fd_addr = (char *) malloc( size * planes )) == NULL )
		return;

	if (planes > 8)
		memset(backbuffer.fd_addr,255,(size * planes));
	else
		memset(backbuffer.fd_addr,0,(size * planes));

	/* Create images: */

	/* (Status stuff) */

	strcat(tempname,title);

	/* I do title seperately since I dont really need a mask */
	img_load(&pix_title,tempname,0,(MFDB *)NULL,1);

	pxy[0] = 0;
	pxy[1] = 0;
	pxy[2] = pix_title.fd_w - 1;
	pxy[3] = pix_title.fd_h - 1;
	pxy[4] = win[GAME_WIN].work.g_x;
	pxy[5] = win[GAME_WIN].work.g_y;
	pxy[6] = pxy[4] + pix_title.fd_w - 1;
	pxy[7] = pxy[5] + pix_title.fd_h - 1;

	/* throw onto screen */
	vro_cpyfm( vdi_handle, S_ONLY, pxy, &pix_title, &screen); /* was source*/

	LoadImage(generate, &pix_generating, &mask_generating,1);

	pxy[0] = 0;
	pxy[1] = 0;
	pxy[2] = pix_generating.fd_w - 1;
	pxy[3] = pix_generating.fd_h - 1;
	pxy[4] = win[GAME_WIN].work.g_x + 30;
	pxy[5] = win[GAME_WIN].work.g_y + 175;
	pxy[6] = pxy[4] + pix_generating.fd_w - 1;
	pxy[7] = pxy[5] + pix_generating.fd_h - 1;

	/* throw onto screen */
	vro_cpyfm( vdi_handle, S_ONLY, pxy, &pix_generating, &screen); /* was source*/

	LoadImage(donename, &pix_done,&mask_done,1);
	LoadImage(numbers, &pix_numbers,&mask_numbers,1);

	LoadImage(cmp_nort, &pix_cmp_north, &mask_cmp_north,1);
	LoadImage(cmp_sout, &pix_cmp_south, &mask_cmp_south,1);
	LoadImage(cmp_east, &pix_cmp_east, &mask_cmp_east,1);
	LoadImage(cmp_west, &pix_cmp_west, &mask_cmp_west,1);

	/* (Background stuff) */

	LoadImage(ground, &pix_ground, &mask_ground,1);
	LoadImage(bkg_nort, &pix_bkg_north, &mask_bkg_north,1);
	LoadImage(bkg_sout, &pix_bkg_south, &mask_bkg_south,1);
	LoadImage(bkg_east, &pix_bkg_east, &mask_bkg_east,1);
	LoadImage(bkg_west, &pix_bkg_west, &mask_bkg_west,1);

	/* (Walls) */

	LoadImage(clo_left, &pix_close_left, &mask_close_left,1);
	LoadImage(clo_cent, &pix_close_center, &mask_close_center,1);
	LoadImage(clo_righ, &pix_close_right, &mask_close_right,1);

	LoadImage(mid_left, &pix_mid_left, &mask_mid_left,1);
	LoadImage(mid_cent, &pix_mid_center, &mask_mid_center,1);
	LoadImage(mid_righ, &pix_mid_right, &mask_mid_right,1);

	LoadImage(far_left, &pix_far_left, &mask_far_left,1);
	LoadImage(far_cent, &pix_far_center, &mask_far_center,1);
	LoadImage(far_righ, &pix_far_right, &mask_far_right,1);

	/* (Bright walls) */
  
	LoadImage(clo_lbri, &pix_close_left_bright, &mask_close_left_bright,1);
	LoadImage(clo_cbri, &pix_close_center_bright, &mask_close_center_bright,1);
	LoadImage(clo_rbri, &pix_close_right_bright, &mask_close_right_bright,1);

	LoadImage(mid_lbri, &pix_mid_left_bright, &mask_mid_left_bright,1);
	LoadImage(mid_cbri, &pix_mid_center_bright, &mask_mid_center_bright,1);
	LoadImage(mid_rbri, &pix_mid_right_bright, &mask_mid_right_bright,1);

	LoadImage(far_lbri, &pix_far_left_bright, &mask_far_left_bright,1);
	LoadImage(far_cbri, &pix_far_center_bright, &mask_far_center_bright,1);
	LoadImage(far_rbri, &pix_far_right_bright, &mask_far_right_bright,1);

	/* Init sound system */
	
	sound_init();

	/* Bring window up! */

	clearwin((GRECT *)&win[GAME_WIN].work,0);
  
 	do_redraw(win[GAME_WIN].handle,(GRECT *)&win[GAME_WIN].work);

	wind_set(win[GAME_WIN].handle, WF_TOP, win[GAME_WIN].handle);
}


/* Create a graphics context: */

#if 0
GC CreateGC(Display *vdi_handle, Drawable drawable, unsigned long forecolor,
            unsigned long backcolor)
{
  XGCValues xgcvalues;
  GC gc;
  
  xgcvalues.foreground = forecolor;
  xgcvalues.background = backcolor;
  gc = XCreateGC(vdi_handle,drawable,(GCForeground | GCBackground),
                 &xgcvalues);
  
  return(gc);
}
#endif


/* Load an image from Ximg data: */

void
LoadImage(char * imgfile, MFDB * pix, MFDB *mask, int mask_color)
{
	strcpy(tempname,path);
	strcat(tempname,imgfile);

	img_load(pix, tempname, 0, mask, mask_color);
}


int
mazechunk(int xx, int yy)
{
	if (xx > 0 &&
		yy > 0 &&
      	xx < maze_size - 1 &&
      	yy < maze_size - 1)
	{
		return(maze[yy][xx]);
	}
	else
		return -1;
}



/* Swap the buffer into the window! */

void
swapbuffer(void)
{
	int pxy[8];

	/* Hide the mouse */

	HIDE_MOUSE

	pxy[0] = 0;
	pxy[1] = 0;
	pxy[2] = backbuffer.fd_w - 1;
	pxy[3] = backbuffer.fd_h - 1;
	pxy[4] = win[GAME_WIN].work.g_x;
	pxy[5] = win[GAME_WIN].work.g_y;
	pxy[6] = win[GAME_WIN].work.g_x + backbuffer.fd_w - 1;
	pxy[7] = win[GAME_WIN].work.g_y + backbuffer.fd_h - 1;

	Vsync();

	/* throw onto screen */
	vro_cpyfm( vdi_handle, S_ONLY, pxy, &backbuffer, &screen);

#if 0
	pxy[0] = 0;
	pxy[1] = 0;
	pxy[2] = scrollbuf.fd_w - 1;
	pxy[3] = scrollbuf.fd_h - 1;
	pxy[4] = win[GAME_WIN].work.g_x;
	pxy[5] = win[GAME_WIN].work.g_y;
	pxy[6] = win[GAME_WIN].work.g_x + scrollbuf.fd_w - 1;
	pxy[7] = win[GAME_WIN].work.g_y + scrollbuf.fd_h - 1;

	Vsync();

	vro_cpyfm( vdi_handle, S_ONLY, pxy, &scrollbuf, &screen);
#endif

	/* Show the mouse */
	SHOW_MOUSE
}


/* Create a maze randomly: */

void create_maze(int size)
{
	int x, y, ok, xx, nx, ny, j;
	int draw_notice;
	int pxy[8];
  
	/* Create 100% wall: */
  
	for (y = 1; y < maze_size - 1; y++)
	{
		maze[y][0] = -1;
		
		for (x = 1; x < maze_size - 1; x++)
		{
			maze[y][x] = 255;
		}

		maze[y][maze_size - 1] = -1;
	}

	for (x = 0; x < maze_size; x++)
    {
      maze[0][x] = -1;
      maze[maze_size - 1][x] = -1;
    }
 
  
	y = 2;
	x = 2;
  
	xx = 0;
	j = 0;
  
	maze[y][x] = 5;
  
	draw_notice = 1;
	ok = 2;
  
	do
    {
		if (ok == 2)
		{
			j = (rand() % 4);
			xx = j;
		}
      
    	ok = 0;
      
		nx = x + xm[j] * 2;
		ny = y + ym[j] * 2;
      
		if (mazechunk(nx, ny) == 255)
		{
			maze[ny][nx] = j + 1;
			maze[y + ym[j]][x + xm[j]] = 0;
	  
			x = nx;
			y = ny;
	  
			ok = 2;
		}
      
		if (ok == 0)
		{
			if (j < 3)
			{
				j = j + 1;
	      
				while (j > 3)
				j = j - 4;
			}
			else
				j = 0;
	  
			if (j != xx)
				ok = 1;
		}
      
		if (ok == 0)
		{
			j = mazechunk(x, y);
			maze[y][x] = 0;
	  
			if (j < 5)
			{
				x = x - (xm[j - 1] * 2);
				y = y - (ym[j - 1] * 2);
	      
				ok = 2;
			}
		}
 
		/* (Re)draw notice: */
      
		if (draw_notice == 1)
		{
			draw_notice = 0;

			pxy[0] = 0;
			pxy[1] = 0;
			pxy[2] = pix_generating.fd_w - 1;
			pxy[3] = pix_generating.fd_h - 1;
			pxy[4] = win[GAME_WIN].work.g_x + 30;
			pxy[5] = win[GAME_WIN].work.g_y + 175;
			pxy[6] = pxy[4] + pix_generating.fd_w - 1;
			pxy[7] = pxy[5] + pix_generating.fd_h - 1;

			/* throw onto screen */
			vro_cpyfm( vdi_handle, S_ONLY, pxy, &pix_generating, &screen); /* was source*/
		}
    }
  while (ok != 0);

  /* Create seen-maze map: */

  for (y = 0; y < maze_size; y++)
  {
    for (x = 0; x < maze_size; x++)
    {
      seenmaze[y][x] = 0;
    }
  }

  /* Clear screen: */
#if 0
  XFillRectangle(vdi_handle, window, whitegc, 0, 0, 160, 240);
  XFlush(vdi_handle);
#endif
}


void
drawtimer(void)
{
	char str[10];
	int i;
	int pxy[8];

	/* Don't draw timer if the window is buried */
	if (win[GAME_WIN].handle != get_topwindow(win[GAME_WIN].handle))
		return;

	timer = (int)(clock()/CLK_TCK) - start_timer;

	if (timer == old_timer)
		return;

	old_timer = timer;

	sprintf(str, "%.2d:%.2d", timer / 60, timer % 60);

	for (i = 0; i < strlen(str); i++)
	{
		if (str[i] >= '0' && str[i] <= ':')
		{
			pxy[0] = (str[i]-'0') * 8;
			pxy[1] = 0;
			pxy[2] = pxy[0] + 7;
			pxy[3] = 11;
			pxy[4] = 118 + (i * 8);
			pxy[5] = 186;
			pxy[6] = pxy[4] + 7;
			pxy[7] = pxy[5] + 11;

			/* throw into backbuffer */
			vro_cpyfm( vdi_handle, S_ONLY, pxy, &pix_numbers, &backbuffer);
		}
	}

	pxy[0] = 118;
	pxy[1] = 186;
	pxy[2] = pxy[0] + 40;
	pxy[3] = 197;
	pxy[4] = win[GAME_WIN].work.g_x + pxy[0];
	pxy[5] = win[GAME_WIN].work.g_y + pxy[1];
	pxy[6] = pxy[4] + 40;
	pxy[7] = pxy[5] + 11;

	/* throw onto screen */
	vro_cpyfm( vdi_handle, S_ONLY, pxy, &backbuffer, &screen);
}

/****************************************************************/
/* open virtual workstation										*/
/****************************************************************/
void
open_vwork(void)
{
	register int i;
	int work_in[11], work_out[57], vwork_out[57];

	for(i=0;i<10;work_in[i++]=1);
	work_in[10]=2;

	v_opnvwk(work_in,&vdi_handle,work_out);

	vq_extnd(vdi_handle, 1, vwork_out);
	screen_colors = work_out[13];
	planes = vwork_out[4];

	screen.fd_addr = 0L; /* This is the official way for the screen FDB */
	screen.fd_nplanes = planes;
}

int
new_game_window(void)
{
	int wh;

	wh = new_window((OBJECT *)NULL,prg_title,0,GAME_WIN);

	if (wh >= 0)
	{
		win[GAME_WIN].handle = wh;
		win[GAME_WIN].window_obj = (OBJECT *)NULL;
		win[GAME_WIN].title = prg_title;
		win[GAME_WIN].cur_item = -1;
		win[GAME_WIN].text_block = NULL;
		win[GAME_WIN].buf_size = 0;
		win[GAME_WIN].status = 0;
		win[GAME_WIN].edit = 0;
		win[GAME_WIN].type = 0;
		win[GAME_WIN].top = 0;

		win[GAME_WIN].icon_obj = icons;

		wind_get(win[GAME_WIN].handle, WF_CURRXYWH, ELTR(win[GAME_WIN].curr));

		wind_get(win[GAME_WIN].handle, WF_WORKXYWH, ELTR(win[GAME_WIN].work));

/*		clearwin((GRECT *)&win[GAME_WIN].work,objcolors[BACKG]);
*/
	}

	return(wh);
}

/* Saves colors in global array screen_colortab[] */
void
save_colors(void)
{
	int i;
	int coltab[3];
	
	for (i=0;i<screen_colors;i++)
	{
		vq_color(vdi_handle,i,0,coltab);

		screen_colortab[i].red = coltab[0];
		screen_colortab[i].green = coltab[1];
		screen_colortab[i].blue = coltab[2];			
	}
}

void
do_loop(void)
{
	int event, mousex, mousey;
	int key = 0, button = 0, clicks = 0;
	int msg[8],junk;


	event = evnt_multi(MU_MESAG | MU_BUTTON | MU_KEYBD | MU_TIMER,
	  0x102, 3, 0,			/* mouses */
	  0, 0, 0, 0, 0,	/* rectangle 1 */
	  0, 0, 0, 0, 0,	/* rectangle 2 */
	  msg,				/* message buffer */
	  10, 0,		/* respond to timer variable */
	  &mousex, &mousey, &button, &junk, &key, &clicks);

	if (event & MU_BUTTON)
	{
		handle_button_events(button,mousex,mousey);
	}
    if (event & MU_MESAG) 
    {
		handle_gem_evnts(msg);
	}
	if (event & MU_KEYBD)
	{        
		handle_key_evnts(key,mousex,mousey);
	}
	if(event & MU_TIMER)
	{			
		if (win[GAME_WIN].handle != -1)
		{
			;
		}
	}
}

void 
rsrc_init(void)
{
	rsrc_gaddr(0, R_MENU,&menu_ptr); 	
	rsrc_gaddr(0, R_ABOUT,&about); 
	rsrc_gaddr(0, R_OPTIONS,&options); 
	rsrc_gaddr(0, R_ICONS,&icons);
	rsrc_gaddr(0, R_ICON_ABOUT,&icon_about);
	rsrc_gaddr(0, R_ICON_OPTIONS,&icon_opt);
}

