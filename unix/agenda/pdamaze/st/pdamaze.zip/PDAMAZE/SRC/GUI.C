/********************************************/
/*											*/
/*					GUI.C					*/
/*				 Sept 30 1996				*/
/*				 Dan Ackerman				*/
/*											*/
/*		Routines for driving dialogs		*/
/*											*/
/********************************************/
/*
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   Electronic contact can be made via the following web address
 *  	http://www.netset.com/~baldrick/stik2.html
 *
 */

/* Easily the worst file in the whole project
 *
 * Many routines that could be split into seperate
 * files.  Some routines in here aren't even used
 * in the project.
 *
 * In general this has 4 main sections
 *   1. Routines to create the various windowed dialogs
 *   2. Support routines for doing alot of routine items
 *          redrawing objects etc
 *   3. Routines for file management and logging
 *	 4. A few routines for redrawing the connection windows
 *
 */
 

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>

#include "global.h"

#define MOPENED               0  /* Datei konnte ge�ffnet werden        */
#define MFSEL                 1  /* Programmende                        */
#define MERROR                2  /* Datei konnte nicht ge�ffnet werden  */

#define STFILELEN            13  /* Maximale L�nge eines Filenamens     */
#define STPATHLEN           128  /* Maximale L�nge eines Pfades         */

#define EOS                '\0'  /* Ende eines Strings                  */
#define BACKSLASH          '\\'

void clear_edits(OBJECT *tree, int object);

/*
 * Routines for object management
 */

void
unroll_window(int wh)
{
	GRECT p;
	int w_info;
	
	w_info = get_wininfo_from_handle(wh);

	if (win[w_info].type == 0)
		wind_calc(WC_BORDER, W_TYPE, 
		  win[w_info].curr.g_x,
		  win[w_info].curr.g_y,
		  win[w_info].window_obj[ROOT].ob_width,
		  win[w_info].window_obj[ROOT].ob_height,
		  ELTR(p));			
	else if (win[w_info].type == 1)
		wind_calc(WC_BORDER, W_T2, 
		  win[w_info].curr.g_x,
		  win[w_info].curr.g_y,
		  win[w_info].window_obj[ROOT].ob_width,
		  win[w_info].window_obj[ROOT].ob_height,
		  ELTR(p));			
	else if (win[w_info].type == 2)
		wind_calc(WC_BORDER, W_T3, 
		  win[w_info].curr.g_x,
		  win[w_info].curr.g_y,
		  win[w_info].window_obj[ROOT].ob_width,
		  win[w_info].window_obj[ROOT].ob_height,
		  ELTR(p));			

	wind_set(wh, WF_NAME, win[w_info].title);
	wind_set(wh, WF_CURRXYWH, PTRS((GRECT *)&p));
		
	wind_get(wh,WF_WORKXYWH,ELTR(p));
			
	win[w_info].window_obj[ROOT].ob_x = p.g_x; /*win[w_info].curr.g_x;*/
	win[w_info].window_obj[ROOT].ob_y = p.g_y;/*win[w_info].curr.g_y;*/
	win[w_info].window_obj[ROOT].ob_width = p.g_w; /*win[w_info].curr.g_w;/*
	win[w_info].window_obj[ROOT].ob_height = p.g_h;/*win[w_info].curr.g_h;*/
}

void
iconify(int w_info, GRECT *new_size)
{
	win[w_info].status = 3; /* Iconified */
				
	wind_set( win[w_info].handle, WF_ICONIFY, PTRS(new_size));	wind_set( win[w_info].handle, WF_NAME, win[w_info].title);	wind_get( win[w_info].handle, WF_WORKXYWH, ELTR(win[w_info].icon));
	/* Set icon's location for later redraws */

	win[w_info].icon_obj[ROOT].ob_x = win[w_info].icon.g_x;
	win[w_info].icon_obj[ROOT].ob_y = win[w_info].icon.g_y;
	win[w_info].icon_obj[ROOT].ob_width = win[w_info].icon.g_w;
	win[w_info].icon_obj[ROOT].ob_height = win[w_info].icon.g_h;
	win[w_info].icon_obj[ICON1].ob_x = (win[w_info].icon.g_w - win[w_info].icon_obj[ICON1].ob_width)/2;
	win[w_info].icon_obj[ICON1].ob_y = (win[w_info].icon.g_h - win[w_info].icon_obj[ICON1].ob_height)/2;}

void
un_iconify(int w_info,GRECT *new_size)
{
	win[w_info].status = 0;
	
	wind_set( win[w_info].handle, WF_UNICONIFY, PTRS(new_size));	wind_get( win[w_info].handle, WF_WORKXYWH, ELTR(win[w_info].icon));}

/* routines to manipulate editable objects - clear, empty, set */

void
empty_edits(OBJECT *tree, int object)
{
	clear_edits(tree,object);

	tree[object].ob_spec.tedinfo->te_ptext = "\0";
}

void
clear_edits(OBJECT *tree, int object)
{
	int template_length = tree[object].ob_spec.tedinfo->te_txtlen;
	char *dest;

	dest = tree[object].ob_spec.tedinfo->te_ptext;

	memset((void *)dest,95,template_length);
}

void
set_edits(OBJECT *tree, int object,char *source)
{
	char *dest;
	
	dest = tree[object].ob_spec.tedinfo->te_ptext;

	strncpy(dest,source,tree[object].ob_spec.tedinfo->te_txtlen);
}


/*
 * copy a string into a TEDINFO structure.
 */

void 
set_tedinfo(OBJECT *tree,int obj,char *source)
{
	char *dest;
	
	dest=tree[obj].ob_spec.tedinfo->te_ptext;

	if((tree[obj].ob_spec.tedinfo->te_tmplen) > (tree[obj].ob_spec.tedinfo->te_txtlen))
		strncpy(dest,source,(tree[obj].ob_spec.tedinfo->te_tmplen));
	else
		strncpy(dest,source,(tree[obj].ob_spec.tedinfo->te_txtlen));
}


void get_tedinfo(OBJECT *tree,int obj,char *dest)
{
	char *source;

	printf("Hey there is something wrong with this routine\r\n");
	
	source = tree[obj].ob_spec.tedinfo->te_ptext;

	strncpy(dest,source,(tree[obj].ob_spec.tedinfo->te_txtlen));
}


void check_button(OBJECT *tree,int button)
{
	if (tree[button].ob_state!=CHECKED)
	{
		tree[button].ob_state|=CHECKED;
	}
}

void decheck_button(OBJECT *tree,int button)
{
	if (tree[button].ob_state==CHECKED)
	{
		tree[button].ob_state&=~CHECKED;
	}
}

/*
 * copy a string into a GBUTTON structure.
 */
void set_GBUTTON(OBJECT *tree,int obj,char *source)
{
	char *dest;
	
	dest = tree[obj].ob_spec.free_string;
	strcpy(dest,source);
}

/*
 * get a string from a GBUTTON structure.
 */

void get_GBUTTON(OBJECT *tree,int obj,char *dest)
{
	char *source;
	
	source = tree[obj].ob_spec.free_string;
	strcpy(dest,source);
}

/* Gets an objects screen location */
void objc_xywh(OBJECT *tree, int obj, GRECT *xywh)
{
	int loc_x, loc_y;

	objc_offset( tree, obj, &loc_x, &loc_y);

	xywh->g_x = loc_x;
	xywh->g_y = loc_y;
	xywh->g_w = tree[obj].ob_width;
	xywh->g_h = tree[obj].ob_height;
}

/*
 * Check window status and open/unroll/uniconify
 */
 
int
proc_window(int window, int (*routine)(void))
{
	if (win[window].handle == NO_WINDOW)
		(*routine)();
	else if (win[window].status == 1)
		unroll_window(win[window].handle);
	else if (win[window].status == 3)
		un_iconify(window, (GRECT *)&win[window].curr);
		
	wind_set(win[window].handle, WF_TOP, win[window].handle);
	
	/* special case since for this program
	 * if the window is the GAMEWIN and you already have
	 * a game that is stopped, start a new game
	 */
#if 0

	if (window == GAME_WIN)
	{
		if (have_game == 1)
			cleanup_game();

		intpmain(gamefile);
	}

#endif

	return(win[window].handle);
}

/*
	 redraw_obj - an inherited routine, but still in use
			redraws an object updating it's string in
			the process.
			
	This routine does not check if the new string is longer
	than possible.  I'm not certain how to do this, so watch
	out.
*/

void
redraw_obj(int wh, int obj, char *s)
{
	GRECT p;

	win[wh].window_obj[obj].ob_spec.free_string = s;

	objc_offset(win[wh].window_obj, obj, &p.g_x, &p.g_y);
	p.g_w = win[wh].window_obj[obj].ob_width;
	p.g_h = win[wh].window_obj[obj].ob_height;

	do_redraw(win[wh].handle, (GRECT *)&p);
}

void
newredraw_obj(int wh, int obj, char *s)
{
	GRECT p;

#if 0
	This is an older version of the code.  Maybe a bug in it?
	I'm not certain I remmed it out some time ago.

	int extralen,i;

	strcat(s,"\0");

	/* Really need another way to find the length of these lines */
	if (strlen(s) < 43)
	{
		extralen = 43 - (int)strlen(s);

		for (i = 0; i<extralen;i++)
			strcat(s," ");
			
		strcat(s,"\0");
	}
#endif
	strcpy(win[wh].window_obj[obj].ob_spec.free_string,"                                           ");

	strncpy(win[wh].window_obj[obj].ob_spec.free_string,s,min(strlen(s),43));

	objc_offset(win[wh].window_obj, obj, &p.g_x, &p.g_y);
	p.g_w = win[wh].window_obj[obj].ob_width;
	p.g_h = win[wh].window_obj[obj].ob_height;

	do_redraw(win[wh].handle, (GRECT *)&p);
}


/**************************************************************/
/*   my_Fwrite - avoids sending 0 length to Fwrite			  */
/*    			This avoids crashes on TOS 1.0 & 1.2		  */
/**************************************************************/
long 
my_Fwrite(int file_handle, long file_length, void *string)
{
	if (file_length > 0)
		return(Fwrite(file_handle,file_length,string));

	return(0);
}


/*
 * Simple routine for determining correct file selector
 * routine to use
 */
 
int
call_fsel( char *path, char *name, int *button, char *label )
{
	int ret_val;
	
	if (aes_version < 0x0104)
		ret_val = fsel_input(path, name, button);
	else
		ret_val = fsel_exinput(path, name, button, label);
	
	return(ret_val);
}

/* Next 2 from PureC example code */



/* -------------------------------------------------------------------- */
/*                                                  build a file name   */
/*       void build_fname( char *dest, char *s1, char *s2 );            */
/*                                                                      */
/*       Konkatoniere Pfadnamen und Dateinamen.                         */
/*                                                                      */
/*       -> dest                 Zielstring.                            */
/*          s1                   Pfadname.                              */
/*          s2                   Dateiname.                             */
/*                                                                      */
/*       <-                      Ergebnis befindet sich in 'dest'.      */
/* -------------------------------------------------------------------- */

void build_fname( char *dest, char *s1, char *s2 )
{
   char *cptr;

   strcpy( dest, s1 );                 /* Pfad kopieren.                */
   cptr = strrchr( dest, (int) BACKSLASH);
   strcpy( ++cptr, s2);                /* Schlie�lich den Dateinamen    */
}                                      /* dranh�ngen.                   */


