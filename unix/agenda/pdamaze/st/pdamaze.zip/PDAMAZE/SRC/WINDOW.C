/*
 * Window.C
 *  v. 1.1    Dan Ackerman c 2000
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   Electronic contact can be made via the following web address
 *  	http://www.netset.com/~baldrick/stik2.html
 *
 * Simple window management routines
 * this handles the basics of creation and redraw
 * of windows
 */

#include <vdi.h>
#include <tos.h>
#include <aes.h>
#include <stdio.h>

#include "global.h"


/* Close all windows
 *
 * Rewritten so it doesn't look so bad 
 */
 
int
close_all_windows(void)
{
	int i;
	
	for(i=0;i<MAX_WINDOWS;i++)
	{
		if (win[i].handle != NO_WINDOW)
		{
			wind_close(win[i].handle);
			wind_delete(win[i].handle);
			win[i].handle = NO_WINDOW;
		}
	}

	return(1);
}

/*
 * get_wininfo_from_handle
 *
 * retrieves a index for the window array from the handle
 * for a window
 */

int
get_wininfo_from_handle(int w_hand)
{
	int i;
	
	for(i = 0; i < MAX_WINDOWS; i++)
	{
		if (win[i].handle == w_hand)
			return (i);
	}

	return(-1); /* Didn't find the handle in our structures */
}

/*
 * get_topwindow
 *
 * A routine for getting the top window simply for tests 
 */

int
get_topwindow(int window)
{
	int top_window;
	int junk;
	
	wind_get(window,WF_TOP,&top_window,&junk,&junk,&junk);
	
	return(top_window);
}

/*
 * close_window
 *
 * a few common routines for closing out a window
 */

int
close_window(int window)
{
	wind_close(win[window].handle);

	wind_delete(win[window].handle);
	win[window].handle = NO_WINDOW;
	
	return(1);
}

/* -------------------------------------------------------------------- *
 *       boolean rc_intersect( GRECT *r1, GRECT *r2 );                  *
 *                                                                      *
 *       Berechnung der Schnittfl�che zweier Rechtecke.                 *
 *                                                                      *
 *       -> r1, r2               Pointer auf Rechteckstruktur.          *
 *                                                                      *
 *       <-                      == 0  falls sich die Rechtecke nicht   *
 *                                     schneiden,                       *
 *                               != 0  sonst.                           *
 *                                                                      *
 * Originally from some sample code somewhere auf deutsche              *
 * -------------------------------------------------------------------- */

int rc_intersect( GRECT *r1, GRECT *r2 )
{
   int x, y, w, h;

   x = max( r2->g_x, r1->g_x );
   y = max( r2->g_y, r1->g_y );
   w = min( r2->g_x + r2->g_w, r1->g_x + r1->g_w );
   h = min( r2->g_y + r2->g_h, r1->g_y + r1->g_h );

   r2->g_x = x;
   r2->g_y = y;
   r2->g_w = w - x;
   r2->g_h = h - y;

   return ( ((w > x) && (h > y) ) );
}

/*
 * new_window
 *
 * creates a new window with a window object of tree
 * window title of title and window type of type
 *
 * The window type is defined in wins.h
 * it is merely to know what window gadgets a window wants
 */

int	
new_window(OBJECT *tree, const char *title, int type, int w_info)
{
	GRECT p,clip;
	int wh;

	if (tree != (OBJECT *)NULL)
	{
		/* compute required size for window given object tree */

		form_center(tree,ELTR(clip));
	}
	else
	{
		wind_get(0,WF_WORKXYWH,ELTR(p));
	}

	if (type == 0)
	{
		if (tree != (OBJECT *)NULL)
			wind_calc(WC_BORDER, W_TYPE, PTRS((GRECT *)&clip), ELTR(p));
		
		wh = wind_create(W_TYPE, ELTS(p));
	}
	else if (type == 1)
	{
		if (tree != (OBJECT *)NULL)
			wind_calc(WC_BORDER, W_T2, PTRS((GRECT *)&clip), ELTR(p));
	
		wh = wind_create(W_T2, ELTS(p));
	}
	else
	{
	
		wh = wind_create(W_T3, ELTS(p));
	}
			
	if (wh >= 0) 
	{
		wind_set(wh, WF_NAME, title);

		if ((win[w_info].curr.g_x > 0)&&(win[w_info].curr.g_y > 10))
		{
			p.g_x = win[w_info].curr.g_x;
			p.g_y = win[w_info].curr.g_y;
			p.g_w = win[w_info].curr.g_w;
			p.g_h = win[w_info].curr.g_h;
		}
		
		wind_open(wh, ELTS(p));
	}
	return wh;
}


/*
 * do_redraw
 *
 * All the windows in this program are windowed dialogs
 * so this routine can be a bit on the simple side :)
 */

int
do_redraw(int wh, GRECT *p)
{
	GRECT new;
	GRECT rect;
	int w_info;
	int cliparray[8];

	/* Suspend menu */

	wind_update(BEG_UPDATE);

	/* turn off mouse */

	v_hide_c(vdi_handle);

	/* Reset the window objects area */

	wind_get(wh,WF_WORKXYWH,ELTR(new));
	
	w_info = get_wininfo_from_handle(wh);
	
	/* If the window doesn't have an object don't try to
	 * manipulate a NULL
	 */
	 
	if (win[w_info].window_obj != (OBJECT *)NULL)
	{
		/* Don't reset if either width or height == 0 */
	
		if (new.g_w && new.g_h)
		{
			win[w_info].window_obj[ROOT].ob_x = new.g_x;
			win[w_info].window_obj[ROOT].ob_y = new.g_y;
			win[w_info].window_obj[ROOT].ob_width = new.g_w;
			win[w_info].window_obj[ROOT].ob_height = new.g_h;
		}
	}

	/* Get the first rectangle of the windows list */

	wind_get(wh, WF_FIRSTXYWH, ELTR(rect));

	while (rect.g_w && rect.g_h) 
	{
		if (rc_intersect(p, &rect))
		{
			cliparray[0] = rect.g_x;
			cliparray[1] = rect.g_y;
			cliparray[2] = cliparray[0] + rect.g_w - 1;
			cliparray[3] = cliparray[1] + rect.g_h - 1;

			vs_clip(vdi_handle, 1, cliparray);

			Vsync();

			switch(win[w_info].status)
			{
				case 0:
					/* Normal */
					
					if (w_info == GAME_WIN)
					{
						if (odir == dir)
							drawscreen(0);
						else if (((odir + 1) % 4) == dir)
							drawscreen(1);
						else
							drawscreen(-1);
						
						break;
					}

					if (win[w_info].type == 2)
					{
						/* its a text window so first
						 * clear the window
						 */
						 
						clearwin((GRECT *)&rect,0);
/*						
						win[w_info].top = win[w_info].cur_item - win[w_info].cl_cnt;
						
						if (win[w_info].top < 0)
							win[w_info].top = 0;
*/													
/*						sprintf(temp,"total %d cl_cnt %d",total,win[w_info].cl_cnt);
*/
						
/*						wind_info(GAME_WIN,win[w_info].info);
*/
					}
					else
					{
						objc_draw(win[w_info].window_obj,ROOT,MAX_DEPTH, ELTS(rect));

						if((win[w_info].cur_item != -1)&&(win[w_info].edit == 1))
						{
							objc_edit(win[w_info].window_obj,win[w_info].cur_item,0,&win[w_info].edit_pos,ED_INIT);
							win[w_info].edit = 0;
						}
					}
					break;
				case 1:
					/* rolled up */
					objc_draw(win[w_info].window_obj, ROOT, MAX_DEPTH, ELTS(rect));
					break;
						
				case 3:
					/* iconified */
					objc_draw(win[w_info].icon_obj, ROOT, MAX_DEPTH, ELTS(rect));
					break;

			}
			vs_clip(vdi_handle, 0, cliparray);

		}

		wind_get(wh, WF_NEXTXYWH, ELTR(rect));
	}

	/* show mouse */

	v_show_c(vdi_handle, 1);

	wind_update(END_UPDATE);

	return 1;
}

int
resizewindow(int w_info,GRECT *p,char flip)
{
	wind_set(win[w_info].handle,WF_CURRXYWH,PTRS(p));
	
	wind_get(win[w_info].handle,WF_CURRXYWH,ELTR(win[w_info].curr));
	wind_get(win[w_info].handle,WF_WORKXYWH,ELTR(win[w_info].work));

	win[w_info].cl_cnt = ((win[w_info].work.g_h - (2 * win[w_info].point) - 15 - 10)/(win[w_info].point * 2))-1;

	win[w_info].top = win[w_info].cur_item - win[w_info].cl_cnt;
						
	if (win[w_info].top < 0)
		win[w_info].top = 0;

	set_vslide_size(w_info);
	set_vslide_pos(w_info);

	if(flip)
		do_redraw(win[w_info].handle,p);

	return 0;
}

void
clearwin(GRECT *p,int color)
{
	int xy[8];

	xy[6]=xy[0]=p->g_x;
	xy[3]=xy[1]=p->g_y;
	xy[4]=xy[2]=p->g_x+p->g_w-1;
	xy[7]=xy[5]=p->g_y+p->g_h-1;

	vsf_color(vdi_handle,color);
	vswr_mode(vdi_handle,MD_REPLACE);
	v_fillarea(vdi_handle,4,xy);
	return;
}

/*
 * wind_info
 *
 * cheap routine for setting window info line
 */

void
wind_info(int w_info, const char *info)
{
	wind_set(win[w_info].handle, WF_INFO, info);
}

/* set slider position */
void
set_vslide_pos(int w_info)
{
int pos;

	if((win[w_info].cur_item - win[w_info].cl_cnt)<=0)
		pos=0;
	else
	{
/*		pos = 10 * ((win[w_info].top*100)/win[w_info].cur_item);

		pos = 1000 - pos;
*/
		pos = (win[w_info].top * 1000)/(win[w_info].cur_item - win[w_info].cl_cnt);		

		if(pos>1000)
			pos = 1000;
		if(pos<0)
			pos=0;
	}


	wind_set(win[w_info].handle,WF_VSLIDE,pos,0,0,0);
}


/* set slider size */
void
set_vslide_size(int w_info)
{
int size;


	if ((win[w_info].cur_item < win[w_info].cl_cnt)||(!win[w_info].cur_item))
	{
		size = 1000;
	}
	else
	{
/*		if (win[w_info].cur_item == win[w_info].cl_cnt)
*/
			size=(1000*win[w_info].cl_cnt)/win[w_info].cur_item;
/*		else
			size=(1000*win[w_info].cl_cnt)/(win[w_info].cur_item - win[w_info].cl_cnt);
*/		
		if(size > 1000)
			size = 1000;
		if(size < 1)
			size = 1;	
	}
		
	wind_set(win[w_info].handle,WF_VSLSIZE,size,0,0,0);
}


/*
sprintf(temp,"cur item %d  count %d  top %d pos %d",win[w_info].cur_item,win[w_info].cl_cnt,win[w_info].top,pos);
output(w_info, &temp);
*/