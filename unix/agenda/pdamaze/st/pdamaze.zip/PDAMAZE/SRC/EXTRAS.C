/* extras.c (c) Dan Ackerman 1997         baldrick@netset.com
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   Electronic contact can be made via the following web address
 *  	http://www.netset.com/~baldrick/stik2.html
 *
 * Misc. routines for various purposes
 */
 
#include <tos.h>
#include <aes.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "global.h"

/* Following just get's TOS version */

long 
get_tos_version(void)
{
	int i = 0;
	ck_entry *jar = *((ck_entry **) 0x5a0);
    unsigned long *_sysbase = (unsigned long *)0x4F2L;
	unsigned int *tv = (unsigned int *)*_sysbase + 1;

	if (jar != (ck_entry *)0) {
		while (jar[i].cktag) {
			if (!strncmp((char *)&jar[i].cktag, "_MCH", 4)) {
				mch_type = (int)(jar[i].ckvalue >> 16);
				break;
			}
			++i;
		}
	}

	tos_ver = *tv;

	return (0L);
}

/*
 * construct_path - build a GEMDOS path name out of a stem, which
 * optionally has junk on the end which we must delete, and a filename
 * which we are interested in.
*/
 
void
construct_path(char *dest,const char *path,const char *name)
{
	char *s=NULL;		/* used to track the position after final \ or : */

	if (path[0] && path[1]==':')
		s=&dest[2];
	while (*dest++ = *path)
		if (*path++=='\\')
			s=dest;
	if (!s)
		s=dest;
	strcpy(s,name);
}

/*
 * get_fname - gets a file name from a full path
 *
 */
 
void
get_fname(char *dest, char *src)
{
	int i;
    
    for(i=(int)strlen(src);i>=0;--i)
    {                                    
		if(src[i] == 92)
			break;
	}
		 
	strcpy(dest,&src[i + 1]);
}

/*
 * get_fname - gets a file name from a full path
 *
 */
 
void
get_fpath(char *dest, char *src)
{
	int i;
    
    for(i=(int)strlen(src);i>=0;--i)
    {                                    
		if(src[i] == 92)
			break;
	}
		 
	strcpy(dest,src);
	dest[i + 1] = '\0';
}

/*  This identifies what AES you are running under 
 *  based almost entirely on code by Ulf Ronald Anderson
 */
 
int
identify_AES(void)
{	
	void	*old_SSP;
	long	search_id;
	long	*search_p;
	int		MiNT_flag = 0;
	int		retv = AES_single;

/* cookie search is made in Super mode to access any RAM */

	old_SSP = (void *) Super(0L);
	if ((search_p = *_cookies) == NULL)	goto exit_super;

search_loop:
	search_id = *search_p;
	if( search_id == 0L )	goto exit_super; /* search completed */
	if( search_id == 0x4D674D63L  ||  search_id == 0x4D616758L ) retv = AES_MagiC;
	if( search_id == 0x6E414553L ) retv = AES_nAES;
	if( search_id == 0x476E7661L ) retv = AES_Geneva;
	if( search_id == 0x4D694E54L ) MiNT_flag = 1;
	search_p += 2;
	goto	search_loop
;
exit_super:
	Super(old_SSP);

	if
	(	retv == AES_single  &&  MiNT_flag
		&& ( _GemParBlk.global[1] > 1  ||  _GemParBlk.global[1] <0 )
	)
		retv = AES_MTOS;

	return( retv );
}	/* Ends:	int identify_AES(void) */


/* This sends a message to the main loop 
 	I know this could be compressed but I like to have it where I can 
	see exactly what I am passing */
	
int
send_message(int msg0, int msg2, int msg3, int msg4, int msg5, int msg6, int msg7)
{
	int msg[8];

	msg[0] = msg0;
	msg[1] = _GemParBlk.global[2];  /* my apps id */ 
	msg[2] = msg2;
	msg[3] = msg3;   
	msg[4] = msg4;
	msg[5] = msg5;
	msg[6] = msg6;
	msg[7] = msg7;

	appl_write(msg[1], (int)sizeof(msg), msg);

	return(1);
}

/* This sends a message to the main loop */
int
send_extmessage(int extapp, int msg0, int msg2, int msg3, int msg4, int msg5, int msg6, int msg7)
{
	int msg[8];

	msg[0] = msg0;
	msg[1] = _GemParBlk.global[2];  /* my apps id */
	msg[2] = msg2;
	msg[3] = msg3;   
	msg[4] = msg4;
	msg[5] = msg5;
	msg[6] = msg6;
	msg[7] = msg7;

	appl_write(extapp, (int)sizeof(msg), msg);

	return(1);
}