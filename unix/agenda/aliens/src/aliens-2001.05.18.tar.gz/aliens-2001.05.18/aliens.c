/*
  aliens.c

  by Bill Kendrick
  bill@newbreedsoftware.com
  http://www.newbreedsoftware.com/

  March 25, 2001 - May 18, 2001
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/xpm.h>
#include <X11/keysym.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>

#include "images/bug1.xpm"
#include "images/bug2.xpm"
#include "images/bugl.xpm"
#include "images/bugr.xpm"
#include "images/bullet.xpm"
#include "images/controls.xpm"
#include "images/expl1.xpm"
#include "images/expl2.xpm"
#include "images/expl3.xpm"
#include "images/flame1.xpm"
#include "images/flame2.xpm"
#include "images/missile.xpm"
#include "images/ship.xpm"
#include "images/text.xpm"
#include "images/title.xpm"


#define WIDTH 240
#define HEIGHT 160

#define NUM_STARS 20
#define NUM_ALIENS 30
#define NUM_BULLETS 2
#define NUM_MISSILES 8
#define NUM_EXPLOSIONS 6

#define MIN_ALIENS_ALIVE 5  /* If this or fewer, keep diving! */


#define USE_BACKBUFFER
#define DEFAULT_VOLUME 100
#define STARTING_LEVEL 1


#define STATE_FORMAT_VERSION "2001.04.30e"


/* Title screen options: */

enum {
  OPT_BEGIN,
  OPT_RESTART,
  OPT_OPTIONS,
  OPT_HELP,
  OPT_QUIT,
  NUM_OPTIONS
};


/* One up music: */

#define NUM_ONEUP_NOTES 10

int oneup_notes[NUM_ONEUP_NOTES] = {
  880,
  988,
  1046,
  1174, 1174,
  1046, 1046,
  1174, 1174, 1174
};


/* Game modes: */

enum {
  MODE_SWOOPING,
  MODE_MARCHING,
  NUM_GAME_MODES
};

char * mode_txt[NUM_GAME_MODES] = {
  "SWOOPING", "MARCHING"
};


/* Help page text: */

#define NUM_HELP_PAGES 6

char * helptext[NUM_HELP_PAGES][9] = {
  {"ALIENS FOR AGENDA!",
   "------------------",
   "OBJECTIVE:",
   " DESTROY AS MANY",
   " ALIENS AS YOU CAN",
   " BEFORE YOU LOSE",
   " ALL YOUR LIVES.",
   "",
   "     (TAP TO CONT)"},

  {"CONTROLS:",
   " MOVEMENT:",
   "  USE PGUP/PGDN",
   "",
   " FIRING:",
   "  USE LEFT/RIGHT",
   "",
   " PAUSE:",
   "  USE SHIFT"},

 {"GAME VARIATIONS:",
  " MARCHING:",
  "  THEY ARE TRYING",
  "  TO LAND!",
  "  (LIKE 'SPACE",
  "  'INVADERS')",
  "",
  "",
  ""},

 {"GAME VARIATIONS:",
  " SWOOPING:",
  "  FOUGHT IN DEEP",
  "  SPACE!",
  "  (LIKE 'GALAGA')",
  "",
  "",
  "",
  ""},

 {"SCORING:",
  " TOP ROW: 10 PTS",
  " 2ND ROW:  5 PTS",
  " 3RD ROW:  1 PT",
  " DIVING:  25 PTS!",
  "",
  "",
  "",
  ""},

 {"BONUS LIVES AT:",
  "   1,000 PTS",
  "   2,000 PTS",
  "   5,000 PTS",
  "   7,500 PTS",
  "  10,000 PTS",
  "",
  " EVERY 5,000 AFTER",
  ""}
};


/* Alien type: */

typedef struct alien_type {
  int alive, diving, returning;
  int xhome, yhome;
  int x, y, xm, ym;
} alien_type;


/* Bullet type: */

typedef struct bullet_type {
  int alive;
  int x, y, xm;
} bullet_type;


/* Explosion type: */

typedef struct explosion_type {
  int timer;
  int x, y;
} explosion_type;


/* Globals: */

Display * display;
Window rootwin, window;
int black, white;
int star_x[NUM_STARS], star_y[NUM_STARS], star_ym[NUM_STARS];
int ship_x, score, game_mode, level, lives, ship_dying, safe_mode;
alien_type aliens[NUM_ALIENS];
int diving_sfx, oneup_sfx, volume;
char notice_text[45];
int notice_time;
int march_x, march_xm, march_max, march_min;
bullet_type missiles[NUM_MISSILES];
bullet_type bullets[NUM_BULLETS];
explosion_type explosions[NUM_EXPLOSIONS];
int game_pending;
GC whitegc, blackgc;
Pixmap backbuf;
Pixmap pix_bug1, mask_bug1,
       pix_bug2, mask_bug2,
       pix_bugl, mask_bugl,
       pix_bugr, mask_bugr,
       pix_bullet, mask_bullet,
       pix_controls, mask_controls,
       pix_expl1, mask_expl1,
       pix_expl2, mask_expl2,
       pix_expl3, mask_expl3,
       pix_flame1, mask_flame1,
       pix_flame2, mask_flame2,
       pix_missile, mask_missile,
       pix_ship, mask_ship,
       pix_text, mask_text,
       pix_title, mask_title;
GC gc_bug1,
   gc_bug2,
   gc_bugl,
   gc_bugr,
   gc_bullet,
   gc_controls,
   gc_expl1,
   gc_expl2,
   gc_expl3,
   gc_flame1,
   gc_flame2,
   gc_missile,
   gc_ship,
   gc_text,
   gc_title;
XKeyboardState kbstate;


/* Local prototypes: */

int title(void);
void help(void);
void options(void);
void game(int kill_pending);
void drawobject(Pixmap pix, Pixmap mask, GC gc, int x, int y);
void drawcenteredtext(int y, char * text);
void drawtext(int x, int y, char * text);
void drawoption(int opt, char * text, int cur_opt, int opt_ctr);
int setup(void);
void finish(void);
void add_bullet(int x);
void add_missile(int x, int y);
void add_explosion(int x, int y);
void reset_aliens(void);
void set_level(int l);
void add_score(int s);
void kill_ship(void);
void game_over(void);
void play_beep(int pitch, int duration);


/* --- MAIN! --- */

int main(int argc, char * argv[])
{
  int opt, i, found;
  char buf[80], rcfile[1024], statefile[1024];
  FILE * fi;


  game_pending = 0;


  /* Set up: */
  
  if (setup() == -1)
    {
      fprintf(stderr, "Couldn't setup!\n");
      exit(1);
    }


  snprintf(rcfile, sizeof(rcfile), "%s/.aliensrc", getenv("HOME"));
  snprintf(statefile, sizeof(statefile), "%s/.aliens-state", getenv("HOME"));


  /* Load options state from disk: */

  fi = fopen(rcfile, "r");
  if (fi != NULL)
  {
    do
    {
      fgets(buf, sizeof(buf), fi);

      if (!feof(fi))
      {
	buf[strlen(buf) - 1] = '\0';

        if (buf[0] != '#' && buf[0] != '\0')
	{
	  if (strstr(buf, "volume=") == buf)
	    volume = atoi(buf + strlen("volume="));
	  else if (strstr(buf, "gamemode=") == buf)
	  {
	    found = -1;
	    for (i = 0; i < NUM_GAME_MODES && found == -1; i++)
	    {
	      if (strcmp(buf + strlen("gamemode="), mode_txt[i]) == 0)
		found = i;
	    }
	    
	    if (found != -1)
	      game_mode = found;
	    else
	      fprintf(stderr, "%s - Unknown gamemode value: %s\n",
		      rcfile, buf + strlen("gamemode="));
	  }
	  else
	  {
	    fprintf(stderr, "%s - Unknown option: %s\n", rcfile, buf);
	  }
	}
      }
    }
    while (!feof(fi));

    fclose(fi);
  }


  /* Load game state file: */

  fi = fopen(statefile, "r");
  if (fi != NULL)
  {
    /* Skip comment line: */

    fgets(buf, sizeof(buf), fi);


    /* Grab statefile version: */

    fgets(buf, sizeof(buf), fi);
    buf[strlen(buf) - 1] = '\0';

    if (strcmp(buf, STATE_FORMAT_VERSION) != 0)
    {
      fprintf(stderr, "Aliens state format file has been updated.\n"
		      "Old game state is unreadable.  Sorry!\n");
    }
    else
    {
      game_pending = fgetc(fi);
      lives = fgetc(fi);
      level = fgetc(fi);
      diving_sfx = fgetc(fi);
      oneup_sfx = fgetc(fi);
      ship_dying = fgetc(fi);
      safe_mode = fgetc(fi);
      fread(&score, sizeof(int), 1, fi);
      fread(&ship_x, sizeof(int), 1, fi);
      fread(&march_x, sizeof(int),1, fi);
      fread(&march_xm, sizeof(int), 1, fi);
      fread(&march_min, sizeof(int), 1, fi);
      fread(&march_max, sizeof(int), 1, fi);
      fread(aliens, sizeof(alien_type), NUM_ALIENS, fi);
      fread(bullets, sizeof(bullet_type), NUM_BULLETS, fi);
      fread(missiles, sizeof(bullet_type), NUM_MISSILES, fi);
      fread(explosions, sizeof(explosion_type), NUM_EXPLOSIONS, fi);
    }


    fclose(fi);
  }
  
  
  /* --- Main Loop: --- */

  opt = 0;
  
  do
    {
      opt = title();

      if (opt != OPT_QUIT)
      {
	if (opt == OPT_BEGIN)
          game(0);
	else if (opt == OPT_RESTART)
	  game(1);
	else if (opt == OPT_OPTIONS)
	  options();
	else if (opt == OPT_HELP)
          help();
      }
    }
  while (opt != OPT_QUIT);


  /* Write game options back to disk: */

  fi = fopen(rcfile, "w");
  if (fi == NULL)
    perror(rcfile);
  else
  {
    fprintf(fi, "# .aliensrc - Options file for \"Aliens\" game\n"
		"# Automatically generated!\n\n");

    fprintf(fi, "volume=%d\n", volume);
    fprintf(fi, "gamemode=%s\n", mode_txt[game_mode]);

    fclose(fi);
  }


  /* Write game state to disk: */

  fi = fopen(statefile, "w");
  if (fi == NULL)
    perror(statefile);
  else
  {
    fprintf(fi, "Aliens State File\n");
    fprintf(fi, "%s\n", STATE_FORMAT_VERSION);

    fputc(game_pending, fi);
    fputc(lives, fi);
    fputc(level, fi);
    fputc(diving_sfx, fi);
    fputc(oneup_sfx, fi);
    fputc(ship_dying, fi);
    fputc(safe_mode, fi);
    fwrite(&score, sizeof(int),1, fi);
    fwrite(&ship_x, sizeof(int), 1, fi);
    fwrite(&march_x, sizeof(int),1, fi);
    fwrite(&march_xm, sizeof(int), 1, fi);
    fwrite(&march_min, sizeof(int), 1, fi);
    fwrite(&march_max, sizeof(int), 1, fi);
    fwrite(aliens, sizeof(alien_type), NUM_ALIENS, fi);
    fwrite(bullets, sizeof(bullet_type), NUM_BULLETS, fi);
    fwrite(missiles, sizeof(bullet_type), NUM_MISSILES, fi);
    fwrite(explosions, sizeof(explosion_type), NUM_EXPLOSIONS, fi);

    fclose(fi);
  }
  
  
 
  /* Shut down: */

  finish();

  return(0);
}


/* --- HELP SCREEN FUNCTION! --- */

void help(void)
{
  XEvent event;
  KeySym key;
  int zoom, done, page, redrawtext, i;


  /* Zoom-in effect: */
  
  for (zoom = 0; zoom <= (WIDTH / 2); zoom = zoom + 5)
  {
    XSetClipOrigin(display, gc_controls, zoom * 2, zoom * 2);
    XCopyArea(display, pix_controls, window, gc_controls,
              (HEIGHT / 2) - zoom, (WIDTH / 2) - zoom, zoom * 2, zoom * 2,
              (HEIGHT / 2) - zoom, (WIDTH / 2) - zoom);
    XFlush(display);
    usleep(50);
  }

  
  done = 0;
  page = 0;
  redrawtext = 1;

  do
  {
    if (redrawtext)
    {
      /* Wipe screen: */
	    
      XSetClipOrigin(display, gc_controls, 0, 0);
      XCopyArea(display, pix_controls, backbuf, gc_controls,
		0, 0, HEIGHT, WIDTH, 0, 0);
      
      
      /* Draw text: */
      
      for (i = 0; i < 9; i++)
	drawtext(45, 35 + (i * 9), helptext[page][i]);


      /* Flip screen: */

      XCopyArea(display, backbuf, window, whitegc, 0, 0, HEIGHT, WIDTH, 0, 0);
      XFlush(display);


      redrawtext = 0;
    }
    
    XNextEvent(display, &event);

    if (event.type == ButtonPress)
      {
	if (event.xbutton.x >= HEIGHT - 17 &&
	    event.xbutton.y >= WIDTH - 17)
	  done = 1;
	else if (page < NUM_HELP_PAGES - 1)
	  {
	    page++;
	    redrawtext = 1;
	  }
      }
    else if (event.type == KeyPress)
      {
        key = XLookupKeysym((XKeyEvent *)&event, 0);
	
	if (key == XK_Page_Down && page < NUM_HELP_PAGES - 1)
	  {
	    page++;
	    redrawtext = 1;
	  }
	else if (key == XK_Page_Up && page > 0)
	  {
	    page--;
	    redrawtext = 1;
	  }
	else if (key == XK_Left || key == XK_Right)
	  done = 1;
      }
  }
  while (!done);
}


/* --- OPTIONS SCREEN FUNCTION! --- */

void options(void)
{
  int done, counter, option, do_option;
  char txt[45];
  XEvent event;
  KeySym key;

  done = 0;

  counter = 0;
  option = 0;
  do_option = 0;
  
  do
  {
    /* Handle counters: */
    
    counter++;


    /* Erase everything! */

    XFillRectangle(display, backbuf, blackgc, 0, 0, 160, 240);


    /* Draw options: */
    
    sprintf(txt, "VOLUME        - %3d", volume);
    drawtext(40, 32, txt);
    
    sprintf(txt, "GAME MODE     - %s", mode_txt[game_mode]);
    drawtext(40, 48, txt);
    drawtext(40, 64, "RETURN TO TITLE");

    if (game_pending && option == 1 && (counter % 15) < 10)
      drawcenteredtext(HEIGHT - 16,
		       "GAME MODE CHANGE WILL ABORT CURRENT GAME");
    
    
    /* Draw alien: */
   
    if ((counter % 10) < 5)
    {
      drawobject(pix_bug1, mask_bug1, gc_bug1, 16, 22 + (option * 16));
    }
    else
    {
      drawobject(pix_bug2, mask_bug2, gc_bug2, 16, 22 + (option * 16));
    }

    
    /* Check for events: */
    
    while (XPending(display))
    {
      XNextEvent(display, &event);

      if (event.type == KeyPress)
      {
        key = XLookupKeysym((XKeyEvent *)&event, 0);

	if (key == XK_Right)
	{
	  /* Select previous option: */
		
	  if (option > 0)
	  {
	    option--;

	    play_beep(1000, 15);
	  }
	}
	else if (key == XK_Left)
	{
	  /* Select next option: */
	
	  if (option < 2)
	  {
	    option++;

            play_beep(1000, 15);
	  }
	}
	else if (key == XK_Shift_L || key == XK_Shift_R ||
		 key == XK_Page_Up || key == XK_Page_Down)
	{
	  /* SHIFT to confirm */
	  
	  do_option = 1;
	}
      }
      else if (event.type == ButtonPress)
      {
        /* Tapping accepts, too */

	if (event.xbutton.x <= HEIGHT - 32 &&
	    event.xbutton.x >= HEIGHT - (32 + (3 * 16)))
	{
	  option = ((HEIGHT - 32) - event.xbutton.x) / 16;
	  do_option = 1;
	}
      }
    }
    
    
    /* Change setting? */
    
    if (do_option)
      {
	do_option = 0;
	
	if (option == 0)
	  {
	    volume = 100 - volume;
	  }
	else if (option == 1)
	  {
	    game_mode++;
	    if (game_mode >= NUM_GAME_MODES)
	      game_mode = 0;

	    game_pending = 0;
	  }
	else if (option == 2)
	  done = 1;
      }


    /* Swap backbuffer onto window! */

#ifdef USE_BACKBUFFER
    XCopyArea(display, backbuf, window, whitegc, 0, 0, HEIGHT, WIDTH, 0, 0);
#endif
    
    
    /* Pause a moment... */

    usleep(100);
    XSync(display, 0);
  }
  while (done == 0);
}


/* --- TITLE SCREEN FUNCTION! --- */

int title(void)
{
  int done, i, title_height, winx, counter, option, old_option, opt_counter;
  XEvent event;
  KeySym key;

  done = 0;

  counter = 0;
  title_height = 0;
  option = 0;
  old_option = 0;
  opt_counter = 10;

  do
  {
    /* Handle counters: */
	  
    counter++;

    if (opt_counter > 0)
      opt_counter--;


    /* Erase everything! */

    XFillRectangle(display, backbuf, blackgc, 0, 0, 160, 240);


    /* Draw starfield: */
	  
    for (i = 0; i < NUM_STARS; i++)
    {
      star_y[i] = star_y[i] + star_ym[i];

      if (star_y[i] >= HEIGHT)
      {
        star_y[i] = 0;
	star_ym[i] = (rand() % 5) + 1;
	star_x[i] = rand() % WIDTH;
      }

      XDrawLine(display, backbuf, whitegc,
                159 - star_y[i], star_x[i],
                159 - (star_y[i] + 5), star_x[i]);
    }


    /* Draw title: */

    winx = 160 - title_height;
    XSetClipOrigin(display, gc_title, winx, 15);
    XCopyArea(display, pix_title, backbuf, gc_title,
	      55 - title_height, 0,
	      title_height, 209,
	      winx, 15);

    title_height++;
    if (title_height > 55)
      title_height = 55;



    /* Draw credits: */

    if (title_height == 55)
    {
      drawcenteredtext(60, "BY BILL KENDRICK");
      drawcenteredtext(70, "NEW BREED SOFTWARE 2001");
    }


    /* Draw options: */

    if (game_pending)
    {
      drawoption(OPT_BEGIN, "CONTINUE", option, opt_counter);
      drawoption(OPT_RESTART, "START OVER", option, opt_counter);
    }
    else
      drawoption(OPT_BEGIN, "BEGIN", option, opt_counter);
    
    drawoption(OPT_OPTIONS, "OPTIONS", option, opt_counter);
    drawoption(OPT_HELP, "HELP", option, opt_counter);
    drawoption(OPT_QUIT, "QUIT", option, opt_counter);


    /* Draw alien: */
   
    if ((counter % 10) < 5)
    {
      drawobject(pix_bug1, mask_bug1, gc_bug1, 16, 82 + (option * 16));
    }
    else
    {
      drawobject(pix_bug2, mask_bug2, gc_bug2, 16, 82 + (option * 16));
    }

    
    /* Check for events: */
    
    while (XPending(display))
    {
      XNextEvent(display, &event);

      if (event.type == KeyPress)
      {
        key = XLookupKeysym((XKeyEvent *)&event, 0);

	if (key == XK_Right)
	{
	  /* Select previous option: */
		
	  if (option > 0)
	  {
	    option--;

	    play_beep(1000, 15);

	    if (option == OPT_RESTART && !game_pending)
	      option--;

	    opt_counter = 10;
	  }
	}
	else if (key == XK_Left)
	{
	  /* Select next option: */
	
	  if (option < NUM_OPTIONS - 1)
	  {
	    option++;

            play_beep(1000, 15);

	    if (option == OPT_RESTART && !game_pending)
	      option++;

	    opt_counter = 10;
	  }
	}
	else if (key == XK_Shift_L || key == XK_Shift_R ||
		 key == XK_Page_Up || key == XK_Page_Down)
	{
	  /* SHIFT to confirm */
		
	  done = 1;
	}
      }
      else if (event.type == ButtonPress)
      {
        /* Tapping accepts, too */

	if (event.xbutton.x <= HEIGHT - 85 &&
	    event.xbutton.x >= HEIGHT - (85 + (NUM_OPTIONS * 16)))
	{
          old_option = option;
	  option = ((HEIGHT - 85) - event.xbutton.x) / 16;


	  /* Don't allow "RESTART" to be tapped if it isn't there! */

	  if (option != OPT_RESTART || game_pending)
	  {
	    done = 1;
	  }
	  else
	  {
            option = old_option;
	  }
	}
      }
    }


    /* Swap backbuffer onto window! */

#ifdef USE_BACKBUFFER
    XCopyArea(display, backbuf, window, whitegc, 0, 0, HEIGHT, WIDTH, 0, 0);
#endif


    /* Pause a moment... */

    usleep(100);
    XSync(display, 0);
  }
  while (done == 0);

  return option;
}


/* --- GAME FUNCTION! --- */

void game(int kill_pending)
{
  int done, counter, down_left, down_right, i, j, rnd,
    num_aliens_alive, last_num_aliens_alive;
  struct timeval now, then;
  long time_padding;
  char str[41];
  KeySym key;
  XEvent event;


  long num_frames, total_time;


  
  
  /* Initialize game: */
  
  if (kill_pending == 1 || game_pending == 0)
    {
      diving_sfx = 0;
      oneup_sfx = 0;
      ship_x = (WIDTH - 16) / 2;
      ship_dying = 0;
      safe_mode = 20;
      score = 0;
      set_level(STARTING_LEVEL);
      reset_aliens();
      lives = 3;
      game_pending = 1;

      for (i = 0; i < NUM_BULLETS; i++)
      {
        bullets[i].alive = 0;
      }

      for (i = 0; i < NUM_MISSILES; i++)
      {
        missiles[i].alive = 0;
      }

      for (i = 0; i < NUM_EXPLOSIONS; i++)
      {
	explosions[i].timer = 0;
      }
    }



  num_frames = 0;
  total_time = 0;
  
  
  /* --- MAIN GAME LOOP!!! --- */
  
  counter = 0;
  down_left = 0;
  down_right = 0;
  done = 0;
  num_aliens_alive = NUM_ALIENS;

  do
    {
      gettimeofday(&then, NULL);

      counter++;


      /* Erase everything! */
      
      XFillRectangle(display, backbuf, blackgc, 0, 0, 160, 240);
      
      
      /* Draw starfield: */
     
      for (i = 0; i < NUM_STARS; i++)
      {
	if (game_mode == MODE_SWOOPING)
	{
	  /* Move stars: */
		
	  star_y[i] = star_y[i] + star_ym[i];
	  
	  if (star_y[i] >= HEIGHT)
	    {
	      star_y[i] = 0;
	      star_ym[i] = (rand() % 5) + 1;
	      star_x[i] = rand() % WIDTH;
	    }
	}
	  
	XDrawLine(display, backbuf, whitegc,
	          159 - star_y[i], star_x[i],
	          159 - (star_y[i] + 1), star_x[i]);
      }

      
      /* Deal with events: */
      
      while (XPending(display))
	{
	  XNextEvent(display, &event);
	  
	  if (event.type == KeyPress)
	    {
	      key = XLookupKeysym((XKeyEvent *)&event, 0);
	      
	      if (key == XK_Page_Up || key == XK_Up)
		{
		  /* Move ship left */
		  
		  down_left = 1;
		  down_right = 0;
		}
	      else if (key == XK_Page_Down || key == XK_Down)
		{
		  /* Move ship right */
		  
		  down_left = 0;
		  down_right = 1;
		}
	      else if ((key == XK_Right || key == XK_Left ||
		       key == XK_space) && ship_dying == 0)
		{
	          /* Fire! */
		
		  add_bullet(ship_x);
		}
	      else if (key == XK_Escape ||
		       key == XK_Shift_L || key == XK_Shift_R)
		{
		  done = 1;
		}
	    }
	  else if (event.type == KeyRelease)
	    {
	      /* Handle left/right releases: */
	      
	      key = XLookupKeysym((XKeyEvent *)&event, 0);

	      if (key == XK_Page_Up || key == XK_Up)
		down_left = 0;
	      else if (key == XK_Page_Down || key == XK_Down)
		down_right = 0;
	    }
	}


      /* Handle explosions: */

      for (i = 0; i < NUM_EXPLOSIONS; i++)
      {
	if (explosions[i].timer > 0)
	  explosions[i].timer--;
      }


      /* Move bullets: */

      for (i = 0; i < NUM_BULLETS; i++)
      {
        if (bullets[i].alive)
	{
	  bullets[i].y = bullets[i].y - 8;

	  if (bullets[i].y <= 0)
	    bullets[i].alive = 0;
	}
      }


      /* Move missiles: */

      for (i = 0; i < NUM_MISSILES; i++)
      {
        if (missiles[i].alive)
	{
	  missiles[i].y = missiles[i].y + 4;

	  if (missiles[i].y > HEIGHT)
	    missiles[i].alive = 0;


	  if (missiles[i].y >= HEIGHT - 48 &&
	      missiles[i].y <= HEIGHT - 16 &&
	      missiles[i].x >= ship_x - 16 &&
	      missiles[i].x <= ship_x + 16 &&
	      ship_dying == 0 && safe_mode == 0)
	  {
	    missiles[i].alive = 0;
	    kill_ship();
	  }
	}
      }


      /* Move aliens: */

      last_num_aliens_alive = num_aliens_alive;
      num_aliens_alive = 0;

      for (i = 0; i < NUM_ALIENS; i++)
      {
        if (aliens[i].alive)
	{
	  num_aliens_alive++;


	  /* Control aliens: */

	  if (aliens[i].diving)
	  {
	    /* Diving! */
		  
            aliens[i].x = aliens[i].x + aliens[i].xm;
	    aliens[i].y = aliens[i].y + aliens[i].ym;


	    /* Increment downward speed: */
	    
	    if (aliens[i].ym < 3 && (counter % 3) == 0)
	      aliens[i].ym++;

	    
	    /* See if alien flew off the screen: */
	    
	    if (aliens[i].y >= HEIGHT ||
	        aliens[i].x < -16 ||
		aliens[i].x > WIDTH)
	    {
	      /* If alien flew off screen, return home: */

	      aliens[i].x = aliens[i].xhome;
	      aliens[i].y = 0;

	      if (last_num_aliens_alive >= MIN_ALIENS_ALIVE || ship_dying > 0)
	      {
		/* Don't return home if you're just going to dive again: */

	        aliens[i].returning = 1;
	        aliens[i].diving = 0;
	      }
	    }


	    /* Home in on player (only while in upper half of screen): */

	    if (aliens[i].y < HEIGHT / 2)
	    {
	      if (aliens[i].x < ship_x && aliens[i].xm < 4)
		aliens[i].xm++;
	      else if (aliens[i].x > ship_x && aliens[i].xm > -4)
		aliens[i].xm--;
	    }
	  }
	  else if (aliens[i].returning)
	  {
	    /* Return home: */
		  
            aliens[i].y++;

	    if (aliens[i].y >= aliens[i].yhome)
	    {
              aliens[i].y = aliens[i].yhome;
	      aliens[i].returning = 0;
	    }
	  }
	  else
	  {
	    /* Make alien dive occasionally: */

            if (game_mode == MODE_SWOOPING)
	    {
              if (((rand() % (1000 / level)) == 0 ||
	  	  (last_num_aliens_alive < MIN_ALIENS_ALIVE &&
		   (rand() % 10) == 0)) &&
	          ship_dying == 0)
	      {
	        aliens[i].diving = 1;
	        aliens[i].xm = 0;
	        aliens[i].ym = -3;

	        diving_sfx = 20;
	      }
	    }
	  }


	  /* Make alien shoot occasionally: */

	  if ((rand() % (1000 - (900 * aliens[i].diving))) == 0 &&
	      ship_dying == 0)
	  {
            add_missile(aliens[i].x, aliens[i].y);
	  }


	  /* Make alien march back and forth: */

	  if (!aliens[i].diving)
	  {
            aliens[i].x = aliens[i].xhome + march_x;
	  }


	  /* See if alien was hit by a bullet: */
	  
	  for (j = 0; j < NUM_BULLETS; j++)
	  {
	    if (bullets[j].alive &&
		bullets[j].x >= aliens[i].x - 8 &&
		bullets[j].x <= aliens[i].x + 8 &&
		bullets[j].y >= aliens[i].y - 16 &&
		bullets[j].y <= aliens[i].y + 16)
	    {
	      bullets[j].alive = 0;
	      aliens[i].alive = 0;
	      add_explosion(aliens[i].x, aliens[i].y);

	      play_beep(200, 10);

	      if (aliens[i].diving)
		add_score(25);
	      else
	      {
		if (i < 10)
	          add_score(10);
		else if (i < 20)
	          add_score(5);
		else
	          add_score(1);
	      }
	    }
	  }


	  /* See if alien crashed into player: */

	  if (ship_dying == 0 && safe_mode == 0 &&
	      aliens[i].x >= ship_x - 16 &&
	      aliens[i].x <= ship_x + 16 &&
	      aliens[i].y >= HEIGHT - 48 &&
	      aliens[i].y <= HEIGHT - 16)
	  {
	    aliens[i].alive = 0;
	    kill_ship();
	  } 
	}
      }


      /* Decide maximum and minimum marching positions: */

      march_min = -WIDTH;
      march_max = WIDTH;

      for (i = 0; i < NUM_ALIENS; i++)
      {
        if (aliens[i].alive)
	{
          if (aliens[i].xhome + march_min < 0)
            march_min = -aliens[i].xhome;

	  if (aliens[i].xhome + march_max > WIDTH - 16)
	    march_max = WIDTH - aliens[i].xhome - 16;
	}
      }


      /* Handle marching of aliens: */

      if ((game_mode == MODE_SWOOPING && (counter % 2) == 0) ||
          (game_mode == MODE_MARCHING && ship_dying == 0 &&
	   (counter % (num_aliens_alive + 1)) == 0))
      {
        march_x = march_x + march_xm;

  	if (march_x < march_min || march_x > march_max)
	{
	  if (march_x < march_min)
            march_x = march_min;
	  else if (march_x > march_max)
            march_x = march_max;

  	  march_xm = -march_xm;

	  if (game_mode == MODE_MARCHING)
	  {
	    /* In marching mode, aliens move down when they reach the sides: */ 

            for (i = 0; i < NUM_ALIENS; i++)
	    {
              aliens[i].yhome = aliens[i].yhome + 10;
	      aliens[i].y = aliens[i].y + 10;

	      if (aliens[i].alive && aliens[i].y >= HEIGHT - 32)
	      {
		kill_ship();
		lives = 0;
	        game_over();
	      }
	    }
	  }
	}
      }


      /* Move to next level? */

      if (num_aliens_alive == 0)
      {
	set_level(level + 1);

	reset_aliens();
      }


      /* Draw explosions: */

      for (i = 0; i < NUM_EXPLOSIONS; i++)
      {
	if (explosions[i].timer > 3)
	{
          drawobject(pix_expl1, mask_expl1, gc_expl1,
	             explosions[i].x, explosions[i].y);
	}
	else if (explosions[i].timer > 1)
	{
	  drawobject(pix_expl2, mask_expl2, gc_expl2,
                     explosions[i].x, explosions[i].y);
	
	}
	else if (explosions[i].timer > 0)
	{
	  drawobject(pix_expl3, mask_expl3, gc_expl3,
	             explosions[i].x, explosions[i].y);
	}
      }


      /* Draw bullets: */

      for (i = 0; i < NUM_BULLETS; i++)
      {
        if (bullets[i].alive)
	{
	  drawobject(pix_bullet, mask_bullet, gc_bullet,
		     bullets[i].x, bullets[i].y);
	}
      }


      /* Draw aliens: */

      for (i = 0; i < NUM_ALIENS; i++)
      {
	if (aliens[i].alive)
	{
	  if (aliens[i].diving == 0)
	  {
	    if ((counter % 10) < 5)
	      drawobject(pix_bug1, mask_bug1, gc_bug1,
			 aliens[i].x, aliens[i].y);
	    else
	      drawobject(pix_bug2, mask_bug2, gc_bug2,
			 aliens[i].x, aliens[i].y);  
	  }
	  else
	  {
            if (aliens[i].xm > 1)
	      drawobject(pix_bugl, mask_bugl, gc_bugl,
	                 aliens[i].x, aliens[i].y);
	    else if (aliens[i].xm < -1)
              drawobject(pix_bugr, mask_bugr, gc_bugr,
	                 aliens[i].x, aliens[i].y);
	    else
	      drawobject(pix_bug2, mask_bug2, gc_bug2,
			 aliens[i].x, aliens[i].y);
	  }
	}
      }


      /* Draw missiles: */

      for (i = 0; i < NUM_MISSILES; i++)
      {
        if (missiles[i].alive)
        {
          drawobject(pix_missile, mask_missile, gc_missile,
                     missiles[i].x, missiles[i].y);
        }
      }
      
      
      /* Draw ship: */
     
      if (ship_dying == 0)
      {
	/* Ship: */
	
	if (safe_mode == 0 || (safe_mode % 4) < 2)
          drawobject(pix_ship, mask_ship, gc_ship, ship_x, HEIGHT - 32);
      } 
     
      if (game_mode == MODE_SWOOPING)
	{
	  if (ship_dying == 0)
	    {		
	      /* Flame: */
	      
	      if ((counter % 16) < 8)
		drawobject(pix_flame1, mask_flame1, gc_flame1, ship_x,
			   HEIGHT - 16);
	      else
		drawobject(pix_flame2, mask_flame2, gc_flame2, ship_x,
			   HEIGHT - 16);
	    }
	}
      else
	{
	  /* Ground: */
	  
	  XFillRectangle(display, backbuf, whitegc, 0, 0, 16, 240);
	}


      if (safe_mode != 0)
      {
	/* Count down the safe mode */

	safe_mode--;
      }
      
	  
      if (ship_dying != 0)
      {
	/* Draw explosion where ship was! */

	ship_dying--;

	rnd = (rand() % 3);

	if (rnd == 0)
	{
	  drawobject(pix_expl1, mask_expl1, gc_expl1,
		     ship_x - 8 + (rand() % 16),
		     HEIGHT - 40 + (rand() % 16));
	}
	else if (rnd == 1)
	{
	  drawobject(pix_expl2, mask_expl2, gc_expl2,
		     ship_x - 8 + (rand() % 16),
		     HEIGHT - 40 + (rand() % 16));
	}
	else if (rnd == 2)
	{
	  drawobject(pix_expl3, mask_expl3, gc_expl3,
		     ship_x - 8 + (rand() % 16),
		     HEIGHT - 40 + (rand() % 16));
	}


	/* Done exploding? */
	
	if (ship_dying == 0)
        {
          ship_x = (WIDTH - 16) / 2;
	  
	  /* No more lives?  Back to title screen! */
	  
	  if (lives == 0)
	  {
            game_pending = 0;
	    done = 1;
	  }

	  safe_mode = 20;
	}
      }


      /* Draw score, level and lives: */

      sprintf(str, "SCORE: %7d    LEVEL: %2d    LIVES: %2d",
	      score, level, lives);
      drawtext(0, 0, str);
      
      
      /* Move ship: */
     
      if (ship_dying == 0)
      { 
        if (down_left && ship_x > 0)
	  ship_x = ship_x - 4;
        else if (down_right && ship_x < WIDTH - 16)
  	  ship_x = ship_x + 4;
      }


      /* Draw notice: */

      if (notice_time > 0)
      {
	notice_time--;

	drawcenteredtext((HEIGHT - 10) / 2, notice_text);
      }
      
      
      /* Swap backbuffer onto window! */
     
#ifdef USE_BACKBUFFER
      XCopyArea(display, backbuf, window, whitegc, 0, 0, HEIGHT, WIDTH, 0, 0);
#endif


      /* Play sound effects: */

      if (oneup_sfx > 0)
      {
	if ((oneup_sfx % 10) == 0)
	  play_beep(oneup_notes[NUM_ONEUP_NOTES - (oneup_sfx / 10)], 15);

	oneup_sfx--;
      }
      else if (ship_dying > 0)
      {
	play_beep(100 + (rand() % 200), 15);
      }
      else if (diving_sfx > 0)
      {
	diving_sfx--;

	play_beep(1000 + (diving_sfx * 100), 15);
      }
      
      
      /* Pause a moment... */
    
      XSync(display, 0);

      gettimeofday(&now, NULL);

      time_padding = 30000 - ((now.tv_sec - then.tv_sec) * 1000000 +
		              (now.tv_usec - then.tv_usec));
      if (time_padding > 0)
      {
	total_time = total_time + time_padding;

	usleep(time_padding);
      }

      num_frames++;
    }
  while (!done);

#ifdef DEBUG
  printf("total_time = %ld\n", total_time);
  printf("num_frames = %ld\n", num_frames);
  printf("average:     %ld\n", total_time / num_frames);
#endif
}


/* Draw a sprite on the screen: */

void drawobject(Pixmap pix, Pixmap mask, GC gc, int x, int y)
{
  int winx, winy;

  winx = 160 - y - 16;
  winy = x;
  
  XSetClipOrigin(display, gc, winx, winy);
  XCopyArea(display, pix, backbuf, gc, 0, 0, 16, 16, winx, winy);
}


/* Draw horizontally-centered text on the screen: */

void drawcenteredtext(int y, char * text)
{
  drawtext((WIDTH - (strlen(text) * 6)) / 2, y, text);
}


/* Draw text on the screen: */

void drawtext(int x, int y, char * text)
{
  int i, winx, winy;

  winx = HEIGHT - 9 - y;
  winy = x;

  for (i = 0; i < strlen(text); i++)
  {
    if (text[i] >= '!' && text[i] <= 'Z')
    {
      XSetClipOrigin(display, gc_text, winx, winy);
      XCopyArea(display, pix_text, backbuf, gc_text,
  	        0, (text[i] - '!') * 6, 9, 6, winx, winy);
    }

    winy = winy + 6;
  }
}


/* Draw one of the title screen options on the screen
   (animated, if necessary): */

void drawoption(int opt, char * text, int cur_opt, int opt_ctr)
{
  char str[2];
  int i;

  if (opt != cur_opt || opt_ctr == 0)
  {
    drawtext(40, 88 + (16 * opt), text);
  }
  else
  {
    for (i = 0; i < strlen(text); i++)
    {
      str[0] = text[i];
      str[1] = '\0';
    
      drawtext(40 + (i * (6 + opt_ctr)), 88 + (16 * opt), str);
    }
  }
}


/* Connect to X server, open window, ready images, etc.: */

int setup(void)
{
  XSetWindowAttributes attr;
  unsigned long attr_mask;
  int screen, i;
  XGCValues xgcvalues;
  XEvent event;


  /* Connect to display: */
  
  display = XOpenDisplay(":0");
  if (display == NULL)
    return(-1);

  screen = DefaultScreen(display);
  rootwin = RootWindow(display, screen);


  /* Get primary colors: */

  black = BlackPixel(display, screen);
  white = WhitePixel(display, screen);


  /* Get keyboard state (so we can put beep values back!) */

  XGetKeyboardControl(display, &kbstate);
  volume = DEFAULT_VOLUME;
  game_mode = 0;


  /* Open a window: */

  attr.event_mask = KeyPressMask | KeyReleaseMask | ButtonPressMask;
  attr.background_pixel = black;
  attr_mask = CWEventMask | CWBackPixel;

  window = XCreateWindow(display, rootwin, 0, 0, 160, 240, 0,
                         CopyFromParent, InputOutput, CopyFromParent,
			 attr_mask, &attr);


  XStoreName(display, window, "Aliens");


#ifdef USE_BACKBUFFER
  backbuf = XCreatePixmap(display, window, HEIGHT, WIDTH,
  		       DefaultDepthOfScreen(DefaultScreenOfDisplay(display)));
#else
  backbuf = window;
#endif


  XMapWindow(display, window);
  XMapRaised(display, window);


  /* Create graphics contexts: */

  xgcvalues.foreground = white;
  xgcvalues.background = black;
  whitegc = XCreateGC(display, window, GCForeground | GCBackground,
		      &xgcvalues);

  xgcvalues.foreground = black;
  xgcvalues.background = white;
  blackgc = XCreateGC(display, window, GCForeground | GCBackground,
		      &xgcvalues);
  
  
  /* Create images: */

  /* (Text) */
  
  XpmCreatePixmapFromData(display, window,
                          text_xpm, &pix_text, &mask_text, NULL);
  xgcvalues.foreground = white;
  xgcvalues.background = black;
  xgcvalues.graphics_exposures = False;
  gc_text = XCreateGC(display, window,
                      GCForeground | GCBackground | GCGraphicsExposures,
	              &xgcvalues);
  XSetClipMask(display, gc_text, mask_text);


  XSync(display, 0);
  XFillRectangle(display, backbuf, blackgc, 0, 0, 160, 240);
  drawcenteredtext((HEIGHT - 32) / 2, "LOADING");
  drawcenteredtext((HEIGHT - 16) / 2, "ALIENS");
  drawcenteredtext(HEIGHT - 16, "HTTP://WWW.NEWBREEDSOFTWARE.COM/ALIENS/");
  XCopyArea(display, backbuf, window, whitegc, 0, 0, HEIGHT, WIDTH, 0, 0);
  XFlush(display);


  /* (Bug1) */
  
  XpmCreatePixmapFromData(display, window,
 	  		  bug1_xpm, &pix_bug1, &mask_bug1, NULL);
  xgcvalues.foreground = white;
  xgcvalues.background = black;
  gc_bug1 = XCreateGC(display, window, GCForeground | GCBackground,
		      &xgcvalues);
  XSetClipMask(display, gc_bug1, mask_bug1);


  
  /* (Bug2) */
  
  XpmCreatePixmapFromData(display, window,
 	  		  bug2_xpm, &pix_bug2, &mask_bug2, NULL);
  xgcvalues.foreground = white;
  xgcvalues.background = black;
  gc_bug2 = XCreateGC(display, window, GCForeground | GCBackground,
		      &xgcvalues);
  XSetClipMask(display, gc_bug2, mask_bug2);


  
  /* (BugL) */
  
  XpmCreatePixmapFromData(display, window,
 	  		  bugl_xpm, &pix_bugl, &mask_bugl, NULL);
  xgcvalues.foreground = white;
  xgcvalues.background = black;
  gc_bugl = XCreateGC(display, window, GCForeground | GCBackground,
		      &xgcvalues);
  XSetClipMask(display, gc_bugl, mask_bugl);


  
  /* (BugR) */
  
  XpmCreatePixmapFromData(display, window,
 	  		  bugr_xpm, &pix_bugr, &mask_bugr, NULL);
  xgcvalues.foreground = white;
  xgcvalues.background = black;
  gc_bugr = XCreateGC(display, window, GCForeground | GCBackground,
		      &xgcvalues);
  XSetClipMask(display, gc_bugr, mask_bugr);


  
  /* (Bullet) */
  
  XpmCreatePixmapFromData(display, window,
 	  		  bullet_xpm, &pix_bullet, &mask_bullet, NULL);
  xgcvalues.foreground = white;
  xgcvalues.background = black;
  gc_bullet = XCreateGC(display, window, GCForeground | GCBackground,
		      &xgcvalues);
  XSetClipMask(display, gc_bullet, mask_bullet);


  /* (Bullet) */

  XpmCreatePixmapFromData(display, window,
                          controls_xpm, &pix_controls, &mask_controls, NULL);
  xgcvalues.foreground = white;
  xgcvalues.background = black;
  gc_controls = XCreateGC(display, window, GCForeground | GCBackground,
			  &xgcvalues);
  XSetClipMask(display, gc_bullet, mask_controls);

  
  /* (Expl1) */
  
  XpmCreatePixmapFromData(display, window,
 	  		  expl1_xpm, &pix_expl1, &mask_expl1, NULL);
  xgcvalues.foreground = white;
  xgcvalues.background = black;
  gc_expl1 = XCreateGC(display, window, GCForeground | GCBackground,
		      &xgcvalues);
  XSetClipMask(display, gc_expl1, mask_expl1);


  
  /* (Expl2) */
  
  XpmCreatePixmapFromData(display, window,
 	  		  expl2_xpm, &pix_expl2, &mask_expl2, NULL);
  xgcvalues.foreground = white;
  xgcvalues.background = black;
  gc_expl2 = XCreateGC(display, window, GCForeground | GCBackground,
		      &xgcvalues);
  XSetClipMask(display, gc_expl2, mask_expl2);


  
  /* (Expl3) */
  
  XpmCreatePixmapFromData(display, window,
 	  		  expl3_xpm, &pix_expl3, &mask_expl3, NULL);
  xgcvalues.foreground = white;
  xgcvalues.background = black;
  gc_expl3 = XCreateGC(display, window, GCForeground | GCBackground,
		      &xgcvalues);
  XSetClipMask(display, gc_expl3, mask_expl3);

  
  /* (Flame1) */
  
  XpmCreatePixmapFromData(display, window,
 	  		  flame1_xpm, &pix_flame1, &mask_flame1, NULL);
  xgcvalues.foreground = white;
  xgcvalues.background = black;
  gc_flame1 = XCreateGC(display, window, GCForeground | GCBackground,
		      &xgcvalues);
  XSetClipMask(display, gc_flame1, mask_flame1);

  
  /* (Flame2) */
  
  XpmCreatePixmapFromData(display, window,
 	  		  flame2_xpm, &pix_flame2, &mask_flame2, NULL);
  xgcvalues.foreground = white;
  xgcvalues.background = black;
  gc_flame2 = XCreateGC(display, window, GCForeground | GCBackground,
		      &xgcvalues);
  XSetClipMask(display, gc_flame2, mask_flame2);

  
  /* (Missile) */
  
  XpmCreatePixmapFromData(display, window,
 	  		  missile_xpm, &pix_missile, &mask_missile, NULL);
  xgcvalues.foreground = white;
  xgcvalues.background = black;
  gc_missile = XCreateGC(display, window, GCForeground | GCBackground,
		      &xgcvalues);
  XSetClipMask(display, gc_missile, mask_missile);
  
  
  /* (Ship) */
  
  XpmCreatePixmapFromData(display, window,
 	  		  ship_xpm, &pix_ship, &mask_ship, NULL);
  xgcvalues.foreground = white;
  xgcvalues.background = black;
  gc_ship = XCreateGC(display, window, GCForeground | GCBackground,
		      &xgcvalues);
  XSetClipMask(display, gc_ship, mask_ship);


  /* (Title) */

  XpmCreatePixmapFromData(display, window, title_xpm, &pix_title, &mask_title,
		          NULL);
  xgcvalues.foreground = white;
  xgcvalues.background = black;
  xgcvalues.graphics_exposures = False;
  gc_title = XCreateGC(display, window, 
                       GCForeground | GCBackground | GCGraphicsExposures,
	               &xgcvalues);
  XSetClipMask(display, gc_title, mask_title);


  /* Not sure why text blitting causes endless "NoExposure" events, but
     setting graphics_exposures flag to "False" makes them go away...
     - BJK 2001.03.26 */

 
  /* Catch up! */

  XSync(display, 0); 


  /* Initialize stars: */

  srand(time(NULL));

  for (i = 0; i < NUM_STARS; i++)
  {
    star_x[i] = (rand() % WIDTH);
    star_y[i] = (rand() % HEIGHT);
    star_ym[i] = (rand() % 5) + 1;
  }


  /* Catch up! */

  while (XPending(display))
    XNextEvent(display, &event);

  XFlush(display);


  
  return(0);
}


/* Close up: */

void finish(void)
{
  XKeyboardControl vals;


  /* Return display's beel pitch/duration to normal! */

  vals.bell_pitch = kbstate.bell_pitch;
  vals.bell_duration = kbstate.bell_duration;

  XChangeKeyboardControl(display, KBBellPitch | KBBellDuration, &vals);
  XFlush(display);
}


/* Fire a bullet: */

void add_bullet(int x)
{
  int i, found;

  found = -1;
  
  for (i = 0; i < NUM_BULLETS && found == -1; i++)
  {
    if (bullets[i].alive == 0)
      found = i;
  }

  if (found != -1)
  {
    bullets[found].alive = 1;
    bullets[found].x = x;
    bullets[found].y = HEIGHT - 40;
  }
}


/* Launch a missile: */

void add_missile(int x, int y)
{
  int i, found;

  found = -1;

  for (i = 0; i < NUM_MISSILES && found == -1; i++)
  {
    if (missiles[i].alive == 0)
      found = i;
  }

  if (found != -1)
  {
    missiles[found].alive = 1;
    missiles[found].x = x;
    missiles[found].y = y;
  }
}



/* Add an explosion: */

void add_explosion(int x, int y)
{
  int i, found;

  found = -1;

  for (i = 0; i < NUM_EXPLOSIONS && found == -1; i++)
  {
    if (explosions[i].timer == 0)
      found = i;
  }

  if (found == -1)
    found = (rand() % NUM_EXPLOSIONS);

  explosions[found].x = x;
  explosions[found].y = y; 
  explosions[found].timer = 5;
}


/* "Launch" some new aliens: */

void reset_aliens(void)
{
  int i, l;


  /* Make sure aliens don't start unmanagably low (in marching mode) */
 
  l = level;
  if (l > 6)
    l = 6;	
  

  /* Set us up the aliens: */
  
  for (i = 0; i < NUM_ALIENS; i++)
    {
      aliens[i].alive = 1;
      aliens[i].diving = 0;

      aliens[i].xhome = (i % 10) * 20 + 20;
      aliens[i].x = aliens[i].xhome;

      if (game_mode == MODE_SWOOPING)
      {
        aliens[i].returning = 1;
	march_x = 0;
        aliens[i].yhome = (i / 10) * 20 + 10;
	aliens[i].y = -16;
      }
      else if (game_mode == MODE_MARCHING)
      {
	aliens[i].returning = 0;
	march_x = -20;
	aliens[i].yhome = (i / 10) * 20 + (l * 10) + 6;
	aliens[i].y = aliens[i].yhome;
      }
      
      aliens[i].xm = 0;
      aliens[i].ym = 0;
    }

  if (game_mode == MODE_SWOOPING)
    march_xm = 1;
  else
    march_xm = 16;

  march_min = 0;
  march_max = 0;
}


void set_level(int l)
{
  level = l;

  sprintf(notice_text, "LEVEL %d", level);
  notice_time = 100;
}


void add_score(int s)
{
  int old_score;

  old_score = score;
  score = score + s;


  /* See if we gained a life: */
  
  if ((score >= 1000 && old_score < 1000) ||
      (score >= 2000 && old_score < 2000) ||
      (score >= 5000 && old_score < 5000) ||
      (score >= 7500 && old_score < 7500) ||
      (score >= 10000 && old_score < 10000) ||
      (score >= 15000 && (old_score / 5000) < (score / 5000)))
  {
    lives++;

    strcpy(notice_text, "BONUS SHIP!");
    oneup_sfx = NUM_ONEUP_NOTES * 10;
    notice_time = 200;
  }
}


/* Remove a ship; game over if all gone! */

void kill_ship(void)
{
  lives--;
  ship_dying = 20;

  if (lives == 0)
    game_over();
}


/* Game over! */

void game_over(void)
{
  strcpy(notice_text, "GAME OVER");
  notice_time = 200;
}


/* Beep! */

void play_beep(int pitch, int duration)
{
  XKeyboardControl vals;

  if (volume != 0)
  {
    vals.bell_pitch = pitch;
    vals.bell_duration = duration;
  
    XChangeKeyboardControl(display, KBBellPitch | KBBellDuration, &vals);
  
    XBell(display, volume);
  }
}

