README.txt for Aliens

by Bill Kendrick
bill@newbreedsoftware.com
http://www.newbreedsoftware.com/aliens/

March 25, 2001 - April 30, 2001


What Is It?
-----------
  "Aliens" is an arcade-style shooting game for the Agenda VR3 PDA.
  It is written using Xlib calls, and is played with the Agenda held
  sideways (for more ergonomic access to control buttons on the device).


Objective
---------
  The objective is simple:  Destroy as many aliens as possible!
  You have 3 lives in which to do this.  You can gain bonus lives
  by reaching certain score thresholds.


Title Screen
------------
  Use the [Left] and [Right] buttons on the front of the Agenda to
  select an option on the title screen:

    BEGIN / CONTINUE
    START OVER
    OPTIONS
    HELP
    QUIT

  Press either [Shift] button to accept your selection.

  Alternately, you can tap one of the options with the stylus or your
  finger.

  If no game is currently active, select "BEGIN" to start a new game.

  If a game is active, the "BEGIN" option will be renamed "CONTINUE."
  Select it to continue your game where you left off.

  If a game is active, an additional option will be available: "START OVER."
  Select it to abort the active game and start a new game.


Game Screen
-----------
  Use the [Page Up] and [Page Down] buttons on the left side of the
  Agenda to move the space ship left and right.

  Press either [Left] or [Right] buttons on the front of the Agenda
  to fire bullets.

  Press either [Shift] button to pause the game (return to the
  title screen).  (Choose "CONTINUE" from the title screen to return
  to your active game.)


How It Works
------------
  The aliens appear in rows at the top of the screen.  Your ship is at the
  bottom.  You can move the ship left and right, and shoot up towards
  the aliens.  Occasionally, an alien will dive down towards you, firing
  missiles.


Scoring
-------
  Each row of aliens is worth a different amount of score:

    Top row:    10 points
    Middle row:  5 points
    Bottom row:  1 point

  If you shoot an alien while it's diving, you get:  25 points


Bonuses
-------
  You gain extra lives when your score passes certain thresholds:

    1,000 points
    2,000 points
    5,000 points
    7,500 points
   10,000 points

  and every 5,000 points thereafter.


Credits
-------
  Concept:  Classic games in this genre (Space Invaders, Galaxian, Galaga, etc.)

  Coding:  Bill Kendrick

  Graphics:  Bill Kendrick
