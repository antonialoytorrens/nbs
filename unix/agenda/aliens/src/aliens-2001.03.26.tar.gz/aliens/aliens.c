/*
  aliens.c

  by Bill Kendrick
  bill@newbreedsoftware.com
  http://www.newbreedsoftware.com/

  March 25, 2001 - March 26, 2001
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/xpm.h>
#include <X11/keysym.h>
#include <time.h>
#include <unistd.h>

#include "ship.xpm"
#include "text.xpm"


#define WIDTH 240
#define HEIGHT 160

#define NUM_STARS 20



/* Globals: */

Display * display;
Window rootwin, window;
int black, white;
int star_x[NUM_STARS], star_y[NUM_STARS];
GC whitegc, blackgc;
Pixmap pix_ship, mask_ship,
       pix_text, mask_text;
GC gc_ship,
   gc_text;


/* Local prototypes: */

int title(void);
int game(void);
void drawobject(Pixmap pix, Pixmap mask, GC gc, int x, int y);
void drawcenteredtext(int y, char * text);
void drawtext(int x, int y, char * text);
int setup(void);
void finish(void);


/* --- MAIN! --- */

int main(int argc, char * argv[])
{
  int done;


  /* Set up: */
  
  if (setup() == -1)
    {
      fprintf(stderr, "Couldn't setup!\n");
      exit(1);
    }
  
  
  /* --- Main Loop: --- */

  done = 0;
  
  do
    {
      done = title();

      if (!done)
      {
        done = game();
      }
    }
  while (!done);
  
 
  /* Shut down: */

  /* finish(); */

  return(0);
}


int title(void)
{
  int done, quit, i, x;
  XEvent event;
  KeySym key;

  quit = 0;
  done = 0;

  x = (WIDTH - 16) / 2;

  do
  {
    /* Draw starfield: */
	  
    for (i = 0; i < NUM_STARS; i++)
    {
      XDrawLine(display, window, blackgc,
		159 - star_y[i], star_x[i],
		159 - (star_y[i] + 7), star_x[i]);

      star_y[i] = star_y[i] + 5;

      if (star_y[i] >= HEIGHT)
      {
        star_y[i] = 0;
	star_x[i] = rand() % WIDTH;
      }

      XDrawLine(display, window, whitegc,
                159 - star_y[i], star_x[i],
                159 - (star_y[i] + 5), star_x[i]);
    }


    /* Draw title: */

    drawcenteredtext(0, "-- ALIENS --");
    drawcenteredtext(15, "BY BILL KENDRICK");
    drawcenteredtext(25, "NEW BREED SOFTWARE 2001");


    /* Draw ship: */

    drawobject(pix_ship, mask_ship, gc_ship, x, HEIGHT - 32);
    
    
    /* Check for events: */
    
    while (XPending(display))
    {
      XNextEvent(display, &event);

      if (event.type == KeyPress)
      {
        key = XLookupKeysym((XKeyEvent *)&event, 0);

	if (key == XK_q || key == XK_Escape)
	{
	  quit = 1;
	}
	else if (key == XK_Page_Up)
	{
	  x = x - 16;
	  if (x < 0)
	    x = 0;
	}
	else if (key == XK_Page_Down)
	{
	  x = x + 16;
	  if (x > WIDTH - 16)
	    x = WIDTH - 16;
	}
	else if (key == XK_Right)
	{
	  printf("POW!\n");
	}
      }
      else if (event.type == ButtonPress)
      {
        done = 1;
      }
    }


    /* Pause a moment... */

    usleep(250);
    XSync(display, 0);
  }
  while (done == 0 && quit == 0);
  
  return quit;
}


int game(void)
{
  printf("Game!\n");
  return 1;
}


void drawobject(Pixmap pix, Pixmap mask, GC gc, int x, int y)
{
  int winx, winy;

  winx = 160 - y - 16;
  winy = x;
  
  XSetClipOrigin(display, gc, winx, winy);
  XCopyArea(display, pix, window, gc, 0, 0, 16, 16, winx, winy);
}


void drawcenteredtext(int y, char * text)
{
  drawtext((WIDTH - (strlen(text) * 6)) / 2, y, text);
}


void drawtext(int x, int y, char * text)
{
  int i, winx, winy;

  winx = HEIGHT - 9 - y;
  winy = x;

  for (i = 0; i < strlen(text); i++)
  {
    if (text[i] >= '!' && text[i] <= 'Z')
    {
      XSetClipOrigin(display, gc_text, winx, winy);
      XCopyArea(display, pix_text, window, gc_text,
  	        0, (text[i] - '!') * 6, 9, 6, winx, winy);
    }

    winy = winy + 6;
  }
}


/* Connect to X server, open window, ready images, etc.: */

int setup(void)
{
  XSetWindowAttributes attr;
  unsigned long attr_mask;
  int screen, i;
  XGCValues xgcvalues;
  XEvent event;


  /* Connect to display: */
  
  display = XOpenDisplay(":0");
  if (display == NULL)
    return(-1);

  screen = DefaultScreen(display);
  rootwin = RootWindow(display, screen);


  /* Get primary colors: */

  black = BlackPixel(display, screen);
  white = WhitePixel(display, screen);


  /* Open a window: */

  attr.event_mask = KeyPressMask | ButtonPressMask;
  attr.background_pixel = black;
  attr_mask = CWEventMask | CWBackPixel;

  window = XCreateWindow(display, rootwin, 0, 0, 160, 240, 0,
                         CopyFromParent, InputOutput, CopyFromParent,
			 attr_mask, &attr);

  XMapWindow(display, window);
  XMapRaised(display, window);


  /* Create graphics contexts: */

  xgcvalues.foreground = white;
  xgcvalues.background = black;
  whitegc = XCreateGC(display, window, GCForeground | GCBackground,
		      &xgcvalues);

  xgcvalues.foreground = black;
  xgcvalues.background = white;
  blackgc = XCreateGC(display, window, GCForeground | GCBackground,
		      &xgcvalues);
  
  
  /* Create images: */

  /* (Ship) */
  
  XpmCreatePixmapFromData(display, window,
 	  		  ship_xpm, &pix_ship, &mask_ship, NULL);
  xgcvalues.foreground = white;
  xgcvalues.background = black;
  gc_ship = XCreateGC(display, window, GCForeground | GCBackground,
		      &xgcvalues);
  XSetClipMask(display, gc_ship, mask_ship);


  
  /* (Text) */
  
  XpmCreatePixmapFromData(display, window,
		  	  text_xpm, &pix_text, &mask_text, NULL);
  xgcvalues.foreground = white;
  xgcvalues.background = black;
  xgcvalues.graphics_exposures = False;
  gc_text = XCreateGC(display, window, GCForeground | GCBackground | GCGraphicsExposures,
		      &xgcvalues);
  XSetClipMask(display, gc_text, mask_text);

  /* Not sure why text blitting causes endless "NoExposure" events, but
   * setting graphics_exposures flag to "False" makes them go away... - BJK 2001.03.26 */

 
  /* Catch up! */

  XSync(display, 0); 


  /* Initialize stars: */

  srand(time(NULL));

  for (i = 0; i < NUM_STARS; i++)
  {
    star_x[i] = (rand() % WIDTH);
    star_y[i] = (rand() % HEIGHT);
  }


  /* Catch up! */

  while (XPending(display))
    XNextEvent(display, &event);

  XFlush(display);


  
  return(0);
}


/* Close up: */

void finish(void)
{
  
}
