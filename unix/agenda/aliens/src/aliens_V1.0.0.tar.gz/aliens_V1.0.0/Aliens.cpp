/*
 * Copyright (C) 2002 Robert Ernst <robert.ernst@linux-solutions.at>
 *
 * This file may be distributed and/or modified under the terms of the
 * GNU General Public License version 2 as published by the Free Software
 * Foundation and appearing in the file LICENSE.GPL included in the
 * packaging of this file.
 *
 * This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 * WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See COPYING for GPL licensing information.
 *
 */

#include <qpe/qpemenubar.h>
#include <qpe/config.h>
#include <qapplication.h>
#include <qmainwindow.h>
#include <qpopupmenu.h>
#include <qtimer.h>
#include "Aliens.h"
#include "GameWidget.h"
#include <stdlib.h>
#include <time.h>

Aliens::Aliens(QWidget *parent, const char *name, WFlags f) :
    QMainWindow(parent, name, f)
{
    /* initialize random number generator */
    srand(::time(0));

    /* set windows style and caption */
    setCaption("Aliens");

    /* create the play field as the central widget */
    m_game = new GameWidget(this);
    setCentralWidget(m_game);
    m_game->show();

    /* create the game/mode submenu */
    m_modeMenu = new QPopupMenu(0, "mode_menu");
    m_modeMenu->setCheckable(true);
    connect(m_modeMenu, SIGNAL(activated(int)), this, SLOT(updateMode(int)));
    connect(m_modeMenu, SIGNAL(activated(int)), m_game, SLOT(updateMode(int)));
    m_modeMenu->insertItem(tr("Shooting"), GameWidget::Shooting);
    m_modeMenu->insertItem(tr("Marching"), GameWidget::Marching);

    /* create the game submenu */
    QPopupMenu *gameMenu = new QPopupMenu(0, "game_menu");
    gameMenu->insertItem(tr("New"), m_game, SLOT(start()));
    gameMenu->insertItem(tr("Mode"), m_modeMenu);
    gameMenu->insertSeparator();
    gameMenu->insertItem(tr("Close"), this, SLOT(close()));

    /* create the menu */
    QPEMenuBar *menu = new QPEMenuBar(this);
    menu->insertItem(tr("Game"), gameMenu);

    /* read the configuration file */
    readConfig();

    /* check the menu entries of game mode submenu */
    m_modeMenu->setItemChecked(m_mode, true);
}

Aliens::~Aliens()
{
    writeConfig();
}

void Aliens::readConfig(void)
{
    Config cfg("Aliens");

    cfg.setGroup("Settings");

    int mode = cfg.readNumEntry("Mode", GameWidget::Shooting);
    if (mode != GameWidget::Shooting && mode != GameWidget::Marching) {
	m_mode = GameWidget::Shooting;
    } else {
	m_mode = mode;
    }
    m_game->updateMode(m_mode);
}

void Aliens::writeConfig(void)
{
    Config cfg("Aliens");

    cfg.setGroup("Settings");
    cfg.writeEntry("Mode", m_mode);
}

void Aliens::updateMode(int mode)
{
    m_modeMenu->setItemChecked(m_mode, false);
    m_mode = mode;
    m_modeMenu->setItemChecked(m_mode, true);
    writeConfig();
}

