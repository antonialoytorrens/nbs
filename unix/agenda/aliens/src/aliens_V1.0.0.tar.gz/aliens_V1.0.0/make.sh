#!/bin/sh

VERSION=1.0.0

if [ "$1" = "cross" ]; then
    export CROSSCOMPILE=/opt/Embedix/tools
    export QPEDIR=/opt/Qtopia/sharp
    export QTDIR=/opt/Qtopia/sharp
    export PATH=$QTDIR/bin:$QPEDIR/bin:$CROSSCOMPILE/bin:$PATH
    export TMAKEPATH=/opt/Qtopia/tmake/lib/qws/linux-sharp-g++/
    export LD_LIBRARY_PATH=$QTDIR/lib:$LD_LIBRARY_PATH
    export ARCHITECTURE=arm
elif [ "$1" = "native" ]; then
    export CROSSCOMPILE=
    export QPEDIR=/opt/Qtopia
    export QTDIR=/opt/Qtopia
    export PATH=$QTDIR/bin:$QPEDIR/bin:$PATH:/opt/Embedix/tools/bin
    export TMAKEPATH=/opt/Qtopia/tmake/lib/qws/linux-x86-g++/
    export LD_LIBRARY_PATH=$QTDIR/lib:$LD_LIBRARY_PATH
    export ARCHITECTURE=x86
else
    echo "usage: $0 cross | native"
    exit 1
fi

make -C tools
make -C images

tmake -o Makefile aliens.pro
make
lrelease aliens.pro

for LANGUAGE in en de; do
    mkdir -p tmp/CONTROL
    mkdir -p tmp/opt/QtPalmtop/apps/Games
    mkdir -p tmp/opt/QtPalmtop/bin
    mkdir -p tmp/opt/QtPalmtop/pics
    if [ "$LANGUAGE" != "en" ]; then
	mkdir -p tmp/opt/QtPalmtop/help/${LANGUAGE}/html
	mkdir -p tmp/opt/QtPalmtop/i18n/${LANGUAGE}
    else
	mkdir -p tmp/opt/QtPalmtop/help/html
    fi
    cp aliens.desktop tmp/opt/QtPalmtop/apps/Games
    cp aliens tmp/opt/QtPalmtop/bin
    cp aliens.png tmp/opt/QtPalmtop/pics
    if [ "$LANGUAGE" != "en" ]; then
	cp help/${LANGUAGE}/aliens.html tmp/opt/QtPalmtop/help/${LANGUAGE}/html
	cp i18n/${LANGUAGE}/aliens.qm tmp/opt/QtPalmtop/i18n/${LANGUAGE}
    else
	cp help/en/aliens.html tmp/opt/QtPalmtop/help/html
    fi
    cat > tmp/CONTROL/control <<END
Version: ${VERSION}
Depends: qpe-base (\$QPE_VERSION)
Priority: optional
Section: Games
Maintainer: Robert Ernst <robert.ernst@linux-solutions.at>
Architecture: ${ARCHITECTURE}
License: GPL
Description: Aliens
 A classic arcade-style shooter.
END
    if [ "$LANGUAGE" != "en" ]; then
	cat >> tmp/CONTROL/control <<END
Package: aliens-${LANGUAGE}
Files: bin/aliens apps/Games/aliens.desktop pics/aliens.png help/${LANGUAGE}/html/aliens.html
Filename: ./aliens-${LANGUAGE}_${VERSION}_${ARCHITECTURE}.ipk
END
    else
	cat >> tmp/CONTROL/control <<END
Package: aliens
Files: bin/aliens apps/Games/aliens.desktop pics/aliens.png help/html/aliens.html
Filename: ./aliens_${VERSION}_${ARCHITECTURE}.ipk
END
    fi
    ipkg-build tmp
    rm -rf tmp
done

