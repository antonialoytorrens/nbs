/*
 * Copyright (C) 2002 Robert Ernst <robert.ernst@linux-solutions.at>
 *
 * This file may be distributed and/or modified under the terms of the
 * GNU General Public License version 2 as published by the Free Software
 * Foundation and appearing in the file LICENSE.GPL included in the
 * packaging of this file.
 *
 * This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 * WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See COPYING for GPL licensing information.
 *
 */

#include <qpe/qpeapplication.h>
#include <qtimer.h>
#include <qmessagebox.h>
#include <qwidget.h>
#include <qpainter.h>
#include <qkeycode.h>
#include "GameWidget.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "images/data.c"

GameWidget::GameWidget(QWidget *parent, const char *name, WFlags f) :
    QWidget(parent, name, f)
{
    m_timer = new QTimer(this);
    m_pixmap = 0;
    m_bug[0].loadFromData(bug1_data_, sizeof (bug1_data_));
    m_bug[1].loadFromData(bug2_data_, sizeof (bug2_data_));
    m_bugdir[0].loadFromData(bugl_data_, sizeof (bugl_data_));
    m_bugdir[1].loadFromData(bugr_data_, sizeof (bugr_data_));
    m_bullet.loadFromData(bullet_data_, sizeof (bullet_data_));
    m_explosion[0].loadFromData(expl1_data_, sizeof (expl1_data_));
    m_explosion[1].loadFromData(expl2_data_, sizeof (expl2_data_));
    m_explosion[2].loadFromData(expl3_data_, sizeof (expl3_data_));
    m_flame[0].loadFromData(flame1_data_, sizeof (flame1_data_));
    m_flame[1].loadFromData(flame2_data_, sizeof (flame2_data_));
    m_missile.loadFromData(missile_data_, sizeof (missile_data_));
    m_ship.loadFromData(ship_data_, sizeof (ship_data_));
    m_text.loadFromData(text_data_, sizeof (text_data_));
    m_title.loadFromData(title_data_, sizeof (title_data_));
    connect(m_timer, SIGNAL(timeout()), this, SLOT(timerTick()));
    m_mode = Shooting;
    m_state = Intro;
    m_counter = 0;
    m_alien_counter = 0;
    m_player_dir = None;
    m_player_x = (width() - 16) / 2;
    m_player_req_x = m_player_x;
    m_bullets_fired = 0;
    m_aliens_killed = 0;
    m_level = 1;
    m_score = 0;
    m_lives = 3;
    m_num_diving = 0;
    m_bullets = 0;
    memset(m_bullet_x, 0, sizeof (m_bullet_x));
    memset(m_bullet_y, 0, sizeof (m_bullet_y));
    m_missiles = 0;
    memset(m_missile_x, 0, sizeof (m_missile_x));
    memset(m_missile_y, 0, sizeof (m_missile_y));
    m_aliens = 0;
    memset(m_alien_x, 0, sizeof (m_alien_x));
    memset(m_alien_y, 0, sizeof (m_alien_y));
    memset(m_alien_state, 0, sizeof (m_alien_state));
    memset(m_alien_xhome, 0, sizeof (m_alien_xhome));
    memset(m_alien_yhome, 0, sizeof (m_alien_yhome));
    memset(m_alien_statehome, 0, sizeof (m_alien_statehome));
    m_stars = 0;
    memset(m_star_x, 0, sizeof (m_star_x));
    memset(m_star_y, 0, sizeof (m_star_y));
    memset(m_star_speed, 0, sizeof (m_star_speed));
    memset(m_star_size, 0, sizeof (m_star_size));
    m_mouse_down = false;
    m_mouse_counter = 0;
}

GameWidget::~GameWidget()
{
    delete m_timer;
    delete m_pixmap;
}

void GameWidget::updateMode(int mode)
{
    switch (mode) {
    case Shooting:
	if (m_mode != Shooting) {
	    m_mode = Shooting;
	    if (m_state == Playing || m_state == Dying || m_state == LevelCompleted) {
		start();
	    }
	}
	break;
    case Marching:
	if (m_mode != Marching) {
	    m_mode = Marching;
	    if (m_state == Playing || m_state == Dying || m_state == LevelCompleted) {
		start();
	    }
	}
	break;
    }
}

void GameWidget::start(void)
{
    int max_y = height();
    int i;

    m_state = Playing;
    m_counter = 0;
    m_alien_counter = 0;
    m_player_dir = None;
    m_player_x = (width() - 16) / 2;
    m_player_req_x = m_player_x;
    m_bullets_fired = 0;
    m_aliens_killed = 0;
    m_level = 1;
    m_score = 0;
    m_lives = 3;
    m_num_diving = 0;
    m_bullets = 0;
    memset(m_bullet_x, 0, sizeof (m_bullet_x));
    memset(m_bullet_y, 0, sizeof (m_bullet_y));
    m_missiles = 0;
    memset(m_missile_x, 0, sizeof (m_missile_x));
    memset(m_missile_y, 0, sizeof (m_missile_y));
    m_aliens = 0;
    memset(m_alien_x, 0, sizeof (m_alien_x));
    memset(m_alien_y, 0, sizeof (m_alien_y));
    memset(m_alien_state, 0, sizeof (m_alien_state));
    memset(m_alien_xhome, 0, sizeof (m_alien_xhome));
    memset(m_alien_yhome, 0, sizeof (m_alien_yhome));
    memset(m_alien_statehome, 0, sizeof (m_alien_statehome));
    m_stars = 0;
    for (i = 0; i < max_stars; i++) {
	m_star_x[m_stars] = rand() % 240;
	m_star_y[m_stars] = rand() % max_y;
	m_star_speed[m_stars] = (rand() % 16) + 1;
	m_star_size[m_stars] = rand() % 16;
	m_stars++;
    }
    newLevel();
    repaint(false);
}

void GameWidget::stop(void)
{
    switchState(Intro);
    repaint(false);
}

void GameWidget::timerTick(void)
{
    m_counter++;
    m_alien_counter++;
    switch (m_state) {
    case Intro:
	break;
    case Playing:
	if (m_mouse_down) {
	    m_mouse_counter++;
	    if (m_mouse_counter > 5) {
		fireBullet();
		m_mouse_counter = 0;
	    }
	}
	updateLevel();
	break;
    case Dying:
	updateLevel();
	if (m_counter >= 60) {
	    m_lives--;
	    if (m_lives == 0) {
		switchState(GameOver);
	    } else {
		switchState(Playing);
	    }
	}
	break;
    case LevelCompleted:
	updateLevel();
	if (m_counter >= 60) {
	    m_level++;
	    newLevel();
	    switchState(Playing);
	}
	break;
    case GameOver:
	if (m_counter >= 600) {
	    switchState(Intro);
	}
	break;
    }
    repaint(false);
}

void GameWidget::paintEvent(QPaintEvent *event)
{
    switch (m_state) {
    case Intro:
	drawIntro();
	break;
    case Playing:
    case Dying:
    case LevelCompleted:
	drawPlaying();
	break;
    case GameOver:
	drawGameOver();
	break;
    }
}

void GameWidget::showEvent(QShowEvent *event)
{
    QWidget::showEvent(event);
    m_timer->start(50);
    setFocusPolicy(StrongFocus);
}

void GameWidget::hideEvent(QHideEvent *event)
{
    QWidget::hideEvent(event);
    m_timer->stop();
}

void GameWidget::resizeEvent(QResizeEvent *event)
{
    QWidget::resizeEvent(event);
    if (!m_pixmap || event->size() != event->oldSize()) {
	if (m_pixmap) {
	    delete m_pixmap;
	}
	m_pixmap = new QPixmap(event->size().width(), event->size().height());
    }
}

void GameWidget::keyPressEvent(QKeyEvent *event)
{
    QWidget::keyPressEvent(event);
    switch (event->key()) {
    case Key_Left:
	if (m_state == Playing || m_state == LevelCompleted || (m_state == Dying && m_counter > 8)) {
	    m_player_dir = Left;
	    m_player_req_x = 0;
	}
	break;
    case Key_Right:
	if (m_state == Playing || m_state == LevelCompleted || (m_state == Dying && m_counter > 8)) {
	    m_player_dir = Right;
	    m_player_req_x = width() - 16;
	}
	break;
    case Key_Space:
    case Key_Enter:
    case Key_Up:
	if (m_state == Playing || m_state == LevelCompleted) {
	    fireBullet();
	} else if (m_state != Dying) {
	    start();
	}
	break;
    case Key_Escape:
	stop();
	break;
    }
}

void GameWidget::keyReleaseEvent(QKeyEvent *event)
{
    QWidget::keyReleaseEvent(event);
    switch (event->key()) {
    case Key_Left:
    case Key_Right:
	m_player_dir = None;
	m_player_req_x = m_player_x;
	break;
    }
}

void GameWidget::mousePressEvent(QMouseEvent *event)
{
    QWidget::mousePressEvent(event);
    if (m_state == Playing || m_state == LevelCompleted || (m_state == Dying && m_counter > 8)) {
	int max_req_x = width() - 16;
	int req_x = event->x() - 8;
	if (req_x < 0) {
	    req_x = 0;
	} else if (req_x > max_req_x) {
	    req_x = max_req_x;
	}
	m_player_req_x = req_x;
	if (req_x < m_player_x) {
	    m_player_dir = Left;
	} else if (req_x > m_player_x) {
	    m_player_dir = Right;
	} else {
	    m_player_dir = None;
	}
	if (m_state != Dying) {
	    if (event->y() < (height() / 2)) {
		fireBullet();
	    }
	    m_mouse_down = true;
	    m_mouse_counter = 0;
	}
    } else if (m_state != Dying) {
	start();
    }
}

void GameWidget::mouseReleaseEvent(QMouseEvent *event)
{
    m_mouse_down = false;
    m_mouse_counter = 0;
}

void GameWidget::drawPixmapText(QPainter &painter, int x, int y, int wrap, const char *str)
{
    int xstart = x;

    while (*str != '\0') {
	if ((*str >= '!') && (*str <= 'Z')) {
	    painter.drawPixmap(x, y, m_text, (*str - '!') * 6, 0, 6, 9);
	    x = x + 7;
	} else if (*str == ' ') {
	    x = x + 7;
	    if (wrap > xstart) {
		int nchars = 0;
		const char *ptr;
		for (ptr = str + 1; *ptr >= '!' && *ptr <= 'Z'; ptr++) {
		    nchars++;
		}
		if (x + (nchars * 7) > wrap) {
		    x = xstart;
		    y = y + 10;
		}
	    }
	} else {
	    x = xstart;
	    y = y + 10;
	}
	str++;
    }
}

void GameWidget::newLevel(void)
{
    int i;

    m_num_diving = 0;
    m_alien_counter = 0;
    m_aliens = 0;
    for (i = 0; i < max_aliens; i++) {
	m_alien_xhome[m_aliens] = (i % 10) * 20 + 10 + ((i / 10) % 2) * 20;
	m_alien_yhome[m_aliens] = -16 - (i / 10) * 20;
	m_alien_statehome[m_aliens] = (i / 10) % 2;
	m_alien_x[m_aliens] = m_alien_xhome[m_aliens];
	m_alien_y[m_aliens] = m_alien_yhome[m_aliens];
	m_alien_state[m_aliens] = m_alien_statehome[m_aliens];
	m_aliens++;
    }
}

void GameWidget::updateLevel(void)
{
    int max_y = height();
    int max_x = width() - 16;
    int i;
    int j;

    /* move player to new position */
    if (m_player_dir == Left) {
	m_player_x = m_player_x - 6;
	if (m_player_x <= m_player_req_x) {
	    m_player_x = m_player_req_x;
	    m_player_dir = None;
	}
    } else if (m_player_dir == Right) {
	m_player_x = m_player_x + 6;
	if (m_player_x >= m_player_req_x) {
	    m_player_x = m_player_req_x;
	    m_player_dir = None;
	}
    }

    /* move bullets to new positions */
    for (i = 0; i < m_bullets; i++) {
	m_bullet_y[i] = m_bullet_y[i] - 12;
	if (m_bullet_y[i] <= -16) {
	    deleteBullet(i);
	}
    }

    /* move missiles to new positions */
    for (i = 0; i < m_missiles; i++) {
	m_missile_y[i] = m_missile_y[i] + 9;
	if (m_missile_y[i] >= max_y) {
	    deleteMissile(i);
	}
    }

    /* move stars to new position */
    for (i = 0; i < m_stars; i++) {
	m_star_y[i] = m_star_y[i] + m_star_speed[i];
	if (m_star_y[i] >= max_y) {
	    m_star_x[i] = rand() % 240;
	    m_star_y[i] = 0;
	    m_star_speed[i] = (rand() % 16) + 1;
	    m_star_size[i] = rand() % 16;
	}
    }

    /* in shooting mode, they move left/right and down until they reach
     * their initial y position. then they only move left/right.
     * in marching mode, they constantly move left/right and down at 
     * the end of each sweep, and their speed rises */
    if (m_mode == Shooting) {
	for (i = 0; i < m_aliens; i++) {
	    if (m_alien_state[i] < 2) {
		/* normal state, moving down to yhome + 60, then swooping and diving */
		if (m_alien_y[i] < (m_alien_yhome[i] + 60)) {
		    m_alien_y[i]++;
		} else if ((rand() % ((33 * m_aliens) / m_level)) == 0
		    && m_num_diving < ((m_level + 5) / 3)) {
		    m_alien_state[i] = 2;
		    m_num_diving++;
		    continue;
		} else if (m_aliens < (4 + m_level / 4)) {
		    m_alien_state[i] = 2;
		    m_num_diving++;
		    continue;
		} else if ((rand() % ((33 * m_aliens) / m_level)) == 0) {
		    fireMissile(i);
		}
		int tmp = (m_alien_counter + m_alien_statehome[i] * 20) % 40;
		if (tmp < 20) {
		    m_alien_x[i] = m_alien_xhome[i] + tmp - m_alien_statehome[i] * 20;
		} else {
		    m_alien_x[i] = m_alien_xhome[i] + 20 - (tmp % 20) - m_alien_statehome[i] * 20;
		}
	    } else if (m_alien_state[i] < 4) {
		/* diving state, dive to bottom of screen, then return home */
		if (m_alien_state[i] == 2) {
		    m_alien_x[i] = m_alien_x[i] - 3;
		    if (m_alien_x[i] <= 0) {
			m_alien_state[i] = 3;
			m_alien_x[i] = 0;
		    }
		} else {
		    m_alien_x[i] = m_alien_x[i] + 3;
		    if (m_alien_x[i] >= max_x) {
			m_alien_state[i] = 2;
			m_alien_x[i] = max_x;
		    }
		}
		if (m_alien_y[i] > (max_y / 2)) {
		    if (m_alien_x[i] > m_player_x) {
			m_alien_state[i] = 2;
		    } else if (m_alien_x[i] < m_player_x) {
			m_alien_state[i] = 3;
		    }
		} else {
		    if ((m_alien_counter % 5) == 0) {
			if (m_alien_state[i] == 2) {
			    m_alien_state[i] = 3;
			} else {
			    m_alien_state[i] = 2;
			}
		    }
		}
		m_alien_y[i] = m_alien_y[i] + 6;
		if (m_alien_y[i] >= max_y) {
		    m_alien_x[i] = m_alien_xhome[i];
		    m_alien_y[i] = m_alien_yhome[i];
		    m_alien_state[i] = m_alien_statehome[i];
		    m_num_diving--;
		} else if (m_alien_y[i] < (max_y - 48)
		    && (rand() % ((100 * m_aliens) / m_level)) == 0) {
		    fireMissile(i);
		}
	    }
	}
    } else {
	int flag = 0;
	if (m_aliens < (4 + m_level / 4)) {
	    flag = 1;
	}
	for (i = 0; i < m_aliens; i++) {
	    if (m_alien_state[i] > 3) {
		continue;
	    }
	    if (m_alien_y[i] > (max_y + 60)) {
		flag = 2;
		break;
	    } else if (m_alien_y[i] >= (max_y / 2 - 16)) {
		flag = 1;
	    }
	}
	if (flag == 2) {
	    for (i = 0; i < m_aliens; i++) {
		if (m_alien_state[i] > 3) {
		    continue;
		}
		m_alien_x[i] = m_alien_xhome[i];
		m_alien_y[i] = m_alien_yhome[i];
		m_alien_state[i] = m_alien_statehome[i];
	    }
	    m_alien_counter = 0;
	}
	for (i = 0; i < m_aliens; i++) {
	    if (m_alien_state[i] > 3) {
		continue;
	    }
	    if (flag == 1 || (m_alien_y[i] < (m_alien_yhome[i] + 60))) {
		m_alien_y[i] = m_alien_y[i] + 1 + flag;
	    } else if ((m_alien_counter % 20) == 0) {
		m_alien_y[i] = m_alien_y[i] + ((m_alien_counter - 60) / 40) + 2;
	    } else if ((rand() % ((33 * m_aliens) / m_level)) == 0) {
		fireMissile(i);
	    }
	    int tmp = (m_alien_counter + m_alien_statehome[i] * 20) % 40;
	    if (tmp < 20) {
		m_alien_x[i] = m_alien_xhome[i] + tmp - m_alien_statehome[i] * 20;
	    } else {
		m_alien_x[i] = m_alien_xhome[i] + 20 - (tmp % 20) - m_alien_statehome[i] * 20;
	    }
	}
    }
retry_aliens:
    for (i = 0; i < m_aliens; i++) {
	if (m_alien_state[i] > 12) {
	    deleteAlien(i);
	    goto retry_aliens;
	} else if (m_alien_state[i] > 3) {
	    m_alien_state[i]++;
	}
    }
retry_bullets:
    for (i = 0; i < m_bullets; i++) {
	for (j = 0; j < m_aliens; j++) {
	    if (m_alien_state[j] < 4
		&& abs(m_alien_x[j] - m_bullet_x[i]) < 12 && abs(m_alien_y[j] - m_bullet_y[i]) < 12) {
		if (m_alien_state[j] > 1) {
		    m_num_diving--;
		}
		addScore((m_alien_state[j] / 2 + 1) * 25);
		m_alien_state[j] = 4;
		deleteBullet(i);
		goto retry_bullets;
	    }
	}
    }
retry_missiles:
    for (i = 0; i < m_missiles; i++) {
	if (abs(max_y - 32 - m_missile_y[i]) < 12 && abs(m_player_x - m_missile_x[i]) < 12) {
	    switchState(Dying);
	    deleteMissile(i);
	    goto retry_missiles;
	}
    }
    for (i = 0; i < m_aliens; i++) {
	if (m_alien_state[i] < 4
	    && abs(max_y - 32 - m_alien_y[i]) < 12 && abs(m_player_x - m_alien_x[i]) < 12) {
	    switchState(Dying);
	    if (m_alien_state[i] > 1) {
		m_num_diving--;
	    }
	    m_alien_state[i] = 4;
	    break;
	}
    }
    if (m_state != Dying && m_state != LevelCompleted && m_aliens <= 0) {
	switchState(LevelCompleted);
	addScore(250);
    }
}

void GameWidget::fireBullet(void)
{
    if (m_bullets < max_bullets) {
	m_bullet_x[m_bullets] = m_player_x;
	m_bullet_y[m_bullets] = height() - 36;
	m_bullets++;
	m_bullets_fired++;
    }
}

void GameWidget::deleteBullet(int i)
{
    m_bullets--;
    while (i < m_bullets) {
	m_bullet_x[i] = m_bullet_x[i + 1];
	m_bullet_y[i] = m_bullet_y[i + 1];
	i++;
    }
}

void GameWidget::fireMissile(int i)
{
    if (m_missiles < max_missiles) {
	m_missile_x[m_missiles] = m_alien_x[i];
	m_missile_y[m_missiles] = m_alien_y[i] + 16;
	m_missiles++;
    }
}

void GameWidget::deleteMissile(int i)
{
    m_missiles--;
    while (i < m_missiles) {
	m_missile_x[i] = m_missile_x[i + 1];
	m_missile_y[i] = m_missile_y[i + 1];
	i++;
    }
}

void GameWidget::deleteAlien(int i)
{
    m_aliens--;
    m_aliens_killed++;
    while (i < m_aliens) {
	m_alien_x[i] = m_alien_x[i + 1];
	m_alien_y[i] = m_alien_y[i + 1];
	m_alien_state[i] = m_alien_state[i + 1];
	m_alien_xhome[i] = m_alien_xhome[i + 1];
	m_alien_yhome[i] = m_alien_yhome[i + 1];
	m_alien_statehome[i] = m_alien_statehome[i + 1];
	i++;
    }
}

void GameWidget::switchState(enum State state)
{
    if (m_state != state) {
	m_state = state;
	m_counter = 0;
    }
}

void GameWidget::drawIntro(void)
{
    QPainter painter_pixmap(m_pixmap);
    QPainter painter_widget(this);
    QColor black(0, 0, 0);
    QColor white(255, 255, 255);
    int max_x = width();
    int max_y = height();

    painter_pixmap.fillRect(0, 0, max_x, max_y, black);
    painter_pixmap.setPen(white);
    painter_pixmap.drawPixmap((width() - m_title.width()) / 2,
	(100 - m_title.height()) / 2, m_title);
    painter_pixmap.drawPixmap(20, 100, m_ship);
    painter_pixmap.drawPixmap(20, 116, m_flame[(m_counter / 15) % 2]);
    drawPixmapText(painter_pixmap, 50, 100, max_x - 20,
	tr("MOVE YOUR SHIP LEFT AND RIGHT USING THE CURSOR KEYS, FIRE USING SPACE"));
    painter_pixmap.drawPixmap(20, 150, m_bug[(m_counter / 10) % 2]);
    if (((m_counter / 20) % 2) == 0) {
	painter_pixmap.drawPixmap(20, 166, m_missile);
    }
    drawPixmapText(painter_pixmap, 50, 150, max_x - 20,
	tr("THESE BUGS WILL SHOOT AT YOU"));
    painter_pixmap.drawPixmap(20, 200, m_bugdir[(m_counter / 10) % 2]);
    drawPixmapText(painter_pixmap, 50, 200, max_x - 20,
	tr("THESE BUGS WILL KILL YOU IF YOU TOUCH THEM"));
    drawPixmapText(painter_pixmap, 50, max_y - 20, max_x - 20,
	tr("PRESS SPACE TO START"));

    painter_pixmap.flush();
    painter_widget.drawPixmap(0, 0, *m_pixmap);
}

void GameWidget::drawPlaying(void)
{
    QPainter painter_pixmap(m_pixmap);
    QPainter painter_widget(this);
    QColor black(0, 0, 0);
    QColor white(255, 255, 255);
    char buffer[80];
    int max_x = width();
    int max_y = height();
    int i;

    painter_pixmap.fillRect(0, 0, max_x, max_y, black);
    painter_pixmap.setPen(white);

    /* draw the stars first, so they are overwritten by all other actors */
    for (i = 0; i < m_stars; i++) {
	int rgb = (m_star_size[i] * 8) + 128;
	painter_pixmap.setPen(QColor(rgb, rgb, rgb));
	painter_pixmap.drawPoint(m_star_x[i], m_star_y[i]);
	painter_pixmap.drawPoint(m_star_x[i], m_star_y[i] + 1);
    }

    /* then, draw all the other actors */
    for (i = 0; i < m_bullets; i++) {
	painter_pixmap.drawPixmap(m_bullet_x[i], m_bullet_y[i], m_bullet);
    }
    for (i = 0; i < m_missiles; i++) {
	painter_pixmap.drawPixmap(m_missile_x[i], m_missile_y[i], m_missile);
    }
    for (i = 0; i < m_aliens; i++) {
	if (m_alien_state[i] < 2) {
	    painter_pixmap.drawPixmap(m_alien_x[i], m_alien_y[i], m_bug[(m_counter / 10) % 2]);
	} else if (m_alien_state[i] < 4) {
	    painter_pixmap.drawPixmap(m_alien_x[i], m_alien_y[i], m_bugdir[m_alien_state[i] % 2]);
	} else {
	    painter_pixmap.drawPixmap(m_alien_x[i], m_alien_y[i],
		m_explosion[((m_alien_state[i] - 4) / 3) % 3]);
	}
    }

    /* draw the player last */
    if (m_state == Dying) {
	if (m_counter < 9) {
	    painter_pixmap.drawPixmap(m_player_x, max_y - 32, m_explosion[(m_counter / 3) % 3]);
	} else if (m_counter >= 18 && (((m_counter - 18) / 2) % 2) && m_lives > 1) {
	    painter_pixmap.drawPixmap(m_player_x, max_y - 32, m_ship);
	}
    } else {
	painter_pixmap.drawPixmap(m_player_x, max_y - 32, m_ship);
	painter_pixmap.drawPixmap(m_player_x, max_y - 16, m_flame[(m_counter / 15) % 2]);
    }

    /* draw some info last */
    if (m_state == LevelCompleted && (m_counter % 4)) {
	snprintf(buffer, sizeof (buffer), tr("LEVEL %d COMPLETED"), m_level);
	drawPixmapText(painter_pixmap, (max_x - strlen(buffer) * 7) / 2, 100, max_x, buffer);
    } else if (m_state == Dying && (m_counter % 4) && m_lives > 1) {
	snprintf(buffer, sizeof (buffer), tr("YOU DIED, %d LIVES LEFT"), m_lives - 1);
	drawPixmapText(painter_pixmap, (max_x - strlen(buffer) * 7) / 2, 100, max_x, buffer);
    }

    painter_pixmap.flush();
    painter_widget.drawPixmap(0, 0, *m_pixmap);
}

void GameWidget::drawGameOver(void)
{
    QPainter painter_pixmap(m_pixmap);
    QPainter painter_widget(this);
    QColor black(0, 0, 0);
    QColor white(255, 255, 255);
    int max_x = width();
    int max_y = height();
    char buffer[80];

    painter_pixmap.fillRect(0, 0, max_x, max_y, black);
    painter_pixmap.setPen(white);
    painter_pixmap.drawPixmap((width() - m_title.width()) / 2,
	(100 - m_title.height()) / 2, m_title);
    painter_pixmap.drawPixmap(20, 100, m_ship);
    painter_pixmap.drawPixmap(20, 116, m_flame[(m_counter / 15) % 2]);
    snprintf(buffer, sizeof (buffer), tr("YOU SCORED %d %s IN %d %s"),
	m_score, m_score != 1 ? tr("POINTS").latin1() : tr("POINT").latin1(),
	m_level, m_level != 1 ? tr("LEVELS").latin1() : tr("LEVEL").latin1());
    drawPixmapText(painter_pixmap, 50, 100, max_x - 20, buffer);
    painter_pixmap.drawPixmap(20, 150, m_bug[(m_counter / 10) % 2]);
    snprintf(buffer, sizeof (buffer), tr("BULLETS FIRED: %d"), m_bullets_fired);
    drawPixmapText(painter_pixmap, 50, 150, max_x - 20, buffer);
    painter_pixmap.drawPixmap(20, 200, m_bugdir[(m_counter / 10) % 2]);
    snprintf(buffer, sizeof (buffer), tr("ALIENS KILLED: %d"), m_aliens_killed);
    drawPixmapText(painter_pixmap, 50, 200, max_x - 20, buffer);
    drawPixmapText(painter_pixmap, 50, max_y - 20, max_x - 20,
	tr("PRESS SPACE TO START"));

    painter_pixmap.flush();
    painter_widget.drawPixmap(0, 0, *m_pixmap);
}

void GameWidget::addScore(int score)
{
    int old_score = m_score;

    m_score = m_score + score;
    if (m_mode == Shooting) {
	if ((m_score % 1000) < (old_score % 1000)) {
	    m_lives++;
	}
    } else {
	if ((m_score % 2000) < (old_score % 2000)) {
	    m_lives++;
	}
    }
}

