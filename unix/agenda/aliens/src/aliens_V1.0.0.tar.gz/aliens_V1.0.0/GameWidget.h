/*
 * Copyright (C) 2002 Robert Ernst <robert.ernst@linux-solutions.at>
 *
 * This file may be distributed and/or modified under the terms of the
 * GNU General Public License version 2 as published by the Free Software
 * Foundation and appearing in the file LICENSE.GPL included in the
 * packaging of this file.
 *
 * This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 * WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See COPYING for GPL licensing information.
 *
 */

#ifndef __GAMEWIDGET_HEADER__
#define __GAMEWIDGET_HEADER__

#include <qwidget.h>
#include <qpixmap.h>
#include <qtimer.h>

class GameWidget : public QWidget
{
    Q_OBJECT

public:
    GameWidget(QWidget *parent, const char *name = 0, WFlags f = 0);
    ~GameWidget();

private:
    static const int max_lives = 6;
    static const int max_bullets = 3;
    static const int max_missiles = 8;
    static const int max_aliens = 30;
    static const int max_stars = 20;

public:
    enum Modes {
	Shooting = 0,
	Marching
    };
    enum State {
	Intro = 0,
	Playing,
	Dying,
	LevelCompleted,
	GameOver
    };
    enum Dir {
	Left = 0,
	Right = 1,
	None = 2
    };
    
private:
    QTimer *m_timer;
    QPixmap *m_pixmap;
    QPixmap m_bug[2];
    QPixmap m_bugdir[2];
    QPixmap m_bullet;
    QPixmap m_explosion[3];
    QPixmap m_flame[2];
    QPixmap m_missile;
    QPixmap m_ship;
    QPixmap m_text;
    QPixmap m_title;
    enum Modes m_mode;
    enum State m_state;
    int m_counter;
    int m_alien_counter;
    enum Dir m_player_dir;
    int m_player_x;
    int m_player_req_x;
    int m_bullets_fired;
    int m_aliens_killed;
    int m_level;
    int m_score;
    int m_lives;
    int m_num_diving;
    int m_bullets;
    int m_bullet_x[max_bullets];
    int m_bullet_y[max_bullets];
    int m_missiles;
    int m_missile_x[max_missiles];
    int m_missile_y[max_missiles];
    int m_aliens;
    int m_alien_x[max_aliens];
    int m_alien_y[max_aliens];
    int m_alien_state[max_aliens];
    int m_alien_xhome[max_aliens];
    int m_alien_yhome[max_aliens];
    int m_alien_statehome[max_aliens];
    int m_stars;
    int m_star_x[max_stars];
    int m_star_y[max_stars];
    int m_star_speed[max_stars];
    int m_star_size[max_stars];
    bool m_mouse_down;
    int m_mouse_counter;

public slots:
    void updateMode(int mode);
    void start(void);
    void stop(void);
    void timerTick(void);

protected:
    void paintEvent(QPaintEvent *event);
    void showEvent(QShowEvent *event);
    void hideEvent(QHideEvent *event);
    void resizeEvent(QResizeEvent *event);
    void keyPressEvent(QKeyEvent *event);
    void keyReleaseEvent(QKeyEvent *event);
    void mousePressEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);

private:
    void drawPixmapText(QPainter &painter, int x, int y, int wrap, const char *str);
    void newLevel(void);
    void updateLevel(void);
    void fireBullet(void);
    void deleteBullet(int i);
    void fireMissile(int i);
    void deleteMissile(int i);
    void deleteAlien(int i);
    void switchState(enum State state);
    void drawIntro(void);
    void drawPlaying(void);
    void drawGameOver(void);
    void addScore(int score);
};

#endif // __GAMEWIDGET_HEADER__

