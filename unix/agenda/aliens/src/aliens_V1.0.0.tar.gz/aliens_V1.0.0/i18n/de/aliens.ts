<!DOCTYPE TS><TS>
<context>
    <name>Aliens</name>
    <message>
        <source>Shooting</source>
        <translation>Traversierend</translation>
    </message>
    <message>
        <source>Marching</source>
        <translation>Marschierend</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Neu</translation>
    </message>
    <message>
        <source>Mode</source>
        <translation>Modus</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Beenden</translation>
    </message>
    <message>
        <source>Game</source>
        <translation>Spiel</translation>
    </message>
</context>
<context>
    <name>GameWidget</name>
    <message>
        <source>MOVE YOUR SHIP LEFT AND RIGHT USING THE CURSOR KEYS, FIRE USING SPACE</source>
        <translation>BEWEGE DAS SCHIFF MIT DEN CURSORTASTEN, SCHIESSE MIT DER LEERTASTE</translation>
    </message>
    <message>
        <source>THESE BUGS WILL SHOOT AT YOU</source>
        <translation>DIESE ALIENS SCHIESSEN AUF DICH</translation>
    </message>
    <message>
        <source>THESE BUGS WILL KILL YOU IF YOU TOUCH THEM</source>
        <translation>DIESE ALIENS RAMMEN DEIN SCHIFF</translation>
    </message>
    <message>
        <source>PRESS SPACE TO START</source>
        <translation>LEERTASTE ZUM STARTEN</translation>
    </message>
    <message>
        <source>LEVEL %d COMPLETED</source>
        <translation>LEVEL %d BEENDET</translation>
    </message>
    <message>
        <source>YOU DIED, %d LIVES LEFT</source>
        <translation>DU HAST NOCH %d LEBEN</translation>
    </message>
    <message>
        <source>BULLETS FIRED: %d</source>
        <translation>KUGELN ABGEFEUERT: %d</translation>
    </message>
    <message>
        <source>ALIENS KILLED: %d</source>
        <translation>ALIENS VERNICHTET: %d</translation>
    </message>
    <message>
        <source>YOU SCORED %d %s IN %d %s</source>
        <translation>DU HAST %d %s IN %d %s ERREICHT</translation>
    </message>
    <message>
        <source>POINTS</source>
        <translation>PUNKTE</translation>
    </message>
    <message>
        <source>POINT</source>
        <translation>PUNKT</translation>
    </message>
    <message>
        <source>LEVELS</source>
        <translation>LEVELS</translation>
    </message>
    <message>
        <source>LEVEL</source>
        <translation>LEVEL</translation>
    </message>
</context>
</TS>
