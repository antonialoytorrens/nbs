/*
  ximp.c

  XIMP: XPM Icon Manipulation Program

  by Bill Kendrick
  bill@newbreedsoftware.com
  http://www.newbreedsoftware.com/

  October 19, 2001 - October 19, 2001
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/xpm.h>
#include <X11/keysym.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <unistd.h>

#include "images/eraser.xpm"
#include "images/fill.xpm"
#include "images/hflip.xpm"
#include "images/invert.xpm"
#include "images/line.xpm"
#include "images/pencil.xpm"
#include "images/rotate.xpm"
#include "images/select.xpm"
#include "images/vflip.xpm"
#include "images/wilbur.xpm"


#define WIN_WIDTH 160
#define WIN_HEIGHT 185


/* Globals: */

Display *display;
Window window;
GC whitegc, blackgc, pastegc, palette_gcs[16];
Pixmap pix_eraser, pix_fill, pix_hflip, pix_invert, pix_line, pix_pencil,
  pix_rotate, pix_select, pix_vflip, pix_wilbur;
unsigned char img[30][30];


/* Local function prototypes: */

void setup(void);
GC CreateGC(Display *display, Drawable drawable, unsigned long forecolor,
            unsigned long backcolor);
void LoadImage(char ** xpm, Pixmap * pix);
void DrawImage(Pixmap pix, Drawable dest, int x, int y, int w, int h);


/* --- MAIN --- */

int main(int argc, char * argv[])
{
  setup();
 
  DrawImage(pix_wilbur, window, WIN_WIDTH - 33, WIN_HEIGHT - 33, 33, 33);
  XFlush(display);
  sleep(3);
  
  return 0;
}


/* Setup: */

void setup(void)
{
  Window rootwindow;
  int screen, black, white;
  XSetWindowAttributes attr;
  XWMHints wmhints;
  char wname[64];
  unsigned long attr_mask;


  /* Connect to X server: */
  
  display = XOpenDisplay(NULL);
  if (display == NULL)
    {
      fprintf(stderr, "Can't connect to display!\n");
      exit(1);
    }
  
  screen = DefaultScreen(display);
  rootwindow = RootWindow(display, screen);
  
  
  /* Get primitive colors: */
  
  black = BlackPixel(display, screen);
  white = WhitePixel(display, screen);
  
  
  /* Open window: */
  
  attr.event_mask = (KeyPressMask | KeyReleaseMask | ButtonPressMask |
		     ButtonReleaseMask | PointerMotionMask |
		     ExposureMask | VisibilityChangeMask);
  
  attr.border_pixel = black;
  attr.background_pixel = white;
  attr_mask = CWEventMask | CWBackPixel | CWBorderPixel;
  
  window = XCreateWindow(display, rootwindow, 0, 0, WIN_WIDTH, WIN_HEIGHT, 0,
			 DefaultDepthOfScreen(DefaultScreenOfDisplay(display)),
			 InputOutput, DefaultVisual(display, screen),
			 attr_mask, &attr);
  
  
  /* Set input hints and window name (so we appear in the window lists).
     Need to do this because of a bug in VRSM.  Not bad to do anyway, tho */
  
  wmhints.input = True;
  wmhints.flags |= InputHint;
  XSetWMHints(display, window, &wmhints);
  
  sprintf(wname, "The Ximp");
  XChangeProperty(display, window, XA_WM_NAME, XA_STRING, 8,
		  PropModeReplace, wname, strlen(wname));
  
  
  blackgc = CreateGC(display, window, black, black);
  whitegc = CreateGC(display, window, white, black);
  pastegc = CreateGC(display, window, black, black);
  
  
  /* Create images: */
  
  LoadImage(eraser_xpm, &pix_eraser);
  LoadImage(fill_xpm, &pix_fill);
  LoadImage(hflip_xpm, &pix_hflip);
  LoadImage(invert_xpm, &pix_invert);
  LoadImage(line_xpm, &pix_line);
  LoadImage(pencil_xpm, &pix_pencil);
  LoadImage(rotate_xpm, &pix_rotate);
  LoadImage(select_xpm, &pix_select);
  LoadImage(vflip_xpm, &pix_vflip);
  LoadImage(wilbur_xpm, &pix_wilbur);
  
  
  /* Bring window up! */
  
  XMapWindow(display, window);
  XMapRaised(display, window);
  XSync(display, 0);
}


/* Create a graphics context: */

GC CreateGC(Display *display, Drawable drawable, unsigned long forecolor,
            unsigned long backcolor)
{
  XGCValues xgcvalues;
  GC gc;
  
  xgcvalues.foreground = forecolor;
  xgcvalues.background = backcolor;
  gc = XCreateGC(display,drawable,(GCForeground | GCBackground),
                 &xgcvalues);
  
  return(gc);
}


/* Convert an image from XPM data to a pixmap: */

void LoadImage(char ** xpm, Pixmap * pix)
{
  XpmCreatePixmapFromData(display, window, xpm, pix, NULL, NULL);
}


/* Paste a pixmap onto the screen: */

void DrawImage(Pixmap pix, Drawable dest, int x, int y, int w, int h)
{
  XSetClipOrigin(display, pastegc, x, y);
  
  XCopyArea(display, pix, dest, pastegc, 0, 0, w, h, x, y);
}
