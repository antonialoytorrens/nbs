#include <stdio.h>
#include <stdlib.h>
#include "SDL.h"
#include "SDL_image.h"

/* Func. prototype: */
SDL_Surface * myLoadImage(char * fname, int trans);


/* Main: */
int main(int argc, char * argv[])
{
  SDL_Surface * screen, * tile, * sprite;
  int x, y, done;
  Uint8 r, g, b;
  int bx, by, bxm, bym;
  Uint32 cur_time;
  SDL_Event event;
  SDL_Rect dest;

  if (SDL_Init(SDL_INIT_VIDEO) < 0)
  {
    fprintf(stderr, "Can't init SDL: %s\n", SDL_GetError());
    exit(1);
  }

  screen = SDL_SetVideoMode(320, 240, 0 /* current display's bpp */, SDL_SWSURFACE);
  if (screen == NULL)
  {
    fprintf(stderr, "Can't open display: %s\n", SDL_GetError());
    SDL_Quit();
    exit(1);
  }

  /* Background bitmap: */
  tile = myLoadImage("tile.png", 0 /* no transparency */);
  if (tile == NULL)
  {
    SDL_Quit();
    exit(1);
  }

  /* Sprite bitmap: */
  sprite = myLoadImage("sprite.png", 1 /* want transparency */);
  if (sprite == NULL)
  {
    SDL_FreeSurface(tile);
    SDL_Quit();
    exit(1);
  }

  x = 0;
  y = 0;

  bx = (screen->w - sprite->w) / 2;
  by = 0;
  bxm = 2;
  bym = 0;

  r = g = b = 0;

  done = 0;

  do
  {
    cur_time = SDL_GetTicks();

    while (SDL_PollEvent(&event) > 0)
    {
      if (event.type == SDL_QUIT)
        done = 1;
      else if (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_ESCAPE)
        done = 1;
    }

    bx += bxm;
    by += bym;
    bym++;

    if (bx < 0)
    {
      bx = 0;
      bxm = 2;
    }
    if (bx >= screen->w - sprite->w)
    {
      bx = screen->w - sprite->w - 1;
      bxm = -2;
    }
    if (by < 0)
    {
      by = 0;
      bym = 0;
    }
    if (by >= screen->h - sprite->h)
    {
      by = screen->h - sprite->h - 1;
      bym = -bym;
    }

    r = (r + 1) % 256;
    g = (g + 2) % 256;
    b = (b + 4) % 256;
    SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, r, g, b));

    for (y = 0; y < screen->h; y = y + tile->h + 2)
    {
      for (x = 0; x < screen->w; x = x + tile->w + 2)
      {
        dest.x = x;
        dest.y = y;
        SDL_BlitSurface(tile, NULL, screen, &dest);
      }
    }

    dest.x = bx;
    dest.y = by;
    SDL_BlitSurface(sprite, NULL, screen, &dest);

    SDL_Flip(screen);

    if (SDL_GetTicks() < cur_time + (1000 / 30) /* capping at 30 FPS */)
      SDL_Delay(cur_time + (1000 / 30) - SDL_GetTicks());
  }
  while (!done);

  return(0);
}


SDL_Surface * myLoadImage(char * fname, int trans)
{
  SDL_Surface * tmp, * ret;
  int err;

  tmp = IMG_Load(fname);
  if (tmp == NULL)
  {
    fprintf(stderr, "Can't load %s: %s\n", fname, SDL_GetError());
    return NULL;
  }

  ret = SDL_DisplayFormat(tmp);
  SDL_FreeSurface(tmp);
  if (ret == NULL)
  {
    fprintf(stderr, "Can't convert %s: %s\n", fname, SDL_GetError());
    return NULL;
  }

  if (trans)
  {
    err = SDL_SetColorKey(ret, SDL_SRCCOLORKEY, SDL_MapRGB(ret->format, 0xff, 0xff, 0xff /* white */));
    if (err == -1)
    {
      fprintf(stderr, "Can't apply color key to %s: %s\n", fname, SDL_GetError());
      SDL_FreeSurface(ret);
      return NULL;
    }
  }

  return ret;
}

