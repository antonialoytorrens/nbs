README.txt for hiworld, "Hello world" in C, for Atari 8-bit
Bill Kendrick <bill@newbreedsoftware.com>
August 2013 - January 2014

= About =
A hello world for Atari 8-bits, written in C, cross-compiled with cc65, and
assembled into a bootable disk image with Franny.

= Files =
 * hiworld.c
   Source code

 * Makefile
   Makefile, with targets:
    - all: hiworld.atr
    - clean
    - hiworld.xex: Executable
    - hiworld.atr: Bootable disk image, with executable auto-loaded
    - run-exe: Launches the executable in Atari800 emulator (via -run option)
    - run-atr: Boots Atari800 emulator into the disk image

 * sd_mydos.xxd
   The first 3 sectors of a single density bootable disk with MyDOS 4.53/3

 * dos.sys, dup.sys
   The binary MyDOS 4.53/3 DOS and DUP files


= Requirements =
 * cc65 C cross compiler for 6502-based targets:
   http://oliverschmidt.github.io/cc65/
   (Old site, prior to March 2013, was http://www.cc65.org/ )
   (Probably available in your distro)

 * Franny Atari disk image manipulator
   http://atari8.sourceforge.net/franny.html
   Part of "atari8" project at SourceForge: http://atari8.sourceforge.net/
   Files here: http://sourceforge.net/projects/atari8/files/

 * xxd
   http://linuxcommand.org/man_pages/xxd1.html
   (Just the manpage; probably available in your distro)

= Optional Requirements =
 * Atari800 Atari emulator
   http://atari800.sourceforge.net/
   (Probably available in your distro)

= Other Sources =
 * MyDOS, which can be found at various places, e.g.
   http://www.mathyvannisselroy.nl/mydos.htm
   http://www.umich.edu/~archive/atari/8bit/Dos/Mydos/ (and mirrors)

 * "Mapping the Atari" Memory Map
   http://www.atariarchives.org/mapping/memorymap.php

 * Atari specific information for cc65
   http://www.cc65.org/doc/atari.html

