/* hiworld.c */

#include <atari.h>
#include <stdio.h>
#include <unistd.h>

#define COLOR1 *(unsigned char *) 709
#define RTCLOK_lo *(unsigned char *) 20

/* http://www.atariarchives.org/dere/chapt07.php */

unsigned char AUDCTL;

void SOUND_INIT(void) {
  AUDCTL = 0;
  POKEY_WRITE.audctl = 0;
  POKEY_WRITE.skctl = 3;
  POKEY_WRITE.audc1 = 0;
  POKEY_WRITE.audc2 = 0;
  POKEY_WRITE.audc3 = 0;
  POKEY_WRITE.audc4 = 0;
}

void SOUND(unsigned char chan, unsigned char pitch,
           unsigned char distortion, unsigned char volume) {
  unsigned char audc;

  audc = ((distortion & 14) << 4) | (volume & 15);

  switch (chan) {
    case 0:
      AUDCTL = AUDCTL & 0xAF; /* disable bits 4 & 6 */
      POKEY_WRITE.audc1 = audc;
      POKEY_WRITE.audf1 = pitch;
      break;
    case 1:
      AUDCTL = AUDCTL & 0xAF; /* disable bits 4 & 6 */
      POKEY_WRITE.audc2 = audc;
      POKEY_WRITE.audf2 = pitch;
      break;
    case 2:
      AUDCTL = AUDCTL & 0xD7; /* disable bits 3 & 5 */
      POKEY_WRITE.audc3 = audc;
      POKEY_WRITE.audf3 = pitch;
      break;
    case 3:
      AUDCTL = AUDCTL & 0xD7; /* disable bist 3 & 5 */
      POKEY_WRITE.audc4 = audc;
      POKEY_WRITE.audf4 = pitch;
      break;
    default:
      break;
  }
  POKEY_WRITE.audctl = AUDCTL;
}

void DSOUND(unsigned char chan, unsigned int pitch,
           unsigned char distortion, unsigned char volume) {
  unsigned char audca, audcb;

  audca = ((distortion & 14) << 4);
  audcb = audca | (volume & 15);

  switch (chan) {
    case 0:
      AUDCTL = AUDCTL | 0x50; /* enable bits 4 & 6 */
      POKEY_WRITE.audc1 = audca;
      POKEY_WRITE.audc2 = audcb;
      POKEY_WRITE.audf1 = pitch & 0xFF;
      POKEY_WRITE.audf2 = pitch >> 8;
      break;
    case 1:
      AUDCTL = AUDCTL | 0x28; /* enable bit 3 & 5 */
      POKEY_WRITE.audc3 = audca;
      POKEY_WRITE.audc4 = audcb;
      POKEY_WRITE.audf3 = pitch & 0xFF;
      POKEY_WRITE.audf4 = pitch >> 8;
      break;
    default:
      break;
  }
  POKEY_WRITE.audctl = AUDCTL;
}

int main(void) {
  unsigned int i;

  SOUND_INIT();
  sleep(1);

  COLOR1 = 0;
  for (i = 0; i < 10; i++)
    printf("Hello, world. ");

  SOUND(2, 100, 12, 4);

  for (i = 0; i < 65000; i = i + 256) {
    printf("%5u ", i);
    DSOUND(0, i, 10, 10);
  }

  for (i = 0; i < 31; i++) {
    COLOR1 = i << 1;
    RTCLOK_lo = 0; do {} while (RTCLOK_lo < 10);
    printf(".");
    SOUND(0, (i + 1) << 3, 10, 15);
    SOUND(1, i << 3, 10, 4);
  }

  POKEY_WRITE.audc1 = 0; 
  POKEY_WRITE.audc2 = 0; 

  return(0);
}
